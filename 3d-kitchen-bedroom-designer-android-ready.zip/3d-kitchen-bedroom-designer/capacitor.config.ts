import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.mumayaz.kitchendesigner',
  appName: 'مصمم المطابخ وغرف النوم 3D',
  webDir: 'dist',
  bundledWebRuntime: false,
  server: {
    // Set this only when testing against a remotely hosted frontend.
    // For production, bundle the web build and configure the API base URL separately.
    androidScheme: 'https',
  },
};

export default config;
