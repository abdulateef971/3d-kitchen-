import React, { useState } from 'react';
import { Project, ProjectType } from './types';
import { projectRepository } from './domain/storage/projectRepository';
import { SplashScreen } from './ui/components/SplashScreen';
import { HomeScreen } from './ui/home/HomeScreen';
import { ProjectsScreen } from './ui/projects/ProjectsScreen';
import { DesignerScreen } from './ui/designer/DesignerScreen';
import { AnimatePresence } from 'motion/react';

type ScreenState = 'home' | 'projects' | 'designer';

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [currentScreen, setCurrentScreen] = useState<ScreenState>('home');
  const [activeProject, setActiveProject] = useState<Project | null>(null);

  const handleOpenProject = (project: Project) => {
    setActiveProject(project);
    setCurrentScreen('designer');
  };

  const handleCreateNewProject = (type: ProjectType, customName?: string) => {
    const newProject = projectRepository.createNewProject(type, customName);
    setActiveProject(newProject);
    setCurrentScreen('designer');
  };

  return (
    <div className="w-full min-h-screen bg-[#0F0F0F] text-[#E5E5E5] font-['Cairo'] antialiased">
      <AnimatePresence>
        {showSplash && <SplashScreen onComplete={() => setShowSplash(false)} />}
      </AnimatePresence>

      {!showSplash && (
        <>
          {currentScreen === 'home' && (
            <HomeScreen
              onOpenProject={handleOpenProject}
              onOpenProjectsList={() => setCurrentScreen('projects')}
              onCreateNewProject={handleCreateNewProject}
            />
          )}

          {currentScreen === 'projects' && (
            <ProjectsScreen
              onOpenProject={handleOpenProject}
              onCreateNewProject={handleCreateNewProject}
              onBackToHome={() => setCurrentScreen('home')}
            />
          )}

          {currentScreen === 'designer' && activeProject && (
            <DesignerScreen
              key={activeProject.projectId}
              initialProject={activeProject}
              onBackToDashboard={() => setCurrentScreen('home')}
              onSwitchProject={handleOpenProject}
              onOpenProjectsList={() => setCurrentScreen('projects')}
              onCreateNewProject={handleCreateNewProject}
            />
          )}
        </>
      )}
    </div>
  );
}
