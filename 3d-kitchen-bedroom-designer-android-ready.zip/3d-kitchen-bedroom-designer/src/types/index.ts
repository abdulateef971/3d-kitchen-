/**
 * 3D Kitchen & Bedroom Designer - Core Type Definitions
 * Clean Architecture Domain Models
 */

export type ProjectType = 'kitchen' | 'bedroom' | 'wardrobe';

export type MeasurementUnit = 'mm' | 'cm';

export type ShadingMode = 'realistic' | 'solid' | 'wireframe';

export type CameraPreset = 'perspective' | 'top' | 'front' | 'side' | 'isometric' | 'eye_level';

export type MaterialCategory = 
  | 'wood' 
  | 'mdf' 
  | 'acrylic' 
  | 'hpl' 
  | 'glass' 
  | 'marble' 
  | 'metal'
  | 'paint'
  | 'ceramic_floor'
  | 'ceramic_wall';

export interface MaterialDefinition {
  id: string;
  name: string;
  nameAr: string;
  category: MaterialCategory;
  color: string;
  roughness: number;
  metalness: number;
  transmission?: number; // for glass
  opacity?: number;
  textureUrl?: string;
  costPerSqMeter: number; // Cost in currency
}

export type HandleStyle = 'bar_modern' | 't_bar' | 'edge_pull' | 'knob_round' | 'knob_square' | 'handleless' | 'classic_cup';

export type DoorProfileStyle = 
  | 'slab'          // Modern flat panel
  | 'shaker'        // Classic recessed frame
  | 'glass_frame'   // Aluminum/Wood frame with glass panel & LED
  | 'fluted'        // Vertical ribbed wooden slats (مضلع مودرن)
  | 'j_pull'        // Integrated J-handle groove (جي بول خفي)
  | 'raised_panel'  // Traditional raised cushion panel (كلاسيك بارز)
  | 'louver';       // Slatted ventilation wood slats (شتر شرائح)

export type GlassType = 'clear' | 'smoked' | 'fluted' | 'frosted';

export type ApplianceType = 
  | 'sink'                 // Single undermount sink + faucet
  | 'sink_double'          // Double bowl sink + luxury pull-down faucet
  | 'sink_granite'         // Luxury black quartz granite composite sink
  | 'sink_workstation'     // Multi-tier workstation sink with cutting board & colander
  | 'sink_farmhouse'       // Apron-front farmhouse ceramic sink
  | 'wire_basket_spice'    // Pull-out chrome wire spice & oil bottle basket
  | 'wire_basket_dishes'   // Pull-out chrome wire dish & plate organizer basket
  | 'corner_carousel'      // 360-degree rotating Lazy Susan corner carousel
  | 'corner_magic'         // Magic corner hydraulic pull-out basket system
  | 'corner_lemans'        // LeMans ergonomic curved pull-out trays
  | 'dressing_mirror'      // Vanity dressing table lighted mirror & jewelry organiser
  | 'nightstand_lamp'      // Bedside nightstand with ambient reading lamp
  | 'bed_headboard'        // Upholstered bed headboard with integrated floating nightstands
  | 'oven'                 // Built-in oven
  | 'microwave'            // Built-in microwave
  | 'cooktop'              // Cooktop general
  | 'cooktop_gas'          // 4/5 burner gas stove with cast iron grates
  | 'cooktop_induction'    // Flat ceramic induction cooktop with red LED coils
  | 'combo_cooking_station_900' // Cooking Station 900mm: 2x 15cm Oil Racks + 60cm Oven with Top Drawer + Gas Cooktop
  | 'combo_cooking_station_1000' // Cooking Station 1000mm: 2x 20cm Oil Racks + 60cm Oven with Top Drawer + Gas Cooktop
  | 'combo_oven_cooktop_drawers' // 60cm Base with Oven + Top Drawer + Countertop Gas Cooktop
  | 'combo_microwave_oven' // Microwave + Oven built-in column
  | 'range_stove'          // Large freestanding oven & range cooker
  | 'hood'                 // Cooker hood general
  | 'hood_pyramid'         // Stainless steel pyramid cooker hood
  | 'hood_box'             // Modern box T-shape glass cooker hood
  | 'refrigerator'         // Tall single door fridge
  | 'refrigerator_french'  // Side-by-side French door fridge with dispenser
  | 'refrigerator_side_by_side' // Side by Side American fridge
  | 'refrigerator_builtin' // Fully integrated tall cabinet refrigerator
  | 'refrigerator_under'   // Under-counter beverage mini-fridge
  | 'dishwasher'           // Integrated dishwasher
  | 'clothes_rod'          // Wardrobe hanging rail
  | 'none';

export interface HandleConfig {
  id: string;
  name: string;
  nameAr: string;
  style: HandleStyle;
  length: number; // in mm
  thickness: number; // in mm
  color: string;
  material: string;
  position: 'vertical' | 'horizontal' | 'centered';
  offsetFromEdge: number; // mm
}

export type HingeSide = 'left' | 'right' | 'double' | 'top_lift' | 'lift_up' | 'sliding' | 'none';

export interface DoorConfig {
  doorId: string;
  width: number;
  height: number;
  thickness: number; // default 18mm
  hingeSide: HingeSide;
  openAngle: number; // 0 to 90 or 110 degrees
  targetAngle: number; // For animation interpolation
  openSpeed: number; // seconds
  materialId: string;
  color: string;
  doorStyle?: DoorProfileStyle;
  hasGlassPanel?: boolean;
  glassType?: GlassType;
  hasFrame?: boolean;
  frameWidth?: number;
  internalLed?: boolean;
  handleConfig?: HandleConfig;
}

export interface DrawerConfig {
  drawerId: string;
  index: number;
  width: number;
  height: number;
  depth: number;
  thickness: number;
  openAmount: number; // 0.0 to 1.0 (0% to 100%)
  targetAmount: number; // For animation
  openSpeed: number;
  materialId: string;
  color: string;
  doorStyle?: DoorProfileStyle;
  handleConfig?: HandleConfig;
}

export interface ShelfConfig {
  count: number;
  thickness: number;
  spacing: 'equal' | 'custom';
  customOffsets?: number[]; // mm from bottom
  isGlass?: boolean;
}

export interface CountertopConfig {
  enabled: boolean;
  thickness: number; // default 30mm or 40mm
  overhangFront: number; // default 20mm
  overhangBack: number; // default 0mm
  overhangLeft: number; // default 0mm
  overhangRight: number; // default 0mm
  materialId: string;
  color: string;
  edgeProfile?: 'straight' | 'bevel' | 'bullnose';
  hasBacksplash: boolean;
  backsplashHeight: number; // mm
  waterfallLeft?: boolean;  // Marble extends to floor on left
  waterfallRight?: boolean; // Marble extends to floor on right
}

export type CabinetCategory = 
  | 'kitchen_base' 
  | 'kitchen_wall' 
  | 'kitchen_tall' 
  | 'kitchen_corner'
  | 'kitchen_island'
  | 'kitchen_appliance'
  | 'bedroom_wardrobe'
  | 'bedroom_drawer'
  | 'bedroom_nightstand'
  | 'bedroom_dressing'
  | 'bedroom_bed'
  | 'bedroom_shelves';

export interface DimensionLimits {
  minWidth: number;
  maxWidth: number;
  minHeight: number;
  maxHeight: number;
  minDepth: number;
  maxDepth: number;
}

export interface ParametricCabinet {
  id: string;
  templateId?: string;
  name: string;
  nameAr: string;
  category: CabinetCategory;
  subCategory?: string;
  
  // Dimensions in Millimeters (mm)
  width: number;
  height: number;
  depth: number;
  limits: DimensionLimits;
  
  // Construction Specifications
  bodyThickness: number; // e.g. 18mm
  backThickness: number; // e.g. 8mm or 18mm
  legsHeight: number; // e.g. 100mm plinth/legs (0 for wall units)
  hasPlinthKick: boolean;
  
  // Transform in 3D scene (Position in mm, Rotation in degrees)
  positionX: number;
  positionY: number; // height from floor
  positionZ: number;
  rotationY: number; // 0, 90, 180, 270 degrees
  
  // Components
  doorCount: number;
  doors: DoorConfig[];
  drawerCount: number;
  drawers: DrawerConfig[];
  shelves: ShelfConfig;
  countertop?: CountertopConfig;
  
  // Materials & Finish
  bodyMaterialId: string;
  bodyColor: string;
  frontMaterialId: string;
  frontColor: string;
  doorStyle?: DoorProfileStyle;
  handleConfig: HandleConfig;
  
  // Appliance / Accessory integration
  accessoryType?: ApplianceType;
  secondaryAccessoryType?: ApplianceType;
  accessories?: ApplianceType[];
  applianceColor?: string;
  applianceFinish?: 'nano_black' | 'stainless_silver' | 'gold_brass' | 'matte_white' | 'dark_anthracite';
  
  // State
  isSelected?: boolean;
  isHovered?: boolean;
}

export interface WallOpening {
  id: string;
  type: 'door' | 'window';
  wallIndex: number; // 0=North/Back, 1=East/Right, 2=South/Front, 3=West/Left
  distanceFromStart: number; // mm from wall left
  width: number; // mm
  height: number; // mm
  sillHeight: number; // mm from floor
  name?: string;
  doorStyle?: 'wood_classic' | 'glass_sliding' | 'aluminum_modern';
  windowStyle?: 'single' | 'panoramic' | 'kitchen';
  wall?: string; // legacy compatibility
  position?: number; // legacy compatibility
}

export interface CustomWall {
  id: string;
  name?: string;
  nameAr?: string;
  startX: number; // mm
  startZ: number; // mm
  length: number; // mm
  rotationY: number; // degrees
  endX?: number;   // mm
  endZ?: number;   // mm
  thickness: number; // mm (e.g. 120 or 150)
  height: number;    // mm (e.g. 2800)
  color: string;
  materialId?: string;
  isPartition?: boolean;
  openings?: WallOpening[];
}

export interface RoomConfig {
  width: number; // X axis mm (e.g. 4000)
  length: number; // Z axis mm (e.g. 5000)
  height: number; // Y axis mm (e.g. 2800)
  wallColor: string;
  wallMaterialId?: string;
  floorMaterialId: string;
  floorColor: string;
  ceilingColor: string;
  showCeiling: boolean;
  showNorthWall: boolean;
  showSouthWall: boolean;
  showEastWall: boolean;
  showWestWall: boolean;
  openings: WallOpening[];
  customWalls?: CustomWall[];
  environment?: 'forest' | 'garden' | 'studio' | 'none';
}

export interface LightingConfig {
  presetMode?: 'day' | 'golden_hour' | 'evening' | 'night' | 'studio';
  ambientEnabled: boolean;
  ambientIntensity: number; // 0.0 to 1.0
  ambientColor: string;
  sunIntensity: number; // 0.0 to 2.0
  sunColor?: string;
  ceilingSpotlights: boolean;
  ceilingSpotlightColor: string;
  ceilingIntensity: number;
  cabinetInteriorLed: boolean;
  cabinetInteriorLedColor: string;
  cabinetInteriorIntensity: number;
  underCabinetLed: boolean;
  underCabinetLedColor: string;
  underCabinetIntensity: number;
  shadowsEnabled: boolean;
}

export interface PricingRules {
  carcaseRatePerSqM: number; // $ or local currency per sq.m of MDF body
  doorRatePerSqM: number;    // $ per sq.m of front panels
  drawerBoxRatePerSqM: number; // $ per sq.m of drawer boxes
  hingePairRate: number;      // $ per soft-close hinge
  drawerSlidePairRate: number;// $ per tandem slide pair
  handleRate: number;         // $ per handle
  countertopRatePerSqM: number; // $ per sq.m of stone/quartz
  edgeBandingRatePerMeter: number; // $ per meter of PVC edging
  laborRatePercentage: number; // % of materials cost (e.g. 35%)
  profitMarginPercentage: number; // % margin (e.g. 20%)
  currency: string;
}

export interface CameraState {
  preset: CameraPreset;
  distance: number;
  target: [number, number, number];
  position: [number, number, number];
}

export interface AnimationKeyframe {
  id: string;
  time: number; // seconds in timeline
  cameraPosition: [number, number, number];
  cameraTarget: [number, number, number];
  unitDoorActions?: { unitId: string; doorIndex: number; targetAngle: number }[];
  unitDrawerActions?: { unitId: string; drawerIndex: number; targetAmount: number }[];
}

export interface TimelineSequence {
  duration: number; // total duration in seconds
  keyframes: AnimationKeyframe[];
  isPlaying: boolean;
  currentTime: number;
}

export interface CostBreakdown {
  materialCost: number;
  hardwareCost: number; // hinges, slides, handles
  doorsCost: number;
  drawersCost: number;
  countertopCost: number;
  laborCost: number;
  totalCost: number;
  currency: string;
  sheetsCount: number; // estimated 2440x1220mm MDF sheets
}

export interface CutListPiece {
  id: string;
  unitName: string;
  partName: string;
  partNameAr: string;
  length: number; // mm
  width: number; // mm
  thickness: number; // mm
  quantity: number;
  material: string;
  edgeBanding: string; // e.g. "2L + 2W"
}

export interface SnapSettings {
  enabled: boolean;
  gridSize: number; // mm (e.g. 50 or 100)
  snapToWall: boolean;
  snapToFloor: boolean;
  snapToCabinet: boolean;
  snapDistance: number; // mm tolerance (e.g. 30mm)
}

export interface Project {
  projectId: string;
  name: string;
  type: ProjectType;
  room: RoomConfig;
  units: ParametricCabinet[];
  lighting: LightingConfig;
  camera: CameraState;
  unitOfMeasure: MeasurementUnit;
  createdAt: string;
  updatedAt: string;
  thumbnail?: string;
  notes?: string;
}

export interface CatalogItemTemplate {
  templateId: string;
  name: string;
  nameAr: string;
  category: CabinetCategory;
  subCategory: string;
  defaultWidth: number;
  defaultHeight: number;
  defaultDepth: number;
  limits: DimensionLimits;
  defaultDoors: number;
  defaultHingeSide: HingeSide;
  defaultDrawers: number;
  defaultShelves: number;
  defaultLegsHeight: number;
  accessoryType?: ApplianceType;
  doorStyle?: DoorProfileStyle;
  descriptionAr: string;
  badge?: string;
}
