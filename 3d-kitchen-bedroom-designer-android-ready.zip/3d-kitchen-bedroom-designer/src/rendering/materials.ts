import * as THREE from 'three';
import { MaterialDefinition, ShadingMode } from '../types';
import { getMaterialById } from '../domain/materials/materialsCatalog';

// Cache for Three.js materials
const materialCache = new Map<string, THREE.Material>();

// Helper to create procedural wood, marble, fluted slats, tiles, or wall paint texture
function createProceduralTexture(
  type: 'wood' | 'marble' | 'fluted' | 'tile' | 'hatch' | 'brushed_metal' | 'ceramic_floor' | 'ceramic_wall' | 'paint',
  baseColor: string,
  variant?: string
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d');

  if (ctx) {
    ctx.fillStyle = baseColor;
    ctx.fillRect(0, 0, 512, 512);

    if (type === 'wood') {
      // Fine wood grain layers
      ctx.fillStyle = 'rgba(0, 0, 0, 0.04)';
      for (let i = 0; i < 512; i += 3) {
        ctx.fillRect(0, i, 512, 1.2);
      }
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
      for (let i = 0; i < 18; i++) {
        ctx.beginPath();
        const y = Math.random() * 512;
        ctx.ellipse(256, y, 220 + Math.random() * 60, 24 + Math.random() * 12, 0, 0, Math.PI * 2);
        ctx.stroke();
      }
    } else if (type === 'fluted') {
      // 3D Fluted slats vertical ribs
      const slatWidth = 16;
      for (let x = 0; x < 512; x += slatWidth) {
        // Shadow groove
        ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
        ctx.fillRect(x, 0, 3, 512);
        // Highlight crest
        ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
        ctx.fillRect(x + 3, 0, slatWidth - 6, 512);
      }
    } else if (type === 'marble') {
      // Luxury Calacatta / Marquina vein branches
      const isDark = baseColor.startsWith('#1') || baseColor.startsWith('#0') || baseColor.startsWith('#2');
      const veinColor = isDark ? 'rgba(255, 255, 255, 0.22)' : 'rgba(120, 110, 100, 0.18)';
      const goldVein = 'rgba(202, 138, 4, 0.12)';

      ctx.lineWidth = 3;
      for (let i = 0; i < 7; i++) {
        ctx.strokeStyle = i % 2 === 0 ? veinColor : goldVein;
        ctx.beginPath();
        let currX = Math.random() * 512;
        ctx.moveTo(currX, 0);
        for (let y = 100; y <= 512; y += 100) {
          const nextX = currX + (Math.random() - 0.5) * 160;
          ctx.quadraticCurveTo(currX + (Math.random() - 0.5) * 80, y - 50, nextX, y);
          currX = nextX;
        }
        ctx.stroke();
      }
    } else if (type === 'brushed_metal') {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.06)';
      for (let i = 0; i < 512; i += 2) {
        ctx.fillRect(0, i, 512, 1);
      }
    } else if (type === 'ceramic_floor' || type === 'tile') {
      // High-end porcelain / ceramic floor tile with realistic grout joints
      const tileSize = 256;
      ctx.strokeStyle = 'rgba(0, 0, 0, 0.18)';
      ctx.lineWidth = 3;

      for (let x = 0; x <= 512; x += tileSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, 512);
        ctx.stroke();
      }
      for (let y = 0; y <= 512; y += tileSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(512, y);
        ctx.stroke();
      }

      // Soft bevel edge highlight
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.18)';
      ctx.lineWidth = 1.5;
      for (let x = 0; x < 512; x += tileSize) {
        ctx.strokeRect(x + 2, 2, tileSize - 4, 508);
      }

      // Subtle marble vein or terrazzo specks in tiles
      if (variant?.includes('statuary') || variant?.includes('calacatta') || baseColor.startsWith('#f')) {
        ctx.strokeStyle = 'rgba(100, 116, 139, 0.12)';
        ctx.lineWidth = 2;
        for (let i = 0; i < 4; i++) {
          ctx.beginPath();
          ctx.moveTo(Math.random() * 512, 0);
          ctx.bezierCurveTo(200, 150, 320, 350, Math.random() * 512, 512);
          ctx.stroke();
        }
      }
    } else if (type === 'ceramic_wall') {
      // Subway running bond brick ceramic tiles
      const rowHeight = 64;
      const colWidth = 128;
      ctx.strokeStyle = 'rgba(0, 0, 0, 0.2)';
      ctx.lineWidth = 2.5;

      let rowIdx = 0;
      for (let y = 0; y <= 512; y += rowHeight) {
        // Horizontal grout line
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(512, y);
        ctx.stroke();

        // Staggered vertical grout lines
        const xOffset = (rowIdx % 2) * (colWidth / 2);
        for (let x = -colWidth; x <= 512 + colWidth; x += colWidth) {
          const posX = x + xOffset;
          if (posX >= 0 && posX <= 512) {
            ctx.beginPath();
            ctx.moveTo(posX, y);
            ctx.lineTo(posX, y + rowHeight);
            ctx.stroke();

            // Subtle gloss glaze highlight on top edge of each tile
            ctx.fillStyle = 'rgba(255, 255, 255, 0.12)';
            ctx.fillRect(posX + 3, y + 3, colWidth - 6, 4);
          }
        }
        rowIdx++;
      }
    } else if (type === 'paint') {
      // Velvet matte wall paint with subtle micro-grain texture
      ctx.fillStyle = 'rgba(0, 0, 0, 0.025)';
      for (let i = 0; i < 3500; i++) {
        const px = Math.random() * 512;
        const py = Math.random() * 512;
        ctx.fillRect(px, py, 1.5, 1.5);
      }
      ctx.fillStyle = 'rgba(255, 255, 255, 0.035)';
      for (let i = 0; i < 3500; i++) {
        const px = Math.random() * 512;
        const py = Math.random() * 512;
        ctx.fillRect(px, py, 1.5, 1.5);
      }
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  return texture;
}

export function getThreeMaterial(
  matDefOrId: string | MaterialDefinition,
  customColor?: string,
  shadingMode: ShadingMode = 'realistic',
  doorStyle?: string
): THREE.Material {
  const matDef: MaterialDefinition =
    typeof matDefOrId === 'string' ? getMaterialById(matDefOrId) : matDefOrId;
  const color = customColor || matDef.color;
  const cacheKey = `${matDef.id}_${color}_${shadingMode}_${doorStyle || 'none'}`;

  if (materialCache.has(cacheKey)) {
    return materialCache.get(cacheKey)!;
  }

  let material: THREE.Material;

  if (shadingMode === 'wireframe') {
    material = new THREE.MeshBasicMaterial({
      color: 0x0284c7,
      wireframe: true,
    });
  } else if (shadingMode === 'solid') {
    material = new THREE.MeshLambertMaterial({
      color: new THREE.Color(color),
    });
  } else {
    // Realistic mode
    if (matDef.category === 'glass') {
      material = new THREE.MeshPhysicalMaterial({
        color: new THREE.Color(color),
        roughness: matDef.roughness || 0.08,
        metalness: matDef.metalness || 0.05,
        transmission: matDef.transmission || 0.85,
        transparent: true,
        opacity: matDef.opacity || 0.6,
        ior: 1.52,
        reflectivity: 0.9,
      });
    } else {
      let map: THREE.Texture | undefined;
      if (doorStyle === 'fluted') {
        map = createProceduralTexture('fluted', color);
        map.repeat.set(4, 2);
      } else if (matDef.category === 'wood') {
        map = createProceduralTexture('wood', color);
        map.repeat.set(2, 2);
      } else if (matDef.category === 'marble') {
        map = createProceduralTexture('marble', color);
        map.repeat.set(1.5, 1.5);
      } else if (matDef.category === 'metal') {
        map = createProceduralTexture('brushed_metal', color);
        map.repeat.set(1, 4);
      } else if (matDef.category === 'ceramic_floor') {
        map = createProceduralTexture('ceramic_floor', color, matDef.id);
        map.repeat.set(4, 4);
      } else if (matDef.category === 'ceramic_wall') {
        map = createProceduralTexture('ceramic_wall', color, matDef.id);
        map.repeat.set(4, 4);
      } else if (matDef.category === 'paint') {
        map = createProceduralTexture('paint', color, matDef.id);
        map.repeat.set(2, 2);
      }

      material = new THREE.MeshStandardMaterial({
        color: new THREE.Color(color),
        roughness: matDef.roughness,
        metalness: matDef.metalness,
        map: map,
        shadowSide: THREE.DoubleSide,
      });
    }
  }

  materialCache.set(cacheKey, material);
  return material;
}

export function clearMaterialCache(): void {
  materialCache.forEach((mat) => mat.dispose());
  materialCache.clear();
}
