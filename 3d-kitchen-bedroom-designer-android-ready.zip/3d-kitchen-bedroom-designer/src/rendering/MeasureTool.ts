import * as THREE from 'three';

export class MeasureTool {
  public group: THREE.Group;
  public startPoint: THREE.Vector3 | null = null;
  public endPoint: THREE.Vector3 | null = null;
  public isActive: boolean = false;
  private lineMesh: THREE.Line | null = null;
  private startSphere: THREE.Mesh | null = null;
  private endSphere: THREE.Mesh | null = null;
  private labelSprite: THREE.Sprite | null = null;

  constructor() {
    this.group = new THREE.Group();
    this.group.name = 'measure_tool_group';
  }

  public activate(): void {
    this.isActive = true;
    this.reset();
  }

  public deactivate(): void {
    this.isActive = false;
    this.reset();
  }

  public setStart(point: THREE.Vector3): void {
    this.startPoint = point.clone();
    this.endPoint = null;
    this.updateVisuals();
  }

  public setEnd(point: THREE.Vector3): number {
    this.endPoint = point.clone();
    this.updateVisuals();
    return this.getDistance();
  }

  public getDistance(): number {
    if (!this.startPoint || !this.endPoint) return 0;
    return Math.round(this.startPoint.distanceTo(this.endPoint));
  }

  public reset(): void {
    this.startPoint = null;
    this.endPoint = null;
    while (this.group.children.length > 0) {
      this.group.remove(this.group.children[0]);
    }
    this.lineMesh = null;
    this.startSphere = null;
    this.endSphere = null;
    this.labelSprite = null;
  }

  private updateVisuals(): void {
    while (this.group.children.length > 0) {
      this.group.remove(this.group.children[0]);
    }

    if (!this.startPoint) return;

    // Start point pin
    const sphereMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
    const sphereGeo = new THREE.SphereGeometry(15, 16, 16);
    this.startSphere = new THREE.Mesh(sphereGeo, sphereMat);
    this.startSphere.position.copy(this.startPoint);
    this.group.add(this.startSphere);

    if (this.endPoint) {
      // End point pin
      this.endSphere = new THREE.Mesh(sphereGeo, sphereMat);
      this.endSphere.position.copy(this.endPoint);
      this.group.add(this.endSphere);

      // Connecting Laser Dimension Line
      const points = [this.startPoint, this.endPoint];
      const lineGeo = new THREE.BufferGeometry().setFromPoints(points);
      const lineMat = new THREE.LineDashedMaterial({
        color: 0xef4444,
        linewidth: 3,
        dashSize: 20,
        gapSize: 10,
      });
      this.lineMesh = new THREE.Line(lineGeo, lineMat);
      this.lineMesh.computeLineDistances();
      this.group.add(this.lineMesh);

      // Distance Text Billboard
      const distanceMm = this.getDistance();
      const text = `${distanceMm} mm (${(distanceMm / 10).toFixed(1)} cm)`;
      const sprite = this.createTextSprite(text);
      const midPoint = new THREE.Vector3().addVectors(this.startPoint, this.endPoint).multiplyScalar(0.5);
      sprite.position.copy(midPoint);
      sprite.position.y += 35; // elevate slightly
      this.labelSprite = sprite;
      this.group.add(sprite);
    }
  }

  private createTextSprite(text: string): THREE.Sprite {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 128;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.roundRect(10, 10, 492, 108, 16);
      ctx.fill();
      ctx.lineWidth = 4;
      ctx.strokeStyle = '#ef4444';
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 36px Cairo, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(text, 256, 64);
    }

    const texture = new THREE.CanvasTexture(canvas);
    const spriteMat = new THREE.SpriteMaterial({ map: texture, depthTest: false });
    const sprite = new THREE.Sprite(spriteMat);
    sprite.scale.set(300, 75, 1);
    return sprite;
  }
}
