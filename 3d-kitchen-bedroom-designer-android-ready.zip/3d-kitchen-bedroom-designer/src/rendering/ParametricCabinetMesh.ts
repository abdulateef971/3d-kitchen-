import * as THREE from 'three';
import { ParametricCabinet, ShadingMode, DoorProfileStyle, ApplianceType } from '../types';
import { getThreeMaterial } from './materials';

export interface DoorPivotInfo {
  pivotGroup: THREE.Group;
  doorIndex: number;
  hingeSide: string;
  currentAngle: number;
  targetAngle: number;
  openSpeed: number;
}

export interface DrawerSlideInfo {
  drawerGroup: THREE.Group;
  drawerIndex: number;
  currentAmount: number;
  targetAmount: number;
  maxTravel: number;
  openSpeed: number;
}

export class ParametricCabinetMesh {
  public group: THREE.Group;
  public unitData: ParametricCabinet;
  public doorPivots: DoorPivotInfo[] = [];
  public drawerSlides: DrawerSlideInfo[] = [];
  private selectionBox: THREE.Object3D | null = null;

  constructor(unitData: ParametricCabinet, shadingMode: ShadingMode = 'realistic') {
    this.unitData = unitData;
    this.group = new THREE.Group();
    this.group.name = `unit_${unitData.id}`;
    this.group.userData = {
      isCabinet: true,
      unitId: unitData.id,
      unit: unitData,
    };

    this.rebuild(shadingMode);
  }

  public rebuild(shadingMode: ShadingMode = 'realistic'): void {
    // Clear existing children
    while (this.group.children.length > 0) {
      const obj = this.group.children[0];
      this.group.remove(obj);
    }
    this.doorPivots = [];
    this.drawerSlides = [];

    const u = this.unitData;
    const w = u.width;
    const h = u.height;
    const d = u.depth;
    const t = u.bodyThickness || 18;
    const legH = u.legsHeight || 0;

    const bodyMat = getThreeMaterial(u.bodyMaterialId, u.bodyColor, shadingMode);
    const frontMat = getThreeMaterial(u.frontMaterialId, u.frontColor, shadingMode, u.doorStyle);

    // Main Carcase Group (offset by legs height)
    const carcaseGroup = new THREE.Group();
    carcaseGroup.position.set(0, legH, 0);
    this.group.add(carcaseGroup);

    // If unit is a pure appliance (like freestanding range, pyramid hood, or freestanding fridge), skip carcase
    const isFreestanding = u.accessoryType === 'refrigerator_french' || 
                           u.accessoryType === 'refrigerator' || 
                           u.accessoryType === 'refrigerator_side_by_side' || 
                           u.accessoryType === 'hood_pyramid' || 
                           u.accessoryType === 'hood_box' || 
                           u.accessoryType === 'range_stove' ||
                           u.accessoryType === 'bed_headboard';

    // Check if unit is a Corner unit (L-Shape or 45° Diagonal)
    const rawTemplateId = (u as any).templateId || '';
    const isCornerUnit = 
      u.category === 'kitchen_corner' ||
      u.subCategory === 'corner_units' ||
      (rawTemplateId && (rawTemplateId.includes('corner_base') || rawTemplateId.includes('corner_wall') || rawTemplateId.includes('corner_l_shape') || rawTemplateId.includes('corner_diagonal'))) ||
      (u.name && u.name.toLowerCase().includes('corner') && (u.name.toLowerCase().includes('l-shape') || u.name.toLowerCase().includes('diagonal') || u.name.toLowerCase().includes('carousel') || u.name.toLowerCase().includes('magic') || u.name.toLowerCase().includes('lemans'))) ||
      (u.nameAr && (u.nameAr.includes('ركن') || u.nameAr.includes('زاوية'))) ||
      u.accessoryType === 'corner_carousel' ||
      u.accessoryType === 'corner_magic' ||
      u.accessoryType === 'corner_lemans';

    if (isCornerUnit) {
      this.buildCornerUnit(carcaseGroup, bodyMat, frontMat, shadingMode);
      if (u.countertop && u.countertop.enabled) {
        this.buildCornerCountertop(shadingMode);
      }
    } else if (u.accessoryType === 'combo_cooking_station_900' || u.accessoryType === 'combo_cooking_station_1000') {
      this.buildCookingStationCombo900(carcaseGroup, bodyMat, frontMat, shadingMode);
      if (u.countertop && u.countertop.enabled) {
        this.buildCookingStationCountertop(shadingMode);
      }
    } else if (u.accessoryType === 'combo_oven_cooktop_drawers') {
      this.buildOvenWithTopDrawerBase(carcaseGroup, bodyMat, frontMat, shadingMode);
      if (u.countertop && u.countertop.enabled) {
        this.buildOvenCountertopWithGasCooktop(shadingMode);
      }
    } else if (!isFreestanding) {
      // 1. Carcase Panels
      // Left Side (Gable)
      const leftGableGeo = new THREE.BoxGeometry(t, h, d);
      const leftGable = new THREE.Mesh(leftGableGeo, bodyMat);
      leftGable.position.set(-w / 2 + t / 2, h / 2, 0);
      leftGable.castShadow = true;
      leftGable.receiveShadow = true;
      carcaseGroup.add(leftGable);

      // Right Side (Gable)
      const rightGableGeo = new THREE.BoxGeometry(t, h, d);
      const rightGable = new THREE.Mesh(rightGableGeo, bodyMat);
      rightGable.position.set(w / 2 - t / 2, h / 2, 0);
      rightGable.castShadow = true;
      rightGable.receiveShadow = true;
      carcaseGroup.add(rightGable);

      // Bottom Base Panel
      const internalW = w - 2 * t;
      const bottomGeo = new THREE.BoxGeometry(internalW, t, d);
      const bottomMesh = new THREE.Mesh(bottomGeo, bodyMat);
      bottomMesh.position.set(0, t / 2, 0);
      bottomMesh.castShadow = true;
      bottomMesh.receiveShadow = true;
      carcaseGroup.add(bottomMesh);

      // Top Panel / Stretchers
      const isWall = u.category === 'kitchen_wall';
      const isTallOrWardrobe = u.category.includes('tall') || u.category.includes('wardrobe');
      if (isWall || isTallOrWardrobe) {
        const topGeo = new THREE.BoxGeometry(internalW, t, d);
        const topMesh = new THREE.Mesh(topGeo, bodyMat);
        topMesh.position.set(0, h - t / 2, 0);
        topMesh.castShadow = true;
        topMesh.receiveShadow = true;
        carcaseGroup.add(topMesh);
      } else {
        // Front and Back Stretchers for base units
        const frontStretcherGeo = new THREE.BoxGeometry(internalW, t, 80);
        const frontStretcher = new THREE.Mesh(frontStretcherGeo, bodyMat);
        frontStretcher.position.set(0, h - t / 2, d / 2 - 40);
        carcaseGroup.add(frontStretcher);

        const backStretcherGeo = new THREE.BoxGeometry(internalW, t, 80);
        const backStretcher = new THREE.Mesh(backStretcherGeo, bodyMat);
        backStretcher.position.set(0, h - t / 2, -d / 2 + 40);
        carcaseGroup.add(backStretcher);
      }

      // Back Panel (8mm)
      const backGeo = new THREE.BoxGeometry(internalW, h - 2 * t, u.backThickness || 8);
      const backMat = getThreeMaterial('mdf_matte_white', '#f1f5f9', shadingMode);
      const backMesh = new THREE.Mesh(backGeo, backMat);
      backMesh.position.set(0, h / 2, -d / 2 + (u.backThickness || 8) / 2);
      backMesh.receiveShadow = true;
      carcaseGroup.add(backMesh);

      // 2. Legs / Plinth
      if (legH > 0) {
        if (u.hasPlinthKick) {
          // Kickboard / Plinth
          const plinthMat = getThreeMaterial(u.bodyMaterialId, '#1e293b', shadingMode);
          const plinthGeo = new THREE.BoxGeometry(w, legH, 18);
          const plinthMesh = new THREE.Mesh(plinthGeo, plinthMat);
          plinthMesh.position.set(0, legH / 2, d / 2 - 40);
          plinthMesh.castShadow = true;
          this.group.add(plinthMesh);
        } else {
          // 4 Modern Cylinder Legs
          const legGeo = new THREE.CylinderGeometry(18, 14, legH, 16);
          const legMat = getThreeMaterial('metal_matte_black', '#18181b', shadingMode);
          const legOffsets = [
            [-w / 2 + 40, -d / 2 + 40],
            [w / 2 - 40, -d / 2 + 40],
            [-w / 2 + 40, d / 2 - 40],
            [w / 2 - 40, d / 2 - 40],
          ];
          legOffsets.forEach(([lx, lz]) => {
            const legMesh = new THREE.Mesh(legGeo, legMat);
            legMesh.position.set(lx, legH / 2, lz);
            legMesh.castShadow = true;
            this.group.add(legMesh);
          });
        }
      }

      // 3. Shelves (Glass or Wood)
      if (u.shelves && u.shelves.count > 0) {
        const isGlassShelf = u.shelves.isGlass || u.doors.some((d) => d.hasGlassPanel || d.doorStyle === 'glass_frame');
        const shelfMat = isGlassShelf
          ? getThreeMaterial('glass_clear_crystal', '#e0f2fe', shadingMode)
          : bodyMat;
        const shelfThick = isGlassShelf ? 8 : t;
        const shelfGeo = new THREE.BoxGeometry(internalW - 2, shelfThick, d - 20);
        const shelfSpacing = (h - 2 * t) / (u.shelves.count + 1);

        for (let i = 1; i <= u.shelves.count; i++) {
          const shelfMesh = new THREE.Mesh(shelfGeo, shelfMat);
          shelfMesh.position.set(0, t + i * shelfSpacing, 5);
          shelfMesh.castShadow = true;
          shelfMesh.receiveShadow = true;
          carcaseGroup.add(shelfMesh);

          // If glass display cabinet with internal LED, add shelf glow
          if (isGlassShelf) {
            const ledGeo = new THREE.BoxGeometry(internalW - 10, 4, 8);
            const ledMat = new THREE.MeshBasicMaterial({ color: 0xfef08a });
            const ledStrip = new THREE.Mesh(ledGeo, ledMat);
            ledStrip.position.set(0, t + i * shelfSpacing + 6, -d / 2 + 20);
            carcaseGroup.add(ledStrip);
          }
        }
      }

      // 4. Doors System with Shaker, Fluted, Glass Frame, J-Pull, and Louver Profiles
      if (u.doors && u.doors.length > 0) {
        const numDoors = u.doors.length;
        const doorW = w / numDoors - 3;
        const doorH = h - 6;

        u.doors.forEach((door, idx) => {
          const pivotGroup = new THREE.Group();
          pivotGroup.name = `door_pivot_${idx}`;

          const isHingeLeft = door.hingeSide === 'left';
          const isHingeRight = door.hingeSide === 'right';
          const isTopLift = door.hingeSide === 'top_lift';

          // Calculate Door Center and Pivot Position
          const doorCenterX = -w / 2 + (idx + 0.5) * (w / numDoors);
          let pivotX = doorCenterX;
          let pivotY = h / 2;
          let pivotZ = d / 2 + (door.thickness || 18) / 2 + 1;

          let doorMeshX = 0;
          let doorMeshY = 0;

          if (isHingeLeft) {
            pivotX = doorCenterX - doorW / 2;
            doorMeshX = doorW / 2;
          } else if (isHingeRight) {
            pivotX = doorCenterX + doorW / 2;
            doorMeshX = -doorW / 2;
          } else if (isTopLift) {
            pivotY = h - 6;
            doorMeshY = -doorH / 2;
          }

          pivotGroup.position.set(pivotX, pivotY, pivotZ);

          const doorStyle: DoorProfileStyle = door.doorStyle || u.doorStyle || (door.hasGlassPanel ? 'glass_frame' : 'slab');
          const doorGroup = this.createDoorStyleMesh(doorW, doorH, door.thickness || 18, doorStyle, frontMat, shadingMode, door);
          doorGroup.position.set(doorMeshX, doorMeshY, 0);
          pivotGroup.add(doorGroup);

          // Add Handle to Door
          if (u.handleConfig && u.handleConfig.style !== 'handleless' && doorStyle !== 'j_pull') {
            const handleMesh = this.createHandleMesh(u.handleConfig, shadingMode);
            const handleOffset = u.handleConfig.offsetFromEdge || 40;
            let handleX = doorMeshX;
            if (isHingeLeft) {
              handleX = doorMeshX + doorW / 2 - handleOffset;
            } else if (isHingeRight) {
              handleX = doorMeshX - doorW / 2 + handleOffset;
            }
            handleMesh.position.set(handleX, doorMeshY + (doorH > 1200 ? 0 : 50), (door.thickness || 18) / 2 + 10);
            pivotGroup.add(handleMesh);
          }

          // Tag pivotGroup and all descendant meshes with door metadata so raycasting anywhere on the door triggers animation
          pivotGroup.userData = { isDoor: true, doorIndex: idx, unitId: u.id };
          pivotGroup.traverse((child) => {
            child.userData = { isDoor: true, doorIndex: idx, unitId: u.id };
          });

          carcaseGroup.add(pivotGroup);

          this.doorPivots.push({
            pivotGroup,
            doorIndex: idx,
            hingeSide: door.hingeSide,
            currentAngle: door.openAngle || 0,
            targetAngle: door.targetAngle || 0,
            openSpeed: door.openSpeed || 0.5,
          });
        });
      }

      // 5. Drawers System with Sliding Tracks
      if (u.drawers && u.drawers.length > 0) {
        const numDrawers = u.drawers.length;
        const drawerH = (h - 2 * t) / numDrawers;
        const drawerW = w - 6;
        const drawerD = d - 50;

        u.drawers.forEach((drawer, drIdx) => {
          const drawerGroup = new THREE.Group();
          drawerGroup.name = `drawer_${drIdx}`;
          drawerGroup.userData = { isDrawer: true, drawerIndex: drIdx, unitId: u.id };

          const drawerY = t + (numDrawers - 1 - drIdx + 0.5) * drawerH;
          drawerGroup.position.set(0, drawerY, 0);

          // Drawer Front with doorStyle
          const dStyle = drawer.doorStyle || u.doorStyle || 'slab';
          const drawerFrontGroup = this.createDoorStyleMesh(drawerW, drawerH - 4, drawer.thickness || 18, dStyle, frontMat, shadingMode, drawer);
          drawerFrontGroup.position.set(0, 0, d / 2 + (drawer.thickness || 18) / 2);
          drawerGroup.add(drawerFrontGroup);

          // Drawer Box (Sides, Front, Back, Bottom)
          const boxMat = getThreeMaterial('mdf_matte_white', '#ffffff', shadingMode);
          const boxH = Math.max(60, drawerH - 50);

          // Left Box Side
          const boxLeftGeo = new THREE.BoxGeometry(16, boxH, drawerD);
          const boxLeft = new THREE.Mesh(boxLeftGeo, boxMat);
          boxLeft.position.set(-internalW / 2 + 15, 0, 0);
          drawerGroup.add(boxLeft);

          // Right Box Side
          const boxRightGeo = new THREE.BoxGeometry(16, boxH, drawerD);
          const boxRight = new THREE.Mesh(boxRightGeo, boxMat);
          boxRight.position.set(internalW / 2 - 15, 0, 0);
          drawerGroup.add(boxRight);

          // Bottom Box
          const boxBottomGeo = new THREE.BoxGeometry(internalW - 30, 12, drawerD);
          const boxBottom = new THREE.Mesh(boxBottomGeo, boxMat);
          boxBottom.position.set(0, -boxH / 2 + 6, 0);
          drawerGroup.add(boxBottom);

          // Back Box
          const boxBackGeo = new THREE.BoxGeometry(internalW - 30, boxH, 16);
          const boxBack = new THREE.Mesh(boxBackGeo, boxMat);
          boxBack.position.set(0, 0, -drawerD / 2 + 8);
          drawerGroup.add(boxBack);

          // Handle for Drawer
          if (u.handleConfig && u.handleConfig.style !== 'handleless' && dStyle !== 'j_pull') {
            const handleMesh = this.createHandleMesh(u.handleConfig, shadingMode, true);
            handleMesh.position.set(0, 0, d / 2 + (drawer.thickness || 18) + 8);
            drawerGroup.add(handleMesh);
          }

          // Tag drawerGroup and all descendant meshes with drawer metadata
          drawerGroup.userData = { isDrawer: true, drawerIndex: drIdx, unitId: u.id };
          drawerGroup.traverse((child) => {
            child.userData = { isDrawer: true, drawerIndex: drIdx, unitId: u.id };
          });

          carcaseGroup.add(drawerGroup);

          this.drawerSlides.push({
            drawerGroup,
            drawerIndex: drIdx,
            currentAmount: drawer.openAmount || 0,
            targetAmount: drawer.targetAmount || 0,
            maxTravel: drawerD * 0.8,
            openSpeed: drawer.openSpeed || 0.4,
          });
        });
      }

      // 6. Countertop Slab with Marble, Overhangs, Bevel Profile, & Waterfall Ends
      if (u.countertop && u.countertop.enabled) {
        const ct = u.countertop;
        const ctMat = getThreeMaterial(ct.materialId || 'marble_calacatta_gold', ct.color || '#ede8df', shadingMode);
        const ctW = w + ct.overhangLeft + ct.overhangRight;
        const ctD = d + ct.overhangFront + ct.overhangBack;
        const ctH = ct.thickness || 35;

        const ctGeo = new THREE.BoxGeometry(ctW, ctH, ctD);
        const ctMesh = new THREE.Mesh(ctGeo, ctMat);
        ctMesh.position.set(
          (ct.overhangRight - ct.overhangLeft) / 2,
          legH + h + ctH / 2,
          (ct.overhangFront - ct.overhangBack) / 2
        );
        ctMesh.castShadow = true;
        ctMesh.receiveShadow = true;
        this.group.add(ctMesh);

        // Waterfall Marble Left (يمتد للأرض)
        if (ct.waterfallLeft) {
          const wfGeo = new THREE.BoxGeometry(ctH, legH + h, ctD);
          const wfMesh = new THREE.Mesh(wfGeo, ctMat);
          wfMesh.position.set(-w / 2 - ct.overhangLeft - ctH / 2, (legH + h) / 2, (ct.overhangFront - ct.overhangBack) / 2);
          wfMesh.castShadow = true;
          this.group.add(wfMesh);
        }

        // Waterfall Marble Right (يمتد للأرض)
        if (ct.waterfallRight) {
          const wfGeo = new THREE.BoxGeometry(ctH, legH + h, ctD);
          const wfMesh = new THREE.Mesh(wfGeo, ctMat);
          wfMesh.position.set(w / 2 + ct.overhangRight + ctH / 2, (legH + h) / 2, (ct.overhangFront - ct.overhangBack) / 2);
          wfMesh.castShadow = true;
          this.group.add(wfMesh);
        }

        // Backsplash
        if (ct.hasBacksplash) {
          const bsH = ct.backsplashHeight || 60;
          const bsGeo = new THREE.BoxGeometry(ctW, bsH, 20);
          const bsMesh = new THREE.Mesh(bsGeo, ctMat);
          bsMesh.position.set(
            (ct.overhangRight - ct.overhangLeft) / 2,
            legH + h + ctH + bsH / 2,
            -d / 2 - 10
          );
          this.group.add(bsMesh);
        }
      }
    }

    // 7. Integrated Appliances & Accessories in 3D
    this.addAccessoryMeshes(shadingMode);

    // Apply Position and Rotation
    this.group.position.set(u.positionX, u.positionY, u.positionZ);
    this.group.rotation.y = (u.rotationY * Math.PI) / 180;

    // Selection Highlight Box
    if (u.isSelected) {
      this.addSelectionHighlight();
    }
  }

  /**
   * Builds distinct 3D door meshes for Shaker, Slab, Glass Frame, Fluted, J-Pull, Raised Panel, Louver
   */
  private createDoorStyleMesh(
    width: number,
    height: number,
    thickness: number,
    style: DoorProfileStyle,
    material: THREE.Material,
    shadingMode: ShadingMode,
    doorData: any
  ): THREE.Group {
    const group = new THREE.Group();

    if (style === 'shaker') {
      // Classic Shaker with 60mm Rails & Stiles and 6mm Recessed Inner Panel
      const railWidth = Math.min(60, width / 4);
      const innerW = width - railWidth * 2;
      const innerH = height - railWidth * 2;

      // Outer Frame (Left, Right, Top, Bottom)
      const stilesGeo = new THREE.BoxGeometry(railWidth, height, thickness);
      const leftStile = new THREE.Mesh(stilesGeo, material);
      leftStile.position.set(-width / 2 + railWidth / 2, 0, 0);
      leftStile.castShadow = true;
      group.add(leftStile);

      const rightStile = new THREE.Mesh(stilesGeo, material);
      rightStile.position.set(width / 2 - railWidth / 2, 0, 0);
      rightStile.castShadow = true;
      group.add(rightStile);

      const railsGeo = new THREE.BoxGeometry(innerW, railWidth, thickness);
      const topRail = new THREE.Mesh(railsGeo, material);
      topRail.position.set(0, height / 2 - railWidth / 2, 0);
      topRail.castShadow = true;
      group.add(topRail);

      const bottomRail = new THREE.Mesh(railsGeo, material);
      bottomRail.position.set(0, -height / 2 + railWidth / 2, 0);
      bottomRail.castShadow = true;
      group.add(bottomRail);

      // Recessed Center Panel
      const panelGeo = new THREE.BoxGeometry(innerW, innerH, 8);
      const centerPanel = new THREE.Mesh(panelGeo, material);
      centerPanel.position.set(0, 0, -thickness / 2 + 4);
      centerPanel.receiveShadow = true;
      group.add(centerPanel);

    } else if (style === 'glass_frame') {
      // Slim Frame (35mm) with Tempered Glass Center & Internal Reflection
      const frameWidth = 35;
      const innerW = width - frameWidth * 2;
      const innerH = height - frameWidth * 2;

      const frameMat = getThreeMaterial('metal_matte_black', '#18181b', shadingMode);
      const frameGeo = new THREE.BoxGeometry(frameWidth, height, thickness);
      const leftF = new THREE.Mesh(frameGeo, frameMat);
      leftF.position.set(-width / 2 + frameWidth / 2, 0, 0);
      group.add(leftF);

      const rightF = new THREE.Mesh(frameGeo, frameMat);
      rightF.position.set(width / 2 - frameWidth / 2, 0, 0);
      group.add(rightF);

      const horizGeo = new THREE.BoxGeometry(innerW, frameWidth, thickness);
      const topF = new THREE.Mesh(horizGeo, frameMat);
      topF.position.set(0, height / 2 - frameWidth / 2, 0);
      group.add(topF);

      const botF = new THREE.Mesh(horizGeo, frameMat);
      botF.position.set(0, -height / 2 + frameWidth / 2, 0);
      group.add(botF);

      // Glass Pane
      const glassTypeId = doorData?.glassType === 'smoked' ? 'glass_smoked_bronze' :
                          doorData?.glassType === 'fluted' ? 'glass_fluted_clear' :
                          doorData?.glassType === 'frosted' ? 'glass_frosted_acid' : 'glass_clear_crystal';
      const glassMat = getThreeMaterial(glassTypeId, '#e0f2fe', shadingMode);
      const glassGeo = new THREE.BoxGeometry(innerW + 6, innerH + 6, 4);
      const glassMesh = new THREE.Mesh(glassGeo, glassMat);
      glassMesh.position.set(0, 0, 0);
      group.add(glassMesh);

    } else if (style === 'fluted') {
      // Fluted Slats 3D Relief (Vertical slats pattern)
      const baseGeo = new THREE.BoxGeometry(width, height, thickness);
      const baseMesh = new THREE.Mesh(baseGeo, material);
      baseMesh.castShadow = true;
      group.add(baseMesh);

      // Physical slat relief strips
      const slatWidth = 14;
      const numSlats = Math.floor(width / slatWidth);
      const slatGeo = new THREE.BoxGeometry(slatWidth - 3, height, 4);
      for (let i = 0; i < numSlats; i++) {
        const slatMesh = new THREE.Mesh(slatGeo, material);
        const sx = -width / 2 + (i + 0.5) * (width / numSlats);
        slatMesh.position.set(sx, 0, thickness / 2 + 2);
        slatMesh.castShadow = true;
        group.add(slatMesh);
      }

    } else if (style === 'j_pull') {
      // J-Pull Profile with Beveled Grip Channel at the Top
      const mainGeo = new THREE.BoxGeometry(width, height - 25, thickness);
      const mainMesh = new THREE.Mesh(mainGeo, material);
      mainMesh.position.set(0, -12.5, 0);
      mainMesh.castShadow = true;
      group.add(mainMesh);

      // Slanted J-Grip lip
      const lipGeo = new THREE.BoxGeometry(width, 25, thickness - 6);
      const lipMesh = new THREE.Mesh(lipGeo, material);
      lipMesh.position.set(0, height / 2 - 12.5, -3);
      group.add(lipMesh);

    } else if (style === 'raised_panel') {
      // Traditional Raised Cushion Center Panel
      const railWidth = 55;
      const innerW = width - railWidth * 2;
      const innerH = height - railWidth * 2;

      const baseGeo = new THREE.BoxGeometry(width, height, thickness);
      const baseMesh = new THREE.Mesh(baseGeo, material);
      group.add(baseMesh);

      // Raised center cushion
      const cushionGeo = new THREE.BoxGeometry(innerW, innerH, 6);
      const cushionMesh = new THREE.Mesh(cushionGeo, material);
      cushionMesh.position.set(0, 0, thickness / 2 + 3);
      cushionMesh.castShadow = true;
      group.add(cushionMesh);

    } else if (style === 'louver') {
      // Slatted Louver Shutter
      const frameWidth = 45;
      const innerW = width - frameWidth * 2;
      const innerH = height - frameWidth * 2;

      const baseFrame = new THREE.BoxGeometry(width, height, thickness);
      const fMesh = new THREE.Mesh(baseFrame, material);
      group.add(fMesh);

      // Louver slants
      const slatCount = Math.floor(innerH / 24);
      const slatGeo = new THREE.BoxGeometry(innerW, 16, 3);
      for (let s = 0; s < slatCount; s++) {
        const slMesh = new THREE.Mesh(slatGeo, material);
        slMesh.rotation.x = 0.35;
        const sy = -innerH / 2 + (s + 0.5) * (innerH / slatCount);
        slMesh.position.set(0, sy, thickness / 2 + 2);
        group.add(slMesh);
      }

    } else {
      // Standard Flat Modern Slab
      const slabGeo = new THREE.BoxGeometry(width, height, thickness);
      const slabMesh = new THREE.Mesh(slabGeo, material);
      slabMesh.castShadow = true;
      slabMesh.receiveShadow = true;
      group.add(slabMesh);
    }

    return group;
  }

  private createHandleMesh(
    handleConfig: { style: string; length: number; color: string; material: string },
    shadingMode: ShadingMode,
    isDrawer: boolean = false
  ): THREE.Object3D {
    const handleGroup = new THREE.Group();
    const handleMat = getThreeMaterial('metal_matte_black', handleConfig.color || '#18181b', shadingMode);

    if (handleConfig.style === 'knob_round') {
      const geo = new THREE.CylinderGeometry(14, 10, 24, 16);
      const mesh = new THREE.Mesh(geo, handleMat);
      mesh.rotation.x = Math.PI / 2;
      handleGroup.add(mesh);
    } else if (handleConfig.style === 'knob_square') {
      const geo = new THREE.BoxGeometry(24, 24, 20);
      const mesh = new THREE.Mesh(geo, handleMat);
      handleGroup.add(mesh);
    } else if (handleConfig.style === 'edge_pull') {
      const geo = new THREE.BoxGeometry(handleConfig.length || 180, 8, 20);
      const mesh = new THREE.Mesh(geo, handleMat);
      handleGroup.add(mesh);
    } else {
      // Modern Bar / T-Bar Handle
      const barLen = handleConfig.length || 160;
      const barThick = 10;
      const mainBarGeo = new THREE.CylinderGeometry(barThick / 2, barThick / 2, barLen, 12);
      const mainBar = new THREE.Mesh(mainBarGeo, handleMat);
      if (isDrawer) {
        mainBar.rotation.z = Math.PI / 2;
      }
      handleGroup.add(mainBar);

      // Standoff feet
      const footGeo = new THREE.CylinderGeometry(4, 4, 25, 8);
      const foot1 = new THREE.Mesh(footGeo, handleMat);
      foot1.rotation.x = Math.PI / 2;
      foot1.position.set(isDrawer ? -barLen / 3 : 0, isDrawer ? 0 : -barLen / 3, -12);
      handleGroup.add(foot1);

      const foot2 = new THREE.Mesh(footGeo, handleMat);
      foot2.rotation.x = Math.PI / 2;
      foot2.position.set(isDrawer ? barLen / 3 : 0, isDrawer ? 0 : barLen / 3, -12);
      handleGroup.add(foot2);
    }

    return handleGroup;
  }

  /**
   * Renders realistic 3D models for all kitchen appliances:
   * - Cooktops (Gas stove & Induction)
   * - Refrigerators (French Door & Column)
   * - Range Cookers
   * - Cooker Hoods (Pyramid & Box Glass)
   * - Sinks (Single & Luxury Double with sprayer)
   * - Built-in Ovens & Microwaves
   */
  private addAccessoryMeshes(shadingMode: ShadingMode): void {
    const u = this.unitData;
    const legH = u.legsHeight || 0;
    const ctH = u.countertop?.thickness || 35;
    const steelMat = getThreeMaterial('metal_brushed_steel', '#94a3b8', shadingMode);
    const blackMat = getThreeMaterial('acrylic_gloss_black', '#09090b', shadingMode);
    const castIronMat = getThreeMaterial('metal_matte_black', '#1c1917', shadingMode);
    const brassMat = getThreeMaterial('metal_brushed_brass', '#ca8a04', shadingMode);

    // 1. Realistic Luxury Workstation Undermount Sink (حوض سنك وورك ستيشن نانو متكامل واقعي كما في الصورة)
    if (u.accessoryType === 'sink' || u.accessoryType === 'sink_workstation') {
      const sinkGroup = new THREE.Group();
      sinkGroup.position.set(0, legH + u.height + ctH, 0);

      const sinkColor = u.applianceColor || '#1c2024'; // Nano Gunmetal Black default
      const sinkMat = getThreeMaterial('metal_brushed_steel', sinkColor, shadingMode);
      const chromeMat = getThreeMaterial('metal_brushed_steel', '#e2e8f0', shadingMode);
      const darkInnerMat = getThreeMaterial('metal_matte_black', '#101418', shadingMode);
      const accentMat = getThreeMaterial('metal_brushed_steel', u.applianceColor ? u.applianceColor : '#334155', shadingMode);

      const sinkW = Math.min(u.width * 0.82, 850);
      const sinkD = Math.min(u.depth * 0.68, 520);
      const rearDeckD = 85; // Rear ledge for faucets and soap dispensers

      // 1. Outer Deck Flange sitting flat on countertop
      const outerFlangeGeo = new THREE.BoxGeometry(sinkW, 6, sinkD);
      const outerFlange = new THREE.Mesh(outerFlangeGeo, sinkMat);
      outerFlange.position.set(0, 3, 0);
      outerFlange.castShadow = true;
      outerFlange.receiveShadow = true;
      sinkGroup.add(outerFlange);

      // 2. Rear Faucet Deck (منصة الخلاط والتجهيزات الخلفية)
      const deckGeo = new THREE.BoxGeometry(sinkW - 16, 12, rearDeckD);
      const deckMesh = new THREE.Mesh(deckGeo, sinkMat);
      deckMesh.position.set(0, 7, -sinkD / 2 + rearDeckD / 2 + 8);
      deckMesh.receiveShadow = true;
      sinkGroup.add(deckMesh);

      // 3. Main Basin Cavity (التجويف الداخلي العميق للحوض)
      const basinW = sinkW - 24;
      const basinD = sinkD - rearDeckD - 20;
      const basinCenterZ = rearDeckD / 2 - 4;

      const basinInnerGeo = new THREE.BoxGeometry(basinW, 14, basinD);
      const basinInner = new THREE.Mesh(basinInnerGeo, darkInnerMat);
      basinInner.position.set(0, 5, basinCenterZ);
      basinInner.receiveShadow = true;
      sinkGroup.add(basinInner);

      // 4. Dual Inner Sliding Rails / Step Ledges (مجرى انزلاق السلة ولوح التقطيع)
      const railW = 10;
      const railGeo = new THREE.BoxGeometry(railW, 6, basinD - 8);
      const leftRail = new THREE.Mesh(railGeo, sinkMat);
      leftRail.position.set(-basinW / 2 + railW / 2, 9, basinCenterZ);
      sinkGroup.add(leftRail);

      const rightRail = new THREE.Mesh(railGeo, sinkMat);
      rightRail.position.set(basinW / 2 - railW / 2, 9, basinCenterZ);
      sinkGroup.add(rightRail);

      // 5. Four Diagonal Drainage Crease Lines (خطوط التصريف المائلة X نحو المصفاة)
      const drainLineMat = new THREE.LineBasicMaterial({ color: 0x475569, linewidth: 2 });
      const drainPoints = [
        // Corner 1 to center
        new THREE.Vector3(-basinW * 0.42, 12.2, basinCenterZ - basinD * 0.4),
        new THREE.Vector3(0, 12.2, basinCenterZ),
        // Corner 2 to center
        new THREE.Vector3(basinW * 0.42, 12.2, basinCenterZ - basinD * 0.4),
        new THREE.Vector3(0, 12.2, basinCenterZ),
        // Corner 3 to center
        new THREE.Vector3(-basinW * 0.42, 12.2, basinCenterZ + basinD * 0.4),
        new THREE.Vector3(0, 12.2, basinCenterZ),
        // Corner 4 to center
        new THREE.Vector3(basinW * 0.42, 12.2, basinCenterZ + basinD * 0.4),
        new THREE.Vector3(0, 12.2, basinCenterZ),
      ];
      const drainGeo = new THREE.BufferGeometry().setFromPoints(drainPoints);
      const drainLines = new THREE.LineSegments(drainGeo, drainLineMat);
      sinkGroup.add(drainLines);

      // 6. Central Stainless Steel Strainer Waste Plug (المصفاة الاستيل الكروم الفضية الدائرية)
      const outerDrainRingGeo = new THREE.CylinderGeometry(36, 36, 4, 32);
      const outerDrainRing = new THREE.Mesh(outerDrainRingGeo, chromeMat);
      outerDrainRing.position.set(0, 12.5, basinCenterZ);
      sinkGroup.add(outerDrainRing);

      const innerPlugGeo = new THREE.CylinderGeometry(24, 24, 6, 24);
      const innerPlug = new THREE.Mesh(innerPlugGeo, chromeMat);
      innerPlug.position.set(0, 13.5, basinCenterZ);
      sinkGroup.add(innerPlug);

      const plugHandleGeo = new THREE.CylinderGeometry(4, 4, 10, 12);
      const plugHandle = new THREE.Mesh(plugHandleGeo, chromeMat);
      plugHandle.position.set(0, 18, basinCenterZ);
      sinkGroup.add(plugHandle);

      // 7. Retractable Stainless Steel Dish Drying Rack (سلة تصفية الصحون والخضار المنزلقة)
      const rackW = basinW * 0.38;
      const rackD = basinD * 0.9;
      const rackGroup = new THREE.Group();
      rackGroup.position.set(basinW * 0.26, 12, basinCenterZ);

      // Rack Outer Frame
      const rackFrameMat = chromeMat;
      const rackSideGeo = new THREE.BoxGeometry(6, 14, rackD);
      const rackSideL = new THREE.Mesh(rackSideGeo, rackFrameMat);
      rackSideL.position.set(-rackW / 2 + 3, 0, 0);
      rackGroup.add(rackSideL);

      const rackSideR = new THREE.Mesh(rackSideGeo, rackFrameMat);
      rackSideR.position.set(rackW / 2 - 3, 0, 0);
      rackGroup.add(rackSideR);

      // Rack Front/Back ends
      const rackEndGeo = new THREE.BoxGeometry(rackW, 14, 6);
      const rackEndF = new THREE.Mesh(rackEndGeo, rackFrameMat);
      rackEndF.position.set(0, 0, rackD / 2 - 3);
      rackGroup.add(rackEndF);

      const rackEndB = new THREE.Mesh(rackEndGeo, rackFrameMat);
      rackEndB.position.set(0, 0, -rackD / 2 + 3);
      rackGroup.add(rackEndB);

      // Rack Stainless Wire Rods (أعواد السلة الاستيل)
      const rodCount = 7;
      const rodSpacing = (rackW - 20) / (rodCount - 1);
      const rodGeo = new THREE.CylinderGeometry(1.5, 1.5, rackD - 12, 8);
      for (let r = 0; r < rodCount; r++) {
        const rod = new THREE.Mesh(rodGeo, chromeMat);
        rod.rotation.x = Math.PI / 2;
        rod.position.set(-rackW / 2 + 10 + r * rodSpacing, -3, 0);
        rackGroup.add(rod);
      }
      sinkGroup.add(rackGroup);

      // 8. Modern Waterfall L-Shaped Mixer Faucet (خلاط مياه شلال مودرن بزاوية 90 درجة كما في الصورة)
      const faucetGroup = new THREE.Group();
      const faucetZ = -sinkD / 2 + rearDeckD / 2 + 8;
      faucetGroup.position.set(-20, 13, faucetZ);

      // Faucet Base Box
      const fBaseGeo = new THREE.BoxGeometry(32, 28, 32);
      const fBase = new THREE.Mesh(fBaseGeo, sinkMat);
      fBase.position.set(0, 14, 0);
      faucetGroup.add(fBase);

      // Faucet Vertical Tower (العمود الرأسي)
      const fTowerGeo = new THREE.BoxGeometry(26, 170, 26);
      const fTower = new THREE.Mesh(fTowerGeo, sinkMat);
      fTower.position.set(0, 95, 0);
      fTower.castShadow = true;
      faucetGroup.add(fTower);

      // Horizontal Spout Arm (الذراع الأفقي)
      const fArmGeo = new THREE.BoxGeometry(26, 22, 140);
      const fArm = new THREE.Mesh(fArmGeo, sinkMat);
      fArm.position.set(0, 170, 60);
      fArm.castShadow = true;
      faucetGroup.add(fArm);

      // Waterfall Spout Mouth (فتحة مخرج الشلال العريضة المسطحة)
      const fMouthGeo = new THREE.BoxGeometry(22, 6, 26);
      const fMouth = new THREE.Mesh(fMouthGeo, chromeMat);
      fMouth.position.set(0, 160, 120);
      faucetGroup.add(fMouth);

      // Faucet Single Control Lever (مقبض التحكم الجانبي الأنيق)
      const fLeverGeo = new THREE.CylinderGeometry(5, 5, 55, 16);
      const fLever = new THREE.Mesh(fLeverGeo, sinkMat);
      fLever.rotation.z = Math.PI / 3.5;
      fLever.position.set(24, 75, 0);
      fLever.castShadow = true;
      faucetGroup.add(fLever);

      sinkGroup.add(faucetGroup);

      // 9. High-Arc Pure Drinking Water Filter Tap (حنفية فلتر مياه نقية مقوسة نحيفة)
      const filterTapGroup = new THREE.Group();
      filterTapGroup.position.set(sinkW * 0.32, 13, faucetZ);

      const ftBaseGeo = new THREE.CylinderGeometry(10, 12, 20, 16);
      const ftBase = new THREE.Mesh(ftBaseGeo, chromeMat);
      ftBase.position.set(0, 10, 0);
      filterTapGroup.add(ftBase);

      const ftRiserGeo = new THREE.CylinderGeometry(4.5, 4.5, 90, 12);
      const ftRiser = new THREE.Mesh(ftRiserGeo, chromeMat);
      ftRiser.position.set(0, 55, 0);
      filterTapGroup.add(ftRiser);

      const ftArcGeo = new THREE.TorusGeometry(32, 4, 12, 24, Math.PI * 0.85);
      const ftArc = new THREE.Mesh(ftArcGeo, chromeMat);
      ftArc.rotation.y = -Math.PI / 2;
      ftArc.position.set(0, 95, 30);
      filterTapGroup.add(ftArc);

      sinkGroup.add(filterTapGroup);

      // 10. Built-in Stainless Soap Dispenser Pump (موزع صابون بلت-إن برأس اسطواني)
      const soapGroup = new THREE.Group();
      soapGroup.position.set(-sinkW * 0.34, 13, faucetZ);

      const soapBaseGeo = new THREE.CylinderGeometry(12, 14, 16, 16);
      const soapBase = new THREE.Mesh(soapBaseGeo, chromeMat);
      soapBase.position.set(0, 8, 0);
      soapGroup.add(soapBase);

      const soapHeadGeo = new THREE.CylinderGeometry(8, 8, 22, 16);
      const soapHead = new THREE.Mesh(soapHeadGeo, chromeMat);
      soapHead.position.set(0, 24, 0);
      soapGroup.add(soapHead);

      const soapSpoutGeo = new THREE.CylinderGeometry(3, 2, 45, 12);
      const soapSpout = new THREE.Mesh(soapSpoutGeo, chromeMat);
      soapSpout.rotation.x = Math.PI / 2;
      soapSpout.position.set(0, 30, 20);
      soapGroup.add(soapSpout);

      sinkGroup.add(soapGroup);

      // 11. Integrated Cup Rinser Platform (قاعدة تنظيف وغسيل الكؤوس الدائرية)
      const rinserGroup = new THREE.Group();
      rinserGroup.position.set(sinkW * 0.16, 13, faucetZ);

      const rinserBaseGeo = new THREE.CylinderGeometry(20, 22, 8, 24);
      const rinserBase = new THREE.Mesh(rinserBaseGeo, sinkMat);
      rinserBase.position.set(0, 4, 0);
      rinserGroup.add(rinserBase);

      const rinserStarGeo = new THREE.BoxGeometry(28, 4, 6);
      const star1 = new THREE.Mesh(rinserStarGeo, chromeMat);
      star1.position.set(0, 9, 0);
      rinserGroup.add(star1);

      const star2 = new THREE.Mesh(rinserStarGeo, chromeMat);
      star2.rotation.y = Math.PI / 3;
      star2.position.set(0, 9, 0);
      rinserGroup.add(star2);

      const star3 = new THREE.Mesh(rinserStarGeo, chromeMat);
      star3.rotation.y = -Math.PI / 3;
      star3.position.set(0, 9, 0);
      rinserGroup.add(star3);

      sinkGroup.add(rinserGroup);

      this.group.add(sinkGroup);
    }

    // 2. Double Bowl Luxury Sink (حوض مزدوج عريض مع خلاط فاخر)
    else if (u.accessoryType === 'sink_double') {
      const sinkGroup = new THREE.Group();
      sinkGroup.position.set(0, legH + u.height + ctH, 0);

      const bowlW = u.width * 0.36;
      const bowlD = u.depth * 0.62;

      // Left Bowl
      const leftBowlGeo = new THREE.BoxGeometry(bowlW, 14, bowlD);
      const leftBowl = new THREE.Mesh(leftBowlGeo, steelMat);
      leftBowl.position.set(-bowlW / 2 - 10, 7, 0);
      sinkGroup.add(leftBowl);

      // Right Bowl
      const rightBowlGeo = new THREE.BoxGeometry(bowlW, 14, bowlD);
      const rightBowl = new THREE.Mesh(rightBowlGeo, steelMat);
      rightBowl.position.set(bowlW / 2 + 10, 7, 0);
      sinkGroup.add(rightBowl);

      // Central Luxury Faucet
      const faucet = this.createLuxuryFaucetMesh(brassMat);
      faucet.position.set(0, 14, -u.depth * 0.24);
      sinkGroup.add(faucet);

      this.group.add(sinkGroup);
    }

    // 2b. Luxury Black Granite Composite Sink (حوض جرانيت كوارتز أسود فاخر)
    else if (u.accessoryType === 'sink_granite') {
      const sinkGroup = new THREE.Group();
      sinkGroup.position.set(0, legH + u.height + ctH, 0);

      const granMat = getThreeMaterial('metal_matte_black', '#18181b', shadingMode);
      const basinGeo = new THREE.BoxGeometry(u.width * 0.72, 16, u.depth * 0.64);
      const basinMesh = new THREE.Mesh(basinGeo, granMat);
      basinMesh.position.set(0, 8, 0);
      sinkGroup.add(basinMesh);

      const faucet = this.createLuxuryFaucetMesh(brassMat);
      faucet.position.set(0, 16, -u.depth * 0.24);
      sinkGroup.add(faucet);

      this.group.add(sinkGroup);
    }

    // 2c. Workstation Sink with Cutting Board & Drainer (حوض وورك ستيشن متكامل)
    else if ((u.accessoryType as string) === 'sink_workstation') {
      const sinkGroup = new THREE.Group();
      sinkGroup.position.set(0, legH + u.height + ctH, 0);

      // Large Basin
      const basinGeo = new THREE.BoxGeometry(u.width * 0.8, 14, u.depth * 0.68);
      const basinMesh = new THREE.Mesh(basinGeo, steelMat);
      basinMesh.position.set(0, 7, 0);
      sinkGroup.add(basinMesh);

      // Solid Wood Sliding Cutting Board on Top
      const woodMat = getThreeMaterial('wood_natural_oak', '#c4975f', shadingMode);
      const boardGeo = new THREE.BoxGeometry(u.width * 0.28, 8, u.depth * 0.65);
      const boardMesh = new THREE.Mesh(boardGeo, woodMat);
      boardMesh.position.set(u.width * 0.22, 14, 0);
      sinkGroup.add(boardMesh);

      // Stainless Wire Colander Basket
      const colGeo = new THREE.BoxGeometry(u.width * 0.24, 10, u.depth * 0.6);
      const colMesh = new THREE.Mesh(colGeo, steelMat);
      colMesh.position.set(-u.width * 0.22, 10, 0);
      sinkGroup.add(colMesh);

      const faucet = this.createLuxuryFaucetMesh(steelMat);
      faucet.position.set(0, 14, -u.depth * 0.26);
      sinkGroup.add(faucet);

      this.group.add(sinkGroup);
    }

    // 2d. Farmhouse Apron Front Ceramic Sink (حوض ريفي سيراميك بارز)
    else if (u.accessoryType === 'sink_farmhouse') {
      const sinkGroup = new THREE.Group();
      const ceramicMat = getThreeMaterial('mdf_matt_white', '#f8fafc', shadingMode);
      sinkGroup.position.set(0, legH + u.height - 100, 0);

      // Protruding Apron Front Body
      const sinkGeo = new THREE.BoxGeometry(u.width - 20, 220, u.depth + 40);
      const sinkMesh = new THREE.Mesh(sinkGeo, ceramicMat);
      sinkMesh.position.set(0, 110, 20);
      sinkGroup.add(sinkMesh);

      const faucet = this.createLuxuryFaucetMesh(brassMat);
      faucet.position.set(0, 230, -u.depth * 0.22);
      sinkGroup.add(faucet);

      this.group.add(sinkGroup);
    }

    // 3. Gas Cooktop with 4/5 Burners, Cast Iron Grates & Control Knobs (طباخ غاز)
    else if (u.accessoryType === 'cooktop_gas' || u.accessoryType === 'cooktop') {
      const cooktopGroup = new THREE.Group();
      cooktopGroup.position.set(0, legH + u.height + ctH + 2, 0);

      // Stainless Steel / Glass Hob Surface
      const baseW = Math.min(u.width - 40, 860);
      const baseD = Math.min(u.depth - 40, 520);
      const hobGeo = new THREE.BoxGeometry(baseW, 6, baseD);
      const hobMesh = new THREE.Mesh(hobGeo, blackMat);
      cooktopGroup.add(hobMesh);

      // 4 Cast Iron Burner Grates
      const burnerOffsets = [
        [-baseW * 0.25, -baseD * 0.22, 55],
        [baseW * 0.25, -baseD * 0.22, 45],
        [-baseW * 0.25, baseD * 0.22, 40],
        [baseW * 0.25, baseD * 0.22, 60],
      ];

      burnerOffsets.forEach(([bx, bz, radius]) => {
        // Brass spreader core
        const coreGeo = new THREE.CylinderGeometry(radius * 0.35, radius * 0.35, 6, 16);
        const coreMesh = new THREE.Mesh(coreGeo, brassMat);
        coreMesh.position.set(bx, 6, bz);
        cooktopGroup.add(coreMesh);

        // Cast Iron Burner Cap
        const capGeo = new THREE.CylinderGeometry(radius * 0.45, radius * 0.45, 4, 16);
        const capMesh = new THREE.Mesh(capGeo, castIronMat);
        capMesh.position.set(bx, 10, bz);
        cooktopGroup.add(capMesh);

        // Cast Iron Spider Grate (Cross fingers)
        const grateCross1 = new THREE.BoxGeometry(radius * 1.6, 6, 8);
        const gMesh1 = new THREE.Mesh(grateCross1, castIronMat);
        gMesh1.position.set(bx, 12, bz);
        cooktopGroup.add(gMesh1);

        const grateCross2 = new THREE.BoxGeometry(8, 6, radius * 1.6);
        const gMesh2 = new THREE.Mesh(grateCross2, castIronMat);
        gMesh2.position.set(bx, 12, bz);
        cooktopGroup.add(gMesh2);
      });

      // Front Dial Knobs
      for (let k = 0; k < 4; k++) {
        const knobX = -baseW * 0.25 + k * (baseW * 0.17);
        const knobGeo = new THREE.CylinderGeometry(10, 10, 10, 16);
        const knobMesh = new THREE.Mesh(knobGeo, steelMat);
        knobMesh.position.set(knobX, 8, baseD * 0.38);
        cooktopGroup.add(knobMesh);
      }

      this.group.add(cooktopGroup);
    }

    // 4. Induction Cooktop with Red Glowing Heating Coils (طباخ سيراميك كهربائي)
    else if (u.accessoryType === 'cooktop_induction') {
      const cooktopGroup = new THREE.Group();
      cooktopGroup.position.set(0, legH + u.height + ctH + 2, 0);

      const baseW = Math.min(u.width - 40, 800);
      const baseD = Math.min(u.depth - 40, 520);

      // Glass plate
      const glassGeo = new THREE.BoxGeometry(baseW, 4, baseD);
      const glassMesh = new THREE.Mesh(glassGeo, blackMat);
      cooktopGroup.add(glassMesh);

      // 4 Glowing Red Induction Zones (Torus rings)
      const ringMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
      const ringPositions = [
        [-baseW * 0.25, -baseD * 0.22, 60],
        [baseW * 0.25, -baseD * 0.22, 45],
        [-baseW * 0.25, baseD * 0.22, 45],
        [baseW * 0.25, baseD * 0.22, 75],
      ];

      ringPositions.forEach(([rx, rz, radius]) => {
        const ringGeo = new THREE.TorusGeometry(radius, 2, 8, 32);
        const ringMesh = new THREE.Mesh(ringGeo, ringMat);
        ringMesh.rotation.x = Math.PI / 2;
        ringMesh.position.set(rx, 3, rz);
        cooktopGroup.add(ringMesh);

        // Center cross mark
        const crossGeo = new THREE.BoxGeometry(16, 1, 3);
        const crossMesh = new THREE.Mesh(crossGeo, ringMat);
        crossMesh.position.set(rx, 3, rz);
        cooktopGroup.add(crossMesh);
      });

      // Digital touch control bar
      const touchGeo = new THREE.BoxGeometry(baseW * 0.4, 1, 24);
      const touchMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
      const touchMesh = new THREE.Mesh(touchGeo, touchMat);
      touchMesh.position.set(0, 3, baseD * 0.38);
      cooktopGroup.add(touchMesh);

      this.group.add(cooktopGroup);
    }

    // 5. Freestanding Cooking Range & Oven Stove (طباخ وفرن قائم كبير)
    else if (u.accessoryType === 'range_stove') {
      const rangeGroup = new THREE.Group();
      rangeGroup.position.set(0, legH, 0);

      // Main heavy body
      const bodyGeo = new THREE.BoxGeometry(u.width, u.height, u.depth);
      const bodyMesh = new THREE.Mesh(bodyGeo, steelMat);
      bodyMesh.position.set(0, u.height / 2, 0);
      rangeGroup.add(bodyMesh);

      // Oven Glass Window
      const windowGeo = new THREE.BoxGeometry(u.width * 0.75, u.height * 0.45, 12);
      const windowMesh = new THREE.Mesh(windowGeo, blackMat);
      windowMesh.position.set(0, u.height * 0.48, u.depth / 2 + 7);
      rangeGroup.add(windowMesh);

      // Towel Bar Handle
      const barGeo = new THREE.CylinderGeometry(7, 7, u.width * 0.7, 16);
      const barMesh = new THREE.Mesh(barGeo, steelMat);
      barMesh.rotation.z = Math.PI / 2;
      barMesh.position.set(0, u.height * 0.72, u.depth / 2 + 25);
      rangeGroup.add(barMesh);

      // Top Grates
      const grateGeo = new THREE.BoxGeometry(u.width * 0.9, 15, u.depth * 0.85);
      const grateMesh = new THREE.Mesh(grateGeo, castIronMat);
      grateMesh.position.set(0, u.height + 8, 0);
      rangeGroup.add(grateMesh);

      this.group.add(rangeGroup);
    }

    // 6. Pyramid Cooker Hood Extractor (مرشحة / شفاط هرمي)
    else if (u.accessoryType === 'hood_pyramid' || u.accessoryType === 'hood') {
      const hoodGroup = new THREE.Group();

      // Lower Angled Pyramid Canopy
      const canopyW = u.width;
      const canopyD = u.depth;
      const canopyH = 200;

      const canopyGeo = new THREE.BoxGeometry(canopyW, 60, canopyD);
      const canopyMesh = new THREE.Mesh(canopyGeo, steelMat);
      canopyMesh.position.set(0, 30, 0);
      hoodGroup.add(canopyMesh);

      // Slanted pyramid transition
      const pyramidGeo = new THREE.ConeGeometry(canopyW * 0.45, canopyH, 4);
      const pyramidMesh = new THREE.Mesh(pyramidGeo, steelMat);
      pyramidMesh.rotation.y = Math.PI / 4;
      pyramidMesh.position.set(0, 60 + canopyH / 2, 0);
      hoodGroup.add(pyramidMesh);

      // Telescopic Chimney Flue extending to ceiling
      const chimneyH = Math.max(300, u.height - canopyH);
      const chimneyGeo = new THREE.BoxGeometry(260, chimneyH, 240);
      const chimneyMesh = new THREE.Mesh(chimneyGeo, steelMat);
      chimneyMesh.position.set(0, canopyH + chimneyH / 2, -canopyD * 0.1);
      hoodGroup.add(chimneyMesh);

      // Downward LED work lights
      const lightGeo = new THREE.CylinderGeometry(18, 18, 4, 16);
      const lightMat = new THREE.MeshBasicMaterial({ color: 0xfffbeb });
      const l1 = new THREE.Mesh(lightGeo, lightMat);
      l1.position.set(-canopyW * 0.25, 0, 0);
      hoodGroup.add(l1);

      const l2 = new THREE.Mesh(lightGeo, lightMat);
      l2.position.set(canopyW * 0.25, 0, 0);
      hoodGroup.add(l2);

      this.group.add(hoodGroup);
    }

    // 7. Modern Box T-Shape Glass Cooker Hood (شفاط زجاجي بوكس)
    else if (u.accessoryType === 'hood_box') {
      const hoodGroup = new THREE.Group();

      // Glass flat horizontal visor
      const glassVisorGeo = new THREE.BoxGeometry(u.width, 10, u.depth);
      const glassVisor = new THREE.Mesh(glassVisorGeo, blackMat);
      glassVisor.position.set(0, 5, 0);
      hoodGroup.add(glassVisor);

      // Stainless chimney
      const chimneyGeo = new THREE.BoxGeometry(280, u.height, 260);
      const chimneyMesh = new THREE.Mesh(chimneyGeo, steelMat);
      chimneyMesh.position.set(0, u.height / 2, 0);
      hoodGroup.add(chimneyMesh);

      this.group.add(hoodGroup);
    }

    // 8. French Door American Refrigerator with Ice Dispenser (ثلاجة بابين فرنسية مع موزع مياه)
    else if (u.accessoryType === 'refrigerator_french') {
      const fridgeGroup = new THREE.Group();
      const fridgeColor = u.applianceColor || '#27272a';
      const gunmetalMat = getThreeMaterial('metal_matte_black', fridgeColor, shadingMode);

      // Main Heavy Appliance Body
      const bodyGeo = new THREE.BoxGeometry(u.width, u.height, u.depth);
      const bodyMesh = new THREE.Mesh(bodyGeo, gunmetalMat);
      bodyMesh.position.set(0, u.height / 2, 0);
      bodyMesh.castShadow = true;
      fridgeGroup.add(bodyMesh);

      const doorH = u.height * 0.62;
      const doorW = u.width / 2 - 4;

      // Left French Door
      const leftDoorGeo = new THREE.BoxGeometry(doorW, doorH, 40);
      const leftDoor = new THREE.Mesh(leftDoorGeo, gunmetalMat);
      leftDoor.position.set(-doorW / 2 - 2, u.height - doorH / 2 - 10, u.depth / 2 + 20);
      leftDoor.castShadow = true;
      fridgeGroup.add(leftDoor);

      // Right French Door
      const rightDoorGeo = new THREE.BoxGeometry(doorW, doorH, 40);
      const rightDoor = new THREE.Mesh(rightDoorGeo, gunmetalMat);
      rightDoor.position.set(doorW / 2 + 2, u.height - doorH / 2 - 10, u.depth / 2 + 20);
      rightDoor.castShadow = true;
      fridgeGroup.add(rightDoor);

      // Water & Ice Dispenser Recess on Left Door
      const dispGeo = new THREE.BoxGeometry(doorW * 0.65, 220, 20);
      const dispMesh = new THREE.Mesh(dispGeo, blackMat);
      dispMesh.position.set(-doorW / 2 - 2, u.height * 0.65, u.depth / 2 + 35);
      fridgeGroup.add(dispMesh);

      // Dispenser Blue LED light
      const dispLedGeo = new THREE.BoxGeometry(doorW * 0.45, 4, 8);
      const dispLedMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
      const dispLed = new THREE.Mesh(dispLedGeo, dispLedMat);
      dispLed.position.set(-doorW / 2 - 2, u.height * 0.65 + 95, u.depth / 2 + 40);
      fridgeGroup.add(dispLed);

      // Bottom Pull-out Freezer Drawer
      const freezerH = u.height * 0.32;
      const freezerGeo = new THREE.BoxGeometry(u.width - 8, freezerH, 40);
      const freezerMesh = new THREE.Mesh(freezerGeo, gunmetalMat);
      freezerMesh.position.set(0, freezerH / 2 + 10, u.depth / 2 + 20);
      fridgeGroup.add(freezerMesh);

      // Handles (Vertical handles on doors, Horizontal on freezer)
      const vHandleGeo = new THREE.CylinderGeometry(8, 8, doorH * 0.75, 16);
      const lHandle = new THREE.Mesh(vHandleGeo, steelMat);
      lHandle.position.set(-20, u.height - doorH / 2 - 10, u.depth / 2 + 50);
      fridgeGroup.add(lHandle);

      const rHandle = new THREE.Mesh(vHandleGeo, steelMat);
      rHandle.position.set(20, u.height - doorH / 2 - 10, u.depth / 2 + 50);
      fridgeGroup.add(rHandle);

      const fHandleGeo = new THREE.CylinderGeometry(8, 8, u.width * 0.7, 16);
      const fHandle = new THREE.Mesh(fHandleGeo, steelMat);
      fHandle.rotation.z = Math.PI / 2;
      fHandle.position.set(0, freezerH - 20, u.depth / 2 + 50);
      fridgeGroup.add(fHandle);

      this.group.add(fridgeGroup);
    }

    // 9. Single Door Tall Refrigerator Column (ثلاجة عمودية باب واحد)
    else if (u.accessoryType === 'refrigerator') {
      const fridgeGroup = new THREE.Group();
      const customFridgeMat = u.applianceColor
        ? getThreeMaterial('metal_matte_black', u.applianceColor, shadingMode)
        : steelMat;

      const bodyGeo = new THREE.BoxGeometry(u.width, u.height, u.depth);
      const bodyMesh = new THREE.Mesh(bodyGeo, customFridgeMat);
      bodyMesh.position.set(0, u.height / 2, 0);
      bodyMesh.castShadow = true;
      fridgeGroup.add(bodyMesh);

      // Vertical Brushed Handle
      const hGeo = new THREE.CylinderGeometry(10, 10, u.height * 0.6, 16);
      const hMesh = new THREE.Mesh(hGeo, steelMat);
      hMesh.position.set(u.width / 2 - 40, u.height / 2, u.depth / 2 + 30);
      fridgeGroup.add(hMesh);

      this.group.add(fridgeGroup);
    }

    // 10. Built-in Oven Unit (فرن مدمج واقعي ثلاثي الأبعاد مجسم بالكامل مع تجويف ورفوف ومفاتيح ولمبة وشاشة)
    else if (u.accessoryType === 'oven' || ((u as any).templateId && ((u as any).templateId.includes('oven_base') || (u as any).templateId.includes('oven_tall')))) {
      const ovenGroup = new THREE.Group();
      const ovenW = Math.min(u.width - 16, 595);
      const ovenH = Math.min(u.height * 0.78, 595);
      const ovenD = Math.min(u.depth - 40, 550);
      const chromeMat = getThreeMaterial('metal_chrome', '#f8fafc', shadingMode);
      const brushedSteelMat = getThreeMaterial('metal_brushed_steel', '#e2e8f0', shadingMode);
      const darkGlassMat = getThreeMaterial('glass_tinted_smoked', '#09090b', shadingMode);
      const enamelMat = getThreeMaterial('metal_matte_black', '#18181b', shadingMode);

      ovenGroup.position.set(0, legH + (u.height - ovenH) / 2 + ovenH / 2, u.depth / 2 - ovenD / 2);

      // A. Deep Internal Oven Cavity (Hollow Volumetric Box)
      const cavW = ovenW - 60;
      const cavH = ovenH * 0.62;
      const cavD = ovenD - 50;

      // Cavity back wall
      const cavBackGeo = new THREE.BoxGeometry(cavW, cavH, 8);
      const cavBack = new THREE.Mesh(cavBackGeo, enamelMat);
      cavBack.position.set(0, -ovenH * 0.08, -cavD / 2);
      ovenGroup.add(cavBack);

      // Cavity fan cover on back wall (Convection ring + vents)
      const fanCoverGeo = new THREE.CylinderGeometry(cavH * 0.28, cavH * 0.28, 4, 24);
      const fanCover = new THREE.Mesh(fanCoverGeo, brushedSteelMat);
      fanCover.rotation.x = Math.PI / 2;
      fanCover.position.set(0, -ovenH * 0.08, -cavD / 2 + 5);
      ovenGroup.add(fanCover);

      // Cavity Left & Right walls
      const cavSideGeo = new THREE.BoxGeometry(8, cavH, cavD);
      const cavLeft = new THREE.Mesh(cavSideGeo, enamelMat);
      cavLeft.position.set(-cavW / 2 + 4, -ovenH * 0.08, 0);
      ovenGroup.add(cavLeft);

      const cavRight = new THREE.Mesh(cavSideGeo, enamelMat);
      cavRight.position.set(cavW / 2 - 4, -ovenH * 0.08, 0);
      ovenGroup.add(cavRight);

      // Cavity Top & Bottom walls
      const cavTopGeo = new THREE.BoxGeometry(cavW, 8, cavD);
      const cavTop = new THREE.Mesh(cavTopGeo, enamelMat);
      cavTop.position.set(0, -ovenH * 0.08 + cavH / 2 - 4, 0);
      ovenGroup.add(cavTop);

      const cavBottomGeo = new THREE.BoxGeometry(cavW, 8, cavD);
      const cavBottom = new THREE.Mesh(cavBottomGeo, enamelMat);
      cavBottom.position.set(0, -ovenH * 0.08 - cavH / 2 + 4, 0);
      ovenGroup.add(cavBottom);

      // Upper Top Grill Heating Element (Serpentine chrome tubes)
      for (let g = -2; g <= 2; g++) {
        const grillGeo = new THREE.CylinderGeometry(3, 3, cavD * 0.75, 8);
        const grill = new THREE.Mesh(grillGeo, chromeMat);
        grill.rotation.x = Math.PI / 2;
        grill.position.set(g * (cavW * 0.16), -ovenH * 0.08 + cavH / 2 - 18, 0);
        ovenGroup.add(grill);
      }

      // Interior Chrome Wire Shelf
      const shelfY = -ovenH * 0.08;
      const shelfW = cavW - 20;
      const shelfD = cavD - 30;
      const outerFrameGeo = new THREE.BoxGeometry(shelfW, 4, shelfD);
      const shelfOuter = new THREE.Mesh(outerFrameGeo, chromeMat);
      shelfOuter.position.set(0, shelfY, 0);
      ovenGroup.add(shelfOuter);

      for (let r = -5; r <= 5; r++) {
        const rodGeo = new THREE.CylinderGeometry(2, 2, shelfD - 10, 8);
        const rod = new THREE.Mesh(rodGeo, chromeMat);
        rod.rotation.x = Math.PI / 2;
        rod.position.set(r * (shelfW / 12), shelfY + 2, 0);
        ovenGroup.add(rod);
      }

      // Deep Black Enamel Roasting Pan on bottom rack
      const panY = -ovenH * 0.08 - cavH * 0.3;
      const panGeo = new THREE.BoxGeometry(cavW - 24, 22, cavD - 40);
      const pan = new THREE.Mesh(panGeo, enamelMat);
      pan.position.set(0, panY, 0);
      ovenGroup.add(pan);

      // Warm Interior Halogen Lamp
      const lampGeo = new THREE.BoxGeometry(35, 20, 15);
      const lampMat = new THREE.MeshBasicMaterial({ color: 0xffedd5 });
      const lamp = new THREE.Mesh(lampGeo, lampMat);
      lamp.position.set(cavW / 2 - 20, -ovenH * 0.08 + cavH * 0.32, -cavD * 0.2);
      ovenGroup.add(lamp);

      // B. Outer Front Flush Stainless Steel Surround Trim Kit
      const trimT = 16;
      const trimZ = ovenD / 2 + 8;
      
      // Left / Right stainless vertical trims
      const trimVGeo = new THREE.BoxGeometry(18, ovenH, trimT);
      const trimL = new THREE.Mesh(trimVGeo, brushedSteelMat);
      trimL.position.set(-ovenW / 2 + 9, 0, trimZ);
      ovenGroup.add(trimL);

      const trimR = new THREE.Mesh(trimVGeo, brushedSteelMat);
      trimR.position.set(ovenW / 2 - 9, 0, trimZ);
      ovenGroup.add(trimR);

      // Bottom stainless trim
      const trimBGeo = new THREE.BoxGeometry(ovenW - 36, 18, trimT);
      const trimB = new THREE.Mesh(trimBGeo, brushedSteelMat);
      trimB.position.set(0, -ovenH / 2 + 9, trimZ);
      ovenGroup.add(trimB);

      // C. Top Control Panel Fascia (Stainless & Glass)
      const fasciaH = ovenH * 0.22;
      const fasciaY = ovenH / 2 - fasciaH / 2;
      const fasciaGeo = new THREE.BoxGeometry(ovenW - 36, fasciaH, trimT);
      const fascia = new THREE.Mesh(fasciaGeo, brushedSteelMat);
      fascia.position.set(0, fasciaY, trimZ);
      ovenGroup.add(fascia);

      // Central Glossy Black Digital Timer Bezel
      const bezelW = ovenW * 0.38;
      const bezelGeo = new THREE.BoxGeometry(bezelW, fasciaH * 0.65, 4);
      const bezel = new THREE.Mesh(bezelGeo, blackMat);
      bezel.position.set(0, fasciaY, trimZ + trimT / 2 + 2);
      ovenGroup.add(bezel);

      // Glowing Cyan LED Display Digits
      const ledGeo = new THREE.BoxGeometry(bezelW * 0.6, fasciaH * 0.28, 2);
      const ledMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
      const led = new THREE.Mesh(ledGeo, ledMat);
      led.position.set(0, fasciaY, trimZ + trimT / 2 + 5);
      ovenGroup.add(led);

      // Left Knob: Mode Selector (Protruding 3D Cylinder with knurled ring)
      const knobGeo = new THREE.CylinderGeometry(15, 15, 14, 24);
      const knobMat = brushedSteelMat;
      const knob1 = new THREE.Mesh(knobGeo, knobMat);
      knob1.rotation.x = Math.PI / 2;
      knob1.position.set(-ovenW * 0.32, fasciaY, trimZ + trimT / 2 + 7);
      ovenGroup.add(knob1);

      // Knob 1 pointer tick
      const tick1Geo = new THREE.BoxGeometry(3, 8, 3);
      const tick1 = new THREE.Mesh(tick1Geo, darkGlassMat);
      tick1.position.set(-ovenW * 0.32, fasciaY + 6, trimZ + trimT / 2 + 14);
      ovenGroup.add(tick1);

      // Right Knob: Temperature Dial (50°C - 275°C)
      const knob2 = new THREE.Mesh(knobGeo, knobMat);
      knob2.rotation.x = Math.PI / 2;
      knob2.position.set(ovenW * 0.32, fasciaY, trimZ + trimT / 2 + 7);
      ovenGroup.add(knob2);

      const tick2 = new THREE.Mesh(tick1Geo, darkGlassMat);
      tick2.position.set(ovenW * 0.32, fasciaY + 6, trimZ + trimT / 2 + 14);
      ovenGroup.add(tick2);

      // Cooling air vent grille louvers between control panel and door
      for (let v = 0; v < 3; v++) {
        const ventGeo = new THREE.BoxGeometry(ovenW - 40, 2, 8);
        const vent = new THREE.Mesh(ventGeo, blackMat);
        vent.position.set(0, ovenH / 2 - fasciaH - v * 4, trimZ);
        ovenGroup.add(vent);
      }

      // D. Realistic Multi-Layer Smoked Glass Oven Door
      const doorDoorH = ovenH - fasciaH - 18;
      const doorDoorY = -ovenH / 2 + doorDoorH / 2 + 10;
      const doorGlassGeo = new THREE.BoxGeometry(ovenW - 38, doorDoorH, 12);
      const doorGlass = new THREE.Mesh(doorGlassGeo, darkGlassMat);
      doorGlass.position.set(0, doorDoorY, trimZ + 4);
      doorGlass.castShadow = true;
      ovenGroup.add(doorGlass);

      // Center transparent inner view pane
      const innerViewGeo = new THREE.BoxGeometry((ovenW - 38) * 0.72, doorDoorH * 0.68, 2);
      const innerViewMat = getThreeMaterial('glass_clear_crystal', '#a1a1aa', shadingMode);
      const innerView = new THREE.Mesh(innerViewGeo, innerViewMat);
      innerView.position.set(0, doorDoorY, trimZ + 10);
      ovenGroup.add(innerView);

      // E. Full 3D Stainless Steel Towel Bar Handle on Standoffs
      const handleBarLength = ovenW - 70;
      const handleBarY = doorDoorY + doorDoorH / 2 - 24;
      const handleZ = trimZ + 36;

      // Horizontal Bar
      const hBarGeo = new THREE.CylinderGeometry(8, 8, handleBarLength, 20);
      const hBar = new THREE.Mesh(hBarGeo, brushedSteelMat);
      hBar.rotation.z = Math.PI / 2;
      hBar.position.set(0, handleBarY, handleZ);
      ovenGroup.add(hBar);

      // Left Standoff post
      const postGeo = new THREE.CylinderGeometry(7, 7, 26, 16);
      const postL = new THREE.Mesh(postGeo, brushedSteelMat);
      postL.rotation.x = Math.PI / 2;
      postL.position.set(-handleBarLength / 2 + 25, handleBarY, handleZ - 13);
      ovenGroup.add(postL);

      // Right Standoff post
      const postR = new THREE.Mesh(postGeo, brushedSteelMat);
      postR.rotation.x = Math.PI / 2;
      postR.position.set(handleBarLength / 2 - 25, handleBarY, handleZ - 13);
      ovenGroup.add(postR);

      this.group.add(ovenGroup);
    }

    // 11. Built-in Microwave (مايكروويف مدمج واقعي 3D بالكامل مع طبق دوار ولوحة لمس ومفتاح سحب)
    else if (u.accessoryType === 'microwave') {
      const microGroup = new THREE.Group();
      const mW = Math.min(u.width - 16, 595);
      const mH = Math.min(u.height * 0.65, 385);
      const mD = Math.min(u.depth - 40, 480);
      const brushedSteelMat = getThreeMaterial('metal_brushed_steel', '#e2e8f0', shadingMode);
      const darkGlassMat = getThreeMaterial('glass_tinted_smoked', '#09090b', shadingMode);
      const chromeMat = getThreeMaterial('metal_chrome', '#f8fafc', shadingMode);
      const trimZ = mD / 2 + 8;

      microGroup.position.set(0, legH + (u.height - mH) / 2 + mH / 2, u.depth / 2 - mD / 2);

      // A. Internal Stainless Cavity
      const cavW = mW * 0.62;
      const cavH = mH * 0.72;
      const cavD = mD - 40;
      const cavCenter = -mW / 2 + cavW / 2 + 22;

      const cavBoxGeo = new THREE.BoxGeometry(cavW, cavH, cavD);
      const cavBox = new THREE.Mesh(cavBoxGeo, brushedSteelMat);
      cavBox.position.set(cavCenter, 0, 0);
      microGroup.add(cavBox);

      // Circular Glass Turntable Plate
      const trayRadius = Math.min(cavW, cavD) * 0.42;
      const trayGeo = new THREE.CylinderGeometry(trayRadius, trayRadius, 6, 32);
      const trayMat = getThreeMaterial('glass_clear_crystal', '#e2e8f0', shadingMode);
      const tray = new THREE.Mesh(trayGeo, trayMat);
      tray.position.set(cavCenter, -cavH / 2 + 8, 0);
      microGroup.add(tray);

      // Turntable roller ring
      const ringGeo = new THREE.TorusGeometry(trayRadius * 0.7, 3, 8, 24);
      const ring = new THREE.Mesh(ringGeo, chromeMat);
      ring.rotation.x = Math.PI / 2;
      ring.position.set(cavCenter, -cavH / 2 + 4, 0);
      microGroup.add(ring);

      // B. Outer Flush Stainless Trim Kit (Bezel)
      const trimW = mW;
      const trimH = mH;
      const outerBezelGeo = new THREE.BoxGeometry(trimW, trimH, 14);
      const outerBezel = new THREE.Mesh(outerBezelGeo, brushedSteelMat);
      outerBezel.position.set(0, 0, trimZ);
      microGroup.add(outerBezel);

      // Cutout window for door
      const doorW = mW * 0.68;
      const doorH = mH * 0.82;
      const doorX = -mW / 2 + doorW / 2 + 18;
      const doorGlassGeo = new THREE.BoxGeometry(doorW, doorH, 18);
      const doorGlass = new THREE.Mesh(doorGlassGeo, darkGlassMat);
      doorGlass.position.set(doorX, 0, trimZ + 3);
      doorGlass.castShadow = true;
      microGroup.add(doorGlass);

      // Inner view screen
      const screenGeo = new THREE.BoxGeometry(doorW * 0.78, doorH * 0.72, 2);
      const screenMat = getThreeMaterial('glass_clear_crystal', '#a1a1aa', shadingMode);
      const screen = new THREE.Mesh(screenGeo, screenMat);
      screen.position.set(doorX, 0, trimZ + 12);
      microGroup.add(screen);

      // Vertical Stainless Door Bar Handle
      const hLength = doorH * 0.65;
      const hX = doorX + doorW / 2 - 18;
      const hBarGeo = new THREE.CylinderGeometry(6, 6, hLength, 16);
      const hBar = new THREE.Mesh(hBarGeo, brushedSteelMat);
      hBar.position.set(hX, 0, trimZ + 28);
      microGroup.add(hBar);

      // Handle Standoffs
      const stGeo = new THREE.CylinderGeometry(5, 5, 18, 12);
      const stTop = new THREE.Mesh(stGeo, brushedSteelMat);
      stTop.rotation.x = Math.PI / 2;
      stTop.position.set(hX, hLength / 2 - 12, trimZ + 18);
      microGroup.add(stTop);

      const stBot = new THREE.Mesh(stGeo, brushedSteelMat);
      stBot.rotation.x = Math.PI / 2;
      stBot.position.set(hX, -hLength / 2 + 12, trimZ + 18);
      microGroup.add(stBot);

      // C. Electronic Control Tower on Right Side
      const panelW = mW - doorW - 40;
      const panelX = mW / 2 - panelW / 2 - 18;

      // Digital Clock / Countdown Display (Green / Cyan LED)
      const dispGeo = new THREE.BoxGeometry(panelW - 12, 38, 4);
      const disp = new THREE.Mesh(dispGeo, blackMat);
      disp.position.set(panelX, mH * 0.28, trimZ + 8);
      microGroup.add(disp);

      const ledGeo = new THREE.BoxGeometry((panelW - 12) * 0.7, 16, 2);
      const ledMat = new THREE.MeshBasicMaterial({ color: 0x22c55e });
      const led = new THREE.Mesh(ledGeo, ledMat);
      led.position.set(panelX, mH * 0.28, trimZ + 11);
      microGroup.add(led);

      // Tactile Knob / Dial
      const dialGeo = new THREE.CylinderGeometry(14, 14, 12, 20);
      const dial = new THREE.Mesh(dialGeo, brushedSteelMat);
      dial.rotation.x = Math.PI / 2;
      dial.position.set(panelX, mH * 0.05, trimZ + 14);
      microGroup.add(dial);

      // Round Touch Push-Buttons
      for (let b = 0; b < 4; b++) {
        const btnGeo = new THREE.CylinderGeometry(5, 5, 4, 16);
        const btn = new THREE.Mesh(btnGeo, chromeMat);
        btn.rotation.x = Math.PI / 2;
        btn.position.set(panelX + (b % 2 === 0 ? -12 : 12), -mH * 0.12 - Math.floor(b / 2) * 20, trimZ + 9);
        microGroup.add(btn);
      }

      // Mechanical Door Open Push Button at bottom
      const openBtnGeo = new THREE.BoxGeometry(panelW - 16, 22, 6);
      const openBtn = new THREE.Mesh(openBtnGeo, brushedSteelMat);
      openBtn.position.set(panelX, -mH * 0.34, trimZ + 10);
      microGroup.add(openBtn);

      this.group.add(microGroup);
    }

    // 11b. Built-in Dishwasher (غسالة صحون مدمجة مع شاشة لمس علوية ومقبض أفقي وضوء أرضي)
    else if (u.accessoryType === 'dishwasher' || (u.accessoryType as string) === 'dishwasher_integrated' || ((u as any).templateId && (u as any).templateId.includes('dishwasher'))) {
      const dwGroup = new THREE.Group();
      const dwW = u.width - 6;
      const dwH = u.height - 8;
      const dwZ = u.depth / 2 + 10;
      const brushedSteelMat = getThreeMaterial('metal_brushed_steel', '#e2e8f0', shadingMode);

      dwGroup.position.set(0, legH + u.height / 2, 0);

      // Stainless Front Door Panel
      const doorGeo = new THREE.BoxGeometry(dwW, dwH - 35, 18);
      const doorMesh = new THREE.Mesh(doorGeo, brushedSteelMat);
      doorMesh.position.set(0, -17, dwZ);
      doorMesh.castShadow = true;
      dwGroup.add(doorMesh);

      // Top Concealed Control Panel Strip
      const ctrlGeo = new THREE.BoxGeometry(dwW - 20, 30, 18);
      const ctrlMesh = new THREE.Mesh(ctrlGeo, blackMat);
      ctrlMesh.position.set(0, dwH / 2 - 15, dwZ);
      dwGroup.add(ctrlMesh);

      // Top Edge LED Countdown Display ("0:45")
      const timeGeo = new THREE.BoxGeometry(40, 12, 2);
      const timeMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
      const timeMesh = new THREE.Mesh(timeGeo, timeMat);
      timeMesh.position.set(0, dwH / 2 - 15, dwZ + 10);
      dwGroup.add(timeMesh);

      // Program Status LEDs (Eco, Auto, Quick)
      for (let p = 0; p < 4; p++) {
        const ledGeo = new THREE.CylinderGeometry(2, 2, 2, 12);
        const ledMat = new THREE.MeshBasicMaterial({ color: p === 0 ? 0x22c55e : 0x94a3b8 });
        const ledMesh = new THREE.Mesh(ledGeo, ledMat);
        ledMesh.rotation.x = Math.PI / 2;
        ledMesh.position.set(-dwW * 0.35 + p * 18, dwH / 2 - 15, dwZ + 10);
        dwGroup.add(ledMesh);
      }

      // Horizontal Bar Handle on Standoffs
      const barLen = dwW * 0.7;
      const barY = dwH / 2 - 50;
      const barGeo = new THREE.CylinderGeometry(7, 7, barLen, 16);
      const barMesh = new THREE.Mesh(barGeo, brushedSteelMat);
      barMesh.rotation.z = Math.PI / 2;
      barMesh.position.set(0, barY, dwZ + 28);
      dwGroup.add(barMesh);

      [-barLen / 2 + 20, barLen / 2 - 20].forEach((sx) => {
        const stGeo = new THREE.CylinderGeometry(6, 6, 20, 12);
        const stMesh = new THREE.Mesh(stGeo, brushedSteelMat);
        stMesh.rotation.x = Math.PI / 2;
        stMesh.position.set(sx, barY, dwZ + 18);
        dwGroup.add(stMesh);
      });

      // Bottom Floor InfoLight Beam (Blue dot on floor while cycle runs)
      const dotGeo = new THREE.CylinderGeometry(14, 14, 2, 16);
      const dotMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
      const dotMesh = new THREE.Mesh(dotGeo, dotMat);
      dotMesh.position.set(0, -legH - u.height / 2 + 2, dwZ + 60);
      dwGroup.add(dotMesh);

      this.group.add(dwGroup);
    }

    // 12. Clothes Hanging Rail (علاقة ملابس في الدواليب)
    else if (u.accessoryType === 'clothes_rod') {
      const railGeo = new THREE.CylinderGeometry(14, 14, u.width - 40, 16);
      const railMesh = new THREE.Mesh(railGeo, steelMat);
      railMesh.rotation.z = Math.PI / 2;
      railMesh.position.set(0, legH + u.height - 250, 0);
      this.group.add(railMesh);
    }

    // 13. Wire Spice & Oil Bottle Pull-Out Basket (سلة زيوت وبهارات سلكية ستانلس قابلة للسحب)
    else if (u.accessoryType === 'wire_basket_spice') {
      const spiceGroup = new THREE.Group();
      spiceGroup.name = 'spice_basket_pullout';
      spiceGroup.userData = { isDrawer: true, drawerIndex: 0, unitId: u.id, isBasket: true };
      spiceGroup.position.set(0, legH, 0);

      const bW = u.width - 36;
      const bD = u.depth - 50;
      const bH = u.height - 50;

      // Chrome Wire Vertical Uprights
      const postGeo = new THREE.CylinderGeometry(4, 4, bH, 8);
      const p1 = new THREE.Mesh(postGeo, steelMat);
      p1.position.set(-bW / 2 + 8, bH / 2, -bD / 2 + 8);
      spiceGroup.add(p1);
      const p2 = new THREE.Mesh(postGeo, steelMat);
      p2.position.set(bW / 2 - 8, bH / 2, -bD / 2 + 8);
      spiceGroup.add(p2);

      // Two Wire Tiers with Baskets
      const tierYs = [50, bH * 0.55];
      tierYs.forEach((ty, idx) => {
        // Wire Tray base
        const trayGeo = new THREE.BoxGeometry(bW, 8, bD);
        const trayMesh = new THREE.Mesh(trayGeo, steelMat);
        trayMesh.position.set(0, ty, 0);
        spiceGroup.add(trayMesh);

        // Guard Rail
        const railGeo = new THREE.BoxGeometry(bW, 35, 4);
        const r1 = new THREE.Mesh(railGeo, steelMat);
        r1.position.set(0, ty + 20, bD / 2 - 2);
        spiceGroup.add(r1);

        // Simulated Glass Bottles / Spice Jars
        const bottleCount = Math.floor(bD / 80);
        const glassJarMat = getThreeMaterial('glass_clear', '#60a5fa', shadingMode);
        const oilCapMat = getThreeMaterial('metal_brushed_brass', '#eab308', shadingMode);

        for (let b = 0; b < bottleCount; b++) {
          const bz = -bD / 2 + 45 + b * 75;
          const bottleH = idx === 0 ? 150 : 80;
          const bottleGeo = new THREE.CylinderGeometry(idx === 0 ? 18 : 14, idx === 0 ? 20 : 16, bottleH, 12);
          const bottleMesh = new THREE.Mesh(bottleGeo, glassJarMat);
          bottleMesh.position.set(0, ty + bottleH / 2 + 4, bz);
          spiceGroup.add(bottleMesh);

          const capGeo = new THREE.CylinderGeometry(8, 8, 12, 8);
          const capMesh = new THREE.Mesh(capGeo, oilCapMat);
          capMesh.position.set(0, ty + bottleH + 8, bz);
          spiceGroup.add(capMesh);
        }
      });

      this.group.add(spiceGroup);

      // Register pull-out slide for smooth interactive animation and tour
      this.drawerSlides.push({
        drawerGroup: spiceGroup,
        drawerIndex: 0,
        currentAmount: u.drawers?.[0]?.openAmount || 0,
        targetAmount: u.drawers?.[0]?.targetAmount || 0,
        maxTravel: bD * 0.75,
        openSpeed: 0.4,
      });
    }

    // 14. Wire Dish & Plate Organizer Pull-Out Rack (سلة مواعين وصحون هيدروليكية قابلة للسحب)
    else if (u.accessoryType === 'wire_basket_dishes') {
      const dishGroup = new THREE.Group();
      dishGroup.name = 'dish_basket_pullout';
      dishGroup.userData = { isDrawer: true, drawerIndex: 0, unitId: u.id, isBasket: true };
      dishGroup.position.set(0, legH, 0);

      const bW = u.width - 40;
      const bD = u.depth - 60;
      const tierH = (u.height - 60) / 2;

      // Bottom & Upper Wire Baskets
      [40, tierH + 50].forEach((baseY, tIdx) => {
        // Wire Frame Mesh
        const basketBase = new THREE.BoxGeometry(bW, 8, bD);
        const bMesh = new THREE.Mesh(basketBase, steelMat);
        bMesh.position.set(0, baseY, 0);
        dishGroup.add(bMesh);

        // Wire Basket Side Walls
        const wallGeo = new THREE.BoxGeometry(bW, 60, 4);
        const wF = new THREE.Mesh(wallGeo, steelMat);
        wF.position.set(0, baseY + 30, bD / 2);
        dishGroup.add(wF);
        const wB = new THREE.Mesh(wallGeo, steelMat);
        wB.position.set(0, baseY + 30, -bD / 2);
        dishGroup.add(wB);

        // Simulated Upright Ceramic Plates
        const plateCount = Math.min(8, Math.floor(bW / 45));
        const plateMat = getThreeMaterial('mdf_matt_white', '#ffffff', shadingMode);
        for (let p = 0; p < plateCount; p++) {
          const px = -bW / 2 + 40 + p * 38;
          const plateGeo = new THREE.CylinderGeometry(tIdx === 0 ? 75 : 55, tIdx === 0 ? 75 : 55, 6, 24);
          const plateMesh = new THREE.Mesh(plateGeo, plateMat);
          plateMesh.rotation.z = Math.PI / 2;
          plateMesh.position.set(px, baseY + 80, 0);
          dishGroup.add(plateMesh);
        }
      });

      this.group.add(dishGroup);

      // Register pull-out slide for smooth interactive animation
      this.drawerSlides.push({
        drawerGroup: dishGroup,
        drawerIndex: 0,
        currentAmount: u.drawers?.[0]?.openAmount || 0,
        targetAmount: u.drawers?.[0]?.targetAmount || 0,
        maxTravel: bD * 0.75,
        openSpeed: 0.4,
      });
    }

    // 15. Corner Rotating Carousel / Lazy Susan (صينية ركن دوارة 360 درجة)
    else if (u.accessoryType === 'corner_carousel' || u.accessoryType === 'corner_lemans') {
      const carouselGroup = new THREE.Group();
      carouselGroup.position.set(0, legH, 0);

      // Central Chrome Mast Axis
      const mastGeo = new THREE.CylinderGeometry(14, 14, u.height - 40, 16);
      const mast = new THREE.Mesh(mastGeo, steelMat);
      mast.position.set(0, u.height / 2, 0);
      carouselGroup.add(mast);

      // 2 Tier Rotating Round Trays (Three-Quarter Pie Cutout)
      const trayRadius = Math.min(u.width, u.depth) * 0.42;
      [u.height * 0.25, u.height * 0.7].forEach((trayY) => {
        const trayGeo = new THREE.CylinderGeometry(trayRadius, trayRadius, 10, 32, 1, false, 0, Math.PI * 1.5);
        const trayMesh = new THREE.Mesh(trayGeo, steelMat);
        trayMesh.position.set(0, trayY, 0);
        carouselGroup.add(trayMesh);

        // Chrome Guard Rail around perimeter
        const railGeo = new THREE.TorusGeometry(trayRadius, 5, 8, 32, Math.PI * 1.5);
        const rail = new THREE.Mesh(railGeo, steelMat);
        rail.rotation.x = Math.PI / 2;
        rail.position.set(0, trayY + 25, 0);
        carouselGroup.add(rail);
      });

      this.group.add(carouselGroup);
    }

    // 15b. Magic Corner Articulating Wire Trays (نظام ماجيك كورنر سحب هيدروليكي)
    else if (u.accessoryType === 'corner_magic') {
      const magicGroup = new THREE.Group();
      magicGroup.position.set(0, legH, 0);

      const tW = u.width * 0.38;
      const tD = u.depth * 0.72;
      [u.height * 0.22, u.height * 0.65].forEach((trayY) => {
        // Front articulating tray
        const frontTrayGeo = new THREE.BoxGeometry(tW, 10, tD * 0.48);
        const fTray = new THREE.Mesh(frontTrayGeo, steelMat);
        fTray.position.set(-u.width * 0.15, trayY, tD * 0.2);
        magicGroup.add(fTray);

        // Rear articulating tray
        const backTrayGeo = new THREE.BoxGeometry(tW, 10, tD * 0.48);
        const bTray = new THREE.Mesh(backTrayGeo, steelMat);
        bTray.position.set(u.width * 0.18, trayY, -tD * 0.15);
        magicGroup.add(bTray);

        // Chrome railing
        const railGeo = new THREE.BoxGeometry(tW + 4, 30, 4);
        const rF = new THREE.Mesh(railGeo, steelMat);
        rF.position.set(-u.width * 0.15, trayY + 15, tD * 0.44);
        magicGroup.add(rF);
      });

      // Chrome pivot arms
      const armGeo = new THREE.BoxGeometry(12, 12, tD * 0.6);
      const arm1 = new THREE.Mesh(armGeo, steelMat);
      arm1.position.set(0, u.height * 0.45, 0);
      magicGroup.add(arm1);

      this.group.add(magicGroup);
    }

    // 16. Side by Side American Refrigerator (ثلاجة سبيس جنباً إلى جنب)
    else if (u.accessoryType === 'refrigerator_side_by_side') {
      const fridgeGroup = new THREE.Group();
      fridgeGroup.position.set(0, legH, 0);

      const fridgeColor = u.applianceColor || '#94a3b8';
      const customFridgeMat = getThreeMaterial('metal_brushed_steel', fridgeColor, shadingMode);

      const bodyGeo = new THREE.BoxGeometry(u.width, u.height, u.depth);
      const bodyMesh = new THREE.Mesh(bodyGeo, customFridgeMat);
      bodyMesh.position.set(0, u.height / 2, 0);
      bodyMesh.castShadow = true;
      fridgeGroup.add(bodyMesh);

      // Left Freezer Door & Right Refrigerator Door
      const lW = u.width * 0.42;
      const rW = u.width * 0.55;
      const dH = u.height - 20;

      const lDoorGeo = new THREE.BoxGeometry(lW, dH, 40);
      const lDoor = new THREE.Mesh(lDoorGeo, customFridgeMat);
      lDoor.position.set(-u.width / 2 + lW / 2 + 2, u.height / 2, u.depth / 2 + 20);
      fridgeGroup.add(lDoor);

      const rDoorGeo = new THREE.BoxGeometry(rW, dH, 40);
      const rDoor = new THREE.Mesh(rDoorGeo, customFridgeMat);
      rDoor.position.set(u.width / 2 - rW / 2 - 2, u.height / 2, u.depth / 2 + 20);
      fridgeGroup.add(rDoor);

      // Water & Ice Dispenser on Left Door
      const dispGeo = new THREE.BoxGeometry(lW * 0.7, 240, 16);
      const dispMesh = new THREE.Mesh(dispGeo, blackMat);
      dispMesh.position.set(-u.width / 2 + lW / 2 + 2, u.height * 0.58, u.depth / 2 + 35);
      fridgeGroup.add(dispMesh);

      // Dual Heavy Handles
      const hGeo = new THREE.CylinderGeometry(8, 8, dH * 0.65, 16);
      const lh = new THREE.Mesh(hGeo, brassMat);
      lh.position.set(-15, u.height / 2, u.depth / 2 + 50);
      fridgeGroup.add(lh);
      const rh = new THREE.Mesh(hGeo, brassMat);
      rh.position.set(15, u.height / 2, u.depth / 2 + 50);
      fridgeGroup.add(rh);

      this.group.add(fridgeGroup);
    }

    // 17. Under-Counter Beverage Mini-Fridge (ثلاجة مشروبات أسفل الرخام)
    else if (u.accessoryType === 'refrigerator_under') {
      const fridgeGroup = new THREE.Group();
      fridgeGroup.position.set(0, legH, 0);

      // Glass front door with black frame
      const frameGeo = new THREE.BoxGeometry(u.width - 10, u.height - 10, 20);
      const frameMesh = new THREE.Mesh(frameGeo, blackMat);
      frameMesh.position.set(0, u.height / 2, u.depth / 2 + 10);
      fridgeGroup.add(frameMesh);

      const glassDoorGeo = new THREE.BoxGeometry(u.width - 70, u.height - 70, 8);
      const glassDoorMat = getThreeMaterial('glass_smoked', '#1e293b', shadingMode);
      const glassMesh = new THREE.Mesh(glassDoorGeo, glassDoorMat);
      glassMesh.position.set(0, u.height / 2, u.depth / 2 + 16);
      fridgeGroup.add(glassMesh);

      // Blue LED glow
      const ledGeo = new THREE.BoxGeometry(u.width - 80, 4, 10);
      const ledMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
      const led = new THREE.Mesh(ledGeo, ledMat);
      led.position.set(0, u.height - 40, u.depth / 2 - 20);
      fridgeGroup.add(led);

      this.group.add(fridgeGroup);
    }

    // 18. Bedroom Vanity Dressing Lighted Mirror (تسريحة مع مرآة مضيئة)
    else if (u.accessoryType === 'dressing_mirror') {
      const vanityGroup = new THREE.Group();
      vanityGroup.position.set(0, legH + u.height, -u.depth * 0.25);

      // Circular Lighted Mirror
      const mirrorRadius = Math.min(u.width * 0.4, 400);
      const mirrorGeo = new THREE.CylinderGeometry(mirrorRadius, mirrorRadius, 8, 32);
      const mirrorMat = getThreeMaterial('glass_clear', '#e2e8f0', shadingMode);
      const mirror = new THREE.Mesh(mirrorGeo, mirrorMat);
      mirror.rotation.x = Math.PI / 2;
      mirror.position.set(0, mirrorRadius + 40, 0);
      vanityGroup.add(mirror);

      // Illuminated Brass Halo Ring Frame
      const haloGeo = new THREE.TorusGeometry(mirrorRadius + 8, 8, 16, 48);
      const haloMat = new THREE.MeshBasicMaterial({ color: 0xfef08a });
      const halo = new THREE.Mesh(haloGeo, haloMat);
      halo.position.set(0, mirrorRadius + 40, 2);
      vanityGroup.add(halo);

      this.group.add(vanityGroup);
    }

    // 19. King/Queen Size Bed Frame & Upholstered Headboard (سرير نوم فاخر مع خلفية)
    else if (u.accessoryType === 'bed_headboard') {
      const bedGroup = new THREE.Group();
      const woodBedMat = getThreeMaterial('wood_natural_oak', '#a8794c', shadingMode);
      const fabricMat = getThreeMaterial('mdf_matt_white', '#cbd5e1', shadingMode);

      // Padded High Headboard
      const headH = Math.max(1000, u.height);
      const headGeo = new THREE.BoxGeometry(u.width, headH, 80);
      const headMesh = new THREE.Mesh(headGeo, fabricMat);
      headMesh.position.set(0, headH / 2, -u.depth / 2 + 40);
      bedGroup.add(headMesh);

      // Bed Base Frame
      const frameGeo = new THREE.BoxGeometry(u.width * 0.9, 300, u.depth - 100);
      const fMesh = new THREE.Mesh(frameGeo, woodBedMat);
      fMesh.position.set(0, 150, 40);
      bedGroup.add(fMesh);

      // Mattress
      const matGeo = new THREE.BoxGeometry(u.width * 0.86, 250, u.depth - 140);
      const matMesh = new THREE.Mesh(matGeo, fabricMat);
      matMesh.position.set(0, 350, 40);
      bedGroup.add(matMesh);

      // Two Soft Pillows
      const pillowGeo = new THREE.BoxGeometry(u.width * 0.35, 70, 260);
      const p1 = new THREE.Mesh(pillowGeo, fabricMat);
      p1.position.set(-u.width * 0.22, 500, -u.depth * 0.22);
      bedGroup.add(p1);
      const p2 = new THREE.Mesh(pillowGeo, fabricMat);
      p2.position.set(u.width * 0.22, 500, -u.depth * 0.22);
      bedGroup.add(p2);

      this.group.add(bedGroup);
    }
  }

  private createLuxuryFaucetMesh(material: THREE.Material): THREE.Group {
    const faucet = new THREE.Group();

    // Base pedestal
    const baseGeo = new THREE.CylinderGeometry(16, 20, 40, 24);
    const baseMesh = new THREE.Mesh(baseGeo, material);
    faucet.add(baseMesh);

    // Vertical riser
    const riserGeo = new THREE.CylinderGeometry(10, 10, 140, 24);
    const riserMesh = new THREE.Mesh(riserGeo, material);
    riserMesh.position.set(0, 70, 0);
    faucet.add(riserMesh);

    // Arch Gooseneck Spout (Torus arc)
    const arcGeo = new THREE.TorusGeometry(65, 9, 16, 32, Math.PI);
    const arcMesh = new THREE.Mesh(arcGeo, material);
    arcMesh.rotation.y = -Math.PI / 2;
    arcMesh.position.set(0, 140, 65);
    faucet.add(arcMesh);

    // Pull-down sprayer head nozzle
    const nozzleGeo = new THREE.CylinderGeometry(12, 10, 30, 24);
    const nozzleMesh = new THREE.Mesh(nozzleGeo, material);
    nozzleMesh.position.set(0, 120, 130);
    faucet.add(nozzleMesh);

    // Single-lever mixer handle on right
    const leverGeo = new THREE.CylinderGeometry(4, 4, 60, 12);
    const leverMesh = new THREE.Mesh(leverGeo, material);
    leverMesh.rotation.z = Math.PI / 4;
    leverMesh.position.set(25, 45, 0);
    faucet.add(leverMesh);

    return faucet;
  }

  public addSelectionHighlight(): void {
    if (this.selectionBox) {
      this.group.remove(this.selectionBox);
    }
    const box = new THREE.Box3().setFromObject(this.group);
    const size = new THREE.Vector3();
    box.getSize(size);
    
    const outlineGeo = new THREE.BoxGeometry(size.x + 8, size.y + 8, size.z + 8);
    const outlineEdges = new THREE.EdgesGeometry(outlineGeo);
    const outlineLine = new THREE.LineSegments(
      outlineEdges,
      new THREE.LineBasicMaterial({ color: 0x38bdf8, linewidth: 2 })
    );
    outlineLine.name = 'selection_outline';
    outlineLine.position.set(0, this.unitData.height / 2 + (this.unitData.legsHeight || 0) / 2, 0);
    this.selectionBox = outlineLine;
    this.group.add(outlineLine);
  }

  public removeSelectionHighlight(): void {
    const existing = this.group.getObjectByName('selection_outline');
    if (existing) {
      this.group.remove(existing);
      this.selectionBox = null;
    }
  }

  /**
   * Smoothly animates doors and drawers each frame based on delta time
   */
  public updateAnimations(deltaTime: number): boolean {
    let hasChanges = false;

    // Animate Doors
    for (const dp of this.doorPivots) {
      const diff = dp.targetAngle - dp.currentAngle;
      if (Math.abs(diff) > 0.01) {
        hasChanges = true;
        const speed = (90 / Math.max(0.1, dp.openSpeed)) * deltaTime;
        if (diff > 0) {
          dp.currentAngle = Math.min(dp.targetAngle, dp.currentAngle + speed);
        } else {
          dp.currentAngle = Math.max(dp.targetAngle, dp.currentAngle - speed);
        }

        const rad = (dp.currentAngle * Math.PI) / 180;
        if (dp.hingeSide === 'left') {
          dp.pivotGroup.rotation.y = -rad;
        } else if (dp.hingeSide === 'right') {
          dp.pivotGroup.rotation.y = rad;
        } else if (dp.hingeSide === 'top_lift') {
          dp.pivotGroup.rotation.x = -rad;
        } else if (dp.hingeSide === 'sliding') {
          dp.pivotGroup.position.x = (dp.currentAngle / 90) * (this.unitData.width / 2);
        }
      }
    }

    // Animate Drawers
    for (const ds of this.drawerSlides) {
      const diff = ds.targetAmount - ds.currentAmount;
      if (Math.abs(diff) > 0.01) {
        hasChanges = true;
        const speed = (1.0 / Math.max(0.1, ds.openSpeed)) * deltaTime;
        if (diff > 0) {
          ds.currentAmount = Math.min(ds.targetAmount, ds.currentAmount + speed);
        } else {
          ds.currentAmount = Math.max(ds.targetAmount, ds.currentAmount - speed);
        }

        ds.drawerGroup.position.z = ds.currentAmount * ds.maxTravel;
      }
    }

    return hasChanges;
  }

  public toggleDoor(doorIndex: number = 0): void {
    if (this.doorPivots[doorIndex]) {
      const dp = this.doorPivots[doorIndex];
      dp.targetAngle = dp.targetAngle > 45 ? 0 : 90;
      if (this.unitData.doors[doorIndex]) {
        this.unitData.doors[doorIndex].targetAngle = dp.targetAngle;
      }
    }
  }

  public toggleDrawer(drawerIndex: number = 0): void {
    if (this.drawerSlides[drawerIndex]) {
      const ds = this.drawerSlides[drawerIndex];
      ds.targetAmount = ds.targetAmount > 0.5 ? 0 : 1.0;
      if (this.unitData.drawers[drawerIndex]) {
        this.unitData.drawers[drawerIndex].targetAmount = ds.targetAmount;
      }
    }
  }

  public openAll(): void {
    this.doorPivots.forEach((dp, idx) => {
      dp.targetAngle = 90;
      if (this.unitData.doors[idx]) this.unitData.doors[idx].targetAngle = 90;
    });
    this.drawerSlides.forEach((ds, idx) => {
      ds.targetAmount = 1.0;
      if (this.unitData.drawers[idx]) this.unitData.drawers[idx].targetAmount = 1.0;
    });
  }

  public closeAll(): void {
    this.doorPivots.forEach((dp, idx) => {
      dp.targetAngle = 0;
      if (this.unitData.doors[idx]) this.unitData.doors[idx].targetAngle = 0;
    });
    this.drawerSlides.forEach((ds, idx) => {
      ds.targetAmount = 0;
      if (this.unitData.drawers[idx]) this.unitData.drawers[idx].targetAmount = 0;
    });
  }

  public toggleUnitOpenClose(): boolean {
    const hasOpenDoor = this.doorPivots.some((dp) => dp.targetAngle > 45);
    const hasOpenDrawer = this.drawerSlides.some((ds) => ds.targetAmount > 0.5);
    const isOpen = hasOpenDoor || hasOpenDrawer;

    if (isOpen) {
      this.closeAll();
      return false;
    } else {
      this.openAll();
      return true;
    }
  }

  /**
   * Builds an authentic L-shaped or 45° Diagonal Corner Cabinet
   * Resolves the issue where corner units appeared as a plain square box.
   * Constructs the true L-shaped carcase, inside 90° corner cut-out, return gables,
   * L-shaped shelves, bi-fold doors or rotating 360° carousel, and 6-point corner legs.
   */
  private buildCornerUnit(
    carcaseGroup: THREE.Group,
    bodyMat: THREE.Material,
    frontMat: THREE.Material,
    shadingMode: ShadingMode
  ): void {
    const u = this.unitData;
    const w = u.width;
    const h = u.height;
    const d = u.depth;
    const t = u.bodyThickness || 18;
    const legH = u.legsHeight || 0;
    const rawTemplateId = (u as any).templateId || '';
    const isWall = u.category === 'kitchen_wall' || rawTemplateId.includes('wall') || (u.nameAr && u.nameAr.includes('علوي'));

    // Depth of return gables connecting to neighboring straight cabinets
    // Base standard depth is ~560mm (or 60% of corner width); Wall standard depth is ~350mm (or 58% of corner width)
    const armD = isWall
      ? Math.min(Math.max(w * 0.58, 300), w - 150)
      : Math.min(Math.max(w * 0.62, 520), w - 220);

    const isDiagonal = 
      rawTemplateId.includes('diagonal') ||
      u.name?.toLowerCase().includes('diagonal') ||
      u.nameAr?.includes('شطف') ||
      u.nameAr?.includes('مائل');

    const hasCarousel = 
      u.accessoryType === 'corner_carousel' || 
      rawTemplateId.includes('carousel') || 
      u.nameAr?.includes('دوار') || 
      u.nameAr?.includes('سوزان');

    const xInner = -w / 2 + armD;
    const zInner = -d / 2 + armD;

    // 1. Orthogonal Back Panels fitting into the room corner
    // Back Wall 1 (along X, at Z = -d / 2)
    const back1Geo = new THREE.BoxGeometry(w, h, t);
    const back1 = new THREE.Mesh(back1Geo, bodyMat);
    back1.position.set(0, h / 2, -d / 2 + t / 2);
    back1.castShadow = true;
    back1.receiveShadow = true;
    carcaseGroup.add(back1);

    // Back Wall 2 (along Z, at X = -w / 2)
    const back2Geo = new THREE.BoxGeometry(t, h, d - t);
    const back2 = new THREE.Mesh(back2Geo, bodyMat);
    back2.position.set(-w / 2 + t / 2, h / 2, t / 2);
    back2.castShadow = true;
    back2.receiveShadow = true;
    carcaseGroup.add(back2);

    // 2. Return Gables (Outer sides that abut neighboring cabinets)
    // Right Gable (at X = w / 2, depth = armD)
    const rightGableGeo = new THREE.BoxGeometry(t, h, armD);
    const rightGable = new THREE.Mesh(rightGableGeo, bodyMat);
    rightGable.position.set(w / 2 - t / 2, h / 2, -d / 2 + armD / 2);
    rightGable.castShadow = true;
    rightGable.receiveShadow = true;
    carcaseGroup.add(rightGable);

    // Front-Left Gable (at Z = d / 2, width = armD)
    const frontGableGeo = new THREE.BoxGeometry(armD, h, t);
    const frontGable = new THREE.Mesh(frontGableGeo, bodyMat);
    frontGable.position.set(-w / 2 + armD / 2, h / 2, d / 2 - t / 2);
    frontGable.castShadow = true;
    frontGable.receiveShadow = true;
    carcaseGroup.add(frontGable);

    if (isDiagonal) {
      // 3A. Diagonal 45° Chamfered Unit
      const p1 = new THREE.Vector2(w / 2, -d / 2 + armD);
      const p2 = new THREE.Vector2(-w / 2 + armD, d / 2);
      const faceW = p1.distanceTo(p2);
      const angle = Math.atan2(p2.y - p1.y, p2.x - p1.x);

      const shape = new THREE.Shape();
      shape.moveTo(-w / 2, -d / 2);
      shape.lineTo(w / 2, -d / 2);
      shape.lineTo(w / 2, -d / 2 + armD);
      shape.lineTo(-w / 2 + armD, d / 2);
      shape.lineTo(-w / 2, d / 2);
      shape.closePath();

      const extrudeSettings = { depth: t, bevelEnabled: false };
      const bottomGeo = new THREE.ExtrudeGeometry(shape, extrudeSettings);
      const bottomMesh = new THREE.Mesh(bottomGeo, bodyMat);
      bottomMesh.rotation.x = Math.PI / 2;
      bottomMesh.position.set(0, t, 0);
      bottomMesh.castShadow = true;
      bottomMesh.receiveShadow = true;
      carcaseGroup.add(bottomMesh);

      if (isWall) {
        const topGeo = new THREE.ExtrudeGeometry(shape, extrudeSettings);
        const topMesh = new THREE.Mesh(topGeo, bodyMat);
        topMesh.rotation.x = Math.PI / 2;
        topMesh.position.set(0, h, 0);
        topMesh.castShadow = true;
        carcaseGroup.add(topMesh);
      }

      // Diagonal Shelf
      const shelfGeo = new THREE.ExtrudeGeometry(shape, { depth: t * 0.9, bevelEnabled: false });
      const shelfMesh = new THREE.Mesh(shelfGeo, bodyMat);
      shelfMesh.rotation.x = Math.PI / 2;
      shelfMesh.position.set(0, h / 2, 0);
      shelfMesh.scale.set(0.96, 0.96, 1);
      carcaseGroup.add(shelfMesh);

      // Angled Front Door
      const doorH = h - 6;
      const doorMesh = this.createDoorStyleMesh(faceW - 6, doorH, 18, u.doorStyle || 'slab', frontMat, shadingMode, { thickness: 18 } as any);
      doorMesh.position.set((p1.x + p2.x) / 2, h / 2, (p1.y + p2.y) / 2);
      doorMesh.rotation.y = -angle;
      carcaseGroup.add(doorMesh);

      if (u.handleConfig && u.handleConfig.style !== 'handleless') {
        const handle = this.createHandleMesh(u.handleConfig, shadingMode, false);
        handle.position.set((p1.x + p2.x) / 2 + 10, h / 2, (p1.y + p2.y) / 2 + 15);
        handle.rotation.y = -angle;
        carcaseGroup.add(handle);
      }
    } else {
      // 3B. Standard L-Shaped Corner Unit
      const shape = new THREE.Shape();
      shape.moveTo(-w / 2, -d / 2);
      shape.lineTo(w / 2, -d / 2);
      shape.lineTo(w / 2, -d / 2 + armD);
      shape.lineTo(xInner, zInner);
      shape.lineTo(xInner, d / 2);
      shape.lineTo(-w / 2, d / 2);
      shape.closePath();

      const extrudeSettings = { depth: t, bevelEnabled: false };
      // Bottom Base L-Panel
      const bottomGeo = new THREE.ExtrudeGeometry(shape, extrudeSettings);
      const bottomMesh = new THREE.Mesh(bottomGeo, bodyMat);
      bottomMesh.rotation.x = Math.PI / 2;
      bottomMesh.position.set(0, t, 0);
      bottomMesh.castShadow = true;
      bottomMesh.receiveShadow = true;
      carcaseGroup.add(bottomMesh);

      // Top L-Panel for wall cabinets, or top stretchers for base
      if (isWall) {
        const topGeo = new THREE.ExtrudeGeometry(shape, extrudeSettings);
        const topMesh = new THREE.Mesh(topGeo, bodyMat);
        topMesh.rotation.x = Math.PI / 2;
        topMesh.position.set(0, h, 0);
        topMesh.castShadow = true;
        carcaseGroup.add(topMesh);
      } else {
        const s1W = w - armD;
        const s1Geo = new THREE.BoxGeometry(s1W, t, 70);
        const s1 = new THREE.Mesh(s1Geo, bodyMat);
        s1.position.set(xInner + s1W / 2, h - t / 2, zInner - 35);
        carcaseGroup.add(s1);

        const s2D = d - armD;
        const s2Geo = new THREE.BoxGeometry(70, t, s2D);
        const s2 = new THREE.Mesh(s2Geo, bodyMat);
        s2.position.set(xInner - 35, h - t / 2, zInner + s2D / 2);
        carcaseGroup.add(s2);
      }

      // Mid-height L-Shaped Shelf
      const shelfGeo = new THREE.ExtrudeGeometry(shape, { depth: t * 0.9, bevelEnabled: false });
      const shelfMesh = new THREE.Mesh(shelfGeo, bodyMat);
      shelfMesh.rotation.x = Math.PI / 2;
      shelfMesh.position.set(0, h / 2, 0);
      shelfMesh.scale.set(0.97, 0.97, 1);
      shelfMesh.castShadow = true;
      carcaseGroup.add(shelfMesh);

      // 4. Lazy Susan Carousel or Bi-Fold Doors
      if (hasCarousel) {
        const carouselGroup = new THREE.Group();
        const carouselCenter = new THREE.Vector3(-w / 2 + armD * 0.72, 0, -d / 2 + armD * 0.72);
        const steelMat = getThreeMaterial('metal_chrome', '#f8fafc', shadingMode);

        // Center Chrome Pole
        const poleGeo = new THREE.CylinderGeometry(14, 14, h - 30, 20);
        const pole = new THREE.Mesh(poleGeo, steelMat);
        pole.position.set(carouselCenter.x, h / 2, carouselCenter.z);
        carouselGroup.add(pole);

        // Two 360° Circular Wire Trays
        const trayRadius = Math.min(w, d) * 0.38;
        [h * 0.28, h * 0.7].forEach((trayY) => {
          const trayBaseGeo = new THREE.CylinderGeometry(trayRadius, trayRadius, 6, 32);
          const trayBase = new THREE.Mesh(trayBaseGeo, steelMat);
          trayBase.position.set(carouselCenter.x, trayY, carouselCenter.z);
          carouselGroup.add(trayBase);

          const rimGeo = new THREE.TorusGeometry(trayRadius, 4, 12, 32);
          const rim = new THREE.Mesh(rimGeo, steelMat);
          rim.rotation.x = Math.PI / 2;
          rim.position.set(carouselCenter.x, trayY + 30, carouselCenter.z);
          carouselGroup.add(rim);

          for (let sp = 0; sp < 6; sp++) {
            const spokeGeo = new THREE.CylinderGeometry(2.5, 2.5, trayRadius, 8);
            const spoke = new THREE.Mesh(spokeGeo, steelMat);
            spoke.rotation.z = Math.PI / 2;
            spoke.rotation.y = (sp * Math.PI) / 3;
            spoke.position.set(carouselCenter.x, trayY + 4, carouselCenter.z);
            carouselGroup.add(spoke);
          }
        });

        carcaseGroup.add(carouselGroup);
      }

      // Bi-Fold Corner Doors (Two orthogonal doors meeting at inner 90° corner)
      // Door 1 on Face 1 (runs from xInner to w / 2 along X, facing +Z)
      const d1W = w - armD - 4;
      const doorH = h - 6;
      const door1Mesh = this.createDoorStyleMesh(d1W, doorH, 18, u.doorStyle || 'slab', frontMat, shadingMode, { thickness: 18 } as any);
      door1Mesh.position.set(xInner + d1W / 2, h / 2, zInner + 10);
      carcaseGroup.add(door1Mesh);

      // Door 2 on Face 2 (runs from zInner to d / 2 along Z, facing +X)
      const d2W = d - armD - 4;
      const door2Mesh = this.createDoorStyleMesh(d2W, doorH, 18, u.doorStyle || 'slab', frontMat, shadingMode, { thickness: 18 } as any);
      door2Mesh.rotation.y = Math.PI / 2;
      door2Mesh.position.set(xInner + 10, h / 2, zInner + d2W / 2);
      carcaseGroup.add(door2Mesh);

      // Corner Door Handles
      if (u.handleConfig && u.handleConfig.style !== 'handleless') {
        const h1 = this.createHandleMesh(u.handleConfig, shadingMode, false);
        h1.position.set(xInner + 30, h / 2, zInner + 26);
        carcaseGroup.add(h1);

        const h2 = this.createHandleMesh(u.handleConfig, shadingMode, false);
        h2.rotation.y = Math.PI / 2;
        h2.position.set(xInner + 26, h / 2, zInner + 30);
        carcaseGroup.add(h2);
      }
    }

    // 5. Corner Legs (6 legs positioned at the vertices of the L-shape or 5 for diagonal)
    if (legH > 0 && !isWall) {
      const legGeo = new THREE.CylinderGeometry(18, 14, legH, 16);
      const legMat = getThreeMaterial('metal_matte_black', '#18181b', shadingMode);

      const legPoints = isDiagonal
        ? [
            [-w / 2 + 50, -d / 2 + 50],
            [w / 2 - 50, -d / 2 + 50],
            [w / 2 - 50, -d / 2 + armD - 50],
            [-w / 2 + armD - 50, d / 2 - 50],
            [-w / 2 + 50, d / 2 - 50],
          ]
        : [
            [-w / 2 + 50, -d / 2 + 50],
            [w / 2 - 50, -d / 2 + 50],
            [w / 2 - 50, -d / 2 + armD - 50],
            [xInner - 40, zInner - 40],
            [xInner - 50, d / 2 - 50],
            [-w / 2 + 50, d / 2 - 50],
          ];

      legPoints.forEach(([lx, lz]) => {
        const legMesh = new THREE.Mesh(legGeo, legMat);
        legMesh.position.set(lx, legH / 2, lz);
        legMesh.castShadow = true;
        this.group.add(legMesh);
      });
    }
  }

  /**
   * Generates a realistic L-shaped or 45° diagonal countertop slab with marble/granite
   */
  private buildCornerCountertop(shadingMode: ShadingMode): void {
    const u = this.unitData;
    const ct = u.countertop;
    if (!ct || !ct.enabled) return;

    const w = u.width;
    const d = u.depth;
    const h = u.height;
    const legH = u.legsHeight || 0;
    const ctH = ct.thickness || 35;
    const rawTemplateId = (u as any).templateId || '';
    const isWall = u.category === 'kitchen_wall' || rawTemplateId.includes('wall');
    const armD = isWall
      ? Math.min(Math.max(w * 0.58, 300), w - 150)
      : Math.min(Math.max(w * 0.62, 520), w - 220);

    const isDiagonal = 
      rawTemplateId.includes('diagonal') ||
      u.name?.toLowerCase().includes('diagonal') ||
      u.nameAr?.includes('شطف') ||
      u.nameAr?.includes('مائل');

    const ctMat = getThreeMaterial(ct.materialId || 'marble_calacatta_gold', ct.color || '#ede8df', shadingMode);

    const overhangF = ct.overhangFront || 20;
    const xInner = -w / 2 + armD + overhangF;
    const zInner = -d / 2 + armD + overhangF;

    const shape = new THREE.Shape();
    if (isDiagonal) {
      shape.moveTo(-w / 2 - ct.overhangLeft, -d / 2 - ct.overhangBack);
      shape.lineTo(w / 2 + ct.overhangRight, -d / 2 - ct.overhangBack);
      shape.lineTo(w / 2 + ct.overhangRight, -d / 2 + armD + overhangF);
      shape.lineTo(-w / 2 + armD + overhangF, d / 2 + overhangF);
      shape.lineTo(-w / 2 - ct.overhangLeft, d / 2 + overhangF);
      shape.closePath();
    } else {
      shape.moveTo(-w / 2 - ct.overhangLeft, -d / 2 - ct.overhangBack);
      shape.lineTo(w / 2 + ct.overhangRight, -d / 2 - ct.overhangBack);
      shape.lineTo(w / 2 + ct.overhangRight, -d / 2 + armD + overhangF);
      shape.lineTo(xInner, zInner);
      shape.lineTo(xInner, d / 2 + overhangF);
      shape.lineTo(-w / 2 - ct.overhangLeft, d / 2 + overhangF);
      shape.closePath();
    }

    const ctGeo = new THREE.ExtrudeGeometry(shape, {
      depth: ctH,
      bevelEnabled: true,
      bevelThickness: 3,
      bevelSize: 3,
      bevelSegments: 2,
    });
    const ctMesh = new THREE.Mesh(ctGeo, ctMat);
    ctMesh.rotation.x = Math.PI / 2;
    ctMesh.position.set(0, legH + h + ctH, 0);
    ctMesh.castShadow = true;
    ctMesh.receiveShadow = true;
    this.group.add(ctMesh);
  }

  /**
   * Builds the Luxury Integrated Cooking Station 900mm:
   * Left 15cm Oil Pull-out Rack + Center 60cm Oven with Top Cutlery Drawer + Right 15cm Oil Pull-out Rack
   * Matching User Photos & Requirements (سلتي زيت 15 سم وبينهما فرن 60 سم وفوق الفرن درج ورخام وطباخ غازي)
   */
  private buildCookingStationCombo900(
    carcaseGroup: THREE.Group,
    bodyMat: THREE.Material,
    frontMat: THREE.Material,
    shadingMode: ShadingMode
  ): void {
    const u = this.unitData;
    const w = u.width;
    const h = u.height;
    const d = u.depth;
    const t = 18; // carcase panel thickness

    const steelMat = getThreeMaterial('metal_brushed_steel', '#e2e8f0', shadingMode);
    const chromeMat = getThreeMaterial('metal_chrome', '#f8fafc', shadingMode);
    const darkGlassMat = getThreeMaterial('glass_tinted_smoked', '#09090b', shadingMode);
    const enamelMat = getThreeMaterial('metal_matte_black', '#18181b', shadingMode);
    const brassMat = getThreeMaterial('metal_brushed_brass', '#eab308', shadingMode);
    const glassJarMat = getThreeMaterial('glass_clear', '#60a5fa', shadingMode);

    // 1. Carcase Outer Panels
    // Bottom Panel
    const bottomGeo = new THREE.BoxGeometry(w, t, d);
    const bottomMesh = new THREE.Mesh(bottomGeo, bodyMat);
    bottomMesh.position.set(0, t / 2, 0);
    carcaseGroup.add(bottomMesh);

    // Back Panel
    const backGeo = new THREE.BoxGeometry(w, h, 8);
    const backMesh = new THREE.Mesh(backGeo, bodyMat);
    backMesh.position.set(0, h / 2, -d / 2 + 4);
    carcaseGroup.add(backMesh);

    // Left Outer Gable
    const leftGableGeo = new THREE.BoxGeometry(t, h, d);
    const leftGable = new THREE.Mesh(leftGableGeo, bodyMat);
    leftGable.position.set(-w / 2 + t / 2, h / 2, 0);
    carcaseGroup.add(leftGable);

    // Right Outer Gable
    const rightGableGeo = new THREE.BoxGeometry(t, h, d);
    const rightGable = new THREE.Mesh(rightGableGeo, bodyMat);
    rightGable.position.set(w / 2 - t / 2, h / 2, 0);
    carcaseGroup.add(rightGable);

    // 2. Internal Dividers for Left & Right Oil/Spice Racks
    const rackW = Math.max(120, Math.min(250, (w - 600) / 2));
    const leftDividerX = -w / 2 + rackW;
    const rightDividerX = w / 2 - rackW;

    const divGeo = new THREE.BoxGeometry(t, h - t, d - 10);
    const leftDiv = new THREE.Mesh(divGeo, bodyMat);
    leftDiv.position.set(leftDividerX, (h + t) / 2, -5);
    carcaseGroup.add(leftDiv);

    const rightDiv = new THREE.Mesh(divGeo, bodyMat);
    rightDiv.position.set(rightDividerX, (h + t) / 2, -5);
    carcaseGroup.add(rightDiv);

    // Center Horizontal Shelf Divider between top drawer and oven
    const centerW = rightDividerX - leftDividerX - t;
    const drawerH = 135;
    const centerShelfGeo = new THREE.BoxGeometry(centerW, t, d - 20);
    const centerShelf = new THREE.Mesh(centerShelfGeo, bodyMat);
    centerShelf.position.set(0, h - drawerH - t / 2, 0);
    carcaseGroup.add(centerShelf);

    // 3. Left 15cm Oil & Spice Pull-out Rack
    const leftRackCenterX = -w / 2 + rackW / 2;
    const rackDoorW = rackW - 6;
    const rackDoorH = h - 6;

    // Door front panel
    const lDoorGeo = new THREE.BoxGeometry(rackDoorW, rackDoorH, t);
    const lDoorMesh = new THREE.Mesh(lDoorGeo, frontMat);
    lDoorMesh.position.set(leftRackCenterX, h / 2, d / 2 + t / 2 + 1);
    lDoorMesh.castShadow = true;
    carcaseGroup.add(lDoorMesh);

    // Vertical Handle on left door
    const lHandleGeo = new THREE.CylinderGeometry(5, 5, 120, 16);
    const lHandle = new THREE.Mesh(lHandleGeo, brassMat);
    lHandle.position.set(leftRackCenterX + 25, h / 2, d / 2 + t + 12);
    carcaseGroup.add(lHandle);

    // Chrome wire pull-out frame with bottles
    const lWireGroup = new THREE.Group();
    lWireGroup.position.set(leftRackCenterX, t + 10, 0);
    [50, (h - 80) * 0.55].forEach((ty, idx) => {
      const trayGeo = new THREE.BoxGeometry(rackDoorW - 20, 6, d - 80);
      const tray = new THREE.Mesh(trayGeo, steelMat);
      tray.position.set(0, ty, 0);
      lWireGroup.add(tray);

      const railGeo = new THREE.BoxGeometry(rackDoorW - 20, 30, 4);
      const rail = new THREE.Mesh(railGeo, steelMat);
      rail.position.set(0, ty + 18, (d - 80) / 2 - 2);
      lWireGroup.add(rail);

      // Glass bottles
      for (let b = 0; b < 3; b++) {
        const bz = -(d - 80) / 2 + 50 + b * 90;
        const bH = idx === 0 ? 160 : 90;
        const bGeo = new THREE.CylinderGeometry(idx === 0 ? 18 : 14, idx === 0 ? 20 : 16, bH, 12);
        const bMesh = new THREE.Mesh(bGeo, glassJarMat);
        bMesh.position.set(0, ty + bH / 2 + 4, bz);
        lWireGroup.add(bMesh);

        const capGeo = new THREE.CylinderGeometry(8, 8, 12, 8);
        const cap = new THREE.Mesh(capGeo, brassMat);
        cap.position.set(0, ty + bH + 8, bz);
        lWireGroup.add(cap);
      }
    });
    carcaseGroup.add(lWireGroup);

    // 4. Right 15cm Oil & Spice Pull-out Rack
    const rightRackCenterX = w / 2 - rackW / 2;
    const rDoorMesh = new THREE.Mesh(lDoorGeo, frontMat);
    rDoorMesh.position.set(rightRackCenterX, h / 2, d / 2 + t / 2 + 1);
    rDoorMesh.castShadow = true;
    carcaseGroup.add(rDoorMesh);

    const rHandle = new THREE.Mesh(lHandleGeo, brassMat);
    rHandle.position.set(rightRackCenterX - 25, h / 2, d / 2 + t + 12);
    carcaseGroup.add(rHandle);

    const rWireGroup = new THREE.Group();
    rWireGroup.position.set(rightRackCenterX, t + 10, 0);
    [50, (h - 80) * 0.55].forEach((ty, idx) => {
      const trayGeo = new THREE.BoxGeometry(rackDoorW - 20, 6, d - 80);
      const tray = new THREE.Mesh(trayGeo, steelMat);
      tray.position.set(0, ty, 0);
      rWireGroup.add(tray);

      const railGeo = new THREE.BoxGeometry(rackDoorW - 20, 30, 4);
      const rail = new THREE.Mesh(railGeo, steelMat);
      rail.position.set(0, ty + 18, (d - 80) / 2 - 2);
      rWireGroup.add(rail);

      for (let b = 0; b < 3; b++) {
        const bz = -(d - 80) / 2 + 50 + b * 90;
        const bH = idx === 0 ? 160 : 90;
        const bGeo = new THREE.CylinderGeometry(idx === 0 ? 18 : 14, idx === 0 ? 20 : 16, bH, 12);
        const bMesh = new THREE.Mesh(bGeo, glassJarMat);
        bMesh.position.set(0, ty + bH / 2 + 4, bz);
        rWireGroup.add(bMesh);

        const capGeo = new THREE.CylinderGeometry(8, 8, 12, 8);
        const cap = new THREE.Mesh(capGeo, brassMat);
        cap.position.set(0, ty + bH + 8, bz);
        rWireGroup.add(cap);
      }
    });
    carcaseGroup.add(rWireGroup);

    // 5. Center Section: Top Cutlery Drawer
    const drawerFaceGeo = new THREE.BoxGeometry(centerW - 6, drawerH - 6, t);
    const drawerFace = new THREE.Mesh(drawerFaceGeo, frontMat);
    drawerFace.position.set(0, h - drawerH / 2, d / 2 + t / 2 + 1);
    drawerFace.castShadow = true;
    carcaseGroup.add(drawerFace);

    // Horizontal handle on top cutlery drawer
    const drawerHandleGeo = new THREE.BoxGeometry(Math.min(centerW * 0.45, 240), 10, 18);
    const drawerHandle = new THREE.Mesh(drawerHandleGeo, brassMat);
    drawerHandle.position.set(0, h - drawerH / 2, d / 2 + t + 10);
    carcaseGroup.add(drawerHandle);

    // 6. Center Section: Lower Built-in 600mm Luxury Oven
    const ovenH = h - drawerH - t;
    const ovenGroup = new THREE.Group();
    ovenGroup.position.set(0, ovenH / 2, 0);

    // Oven Outer Frame
    const ovenFrameGeo = new THREE.BoxGeometry(centerW - 8, ovenH - 8, 20);
    const ovenFrame = new THREE.Mesh(ovenFrameGeo, enamelMat);
    ovenFrame.position.set(0, 0, d / 2 + 8);
    ovenGroup.add(ovenFrame);

    // Smoked Black Glass Window
    const glassGeo = new THREE.BoxGeometry(centerW - 60, ovenH * 0.58, 6);
    const glassMesh = new THREE.Mesh(glassGeo, darkGlassMat);
    glassMesh.position.set(0, -15, d / 2 + 19);
    ovenGroup.add(glassMesh);

    // Oven Control Fascia Panel (Brushed Stainless / Black)
    const fasciaGeo = new THREE.BoxGeometry(centerW - 12, ovenH * 0.22, 6);
    const fascia = new THREE.Mesh(fasciaGeo, steelMat);
    fascia.position.set(0, ovenH / 2 - ovenH * 0.11 - 6, d / 2 + 19);
    ovenGroup.add(fascia);

    // Digital LED Display in Center
    const displayGeo = new THREE.BoxGeometry(60, 24, 2);
    const displayMat = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });
    const display = new THREE.Mesh(displayGeo, displayMat);
    display.position.set(0, ovenH / 2 - ovenH * 0.11 - 6, d / 2 + 23);
    ovenGroup.add(display);

    // 2 Rotary Knobs on Fascia
    [-80, 80].forEach((kx) => {
      const knobGeo = new THREE.CylinderGeometry(14, 14, 12, 20);
      const knob = new THREE.Mesh(knobGeo, steelMat);
      knob.rotation.x = Math.PI / 2;
      knob.position.set(kx, ovenH / 2 - ovenH * 0.11 - 6, d / 2 + 25);
      ovenGroup.add(knob);
    });

    // Horizontal Oven Door Towel-Bar Handle
    const oHandleBarGeo = new THREE.BoxGeometry(centerW * 0.65, 14, 14);
    const oHandleBar = new THREE.Mesh(oHandleBarGeo, chromeMat);
    oHandleBar.position.set(0, ovenH * 0.15, d / 2 + 36);
    ovenGroup.add(oHandleBar);

    // Internal illuminated oven cavity
    const cavW = centerW - 40;
    const cavH = ovenH * 0.68;
    const cavD = d - 80;
    const cavGeo = new THREE.BoxGeometry(cavW, cavH, cavD);
    const cavMesh = new THREE.Mesh(cavGeo, enamelMat);
    cavMesh.position.set(0, -10, 0);
    ovenGroup.add(cavMesh);

    // Chrome wire baking rack inside oven
    const rackMeshGeo = new THREE.BoxGeometry(cavW - 16, 4, cavD - 20);
    const rackMesh = new THREE.Mesh(rackMeshGeo, chromeMat);
    rackMesh.position.set(0, -10, 0);
    ovenGroup.add(rackMesh);

    carcaseGroup.add(ovenGroup);
  }

  /**
   * Builds the Luxury 900mm Countertop with 5-Burner Gas Cooktop (Electrolux Style)
   */
  private buildCookingStationCountertop(shadingMode: ShadingMode): void {
    const u = this.unitData;
    const w = u.width;
    const h = u.height;
    const d = u.depth;
    const legH = u.legsHeight || 0;
    const ctH = u.countertop?.thickness || 35;

    const marbleMat = getThreeMaterial(u.countertop?.materialId || 'marble_calacatta_gold', u.countertop?.color || '#ede8df', shadingMode);
    const steelMat = getThreeMaterial('metal_brushed_steel', '#e2e8f0', shadingMode);
    const castIronMat = getThreeMaterial('metal_cast_iron', '#18181b', shadingMode);
    const brassMat = getThreeMaterial('metal_brushed_brass', '#eab308', shadingMode);

    // 1. Marble Countertop Slab (Harmonized seamlessly with adjacent units)
    const ohL = u.countertop?.overhangLeft ?? 0;
    const ohR = u.countertop?.overhangRight ?? 0;
    const ohF = u.countertop?.overhangFront ?? 25;
    const ohB = u.countertop?.overhangBack ?? 0;
    const ctW = w + ohL + ohR;
    const ctD = d + ohF + ohB;
    const ctGeo = new THREE.BoxGeometry(ctW, ctH, ctD);
    const ctMesh = new THREE.Mesh(ctGeo, marbleMat);
    ctMesh.position.set((ohR - ohL) / 2, legH + h + ctH / 2, (ohF - ohB) / 2);
    ctMesh.castShadow = true;
    ctMesh.receiveShadow = true;
    this.group.add(ctMesh);

    // 2. Built-in 5-Burner Gas Cooktop (طباخ غازي منضدي 5 عيون مسطح كما في صورة 3)
    const hobGroup = new THREE.Group();
    hobGroup.position.set(0, legH + h + ctH + 2, 5);

    // Stainless steel base hob tray
    const hobW = Math.min(w - 60, 860);
    const hobD = Math.min(d - 60, 510);
    const hobTrayGeo = new THREE.BoxGeometry(hobW, 6, hobD);
    const hobTray = new THREE.Mesh(hobTrayGeo, steelMat);
    hobTray.position.set(0, 3, 0);
    hobGroup.add(hobTray);

    // 5 Burner Grates (1 Central Large Wok Burner + 4 Corner Burners)
    const burners = [
      { x: 0, z: -10, rad: 70, isWok: true },
      { x: -hobW * 0.3, z: -hobD * 0.24, rad: 48, isWok: false },
      { x: -hobW * 0.3, z: hobD * 0.22, rad: 42, isWok: false },
      { x: hobW * 0.3, z: -hobD * 0.24, rad: 55, isWok: false },
      { x: hobW * 0.3, z: hobD * 0.22, rad: 45, isWok: false },
    ];

    burners.forEach((b) => {
      // Brass core
      const coreGeo = new THREE.CylinderGeometry(b.rad * 0.38, b.rad * 0.38, 7, 24);
      const core = new THREE.Mesh(coreGeo, brassMat);
      core.position.set(b.x, 8, b.z);
      hobGroup.add(core);

      // Cast iron cap
      const capGeo = new THREE.CylinderGeometry(b.rad * 0.5, b.rad * 0.5, 5, 24);
      const cap = new THREE.Mesh(capGeo, castIronMat);
      cap.position.set(b.x, 12, b.z);
      hobGroup.add(cap);

      // Heavy duty cast iron spider grates
      const grateGeo1 = new THREE.BoxGeometry(b.rad * 1.8, 8, 10);
      const g1 = new THREE.Mesh(grateGeo1, castIronMat);
      g1.position.set(b.x, 14, b.z);
      hobGroup.add(g1);

      const grateGeo2 = new THREE.BoxGeometry(10, 8, b.rad * 1.8);
      const g2 = new THREE.Mesh(grateGeo2, castIronMat);
      g2.position.set(b.x, 14, b.z);
      hobGroup.add(g2);

      if (b.isWok) {
        // Wok ring support
        const wokRingGeo = new THREE.TorusGeometry(b.rad * 0.85, 4, 8, 32);
        const wokRing = new THREE.Mesh(wokRingGeo, castIronMat);
        wokRing.rotation.x = Math.PI / 2;
        wokRing.position.set(b.x, 18, b.z);
        hobGroup.add(wokRing);
      }
    });

    // 5 Front Control Knobs with Chrome / Black Trim
    for (let k = 0; k < 5; k++) {
      const knobX = -hobW * 0.28 + k * (hobW * 0.14);
      const knobGeo = new THREE.CylinderGeometry(11, 11, 12, 16);
      const knob = new THREE.Mesh(knobGeo, steelMat);
      knob.position.set(knobX, 9, hobD * 0.4);
      hobGroup.add(knob);
    }

    this.group.add(hobGroup);
  }

  /**
   * Builds the 600mm Oven Base Cabinet with Top Cutlery Drawer
   */
  private buildOvenWithTopDrawerBase(
    carcaseGroup: THREE.Group,
    bodyMat: THREE.Material,
    frontMat: THREE.Material,
    shadingMode: ShadingMode
  ): void {
    const u = this.unitData;
    const w = u.width;
    const h = u.height;
    const d = u.depth;
    const t = 18;

    const steelMat = getThreeMaterial('metal_brushed_steel', '#e2e8f0', shadingMode);
    const chromeMat = getThreeMaterial('metal_chrome', '#f8fafc', shadingMode);
    const darkGlassMat = getThreeMaterial('glass_tinted_smoked', '#09090b', shadingMode);
    const enamelMat = getThreeMaterial('metal_matte_black', '#18181b', shadingMode);
    const brassMat = getThreeMaterial('metal_brushed_brass', '#eab308', shadingMode);

    // Carcase outer box
    const bottomGeo = new THREE.BoxGeometry(w, t, d);
    const bottomMesh = new THREE.Mesh(bottomGeo, bodyMat);
    bottomMesh.position.set(0, t / 2, 0);
    carcaseGroup.add(bottomMesh);

    const backGeo = new THREE.BoxGeometry(w, h, 8);
    const backMesh = new THREE.Mesh(backGeo, bodyMat);
    backMesh.position.set(0, h / 2, -d / 2 + 4);
    carcaseGroup.add(backMesh);

    const leftGableGeo = new THREE.BoxGeometry(t, h, d);
    const leftGable = new THREE.Mesh(leftGableGeo, bodyMat);
    leftGable.position.set(-w / 2 + t / 2, h / 2, 0);
    carcaseGroup.add(leftGable);

    const rightGableGeo = new THREE.BoxGeometry(t, h, d);
    const rightGable = new THREE.Mesh(rightGableGeo, bodyMat);
    rightGable.position.set(w / 2 - t / 2, h / 2, 0);
    carcaseGroup.add(rightGable);

    // Shelf divider
    const drawerH = 135;
    const centerShelfGeo = new THREE.BoxGeometry(w - 2 * t, t, d - 20);
    const centerShelf = new THREE.Mesh(centerShelfGeo, bodyMat);
    centerShelf.position.set(0, h - drawerH - t / 2, 0);
    carcaseGroup.add(centerShelf);

    // Top Cutlery Drawer
    const drawerFaceGeo = new THREE.BoxGeometry(w - 6, drawerH - 6, t);
    const drawerFace = new THREE.Mesh(drawerFaceGeo, frontMat);
    drawerFace.position.set(0, h - drawerH / 2, d / 2 + t / 2 + 1);
    drawerFace.castShadow = true;
    carcaseGroup.add(drawerFace);

    const drawerHandleGeo = new THREE.BoxGeometry(Math.min(w * 0.45, 240), 10, 18);
    const drawerHandle = new THREE.Mesh(drawerHandleGeo, brassMat);
    drawerHandle.position.set(0, h - drawerH / 2, d / 2 + t + 10);
    carcaseGroup.add(drawerHandle);

    // Lower Built-in 600mm Oven
    const ovenH = h - drawerH - t;
    const ovenGroup = new THREE.Group();
    ovenGroup.position.set(0, ovenH / 2, 0);

    const ovenFrameGeo = new THREE.BoxGeometry(w - 8, ovenH - 8, 20);
    const ovenFrame = new THREE.Mesh(ovenFrameGeo, enamelMat);
    ovenFrame.position.set(0, 0, d / 2 + 8);
    ovenGroup.add(ovenFrame);

    const glassGeo = new THREE.BoxGeometry(w - 50, ovenH * 0.58, 6);
    const glassMesh = new THREE.Mesh(glassGeo, darkGlassMat);
    glassMesh.position.set(0, -15, d / 2 + 19);
    ovenGroup.add(glassMesh);

    const fasciaGeo = new THREE.BoxGeometry(w - 12, ovenH * 0.22, 6);
    const fascia = new THREE.Mesh(fasciaGeo, steelMat);
    fascia.position.set(0, ovenH / 2 - ovenH * 0.11 - 6, d / 2 + 19);
    ovenGroup.add(fascia);

    [-70, 70].forEach((kx) => {
      const knobGeo = new THREE.CylinderGeometry(14, 14, 12, 20);
      const knob = new THREE.Mesh(knobGeo, steelMat);
      knob.rotation.x = Math.PI / 2;
      knob.position.set(kx, ovenH / 2 - ovenH * 0.11 - 6, d / 2 + 25);
      ovenGroup.add(knob);
    });

    const oHandleBarGeo = new THREE.BoxGeometry(w * 0.65, 14, 14);
    const oHandleBar = new THREE.Mesh(oHandleBarGeo, chromeMat);
    oHandleBar.position.set(0, ovenH * 0.15, d / 2 + 36);
    ovenGroup.add(oHandleBar);

    carcaseGroup.add(ovenGroup);
  }

  /**
   * Builds the 600mm Countertop with 4-Burner Gas Cooktop
   */
  private buildOvenCountertopWithGasCooktop(shadingMode: ShadingMode): void {
    const u = this.unitData;
    const w = u.width;
    const h = u.height;
    const d = u.depth;
    const legH = u.legsHeight || 0;
    const ctH = u.countertop?.thickness || 35;

    const marbleMat = getThreeMaterial(u.countertop?.materialId || 'marble_calacatta_gold', u.countertop?.color || '#ede8df', shadingMode);
    const steelMat = getThreeMaterial('metal_brushed_steel', '#e2e8f0', shadingMode);
    const castIronMat = getThreeMaterial('metal_cast_iron', '#18181b', shadingMode);
    const brassMat = getThreeMaterial('metal_brushed_brass', '#eab308', shadingMode);

    const ohL = u.countertop?.overhangLeft ?? 0;
    const ohR = u.countertop?.overhangRight ?? 0;
    const ohF = u.countertop?.overhangFront ?? 25;
    const ohB = u.countertop?.overhangBack ?? 0;
    const ctW = w + ohL + ohR;
    const ctD = d + ohF + ohB;
    const ctGeo = new THREE.BoxGeometry(ctW, ctH, ctD);
    const ctMesh = new THREE.Mesh(ctGeo, marbleMat);
    ctMesh.position.set((ohR - ohL) / 2, legH + h + ctH / 2, (ohF - ohB) / 2);
    ctMesh.castShadow = true;
    ctMesh.receiveShadow = true;
    this.group.add(ctMesh);

    const hobGroup = new THREE.Group();
    hobGroup.position.set(0, legH + h + ctH + 2, 5);

    const hobW = Math.min(w - 40, 580);
    const hobD = Math.min(d - 60, 510);
    const hobTrayGeo = new THREE.BoxGeometry(hobW, 6, hobD);
    const hobTray = new THREE.Mesh(hobTrayGeo, steelMat);
    hobTray.position.set(0, 3, 0);
    hobGroup.add(hobTray);

    const burners = [
      { x: -hobW * 0.25, z: -hobD * 0.22, rad: 48 },
      { x: -hobW * 0.25, z: hobD * 0.22, rad: 40 },
      { x: hobW * 0.25, z: -hobD * 0.22, rad: 55 },
      { x: hobW * 0.25, z: hobD * 0.22, rad: 45 },
    ];

    burners.forEach((b) => {
      const coreGeo = new THREE.CylinderGeometry(b.rad * 0.38, b.rad * 0.38, 7, 20);
      const core = new THREE.Mesh(coreGeo, brassMat);
      core.position.set(b.x, 8, b.z);
      hobGroup.add(core);

      const capGeo = new THREE.CylinderGeometry(b.rad * 0.5, b.rad * 0.5, 5, 20);
      const cap = new THREE.Mesh(capGeo, castIronMat);
      cap.position.set(b.x, 12, b.z);
      hobGroup.add(cap);

      const grateGeo1 = new THREE.BoxGeometry(b.rad * 1.8, 8, 8);
      const g1 = new THREE.Mesh(grateGeo1, castIronMat);
      g1.position.set(b.x, 14, b.z);
      hobGroup.add(g1);

      const grateGeo2 = new THREE.BoxGeometry(8, 8, b.rad * 1.8);
      const g2 = new THREE.Mesh(grateGeo2, castIronMat);
      g2.position.set(b.x, 14, b.z);
      hobGroup.add(g2);
    });

    for (let k = 0; k < 4; k++) {
      const knobX = -hobW * 0.24 + k * (hobW * 0.16);
      const knobGeo = new THREE.CylinderGeometry(10, 10, 12, 16);
      const knob = new THREE.Mesh(knobGeo, steelMat);
      knob.position.set(knobX, 9, hobD * 0.38);
      hobGroup.add(knob);
    }

    this.group.add(hobGroup);
  }
}

