import * as THREE from 'three';
import { RoomConfig, ShadingMode, CustomWall, WallOpening } from '../types';
import { getThreeMaterial } from './materials';

export class RoomMesh {
  public group: THREE.Group;
  public config: RoomConfig;
  public selectedOpeningId: string | null = null;

  constructor(
    config: RoomConfig,
    shadingMode: ShadingMode = 'realistic',
    selectedOpeningId: string | null = null
  ) {
    this.config = config;
    this.selectedOpeningId = selectedOpeningId;
    this.group = new THREE.Group();
    this.group.name = 'room_mesh_group';
    this.rebuild(shadingMode);
  }

  public setSelectedOpening(id: string | null): void {
    if (this.selectedOpeningId === id) return;
    this.selectedOpeningId = id;
    this.rebuild();
  }

  public rebuild(shadingMode: ShadingMode = 'realistic'): void {
    while (this.group.children.length > 0) {
      this.group.remove(this.group.children[0]);
    }

    const { width: w, length: l, height: h } = this.config;

    // 1. Floor Mesh
    const floorMat = getThreeMaterial(
      this.config.floorMaterialId || 'marble_carrara_white',
      this.config.floorColor || '#e2e8f0',
      shadingMode
    );
    const floorGeo = new THREE.PlaneGeometry(w, l);
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.rotation.x = -Math.PI / 2;
    floorMesh.position.set(0, 0, 0);
    floorMesh.receiveShadow = true;
    this.group.add(floorMesh);

    // 2. Floor Grid Helper (Subtle millimetric guide)
    const gridHelper = new THREE.GridHelper(
      Math.max(w, l),
      Math.round(Math.max(w, l) / 500),
      0x94a3b8,
      0xe2e8f0
    );
    gridHelper.position.y = 1;
    (gridHelper.material as THREE.Material).opacity = 0.25;
    (gridHelper.material as THREE.Material).transparent = true;
    this.group.add(gridHelper);

    // 3. Wall Material
    const wallMat = getThreeMaterial(
      this.config.wallMaterialId || 'paint_cotton_white',
      this.config.wallColor || '#f8fafc',
      shadingMode
    );

    const wallThickness = 120;

    // Build each of the 4 perimeter walls with real physical cutouts for windows and doors!
    // North Wall (Back: -Z, index 0, length = w)
    if (this.config.showNorthWall) {
      this.buildWallWithCutouts(0, w, h, wallThickness, wallMat, shadingMode);
    }

    // East Wall (Right: +X, index 1, length = l)
    if (this.config.showEastWall) {
      this.buildWallWithCutouts(1, l, h, wallThickness, wallMat, shadingMode);
    }

    // South Wall (Front: +Z, index 2, length = w)
    if (this.config.showSouthWall) {
      this.buildWallWithCutouts(2, w, h, wallThickness, wallMat, shadingMode);
    }

    // West Wall (Left: -X, index 3, length = l)
    if (this.config.showWestWall) {
      this.buildWallWithCutouts(3, l, h, wallThickness, wallMat, shadingMode);
    }

    // 4. Custom Walls & Partitions (الجدران المخصصة والقواطع)
    if (this.config.customWalls && this.config.customWalls.length > 0) {
      this.config.customWalls.forEach((cw: CustomWall) => {
        const wallH = cw.height || h;
        const wallT = cw.thickness || 120;
        const cWallMat = cw.materialId
          ? getThreeMaterial(cw.materialId, cw.color || this.config.wallColor, shadingMode)
          : wallMat;

        const cWallGeo = new THREE.BoxGeometry(cw.length, wallH, wallT);
        const cWallMesh = new THREE.Mesh(cWallGeo, cWallMat);
        cWallMesh.position.set(
          cw.startX + (cw.length / 2) * Math.cos((cw.rotationY * Math.PI) / 180),
          wallH / 2,
          cw.startZ + (cw.length / 2) * Math.sin((cw.rotationY * Math.PI) / 180)
        );
        cWallMesh.rotation.y = -(cw.rotationY * Math.PI) / 180;
        cWallMesh.castShadow = true;
        cWallMesh.receiveShadow = true;
        cWallMesh.userData = { customWallId: cw.id, isWall: true, isCustomWall: true };
        this.group.add(cWallMesh);
      });
    }

    // 5. Ceiling (Optional)
    if (this.config.showCeiling) {
      const ceilingMat = getThreeMaterial(
        'mdf_matte_white',
        this.config.ceilingColor || '#ffffff',
        shadingMode
      );
      const ceilingGeo = new THREE.PlaneGeometry(w, l);
      const ceilingMesh = new THREE.Mesh(ceilingGeo, ceilingMat);
      ceilingMesh.rotation.x = Math.PI / 2;
      ceilingMesh.position.set(0, h, 0);
      this.group.add(ceilingMesh);
    }
  }

  /**
   * Constructs wall segments with actual cutouts/voids for all windows and doors on this wall.
   * Places window and door assemblies directly inside the wall cutouts flush with wall thickness.
   */
  private buildWallWithCutouts(
    wallIndex: number,
    wallLength: number,
    wallHeight: number,
    wallThickness: number,
    wallMat: THREE.Material,
    shadingMode: ShadingMode
  ): void {
    const openings = (this.config.openings || [])
      .filter((op) => (op.wallIndex ?? 0) === wallIndex)
      .sort((a, b) => a.distanceFromStart - b.distanceFromStart);

    const halfW = this.config.width / 2;
    const halfL = this.config.length / 2;

    const addWallBox = (xStart: number, xEnd: number, yStart: number, yEnd: number) => {
      const boxW = xEnd - xStart;
      const boxH = yEnd - yStart;
      if (boxW <= 1 || boxH <= 1) return;

      const localX = xStart + boxW / 2;
      const localY = yStart + boxH / 2;

      let geo: THREE.BoxGeometry;
      let posX = 0, posY = localY, posZ = 0;

      switch (wallIndex) {
        case 0: // North Wall
          geo = new THREE.BoxGeometry(boxW, boxH, wallThickness);
          posX = -halfW + localX;
          posZ = -halfL - wallThickness / 2;
          break;
        case 1: // East Wall
          geo = new THREE.BoxGeometry(wallThickness, boxH, boxW);
          posX = halfW + wallThickness / 2;
          posZ = -halfL + localX;
          break;
        case 2: // South Wall
          geo = new THREE.BoxGeometry(boxW, boxH, wallThickness);
          posX = -halfW + localX;
          posZ = halfL + wallThickness / 2;
          break;
        case 3: // West Wall
        default:
          geo = new THREE.BoxGeometry(wallThickness, boxH, boxW);
          posX = -halfW - wallThickness / 2;
          posZ = -halfL + localX;
          break;
      }

      const mesh = new THREE.Mesh(geo, wallMat);
      mesh.position.set(posX, posY, posZ);
      mesh.receiveShadow = true;
      mesh.castShadow = true;
      this.group.add(mesh);
    };

    if (openings.length === 0) {
      // Solid wall if no openings
      addWallBox(0, wallLength, 0, wallHeight);
      return;
    }

    // Subdivide wall into pillars and lintels around openings
    let cursorX = 0;

    openings.forEach((op) => {
      const margin = 30;
      const safeWidth = Math.min(Math.max(200, op.width), Math.max(200, wallLength - margin * 2));
      const maxStart = Math.max(margin, wallLength - safeWidth - margin);
      const opStart = Math.max(margin, Math.min(maxStart, op.distanceFromStart));
      const opWidth = Math.min(safeWidth, wallLength - opStart - margin);
      const opEnd = opStart + opWidth;
      const opSill = Math.max(0, Math.min(wallHeight - 200, op.sillHeight || 0));
      const opHeight = Math.max(150, Math.min(wallHeight - opSill - margin, op.height));
      const opTop = opSill + opHeight;

      // 1. Pillar before opening
      if (opStart > cursorX) {
        addWallBox(cursorX, opStart, 0, wallHeight);
      }

      // 2. Sill panel below opening (for windows)
      if (opSill > 0) {
        addWallBox(opStart, opEnd, 0, opSill);
      }

      // 3. Header panel above opening (lintel)
      if (wallHeight > opTop) {
        addWallBox(opStart, opEnd, opTop, wallHeight);
      }

      cursorX = Math.max(cursorX, opEnd);

      // 4. Place Window or Door inside the cutout void
      const isSelected = this.selectedOpeningId === op.id;
      let openingMesh: THREE.Group;

      if (op.type === 'window') {
        openingMesh = this.createWindowMesh(op, shadingMode, isSelected, wallThickness);
      } else {
        openingMesh = this.createDoorMesh(op, shadingMode, isSelected, wallThickness);
      }

      const opCenterX = opStart + opWidth / 2;
      const opCenterY = opSill + opHeight / 2;

      switch (wallIndex) {
        case 0: // North Wall
          openingMesh.position.set(-halfW + opCenterX, opCenterY, -halfL - wallThickness / 2);
          openingMesh.rotation.y = 0;
          break;
        case 1: // East Wall
          openingMesh.position.set(halfW + wallThickness / 2, opCenterY, -halfL + opCenterX);
          openingMesh.rotation.y = -Math.PI / 2;
          break;
        case 2: // South Wall
          openingMesh.position.set(-halfW + opCenterX, opCenterY, halfL + wallThickness / 2);
          openingMesh.rotation.y = Math.PI;
          break;
        case 3: // West Wall
        default:
          openingMesh.position.set(-halfW - wallThickness / 2, opCenterY, -halfL + opCenterX);
          openingMesh.rotation.y = Math.PI / 2;
          break;
      }

      this.group.add(openingMesh);
    });

    // 5. Pillar after last opening to the end of the wall
    if (wallLength > cursorX) {
      addWallBox(cursorX, wallLength, 0, wallHeight);
    }
  }

  /**
   * Builds realistic 3D Window with aluminum/wood frame, glass pane, divider, marble sill, and selection highlight
   * Perfectly fitted inside the wall opening cutout void.
   */
  private createWindowMesh(
    op: WallOpening,
    shadingMode: ShadingMode,
    isSelected: boolean,
    wallThickness: number = 120
  ): THREE.Group {
    const group = new THREE.Group();
    group.name = `window_${op.id}`;
    group.userData = {
      isOpening: true,
      openingId: op.id,
      openingType: 'window',
      wallIndex: op.wallIndex,
    };

    const frameMat = getThreeMaterial('metal_matte_black', '#1c1917', shadingMode);
    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      transmission: 0.95,
      opacity: 0.15,
      transparent: true,
      roughness: 0.05,
      metalness: 0.05,
      ior: 1.5,
      side: THREE.DoubleSide,
    });
    const sillMat = getThreeMaterial('marble_carrara_white', '#f8fafc', shadingMode);

    const frameThickness = 35;
    const frameDepth = Math.max(80, wallThickness);

    // 1. Window Glass Pane (looking through to outdoor landscape)
    const glassW = Math.max(10, op.width - frameThickness * 2);
    const glassH = Math.max(10, op.height - frameThickness * 2);
    const glassGeo = new THREE.PlaneGeometry(glassW, glassH);
    const glassMesh = new THREE.Mesh(glassGeo, glassMat);
    glassMesh.userData = { isOpening: true, openingId: op.id };
    group.add(glassMesh);

    // 2. Window Outer Frame - Sits STRICTLY inside the wall opening void:
    // Left post
    const leftGeo = new THREE.BoxGeometry(frameThickness, op.height, frameDepth);
    const leftMesh = new THREE.Mesh(leftGeo, frameMat);
    leftMesh.position.set(-op.width / 2 + frameThickness / 2, 0, 0);
    leftMesh.userData = { isOpening: true, openingId: op.id };
    group.add(leftMesh);

    // Right post
    const rightGeo = new THREE.BoxGeometry(frameThickness, op.height, frameDepth);
    const rightMesh = new THREE.Mesh(rightGeo, frameMat);
    rightMesh.position.set(op.width / 2 - frameThickness / 2, 0, 0);
    rightMesh.userData = { isOpening: true, openingId: op.id };
    group.add(rightMesh);

    // Top beam (connecting between left and right posts)
    const topGeo = new THREE.BoxGeometry(glassW, frameThickness, frameDepth);
    const topMesh = new THREE.Mesh(topGeo, frameMat);
    topMesh.position.set(0, op.height / 2 - frameThickness / 2, 0);
    topMesh.userData = { isOpening: true, openingId: op.id };
    group.add(topMesh);

    // Bottom beam (connecting between left and right posts)
    const btmGeo = new THREE.BoxGeometry(glassW, frameThickness, frameDepth);
    const btmMesh = new THREE.Mesh(btmGeo, frameMat);
    btmMesh.position.set(0, -op.height / 2 + frameThickness / 2, 0);
    btmMesh.userData = { isOpening: true, openingId: op.id };
    group.add(btmMesh);

    // Central Mullion Divider (if wide window)
    if (op.width >= 800) {
      const mullionGeo = new THREE.BoxGeometry(26, glassH, frameDepth - 10);
      const mullionMesh = new THREE.Mesh(mullionGeo, frameMat);
      mullionMesh.userData = { isOpening: true, openingId: op.id };
      group.add(mullionMesh);

      // Casement handle
      const handleMat = getThreeMaterial('metal_chrome', '#cbd5e1', shadingMode);
      const handleGeo = new THREE.BoxGeometry(16, 70, 20);
      const handleMesh = new THREE.Mesh(handleGeo, handleMat);
      handleMesh.position.set(20, 0, frameDepth / 2 + 5);
      handleMesh.userData = { isOpening: true, openingId: op.id };
      group.add(handleMesh);
    }

    // Marble Window Sill (جلسة الرخام الأنيقة في قاع فتحة الشباك)
    const sillGeo = new THREE.BoxGeometry(op.width + 40, 24, frameDepth + 30);
    const sillMesh = new THREE.Mesh(sillGeo, sillMat);
    sillMesh.position.set(0, -op.height / 2 + 12, 10);
    sillMesh.userData = { isOpening: true, openingId: op.id };
    group.add(sillMesh);

    // Selection Highlight (Cyan wireframe box if active)
    if (isSelected) {
      const boxGeo = new THREE.BoxGeometry(op.width + 20, op.height + 20, frameDepth + 20);
      const wireMat = new THREE.MeshBasicMaterial({
        color: 0x06b6d4,
        wireframe: true,
        transparent: true,
        opacity: 0.9,
      });
      const highlightMesh = new THREE.Mesh(boxGeo, wireMat);
      group.add(highlightMesh);
    }

    return group;
  }

  /**
   * Builds realistic 3D Door with door jamb, styled door panel/leaf, metallic lever handle, and selection highlight
   * Perfectly fitted inside the wall opening cutout void.
   */
  private createDoorMesh(
    op: WallOpening,
    shadingMode: ShadingMode,
    isSelected: boolean,
    wallThickness: number = 120
  ): THREE.Group {
    const group = new THREE.Group();
    group.name = `door_${op.id}`;
    group.userData = {
      isOpening: true,
      openingId: op.id,
      openingType: 'door',
      wallIndex: op.wallIndex,
    };

    const jambThickness = 40;
    const jambDepth = Math.max(90, wallThickness);

    // Casing / Architrave Material (Warm Oak or Dark Wood)
    const frameMat = getThreeMaterial('wood_oak_natural', '#3e2c1d', shadingMode);
    // Door Leaf panel
    const doorMat = getThreeMaterial('wood_walnut', '#4a3525', shadingMode);
    const handleMat = getThreeMaterial('metal_chrome', '#f1f5f9', shadingMode);

    // Door Jamb Frame - Fits STRICTLY inside opening void:
    // Left Jamb Post
    const leftGeo = new THREE.BoxGeometry(jambThickness, op.height, jambDepth);
    const leftMesh = new THREE.Mesh(leftGeo, frameMat);
    leftMesh.position.set(-op.width / 2 + jambThickness / 2, 0, 0);
    leftMesh.userData = { isOpening: true, openingId: op.id };
    group.add(leftMesh);

    // Right Jamb Post
    const rightGeo = new THREE.BoxGeometry(jambThickness, op.height, jambDepth);
    const rightMesh = new THREE.Mesh(rightGeo, frameMat);
    rightMesh.position.set(op.width / 2 - jambThickness / 2, 0, 0);
    rightMesh.userData = { isOpening: true, openingId: op.id };
    group.add(rightMesh);

    // Top Header Jamb (between left and right posts)
    const innerW = Math.max(100, op.width - jambThickness * 2);
    const topGeo = new THREE.BoxGeometry(innerW, jambThickness, jambDepth);
    const topMesh = new THREE.Mesh(topGeo, frameMat);
    topMesh.position.set(0, op.height / 2 - jambThickness / 2, 0);
    topMesh.userData = { isOpening: true, openingId: op.id };
    group.add(topMesh);

    // Door Leaf (Main door panel) inside the jamb frame
    const leafWidth = innerW - 6;
    const leafHeight = op.height - jambThickness - 6;
    const leafGeo = new THREE.BoxGeometry(leafWidth, leafHeight, 40);
    const leafMesh = new THREE.Mesh(leafGeo, doorMat);
    leafMesh.position.set(0, -jambThickness / 2, 0);
    leafMesh.userData = { isOpening: true, openingId: op.id };
    group.add(leafMesh);

    // Inset Decorative Grooves on Door Leaf (Shaker / Modern Lines)
    const grooveMat = getThreeMaterial('metal_matte_black', '#1c1917', shadingMode);
    const grooveGeo = new THREE.BoxGeometry(leafWidth - 40, 4, 42);
    [-250, 0, 250].forEach((yOffset) => {
      const grooveMesh = new THREE.Mesh(grooveGeo, grooveMat);
      grooveMesh.position.set(0, yOffset - jambThickness / 2, 0);
      grooveMesh.userData = { isOpening: true, openingId: op.id };
      group.add(grooveMesh);
    });

    // Metallic Door Handle & Escutcheon Plate
    const plateGeo = new THREE.BoxGeometry(32, 160, 6);
    const plateMesh = new THREE.Mesh(plateGeo, handleMat);
    plateMesh.position.set(leafWidth / 2 - 50, 0, 23);
    plateMesh.userData = { isOpening: true, openingId: op.id };
    group.add(plateMesh);

    // Lever Handle
    const leverGeo = new THREE.BoxGeometry(100, 16, 18);
    const leverMesh = new THREE.Mesh(leverGeo, handleMat);
    leverMesh.position.set(leafWidth / 2 - 95, 20, 31);
    leverMesh.userData = { isOpening: true, openingId: op.id };
    group.add(leverMesh);

    // Floor Threshold bar
    const thresholdGeo = new THREE.BoxGeometry(op.width, 10, jambDepth);
    const thresholdMesh = new THREE.Mesh(thresholdGeo, frameMat);
    thresholdMesh.position.set(0, -op.height / 2 + 5, 0);
    thresholdMesh.userData = { isOpening: true, openingId: op.id };
    group.add(thresholdMesh);

    // Selection Highlight
    if (isSelected) {
      const boxGeo = new THREE.BoxGeometry(op.width + 20, op.height + 20, jambDepth + 20);
      const wireMat = new THREE.MeshBasicMaterial({
        color: 0x06b6d4,
        wireframe: true,
        transparent: true,
        opacity: 0.9,
      });
      const highlightMesh = new THREE.Mesh(boxGeo, wireMat);
      group.add(highlightMesh);
    }

    return group;
  }
}
