import * as THREE from 'three';
import {
  Project,
  ParametricCabinet,
  CameraPreset,
  ShadingMode,
  SnapSettings,
  LightingConfig,
  RoomConfig,
} from '../types';
import { ParametricCabinetMesh } from './ParametricCabinetMesh';
import { RoomMesh } from './RoomMesh';
import { MeasureTool } from './MeasureTool';
import { resolveCabinetMovement, checkCabinetCollision } from '../domain/collision/CollisionManager';
import forestPanoramaUrl from '../assets/images/forest_panorama_1789542236624.jpg';
import gardenPanoramaUrl from '../assets/images/garden_panorama_1789542253140.jpg';

export interface SceneCallbacks {
  onUnitSelect?: (unitId: string | null) => void;
  onCustomWallSelect?: (wallId: string | null) => void;
  onOpeningSelect?: (openingId: string | null) => void;
  onDoorToggle?: (unitId: string, doorIndex: number) => void;
  onDrawerToggle?: (unitId: string, drawerIndex: number) => void;
  onUnitInteractToggle?: (unitId: string, isOpen: boolean) => void;
  onMeasureDistance?: (distanceMm: number) => void;
}

export class SceneManager {
  public container: HTMLElement;
  public scene: THREE.Scene;
  public camera: THREE.PerspectiveCamera;
  public renderer: THREE.WebGLRenderer;
  public roomMesh: RoomMesh | null = null;
  public selectedOpeningId: string | null = null;
  public cabinetMeshes: Map<string, ParametricCabinetMesh> = new Map();
  public measureTool: MeasureTool;
  public project: Project;
  public shadingMode: ShadingMode = 'realistic';
  public collisionGuardEnabled: boolean = true;
  public snapSettings: SnapSettings = {
    enabled: true,
    gridSize: 50,
    snapToWall: true,
    snapToFloor: true,
    snapToCabinet: true,
    snapDistance: 40,
  };

  // Lighting Objects
  private ambientLight: THREE.AmbientLight;
  private sunLight: THREE.DirectionalLight;
  private spotLights: THREE.SpotLight[] = [];
  private underCabinetLights: THREE.PointLight[] = [];
  private cabinetInteriorLights: THREE.PointLight[] = [];
  private shadowNeedsUpdate: boolean = true;

  // Interaction & Smooth Orbit State
  public isInteractMode: boolean = false;
  public autoRotateEnabled: boolean = false;
  public autoRotateSpeed: number = 0.35;
  public cameraCollisionEnabled: boolean = true;
  public environmentGroup: THREE.Group = new THREE.Group();
  public environmentType: 'forest' | 'garden' | 'studio' | 'none' = 'forest';
  private hemiLight: THREE.HemisphereLight | null = null;
  private isPointerDown = false;
  private pointerStartX = 0;
  private pointerStartY = 0;
  private pointerTotalDragDist = 0;
  public cameraTheta = 0; // Horizontal orbit angle
  public cameraPhi = Math.PI / 4; // Vertical angle
  public cameraRadius = 3800;
  public cameraTarget = new THREE.Vector3(0, 800, 0);

  // Damping targets for lag-free 60/120fps camera rotation
  private targetTheta = 0;
  private targetPhi = Math.PI / 4;
  private targetRadius = 3800;
  private targetCenter = new THREE.Vector3(0, 800, 0);

  // First-Person Walkthrough (Home Planner Walk / Run Mode)
  public isWalkMode = false;
  public walkPosition = new THREE.Vector3(0, 1550, 1200);
  public walkYaw = 0; // horizontal look angle (radians)
  public walkPitch = -0.05; // vertical look tilt (radians)
  public walkEyeHeight = 1550; // standard human eye height in mm

  private raycaster = new THREE.Raycaster();
  private pointer = new THREE.Vector2();
  private isPanning = false;
  private callbacks: SceneCallbacks = {};

  private animationFrameId: number | null = null;
  private lastTime: number = performance.now();
  private isDisposed = false;

  constructor(container: HTMLElement, project: Project, callbacks: SceneCallbacks = {}) {
    this.container = container;
    this.project = project;
    this.callbacks = callbacks;

    // 1. Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#0e1d13');
    this.scene.add(this.environmentGroup);
    this.setEnvironment(project.room.environment || 'forest');

    // 2. Camera: Wide-angle interior perspective FOV 54° for comfortable, natural viewing
    const aspect = container.clientWidth / container.clientHeight;
    this.camera = new THREE.PerspectiveCamera(54, aspect, 10, 50000);
    const initialDim = Math.max(project.room.width, project.room.length, 2800);
    this.cameraRadius = Math.round(initialDim * 1.35);
    this.targetRadius = this.cameraRadius;
    this.targetTheta = this.cameraTheta;
    this.targetPhi = this.cameraPhi;
    this.targetCenter.copy(this.cameraTarget);
    this.updateCameraTransform();

    // 3. WebGL Renderer with optimized pixel ratio and on-demand shadow updates for lag-free orbit
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      preserveDrawingBuffer: true,
      powerPreference: 'high-performance',
    });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    // AutoUpdate false prevents heavy shadow-pass recomputation every frame while orbiting camera!
    this.renderer.shadowMap.autoUpdate = false;
    this.renderer.shadowMap.needsUpdate = true;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    container.appendChild(this.renderer.domElement);

    // 4. Lights
    this.ambientLight = new THREE.AmbientLight(0xffffff, 0.65);
    this.scene.add(this.ambientLight);

    // Unreal Engine style Sky / Ground ambient bounce
    this.hemiLight = new THREE.HemisphereLight(0xfffbeb, 0x1e293b, 0.45);
    this.hemiLight.position.set(0, 3000, 0);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xfffbeb, 1.2);
    this.sunLight.position.set(1500, 3500, 2000);
    this.sunLight.castShadow = true;
    this.sunLight.shadow.mapSize.width = 1024;
    this.sunLight.shadow.mapSize.height = 1024;
    this.sunLight.shadow.bias = -0.0005;
    this.sunLight.shadow.camera.near = 100;
    this.sunLight.shadow.camera.far = 10000;
    const d = 4000;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.scene.add(this.sunLight);

    // 5. Measure Tool
    this.measureTool = new MeasureTool();
    this.scene.add(this.measureTool.group);

    // 6. Build Initial Scene
    this.rebuildRoom();
    this.rebuildAllCabinets();
    this.applyLightingConfig(project.lighting);

    // 7. Event Listeners
    this.setupEventListeners();

    // 8. Start Loop
    this.renderLoop();
  }

  public setCallbacks(callbacks: SceneCallbacks): void {
    this.callbacks = callbacks;
  }

  public setSelectedOpening(openingId: string | null): void {
    this.selectedOpeningId = openingId;
    if (this.roomMesh) {
      this.roomMesh.setSelectedOpening(openingId);
    }
  }

  public updateRoom(room: RoomConfig): void {
    const prevEnv = this.project.room.environment;
    this.project.room = room;
    if (room.environment && room.environment !== prevEnv) {
      this.setEnvironment(room.environment);
    }
    this.rebuildRoom();
  }

  /**
   * Builds high-resolution 360 landscape environment (Forest, Garden, Studio) surrounding the room
   */
  public setEnvironment(type: 'forest' | 'garden' | 'studio' | 'none'): void {
    this.environmentType = type;
    this.project.room.environment = type;

    // Dispose and clear existing environment children
    while (this.environmentGroup.children.length > 0) {
      const child = this.environmentGroup.children[0];
      if (child instanceof THREE.Mesh) {
        child.geometry?.dispose();
        if (Array.isArray(child.material)) {
          child.material.forEach((m) => m.dispose());
        } else {
          child.material?.dispose();
        }
      }
      this.environmentGroup.remove(child);
    }

    if (type === 'none') {
      this.scene.background = new THREE.Color('#090d16');
      return;
    }

    if (type === 'studio') {
      this.scene.background = new THREE.Color('#0c1322');
      const studioGroundGeo = new THREE.CircleGeometry(25000, 48);
      const studioGroundMat = new THREE.MeshLambertMaterial({
        color: 0x111c30,
        side: THREE.FrontSide,
      });
      const ground = new THREE.Mesh(studioGroundGeo, studioGroundMat);
      ground.rotation.x = -Math.PI / 2;
      ground.position.y = -2;
      ground.receiveShadow = true;
      this.environmentGroup.add(ground);
      return;
    }

    // Panorama for Forest or Garden
    const isGarden = type === 'garden';
    const textureUrl = isGarden ? gardenPanoramaUrl : forestPanoramaUrl;
    this.scene.background = new THREE.Color(isGarden ? '#14251b' : '#0e1d13');

    // 1. Outdoor Earthy Soil Ground Disk & Room Perimeter Apron
    const soilTexture = this.createSoilTexture();
    const groundGeo = new THREE.CircleGeometry(48000, 64);
    const groundMat = new THREE.MeshStandardMaterial({
      map: soilTexture,
      color: isGarden ? 0x5a3e2b : 0x4a3221,
      roughness: 0.95,
      metalness: 0.05,
      side: THREE.FrontSide,
    });
    const groundMesh = new THREE.Mesh(groundGeo, groundMat);
    groundMesh.rotation.x = -Math.PI / 2;
    groundMesh.position.y = -3;
    groundMesh.receiveShadow = true;
    this.environmentGroup.add(groundMesh);

    // Immediate Earthy Perimeter Apron framing the room walls
    const roomW = this.project.room.width || 4000;
    const roomL = this.project.room.length || 5000;
    const apronW = roomW + 3600;
    const apronL = roomL + 3600;
    const apronGeo = new THREE.PlaneGeometry(apronW, apronL);
    const apronMat = new THREE.MeshStandardMaterial({
      map: soilTexture,
      color: 0x523724,
      roughness: 0.9,
      metalness: 0.05,
    });
    const apronMesh = new THREE.Mesh(apronGeo, apronMat);
    apronMesh.rotation.x = -Math.PI / 2;
    apronMesh.position.set(0, -2, 0);
    apronMesh.receiveShadow = true;
    this.environmentGroup.add(apronMesh);

    // Stone / Gravel curb edge outlining the earthy perimeter
    const curbGeo = new THREE.RingGeometry(Math.min(apronW, apronL) * 0.48, Math.max(apronW, apronL) * 0.54, 4);
    const curbMat = new THREE.MeshStandardMaterial({
      color: 0x3d281a,
      roughness: 0.92,
      metalness: 0.05,
      side: THREE.FrontSide,
    });
    const curbMesh = new THREE.Mesh(curbGeo, curbMat);
    curbMesh.rotation.x = -Math.PI / 2;
    curbMesh.position.set(0, -1.8, 0);
    curbMesh.receiveShadow = true;
    this.environmentGroup.add(curbMesh);

    // 2. 360 Cylindrical Landscape Panorama surrounding the room
    const envRadius = 38000;
    const envHeight = 28000;
    const cylGeo = new THREE.CylinderGeometry(envRadius, envRadius, envHeight, 64, 1, true);

    const loader = new THREE.TextureLoader();
    loader.load(
      textureUrl,
      (texture) => {
        texture.wrapS = THREE.RepeatWrapping;
        texture.wrapT = THREE.ClampToEdgeWrapping;
        texture.repeat.set(2, 1);
        texture.colorSpace = THREE.SRGBColorSpace;

        const cylMat = new THREE.MeshBasicMaterial({
          map: texture,
          side: THREE.BackSide,
          toneMapped: false,
          depthWrite: false,
        });

        const cylMesh = new THREE.Mesh(cylGeo, cylMat);
        // Position cylinder so window sightlines gaze into lush trees, meadow, and horizon
        cylMesh.position.set(0, envHeight / 2 - 2000, 0);
        this.environmentGroup.add(cylMesh);
      },
      undefined,
      (err) => {
        console.warn('Landscape panorama texture load error:', err);
      }
    );

    // 3. Sky Cap Dome above
    const domeGeo = new THREE.SphereGeometry(envRadius + 500, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2);
    const domeMat = new THREE.MeshBasicMaterial({
      color: isGarden ? 0x649cb6 : 0x4a7a63,
      side: THREE.BackSide,
      depthWrite: false,
    });
    const domeMesh = new THREE.Mesh(domeGeo, domeMat);
    domeMesh.position.set(0, envHeight - 3000, 0);
    this.environmentGroup.add(domeMesh);

    // 4. Outdoor trees removed per user request
    // this.addOutdoorTrees(isGarden);
  }

  /**
   * Generates realistic procedural earthy soil texture with loam grain and pebbles
   */
  private createSoilTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      // Base rich warm earth
      ctx.fillStyle = '#4e3524';
      ctx.fillRect(0, 0, 512, 512);

      // Fine loam and micro-texture grains
      for (let i = 0; i < 5000; i++) {
        const x = Math.random() * 512;
        const y = Math.random() * 512;
        const r = Math.random() * 2.5 + 0.8;
        const shades = ['#3d281a', '#5c3e2b', '#6b4832', '#362316', '#7a5238', '#452f20'];
        ctx.fillStyle = shades[Math.floor(Math.random() * shades.length)];
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();
      }

      // Small pebbles and soil aggregate stones
      for (let j = 0; j < 350; j++) {
        const px = Math.random() * 512;
        const py = Math.random() * 512;
        const pr = Math.random() * 4 + 2;
        ctx.fillStyle = Math.random() > 0.5 ? '#554236' : '#2e1e13';
        ctx.beginPath();
        ctx.ellipse(px, py, pr, pr * 0.75, Math.random() * Math.PI, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(16, 16);
    return tex;
  }

  /**
   * Adds 3D pine trees, deciduous leafy trees, and garden bushes outside the room walls
   * Visible through windows and open doors for authentic nature depth.
   */
  private addOutdoorTrees(isGarden: boolean): void {
    const halfW = (this.project.room.width || 4000) / 2;
    const halfL = (this.project.room.length || 5000) / 2;

    const trunkMat = new THREE.MeshLambertMaterial({ color: 0x3d2817 });
    const leafMatDark = new THREE.MeshLambertMaterial({ color: isGarden ? 0x2e6b22 : 0x1e4620 });
    const leafMatMid = new THREE.MeshLambertMaterial({ color: isGarden ? 0x3f8a2f : 0x295a28 });
    const leafMatLight = new THREE.MeshLambertMaterial({ color: isGarden ? 0x55a630 : 0x38662d });

    // Deterministic cluster of tree positions surrounding all 4 exterior walls
    const treeOffsets: Array<[number, number, number, 'pine' | 'leafy' | 'bush']> = [
      // North Wall (Window side)
      [0, -halfL - 2500, 1.1, 'leafy'],
      [-1600, -halfL - 3200, 1.3, 'pine'],
      [1800, -halfL - 2800, 1.0, 'leafy'],
      [-3200, -halfL - 4500, 1.5, 'pine'],
      [3400, -halfL - 4200, 1.4, 'pine'],
      [-800, -halfL - 1800, 0.7, 'bush'],
      [900, -halfL - 1900, 0.8, 'bush'],

      // South Wall
      [0, halfL + 3000, 1.2, 'leafy'],
      [-2200, halfL + 3500, 1.4, 'pine'],
      [2400, halfL + 3800, 1.3, 'pine'],
      [-1000, halfL + 2200, 0.7, 'bush'],
      [1200, halfL + 2100, 0.8, 'bush'],

      // East Wall
      [halfW + 2800, 0, 1.2, 'pine'],
      [halfW + 3500, -1800, 1.3, 'leafy'],
      [halfW + 3600, 2000, 1.4, 'pine'],
      [halfW + 2000, -800, 0.7, 'bush'],
      [halfW + 2100, 1000, 0.8, 'bush'],

      // West Wall
      [-halfW - 2800, 0, 1.3, 'leafy'],
      [-halfW - 3500, -2000, 1.4, 'pine'],
      [-halfW - 3600, 1900, 1.2, 'pine'],
      [-halfW - 2000, -600, 0.7, 'bush'],
      [-halfW - 2200, 800, 0.8, 'bush'],
    ];

    treeOffsets.forEach(([tx, tz, scale, type]) => {
      const treeGroup = new THREE.Group();
      treeGroup.position.set(tx, 0, tz);

      if (type === 'pine') {
        // Pine Trunk
        const trunkGeo = new THREE.CylinderGeometry(55 * scale, 85 * scale, 2400 * scale, 8);
        const trunk = new THREE.Mesh(trunkGeo, trunkMat);
        trunk.position.y = (1200 * scale);
        treeGroup.add(trunk);

        // 3 Tier Pine Cones
        [1400, 2100, 2700].forEach((baseY, idx) => {
          const coneRadius = (750 - idx * 160) * scale;
          const coneH = (1200 - idx * 150) * scale;
          const coneGeo = new THREE.ConeGeometry(coneRadius, coneH, 7);
          const coneMat = idx === 0 ? leafMatDark : idx === 1 ? leafMatMid : leafMatLight;
          const cone = new THREE.Mesh(coneGeo, coneMat);
          cone.position.y = baseY * scale + coneH / 2;
          treeGroup.add(cone);
        });
      } else if (type === 'leafy') {
        // Broadleaf Trunk
        const trunkGeo = new THREE.CylinderGeometry(65 * scale, 95 * scale, 1800 * scale, 8);
        const trunk = new THREE.Mesh(trunkGeo, trunkMat);
        trunk.position.y = (900 * scale);
        treeGroup.add(trunk);

        // Spherical foliage clouds
        const f1Geo = new THREE.DodecahedronGeometry(850 * scale, 1);
        const f1 = new THREE.Mesh(f1Geo, leafMatMid);
        f1.position.set(0, 2200 * scale, 0);
        treeGroup.add(f1);

        const f2Geo = new THREE.DodecahedronGeometry(650 * scale, 1);
        const f2 = new THREE.Mesh(f2Geo, leafMatDark);
        f2.position.set(-300 * scale, 1900 * scale, 200 * scale);
        treeGroup.add(f2);

        const f3Geo = new THREE.DodecahedronGeometry(600 * scale, 1);
        const f3 = new THREE.Mesh(f3Geo, leafMatLight);
        f3.position.set(300 * scale, 2000 * scale, -200 * scale);
        treeGroup.add(f3);
      } else {
        // Bush / Flowering shrub
        const bushGeo = new THREE.DodecahedronGeometry(450 * scale, 1);
        const bush = new THREE.Mesh(bushGeo, leafMatLight);
        bush.position.y = 350 * scale;
        treeGroup.add(bush);
      }

      this.environmentGroup.add(treeGroup);
    });
  }

  public rebuildRoom(): void {
    if (this.roomMesh) {
      this.scene.remove(this.roomMesh.group);
    }
    this.roomMesh = new RoomMesh(this.project.room, this.shadingMode, this.selectedOpeningId);
    this.scene.add(this.roomMesh.group);
  }

  public rebuildAllCabinets(): void {
    // Clear old
    this.cabinetMeshes.forEach((mesh) => {
      this.scene.remove(mesh.group);
    });
    this.cabinetMeshes.clear();

    // Build new
    this.project.units.forEach((unit) => {
      const mesh = new ParametricCabinetMesh(unit, this.shadingMode);
      this.cabinetMeshes.set(unit.id, mesh);
      this.scene.add(mesh.group);
    });

    this.updateUnderCabinetLedLights();
    this.updateCabinetInteriorLights();
  }

  public updateCabinet(unit: ParametricCabinet): void {
    try {
      let mesh = this.cabinetMeshes.get(unit.id);
      if (mesh) {
        mesh.unitData = unit;
        mesh.rebuild(this.shadingMode);
      } else {
        mesh = new ParametricCabinetMesh(unit, this.shadingMode);
        this.cabinetMeshes.set(unit.id, mesh);
        this.scene.add(mesh.group);
      }
      this.updateUnderCabinetLedLights();
      this.updateCabinetInteriorLights();
      this.requestShadowUpdate();
      this.requestRender?.();
    } catch (err) {
      console.warn('Failed to rebuild cabinet mesh safely:', err);
    }
  }

  public removeCabinet(unitId: string): void {
    try {
      const mesh = this.cabinetMeshes.get(unitId);
      if (mesh) {
        this.scene.remove(mesh.group);
        this.cabinetMeshes.delete(unitId);
      }
      this.updateUnderCabinetLedLights();
      this.updateCabinetInteriorLights();
      this.requestShadowUpdate();
      this.requestRender?.();
    } catch (err) {
      console.warn('Failed to remove cabinet mesh safely:', err);
    }
  }

  public setShadingMode(mode: ShadingMode): void {
    this.shadingMode = mode;
    this.rebuildRoom();
    this.rebuildAllCabinets();
  }

  public applyLightingConfig(lighting: LightingConfig): void {
    // 0. Preset Mode (Daylight vs. Nighttime vs. Golden Hour vs. Evening)
    if (lighting.presetMode === 'night') {
      this.scene.background = new THREE.Color(0x090d18);
      if (this.scene.fog) {
        this.scene.fog.color.set(0x090d18);
      }
      if (this.hemiLight) {
        this.hemiLight.color.set(0x1e293b);
        this.hemiLight.groundColor.set(0x020617);
        this.hemiLight.intensity = 0.2;
      }
    } else if (lighting.presetMode === 'golden_hour') {
      this.scene.background = new THREE.Color(0x1c140e);
      if (this.scene.fog) {
        this.scene.fog.color.set(0x1c140e);
      }
      if (this.hemiLight) {
        this.hemiLight.color.set(0xfed7aa);
        this.hemiLight.groundColor.set(0x451a03);
        this.hemiLight.intensity = 0.45;
      }
    } else if (lighting.presetMode === 'evening') {
      this.scene.background = new THREE.Color(0x111827);
      if (this.scene.fog) {
        this.scene.fog.color.set(0x111827);
      }
      if (this.hemiLight) {
        this.hemiLight.color.set(0x94a3b8);
        this.hemiLight.groundColor.set(0x0f172a);
        this.hemiLight.intensity = 0.35;
      }
    } else {
      // Day / Studio
      this.scene.background = new THREE.Color(0xf3f4f6);
      if (this.scene.fog) {
        this.scene.fog.color.set(0xf3f4f6);
      }
      if (this.hemiLight) {
        this.hemiLight.color.set(0xfffbeb);
        this.hemiLight.groundColor.set(0x1e293b);
        this.hemiLight.intensity = 0.45;
      }
    }

    // 1. Ambient Light
    const isAmbientOn = lighting.ambientEnabled ?? true;
    this.ambientLight.intensity = isAmbientOn ? (lighting.ambientIntensity ?? 0.7) : 0;
    this.ambientLight.color.set(lighting.ambientColor || '#ffffff');

    // 2. Sun Directional Light
    const isSunOn = isAmbientOn;
    this.sunLight.intensity = isSunOn ? (lighting.sunIntensity ?? 1.2) : (lighting.sunIntensity ?? 1.2) * 0.2;
    this.sunLight.color.set(lighting.sunColor || '#fffbeb');
    this.sunLight.castShadow = lighting.shadowsEnabled ?? true;

    // 3. Ceiling Spotlights Grid
    this.spotLights.forEach((sl) => {
      this.scene.remove(sl.target);
      this.scene.remove(sl);
    });
    this.spotLights = [];

    if (lighting.ceilingSpotlights) {
      const rW = this.project.room.width / 3;
      const rL = this.project.room.length / 3;
      const ceilingH = this.project.room.height - 40;
      const positions = [
        [-rW, ceilingH, -rL],
        [rW, ceilingH, -rL],
        [-rW, ceilingH, rL],
        [rW, ceilingH, rL],
        [0, ceilingH, 0], // Center spotlight
      ];

      positions.forEach(([sx, sy, sz]) => {
        const spot = new THREE.SpotLight(
          lighting.ceilingSpotlightColor || '#fff7ed',
          lighting.ceilingIntensity ?? 0.8
        );
        spot.position.set(sx, sy, sz);
        spot.angle = Math.PI / 3.8;
        spot.penumbra = 0.6;
        spot.decay = 1.8;
        spot.distance = 7000;
        spot.castShadow = lighting.shadowsEnabled ?? true;
        if (spot.shadow) {
          spot.shadow.mapSize.width = 1024;
          spot.shadow.mapSize.height = 1024;
          spot.shadow.bias = -0.0005;
        }

        const targetObj = new THREE.Object3D();
        targetObj.position.set(sx * 0.5, 0, sz * 0.5);
        this.scene.add(targetObj);
        spot.target = targetObj;

        this.scene.add(spot);
        this.spotLights.push(spot);
      });
    }

    // 4. Update Cabinet and Under-Cabinet LED systems
    this.updateUnderCabinetLedLights();
    this.updateCabinetInteriorLights();
  }

  public updateUnderCabinetLedLights(): void {
    this.underCabinetLights.forEach((led) => this.scene.remove(led));
    this.underCabinetLights = [];

    if (this.project.lighting.underCabinetLed) {
      const ledColor = this.project.lighting.underCabinetLedColor || '#fef08a';
      const ledIntensity = this.project.lighting.underCabinetIntensity ?? 0.85;

      this.project.units.forEach((u) => {
        if (u.category === 'kitchen_wall') {
          // Linear light strip approximation under wall units
          const ledCount = u.width > 800 ? 2 : 1;
          const offsets = ledCount === 2 ? [-u.width / 4, u.width / 4] : [0];

          offsets.forEach((offX) => {
            const led = new THREE.PointLight(ledColor, ledIntensity, 1800, 1.8);
            const rad = (u.rotationY * Math.PI) / 180;
            const rotX = offX * Math.cos(rad);
            const rotZ = offX * Math.sin(rad);

            led.position.set(u.positionX + rotX, u.positionY - 15, u.positionZ + rotZ);
            this.scene.add(led);
            this.underCabinetLights.push(led);
          });
        }
      });
    }
  }

  public updateCabinetInteriorLights(): void {
    this.cabinetInteriorLights.forEach((led) => this.scene.remove(led));
    this.cabinetInteriorLights = [];

    if (this.project.lighting.cabinetInteriorLed) {
      const ledColor = this.project.lighting.cabinetInteriorLedColor || '#fef3c7';
      const ledIntensity = this.project.lighting.cabinetInteriorIntensity ?? 0.75;

      this.project.units.forEach((u) => {
        // Cabinet Interior lights glow inside glass units, open units, wardrobes, and tall cabinets
        const isGlassOrOpen =
          u.doorStyle === 'glass_frame' ||
          (u.doors && u.doors.some((d) => d.hasGlassPanel)) ||
          u.category === 'bedroom_wardrobe' ||
          u.category === 'bedroom_dressing' ||
          u.category === 'kitchen_tall';

        if (isGlassOrOpen || this.project.lighting.cabinetInteriorLed) {
          const interiorLight = new THREE.PointLight(ledColor, ledIntensity, 1500, 2.0);
          interiorLight.position.set(
            u.positionX,
            u.positionY + u.height * 0.65,
            u.positionZ
          );
          this.scene.add(interiorLight);
          this.cabinetInteriorLights.push(interiorLight);
        }
      });
    }
  }

  /**
   * Toggles between first-person walk mode and orbit/rotate mode
   * preserving camera position exactly so it never jumps or resets!
   */
  public setWalkMode(walk: boolean, preservePosition: boolean = true): void {
    if (this.isWalkMode === walk) return;

    if (preservePosition) {
      if (walk) {
        // Transition Orbit/Pan -> Walk mode: retain or safely position camera inside room
        const { width: rW, length: rL } = this.project.room;
        const halfW = (rW || 6000) / 2;
        const halfL = (rL || 5000) / 2;
        const margin = 400;

        let posX = this.camera.position.x;
        let posZ = this.camera.position.z;

        // If camera was outside room or very high (overview orbit), spawn inside central walkable area
        if (Math.abs(posX) > halfW - margin || Math.abs(posZ) > halfL - margin || this.camera.position.y > 2200) {
          posX = 0;
          posZ = Math.min(halfL - margin, Math.max(-halfL + margin, 500));
        } else {
          posX = Math.max(-halfW + margin, Math.min(halfW - margin, posX));
          posZ = Math.max(-halfL + margin, Math.min(halfL - margin, posZ));
        }

        this.walkPosition.set(posX, this.walkEyeHeight, posZ);

        const dir = new THREE.Vector3();
        this.camera.getWorldDirection(dir);
        this.walkYaw = Math.atan2(-dir.x, -dir.z);
        this.walkPitch = Math.asin(Math.max(-0.95, Math.min(0.95, dir.y)));
        this.isWalkMode = true;
        this.camera.fov = 68;
        this.camera.updateProjectionMatrix();
      } else {
        // Transition Walk mode -> Orbit/Rotate/Pan mode: retain current camera location
        const dir = new THREE.Vector3();
        this.camera.getWorldDirection(dir);
        const orbitDist = Math.max(600, Math.min(2500, this.targetRadius || 1200));
        const target = new THREE.Vector3().addVectors(this.camera.position, dir.clone().multiplyScalar(orbitDist));
        this.targetCenter.copy(target);
        this.cameraTarget.copy(target);

        const offset = new THREE.Vector3().subVectors(this.camera.position, this.cameraTarget);
        this.cameraRadius = offset.length();
        this.targetRadius = this.cameraRadius;
        this.cameraTheta = Math.atan2(offset.x, offset.z);
        this.targetTheta = this.cameraTheta;
        const clampedY = Math.max(-this.cameraRadius * 0.99, Math.min(this.cameraRadius * 0.99, offset.y));
        this.cameraPhi = Math.acos(clampedY / this.cameraRadius);
        this.targetPhi = this.cameraPhi;
        this.isWalkMode = false;
        this.camera.fov = 54;
        this.camera.updateProjectionMatrix();
      }
    } else {
      this.isWalkMode = walk;
    }

    this.updateCameraTransform();
    this.requestShadowUpdate();
  }

  /**
   * Switches navigation mode between walk, rotate, and pan
   * without altering or resetting camera position
   */
  public setNavigationMode(mode: 'walk' | 'rotate' | 'pan'): void {
    if (mode === 'walk') {
      this.setWalkMode(true, true);
    } else {
      this.setWalkMode(false, true);
    }
  }

  public setCameraPreset(preset: CameraPreset): void {
    const roomDim = Math.max(this.project.room.width, this.project.room.length, 2800);
    switch (preset) {
      case 'perspective':
        if (this.isWalkMode) {
          this.setWalkMode(false, true);
          return;
        }
        this.isWalkMode = false;
        this.camera.fov = 54;
        this.camera.updateProjectionMatrix();
        this.targetTheta = 0;
        this.targetPhi = Math.PI / 4.2;
        this.targetRadius = Math.round(roomDim * 1.35);
        this.targetCenter.set(0, 800, 0);
        break;
      case 'top':
        this.isWalkMode = false;
        this.camera.fov = 50;
        this.camera.updateProjectionMatrix();
        this.targetTheta = 0;
        this.targetPhi = 0.05;
        this.targetRadius = Math.round(roomDim * 1.5);
        this.targetCenter.set(0, 0, 0);
        break;
      case 'front':
        this.isWalkMode = false;
        this.camera.fov = 52;
        this.camera.updateProjectionMatrix();
        this.targetTheta = 0;
        this.targetPhi = Math.PI / 2 - 0.01;
        this.targetRadius = Math.round(roomDim * 1.35);
        this.targetCenter.set(0, 900, 0);
        break;
      case 'side':
        this.isWalkMode = false;
        this.camera.fov = 52;
        this.camera.updateProjectionMatrix();
        this.targetTheta = Math.PI / 2;
        this.targetPhi = Math.PI / 2 - 0.01;
        this.targetRadius = Math.round(roomDim * 1.35);
        this.targetCenter.set(0, 900, 0);
        break;
      case 'isometric':
        this.isWalkMode = false;
        this.camera.fov = 52;
        this.camera.updateProjectionMatrix();
        this.targetTheta = Math.PI / 4;
        this.targetPhi = Math.PI / 3.2;
        this.targetRadius = Math.round(roomDim * 1.45);
        this.targetCenter.set(0, 800, 0);
        break;
      case 'eye_level':
        if (!this.isWalkMode) {
          this.setWalkMode(true, true);
        }
        return;
    }
    // Fast snap for instant preset response
    this.cameraTheta = this.targetTheta;
    this.cameraPhi = this.targetPhi;
    this.cameraRadius = this.targetRadius;
    this.cameraTarget.copy(this.targetCenter);
    this.updateCameraTransform();
    this.requestShadowUpdate();
  }

  public zoomCamera(factor: number): void {
    if (this.isWalkMode) {
      if (factor > 1.0) {
        // Zoom out in walk mode: broaden view angle and step backward
        this.camera.fov = Math.min(88, this.camera.fov + 4);
        this.camera.updateProjectionMatrix();
        this.walkContinuous(-1, 0, 350);
      } else {
        // Zoom in in walk mode: narrow view and step forward
        this.camera.fov = Math.max(42, this.camera.fov - 4);
        this.camera.updateProjectionMatrix();
        this.walkContinuous(1, 0, 350);
      }
      this.updateCameraTransform();
      this.requestShadowUpdate();
      return;
    }
    // In 3D Orbit / Perspective: completely unconstrained zoom out up to 35,000mm!
    this.targetRadius = Math.max(300, Math.min(35000, this.targetRadius * factor));
    this.cameraRadius = Math.max(300, Math.min(35000, this.cameraRadius * factor));
    this.updateCameraTransform();
    this.requestShadowUpdate();
  }

  public rotateCameraStep(direction: 'left' | 'right' | 'up' | 'down', angleDeg: number = 20): void {
    const rad = (angleDeg * Math.PI) / 180;
    if (this.isWalkMode) {
      if (direction === 'left') this.walkYaw += rad;
      else if (direction === 'right') this.walkYaw -= rad;
      else if (direction === 'up') this.walkPitch = Math.min(Math.PI / 2.6, this.walkPitch + rad);
      else if (direction === 'down') this.walkPitch = Math.max(-Math.PI / 2.6, this.walkPitch - rad);
      this.updateCameraTransform();
      this.requestShadowUpdate();
      return;
    }

    if (direction === 'left') {
      this.targetTheta -= rad;
    } else if (direction === 'right') {
      this.targetTheta += rad;
    } else if (direction === 'up') {
      this.targetPhi = Math.max(0.02, this.targetPhi - rad);
    } else if (direction === 'down') {
      this.targetPhi = Math.min(Math.PI / 2 - 0.02, this.targetPhi + rad);
    }
    this.requestShadowUpdate();
  }

  /**
   * Sets or toggles Camera 0.5x Ultra-Wide view (88° FOV)
   */
  public setCameraWide05(enabled: boolean): void {
    this.camera.fov = enabled ? 88 : 54;
    this.camera.updateProjectionMatrix();
    this.requestShadowUpdate();
  }

  public isCameraWide05(): boolean {
    return this.camera.fov >= 80;
  }

  public toggleCameraWide05(): boolean {
    const nextState = this.camera.fov < 80;
    this.setCameraWide05(nextState);
    return nextState;
  }

  /**
   * Continuous camera rotation for analog joystick control (-1.0 to 1.0 on both axes)
   * Dragging right (positive normalizedX) increases theta, rotating the view to the right.
   * Reduced speed multiplier for buttery-smooth, gentle rotation control.
   */
  public rotateCameraContinuous(normalizedX: number, normalizedY: number, speedMultiplier: number = 0.015): void {
    if (this.isWalkMode) {
      this.walkYaw -= normalizedX * speedMultiplier;
      this.walkPitch = Math.max(-Math.PI / 2.6, Math.min(Math.PI / 2.6, this.walkPitch - normalizedY * speedMultiplier));
      this.updateCameraTransform();
      this.requestShadowUpdate();
      return;
    }

    this.targetTheta += normalizedX * speedMultiplier;
    this.targetPhi += normalizedY * speedMultiplier;
    this.targetPhi = Math.max(0.015, Math.min(Math.PI / 2 - 0.015, this.targetPhi));
    this.requestShadowUpdate();
  }

  /**
   * Continuous camera pan for analog joystick / dpad
   */
  public panCameraContinuous(normalizedX: number, normalizedY: number, speedMultiplier: number = 25): void {
    if (this.isWalkMode) {
      this.walkContinuous(normalizedY, normalizedX, speedMultiplier * 4);
      return;
    }
    const right = new THREE.Vector3(Math.cos(this.cameraTheta), 0, -Math.sin(this.cameraTheta));
    const forward = new THREE.Vector3(-Math.sin(this.cameraTheta), 0, -Math.cos(this.cameraTheta));
    this.targetCenter.addScaledVector(right, normalizedX * speedMultiplier);
    this.targetCenter.addScaledVector(forward, normalizedY * speedMultiplier);
    if (this.cameraCollisionEnabled) {
      this.constrainTargetCenter();
    }
    this.requestShadowUpdate();
  }

  /**
   * Human Walk / Run Mode (FPS Walk / Pan inside room)
   * normForward: +1 forward, -1 backward
   * normRight: +1 strafe right, -1 strafe left
   * speedMmPerStep: step speed in mm (multiplied by sprint mode)
   */
  public walkContinuous(normForward: number, normRight: number, speedMmPerStep: number = 110): void {
    if (!this.isWalkMode) {
      // In orbit mode: forward/backward moves target center along camera look direction
      const forward = new THREE.Vector3(
        -Math.sin(this.cameraTheta),
        0,
        -Math.cos(this.cameraTheta)
      ).normalize();

      const right = new THREE.Vector3(
        Math.cos(this.cameraTheta),
        0,
        -Math.sin(this.cameraTheta)
      ).normalize();

      const moveDelta = new THREE.Vector3();
      moveDelta.addScaledVector(forward, normForward * speedMmPerStep);
      moveDelta.addScaledVector(right, normRight * speedMmPerStep);

      this.targetCenter.add(moveDelta);

      if (this.cameraCollisionEnabled) {
        this.constrainTargetCenter();
      }
      this.requestShadowUpdate();
      return;
    }

    // In TRUE First-Person Walk Mode: move human avatar smoothly inside room
    const fwd = new THREE.Vector3(-Math.sin(this.walkYaw), 0, -Math.cos(this.walkYaw)).normalize();
    const rgt = new THREE.Vector3(Math.cos(this.walkYaw), 0, -Math.sin(this.walkYaw)).normalize();

    const moveDelta = new THREE.Vector3();
    moveDelta.addScaledVector(fwd, normForward * speedMmPerStep);
    moveDelta.addScaledVector(rgt, normRight * speedMmPerStep);

    const candidatePos = this.walkPosition.clone().add(moveDelta);
    candidatePos.y = this.walkEyeHeight;

    const { width: rW, length: rL } = this.project.room;
    const halfW = rW / 2;
    const halfL = rL / 2;
    const wallMargin = 220; // 220mm human body radius

    if (this.cameraCollisionEnabled) {
      // Smooth slide along room perimeter
      candidatePos.x = Math.max(-halfW + wallMargin, Math.min(halfW - wallMargin, candidatePos.x));
      candidatePos.z = Math.max(-halfL + wallMargin, Math.min(halfL - wallMargin, candidatePos.z));

      // Sliding collision against kitchen units/appliances (excluding wall-mounted cabinets above eye level)
      for (const u of this.project.units) {
        if (u.category === 'kitchen_wall') continue;
        const isRotated = Math.abs((u.rotationY || 0) % 180) === 90;
        const uHalfW = (isRotated ? u.depth : u.width) / 2 + 120; // 120mm body margin
        const uHalfD = (isRotated ? u.width : u.depth) / 2 + 120;

        const minX = u.positionX - uHalfW;
        const maxX = u.positionX + uHalfW;
        const minZ = u.positionZ - uHalfD;
        const maxZ = u.positionZ + uHalfD;

        if (
          candidatePos.x > minX &&
          candidatePos.x < maxX &&
          candidatePos.z > minZ &&
          candidatePos.z < maxZ
        ) {
          // Push out smoothly along the shallowest penetration axis so user slides along cabinets
          const overlapLeft = candidatePos.x - minX;
          const overlapRight = maxX - candidatePos.x;
          const overlapBack = candidatePos.z - minZ;
          const overlapFront = maxZ - candidatePos.z;

          const minOverlapX = Math.min(overlapLeft, overlapRight);
          const minOverlapZ = Math.min(overlapBack, overlapFront);

          if (minOverlapX < minOverlapZ) {
            candidatePos.x = overlapLeft < overlapRight ? minX : maxX;
          } else {
            candidatePos.z = overlapBack < overlapFront ? minZ : maxZ;
          }
        }
      }
    } else {
      candidatePos.x = Math.max(-halfW + 60, Math.min(halfW - 60, candidatePos.x));
      candidatePos.z = Math.max(-halfL + 60, Math.min(halfL - 60, candidatePos.z));
    }

    this.walkPosition.copy(candidatePos);
    this.updateCameraTransform();
    this.requestShadowUpdate();
  }

  public panCamera(deltaRightMm: number, deltaUpMm: number): void {
    if (this.isWalkMode) {
      const rgt = new THREE.Vector3(Math.cos(this.walkYaw), 0, -Math.sin(this.walkYaw)).normalize();
      this.walkPosition.addScaledVector(rgt, deltaRightMm);
      this.walkPosition.y = Math.max(400, Math.min(2500, this.walkPosition.y + deltaUpMm));
      this.updateCameraTransform();
      this.requestShadowUpdate();
      return;
    }

    const forward = new THREE.Vector3().subVectors(this.targetCenter, this.camera.position).normalize();
    const right = new THREE.Vector3().crossVectors(forward, this.camera.up).normalize();
    const up = new THREE.Vector3().crossVectors(right, forward).normalize();

    this.targetCenter.addScaledVector(right, deltaRightMm);
    this.targetCenter.addScaledVector(up, deltaUpMm);

    if (this.cameraCollisionEnabled) {
      this.constrainTargetCenter();
    }
    this.requestShadowUpdate();
  }

  public constrainTargetCenter(): void {
    const { width: rW, length: rL, height: rH } = this.project.room;
    const halfW = rW / 2;
    const halfL = rL / 2;
    const margin = 250;
    this.targetCenter.x = Math.max(-halfW + margin, Math.min(halfW - margin, this.targetCenter.x));
    this.targetCenter.z = Math.max(-halfL + margin, Math.min(halfL - margin, this.targetCenter.z));
    this.targetCenter.y = Math.max(150, Math.min(rH - 150, this.targetCenter.y));
  }

  public setAutoRotate(enabled: boolean, speed: number = 0.35): void {
    this.autoRotateEnabled = enabled;
    this.autoRotateSpeed = speed;
    this.requestShadowUpdate();
  }

  public toggleAutoRotate(): boolean {
    this.autoRotateEnabled = !this.autoRotateEnabled;
    this.requestShadowUpdate();
    return this.autoRotateEnabled;
  }

  public setInteractMode(enabled: boolean): void {
    this.isInteractMode = enabled;
    if (this.renderer?.domElement) {
      this.renderer.domElement.style.cursor = enabled ? 'pointer' : 'default';
    }
  }

  public frameAll(): void {
    this.isWalkMode = false;
    const roomDim = Math.max(this.project.room.width, this.project.room.length, 2800);
    this.camera.fov = 54;
    this.camera.updateProjectionMatrix();
    this.targetCenter.set(0, 800, 0);
    this.targetRadius = Math.round(roomDim * 1.4);
    this.targetTheta = Math.PI / 4;
    this.targetPhi = Math.PI / 3.2;
    this.cameraTarget.copy(this.targetCenter);
    this.cameraRadius = this.targetRadius;
    this.cameraTheta = this.targetTheta;
    this.cameraPhi = this.targetPhi;
    this.updateCameraTransform();
    this.requestShadowUpdate();
  }

  public requestShadowUpdate(): void {
    this.shadowNeedsUpdate = true;
  }

  /**
   * Moves a cabinet using D-Pad with full collision prevention
   */
  public moveCabinetByDpad(
    unitId: string,
    axis: 'x' | 'y' | 'z',
    deltaMm: number,
    collisionGuardOverride?: boolean
  ): {
    success: boolean;
    collided: boolean;
    collidedWith?: string;
    position: { x: number; y: number; z: number };
    newPosition: { x: number; y: number; z: number };
  } {
    const unit = this.project.units.find((u) => u.id === unitId);
    if (!unit) {
      return {
        success: false,
        collided: false,
        position: { x: 0, y: 0, z: 0 },
        newPosition: { x: 0, y: 0, z: 0 },
      };
    }

    const useCollisionGuard =
      collisionGuardOverride !== undefined ? collisionGuardOverride : this.collisionGuardEnabled;

    const targetPos = {
      x: unit.positionX + (axis === 'x' ? deltaMm : 0),
      y: Math.max(0, unit.positionY + (axis === 'y' ? deltaMm : 0)),
      z: unit.positionZ + (axis === 'z' ? deltaMm : 0),
    };

    if (useCollisionGuard) {
      const resolved = resolveCabinetMovement(unit, targetPos, this.project.units, this.project.room);
      unit.positionX = resolved.position.x;
      unit.positionY = resolved.position.y;
      unit.positionZ = resolved.position.z;

      this.updateCabinet(unit);
      this.requestShadowUpdate();

      const finalPos = { x: unit.positionX, y: unit.positionY, z: unit.positionZ };
      return {
        success: true,
        collided: resolved.collided,
        collidedWith: resolved.collidedWithUnitName,
        position: finalPos,
        newPosition: finalPos,
      };
    } else {
      unit.positionX = targetPos.x;
      unit.positionY = targetPos.y;
      unit.positionZ = targetPos.z;

      this.updateCabinet(unit);
      this.requestShadowUpdate();

      const finalPos = { x: unit.positionX, y: unit.positionY, z: unit.positionZ };
      return {
        success: true,
        collided: false,
        position: finalPos,
        newPosition: finalPos,
      };
    }
  }

  public snapPosition(unit: ParametricCabinet, newX: number, newY: number, newZ: number): { x: number; y: number; z: number } {
    if (!this.snapSettings.enabled) {
      if (this.collisionGuardEnabled) {
        const resolved = resolveCabinetMovement(unit, { x: newX, y: newY, z: newZ }, this.project.units, this.project.room);
        return resolved.position;
      }
      return { x: newX, y: newY, z: newZ };
    }

    let snappedX = newX;
    let snappedY = newY;
    let snappedZ = newZ;

    const rW = this.project.room.width / 2;
    const rL = this.project.room.length / 2;
    const halfW = unit.width / 2;
    const halfD = unit.depth / 2;
    const snapDist = this.snapSettings.snapDistance;

    // 1. Snap to North Back Wall (-Z)
    if (this.snapSettings.snapToWall) {
      const backWallZ = -rL + halfD;
      if (Math.abs(snappedZ - backWallZ) < snapDist) {
        snappedZ = backWallZ;
      }
      // Snap to East Wall (+X)
      const eastWallX = rW - halfW;
      if (Math.abs(snappedX - eastWallX) < snapDist) {
        snappedX = eastWallX;
      }
      // Snap to West Wall (-X)
      const westWallX = -rW + halfW;
      if (Math.abs(snappedX - westWallX) < snapDist) {
        snappedX = westWallX;
      }
    }

    // 2. Snap to Adjacent Cabinets
    if (this.snapSettings.snapToCabinet) {
      this.project.units.forEach((other) => {
        if (other.id === unit.id) return;
        const otherHalfW = other.width / 2;
        // Snap X (Left edge of unit to Right edge of other, or vice versa)
        const leftSnapX = other.positionX + otherHalfW + halfW;
        const rightSnapX = other.positionX - otherHalfW - halfW;
        if (Math.abs(snappedX - leftSnapX) < snapDist && Math.abs(snappedZ - other.positionZ) < 100) {
          snappedX = leftSnapX;
          snappedZ = other.positionZ; // Align Z depth automatically!
        } else if (Math.abs(snappedX - rightSnapX) < snapDist && Math.abs(snappedZ - other.positionZ) < 100) {
          snappedX = rightSnapX;
          snappedZ = other.positionZ;
        }
      });
    }

    // 3. Grid Snapping
    if (this.snapSettings.gridSize > 0) {
      const grid = this.snapSettings.gridSize;
      snappedX = Math.round(snappedX / grid) * grid;
      snappedZ = Math.round(snappedZ / grid) * grid;
    }

    // 4. Strict Collision Prevention Check
    if (this.collisionGuardEnabled) {
      const resolved = resolveCabinetMovement(
        unit,
        { x: snappedX, y: snappedY, z: snappedZ },
        this.project.units,
        this.project.room
      );
      snappedX = resolved.position.x;
      snappedY = resolved.position.y;
      snappedZ = resolved.position.z;
    }

    return { x: snappedX, y: snappedY, z: snappedZ };
  }

  public areAnyDoorsOrDrawersOpen(): boolean {
    for (const mesh of this.cabinetMeshes.values()) {
      const hasDoorOpen = (mesh as any).doorPivots?.some((dp: any) => dp.targetAngle > 45);
      const hasDrawerOpen = (mesh as any).drawerSlides?.some((ds: any) => ds.targetAmount > 0.5);
      if (hasDoorOpen || hasDrawerOpen) return true;
    }
    return false;
  }

  public toggleAllDoorsAndDrawers(): boolean {
    const isOpen = this.areAnyDoorsOrDrawersOpen();
    if (isOpen) {
      this.closeAllDoorsAndDrawers();
      return false;
    } else {
      this.openAllDoorsAndDrawers();
      return true;
    }
  }

  public openAllDoorsAndDrawers(): void {
    this.cabinetMeshes.forEach((mesh) => mesh.openAll());
    this.requestShadowUpdate();
  }

  public closeAllDoorsAndDrawers(): void {
    this.cabinetMeshes.forEach((mesh) => mesh.closeAll());
    this.requestShadowUpdate();
  }

  public toggleUnitDoors(unitId: string): boolean {
    const mesh = this.cabinetMeshes.get(unitId);
    if (mesh) {
      const res = mesh.toggleUnitOpenClose();
      this.requestShadowUpdate();
      return res;
    }
    return false;
  }

  public setCameraCollisionEnabled(enabled: boolean): void {
    this.cameraCollisionEnabled = enabled;
    this.updateCameraTransform();
  }

  /**
   * Unreal Engine style SpringArm camera collision solver:
   * Prevents camera from penetrating or clipping into walls, floor, ceiling, and kitchen cabinets/appliances
   */
  private resolveCameraCollision(candidatePos: THREE.Vector3, target: THREE.Vector3): THREE.Vector3 {
    const dir = new THREE.Vector3().subVectors(candidatePos, target);
    const fullDist = dir.length();
    if (fullDist < 1) return candidatePos;
    dir.normalize();

    let maxDist = fullDist;
    const { width: rW, length: rL, height: rH } = this.project.room;
    const halfW = rW / 2;
    const halfL = rL / 2;
    const wallBuffer = 150; // 150mm safety distance away from walls

    // 1. Collision with All Room Walls (SpringArm raycast)
    // North Wall (-Z)
    if (dir.z < -0.001) {
      const wallZ = -halfL + wallBuffer;
      if (target.z > wallZ) {
        const t = (wallZ - target.z) / dir.z;
        if (t > 20 && t < maxDist) {
          maxDist = t;
        }
      }
    }

    // South Wall (+Z)
    if (dir.z > 0.001) {
      const wallZ = halfL - wallBuffer;
      if (target.z < wallZ) {
        const t = (wallZ - target.z) / dir.z;
        if (t > 20 && t < maxDist) {
          maxDist = t;
        }
      }
    }

    // West Wall (-X)
    if (dir.x < -0.001) {
      const wallX = -halfW + wallBuffer;
      if (target.x > wallX) {
        const t = (wallX - target.x) / dir.x;
        if (t > 20 && t < maxDist) {
          maxDist = t;
        }
      }
    }

    // East Wall (+X)
    if (dir.x > 0.001) {
      const wallX = halfW - wallBuffer;
      if (target.x < wallX) {
        const t = (wallX - target.x) / dir.x;
        if (t > 20 && t < maxDist) {
          maxDist = t;
        }
      }
    }

    // Floor (Y = 0)
    if (dir.y < -0.001) {
      const floorY = 120;
      if (target.y > floorY) {
        const t = (floorY - target.y) / dir.y;
        if (t > 20 && t < maxDist) {
          maxDist = t;
        }
      }
    }

    // Ceiling (Y = rH)
    if (dir.y > 0.001) {
      const ceilY = rH - 120;
      if (target.y < ceilY) {
        const t = (ceilY - target.y) / dir.y;
        if (t > 20 && t < maxDist) {
          maxDist = t;
        }
      }
    }

    // 2. Collision with Cabinets & Appliances (Raycast & Bounding Box)
    const cabRay = new THREE.Ray(target, dir);
    const hitPoint = new THREE.Vector3();
    const cabBoxes: THREE.Box3[] = [];
    const cabBuffer = 90;

    for (const unit of this.project.units) {
      const ctH = unit.countertop?.enabled ? (unit.countertop?.thickness || 35) : 0;
      const totalH = (unit.legsHeight || 0) + unit.height + ctH;
      const minX = unit.positionX - unit.width / 2 - cabBuffer;
      const maxX = unit.positionX + unit.width / 2 + cabBuffer;
      const minY = Math.max(0, unit.positionY - 10);
      const maxY = unit.positionY + totalH + cabBuffer;
      const minZ = unit.positionZ - unit.depth / 2 - cabBuffer;
      const maxZ = unit.positionZ + unit.depth / 2 + cabBuffer;

      const cabBox = new THREE.Box3(
        new THREE.Vector3(minX, minY, minZ),
        new THREE.Vector3(maxX, maxY, maxZ)
      );
      cabBoxes.push(cabBox);

      // If ray originates outside box and hits box
      if (!cabBox.containsPoint(target)) {
        const hit = cabRay.intersectBox(cabBox, hitPoint);
        if (hit) {
          const hitDist = target.distanceTo(hitPoint);
          if (hitDist < maxDist) {
            maxDist = Math.max(80, hitDist - 25);
          }
        }
      }
    }

    const resolved = target.clone().addScaledVector(dir, maxDist);

    // 3. Direct Unit Penetration Prevention
    // If the resolved position is inside or penetrates any cabinet box, push it out
    for (const box of cabBoxes) {
      if (box.containsPoint(resolved)) {
        // Push along direction towards target until outside box
        let safetyDist = maxDist;
        while (box.containsPoint(resolved) && safetyDist > 80) {
          safetyDist -= 40;
          resolved.copy(target).addScaledVector(dir, safetyDist);
        }
      }
    }

    // 4. Room Boundaries Hard Clamp
    resolved.x = Math.max(-halfW + wallBuffer, Math.min(halfW - wallBuffer, resolved.x));
    resolved.z = Math.max(-halfL + wallBuffer, Math.min(halfL - wallBuffer, resolved.z));
    resolved.y = Math.max(120, Math.min(rH - 120, resolved.y));

    return resolved;
  }

  public updateCameraTransform(): void {
    if (this.isWalkMode) {
      this.camera.position.copy(this.walkPosition);
      const cosPitch = Math.cos(this.walkPitch);
      const lookDir = new THREE.Vector3(
        -Math.sin(this.walkYaw) * cosPitch,
        Math.sin(this.walkPitch),
        -Math.cos(this.walkYaw) * cosPitch
      ).normalize();
      const lookTarget = new THREE.Vector3().addVectors(this.walkPosition, lookDir);
      this.camera.lookAt(lookTarget);
      this.cameraTarget.copy(lookTarget);
      this.targetCenter.copy(this.walkPosition);
      return;
    }

    // Clamp vertical orbit so camera doesn't flip over top/bottom
    this.cameraPhi = Math.max(0.01, Math.min(Math.PI / 2 - 0.01, this.cameraPhi));
    this.cameraRadius = Math.max(300, Math.min(35000, this.cameraRadius));

    const x = this.cameraRadius * Math.sin(this.cameraPhi) * Math.sin(this.cameraTheta);
    const y = this.cameraRadius * Math.cos(this.cameraPhi);
    const z = this.cameraRadius * Math.sin(this.cameraPhi) * Math.cos(this.cameraTheta);

    const pos = new THREE.Vector3(
      this.cameraTarget.x + x,
      this.cameraTarget.y + y,
      this.cameraTarget.z + z
    );

    // Keep orbit camera above floor level so it never clips under ground
    pos.y = Math.max(60, pos.y);

    this.camera.position.copy(pos);
    this.camera.lookAt(this.cameraTarget);
  }

  private setupEventListeners(): void {
    const el = this.renderer.domElement;

    el.addEventListener('pointerdown', (e: PointerEvent) => {
      // ONLY accept pointer down if targeted directly on the 3D canvas!
      // This prevents click-through when pressing UI buttons or overlays.
      if (e.target !== el) return;
      this.isPointerDown = true;
      this.pointerStartX = e.clientX;
      this.pointerStartY = e.clientY;
      this.pointerTotalDragDist = 0;
      this.isPanning = e.button === 2 || e.shiftKey; // Right click or Shift+drag to pan
      try {
        el.setPointerCapture(e.pointerId);
      } catch {}
    });

    window.addEventListener('pointermove', (e: PointerEvent) => {
      if (!this.isPointerDown) return;

      const deltaX = e.clientX - this.pointerStartX;
      const deltaY = e.clientY - this.pointerStartY;
      this.pointerTotalDragDist += Math.hypot(deltaX, deltaY);
      this.pointerStartX = e.clientX;
      this.pointerStartY = e.clientY;

      if (this.isWalkMode) {
        // Dragging in walk mode looks around seamlessly
        this.walkYaw -= deltaX * 0.005;
        this.walkPitch = Math.max(-Math.PI / 2.6, Math.min(Math.PI / 2.6, this.walkPitch - deltaY * 0.005));
        this.updateCameraTransform();
        this.requestShadowUpdate();
        return;
      }

      if (this.isPanning) {
        // Pan Target
        const panSpeed = this.targetRadius * 0.0008;
        const forward = new THREE.Vector3().subVectors(this.targetCenter, this.camera.position).normalize();
        const right = new THREE.Vector3().crossVectors(forward, this.camera.up).normalize();
        const up = new THREE.Vector3().crossVectors(right, forward).normalize();

        this.targetCenter.addScaledVector(right, -deltaX * panSpeed);
        this.targetCenter.addScaledVector(up, deltaY * panSpeed);
        if (this.cameraCollisionEnabled) {
          this.constrainTargetCenter();
        }
      } else {
        // Orbit: Update targets smoothly for 60/120fps interpolation
        const rotSpeed = 0.0045;
        this.targetTheta -= deltaX * rotSpeed;
        this.targetPhi -= deltaY * rotSpeed;
        this.targetPhi = Math.max(0.015, Math.min(Math.PI / 2 - 0.015, this.targetPhi));
      }
    });

    window.addEventListener('pointerup', (e: PointerEvent) => {
      if (this.isPointerDown) {
        // CRITICAL FIX: Only raycast/select 3D objects if total drag movement was minimal (<8px)
        // and pointer target was the 3D canvas itself! Never trigger selection after a rotate drag!
        if (this.pointerTotalDragDist < 8 && e.target === el) {
          this.handlePointerClick(e);
        }
        try {
          if (el.hasPointerCapture(e.pointerId)) {
            el.releasePointerCapture(e.pointerId);
          }
        } catch {}
      }
      this.isPointerDown = false;
      this.requestShadowUpdate();
    });

    el.addEventListener('wheel', (e: WheelEvent) => {
      e.preventDefault();
      const zoomFactor = 1 + (e.deltaY > 0 ? 0.08 : -0.08);
      this.zoomCamera(zoomFactor);
    }, { passive: false });

    // Touch Pinch Zoom support
    let touchDist = 0;
    el.addEventListener('touchstart', (e: TouchEvent) => {
      if (e.touches.length === 2) {
        touchDist = Math.hypot(
          e.touches[0].clientX - e.touches[1].clientX,
          e.touches[0].clientY - e.touches[1].clientY
        );
      }
    }, { passive: true });

    el.addEventListener('touchmove', (e: TouchEvent) => {
      if (e.touches.length === 2) {
        const newDist = Math.hypot(
          e.touches[0].clientX - e.touches[1].clientX,
          e.touches[0].clientY - e.touches[1].clientY
        );
        const diff = touchDist - newDist;
        this.targetRadius = Math.max(400, Math.min(15000, this.targetRadius + diff * 4));
        touchDist = newDist;
      }
    }, { passive: true });
  }

  private handlePointerClick(e: PointerEvent): void {
    if (e.target !== this.renderer.domElement) {
      return;
    }
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.pointer, this.camera);
    const intersects = this.raycaster.intersectObjects(this.scene.children, true);

    if (intersects.length > 0) {
      const hit = intersects[0];

      // Measure tool active
      if (this.measureTool.isActive) {
        if (!this.measureTool.startPoint) {
          this.measureTool.setStart(hit.point);
        } else {
          const dist = this.measureTool.setEnd(hit.point);
          if (this.callbacks.onMeasureDistance) {
            this.callbacks.onMeasureDistance(dist);
          }
        }
        return;
      }

      // Check if user clicked an Opening, Door or Drawer
      let curr: THREE.Object3D | null = hit.object;
      let doorInfo: { unitId: string; doorIndex: number } | null = null;
      let drawerInfo: { unitId: string; drawerIndex: number } | null = null;
      let foundUnitId: string | null = null;
      let foundOpeningId: string | null = null;
      let foundCustomWallId: string | null = null;

      while (curr && curr !== this.scene) {
        if (curr.userData?.customWallId) {
          foundCustomWallId = curr.userData.customWallId;
          break;
        }
        if (curr.userData?.isOpening) {
          foundOpeningId = curr.userData.openingId;
          break;
        }
        if (curr.userData?.isDoor) {
          doorInfo = { unitId: curr.userData.unitId, doorIndex: curr.userData.doorIndex };
        }
        if (curr.userData?.isDrawer) {
          drawerInfo = { unitId: curr.userData.unitId, drawerIndex: curr.userData.drawerIndex };
        }
        if (curr.userData?.isCabinet) {
          foundUnitId = curr.userData.unitId;
          break;
        }
        curr = curr.parent;
      }

      // If clicked on an opening (Door or Window on wall)
      if (foundOpeningId) {
        if (!this.isInteractMode) {
          this.setSelectedOpening(foundOpeningId);
          if (this.callbacks.onOpeningSelect) {
            this.callbacks.onOpeningSelect(foundOpeningId);
          }
          if (this.callbacks.onUnitSelect) {
            this.callbacks.onUnitSelect(null);
          }
        }
        return;
      }

      // If in walk mode OR direct interact mode:
      // Clicking any door, drawer, or unit toggles it open/close without opening properties panel!
      if (this.isWalkMode || this.isInteractMode) {
        if (doorInfo) {
          const mesh = this.cabinetMeshes.get(doorInfo.unitId);
          mesh?.toggleDoor(doorInfo.doorIndex);
          if (this.callbacks.onDoorToggle) {
            this.callbacks.onDoorToggle(doorInfo.unitId, doorInfo.doorIndex);
          }
        } else if (drawerInfo) {
          const mesh = this.cabinetMeshes.get(drawerInfo.unitId);
          mesh?.toggleDrawer(drawerInfo.drawerIndex);
          if (this.callbacks.onDrawerToggle) {
            this.callbacks.onDrawerToggle(drawerInfo.unitId, drawerInfo.drawerIndex);
          }
        } else if (foundUnitId) {
          const mesh = this.cabinetMeshes.get(foundUnitId);
          if (mesh) {
            const isOpen = mesh.toggleUnitOpenClose();
            if (this.callbacks.onUnitInteractToggle) {
              this.callbacks.onUnitInteractToggle(foundUnitId, isOpen);
            }
          }
        }
        // In walk or interact mode, never trigger selection or properties panel!
        return;
      }

      if (doorInfo) {
        const mesh = this.cabinetMeshes.get(doorInfo.unitId);
        mesh?.toggleDoor(doorInfo.doorIndex);
        if (this.callbacks.onDoorToggle) {
          this.callbacks.onDoorToggle(doorInfo.unitId, doorInfo.doorIndex);
        }
      } else if (drawerInfo) {
        const mesh = this.cabinetMeshes.get(drawerInfo.unitId);
        mesh?.toggleDrawer(drawerInfo.drawerIndex);
        if (this.callbacks.onDrawerToggle) {
          this.callbacks.onDrawerToggle(drawerInfo.unitId, drawerInfo.drawerIndex);
        }
      }

      // Normal mode: Trigger selection
      if (foundCustomWallId) {
        this.setSelectedOpening(null);
        this.callbacks.onOpeningSelect?.(null);
        this.callbacks.onUnitSelect?.(null);
        this.callbacks.onCustomWallSelect?.(foundCustomWallId);
      } else if (foundUnitId) {
        this.setSelectedOpening(null);
        this.callbacks.onOpeningSelect?.(null);
        this.callbacks.onCustomWallSelect?.(null);
        this.callbacks.onUnitSelect?.(foundUnitId);
      } else {
        this.setSelectedOpening(null);
        this.callbacks.onOpeningSelect?.(null);
        this.callbacks.onCustomWallSelect?.(null);
        this.callbacks.onUnitSelect?.(null);
      }
    } else {
      if (!this.isInteractMode) {
        this.setSelectedOpening(null);
        this.callbacks.onOpeningSelect?.(null);
        this.callbacks.onCustomWallSelect?.(null);
        this.callbacks.onUnitSelect?.(null);
      }
    }
  }

  public resize(): void {
    if (!this.container || this.isDisposed) return;
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    if (w === 0 || h === 0) return;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  }

  public handleResize(): void {
    this.resize();
  }

  public captureSnapshot(): string {
    this.renderer.render(this.scene, this.camera);
    return this.renderer.domElement.toDataURL('image/jpeg', 0.85);
  }

  /**
   * Captures ultra high-resolution render (4K / 2K / 1080p / Instagram Square)
   * Forces shadow map recalculation and multi-pass anti-aliased frame buffer.
   */
  public captureHighResSnapshot(
    targetWidth: number = 3840,
    targetHeight: number = 2160,
    format: 'png' | 'jpeg' = 'jpeg',
    quality: number = 0.96
  ): string {
    if (!this.container) return this.captureSnapshot();

    const originalWidth = this.container.clientWidth || 1920;
    const originalHeight = this.container.clientHeight || 1080;
    const originalAspect = this.camera.aspect;
    const originalPixelRatio = this.renderer.getPixelRatio();

    try {
      this.renderer.setPixelRatio(1);
      this.renderer.setSize(targetWidth, targetHeight, false);
      this.camera.aspect = targetWidth / targetHeight;
      this.camera.updateProjectionMatrix();

      // Recalculate shadows & lighting
      this.renderer.shadowMap.needsUpdate = true;
      this.renderer.render(this.scene, this.camera);

      const mime = format === 'png' ? 'image/png' : 'image/jpeg';
      const dataUrl = this.renderer.domElement.toDataURL(mime, quality);
      return dataUrl;
    } finally {
      this.renderer.setPixelRatio(originalPixelRatio);
      this.renderer.setSize(originalWidth, originalHeight, true);
      this.camera.aspect = originalAspect;
      this.camera.updateProjectionMatrix();
      this.renderer.render(this.scene, this.camera);
    }
  }

  private renderLoop = (): void => {
    if (this.isDisposed) return;
    const now = performance.now();
    const deltaTime = Math.min((now - this.lastTime) / 1000, 0.1);
    this.lastTime = now;

    // Automatic smooth cinematic camera orbit when enabled
    if (this.autoRotateEnabled && !this.isPointerDown) {
      this.targetTheta += this.autoRotateSpeed * deltaTime;
    }

    // Smooth camera damping for lag-free 60/120fps rotation and navigation
    const damping = 0.28;
    const dTheta = this.targetTheta - this.cameraTheta;
    const dPhi = this.targetPhi - this.cameraPhi;
    const dRadius = this.targetRadius - this.cameraRadius;
    const dCenter = this.targetCenter.distanceTo(this.cameraTarget);

    if (Math.abs(dTheta) > 0.0001 || Math.abs(dPhi) > 0.0001 || Math.abs(dRadius) > 0.5 || dCenter > 0.5) {
      this.cameraTheta += dTheta * damping;
      this.cameraPhi += dPhi * damping;
      this.cameraRadius += dRadius * damping;
      this.cameraTarget.lerp(this.targetCenter, damping);
      this.updateCameraTransform();
    }

    // Update animations for doors, drawers, and baskets
    let anyAnimationActive = false;
    this.cabinetMeshes.forEach((mesh) => {
      const active = mesh.updateAnimations(deltaTime);
      if (active) anyAnimationActive = true;
    });

    if (this.shadowNeedsUpdate || anyAnimationActive) {
      this.renderer.shadowMap.needsUpdate = true;
      this.shadowNeedsUpdate = false;
    }

    this.renderer.render(this.scene, this.camera);
    this.animationFrameId = requestAnimationFrame(this.renderLoop);
  };

  /**
   * Explicitly renders the current scene frame immediately
   */
  public requestRender(): void {
    if (this.renderer && this.scene && this.camera) {
      this.renderer.render(this.scene, this.camera);
    }
  }

  public getCanvas(): HTMLCanvasElement {
    return this.renderer.domElement;
  }

  /**
   * Get interactable object currently in front of camera center (Crosshair)
   */
  public getCenterTargetedInteractable(): {
    type: 'door' | 'drawer' | 'cabinet';
    unitId: string;
    unitName: string;
    doorIndex?: number;
    drawerIndex?: number;
    distanceMm: number;
    isOpen?: boolean;
  } | null {
    this.raycaster.setFromCamera(new THREE.Vector2(0, 0), this.camera);
    const intersects = this.raycaster.intersectObjects(this.scene.children, true);

    for (const hit of intersects) {
      if (hit.distance > 4500) continue; // max 4.5m interaction distance

      let curr: THREE.Object3D | null = hit.object;
      let doorInfo: { unitId: string; doorIndex: number } | null = null;
      let drawerInfo: { unitId: string; drawerIndex: number } | null = null;
      let foundUnitId: string | null = null;

      while (curr && curr !== this.scene) {
        if (curr.userData?.isDoor) {
          doorInfo = { unitId: curr.userData.unitId, doorIndex: curr.userData.doorIndex };
        }
        if (curr.userData?.isDrawer) {
          drawerInfo = { unitId: curr.userData.unitId, drawerIndex: curr.userData.drawerIndex };
        }
        if (curr.userData?.isCabinet) {
          foundUnitId = curr.userData.unitId;
          break;
        }
        curr = curr.parent;
      }

      if (foundUnitId) {
        const unit = this.project.units.find((u) => u.id === foundUnitId);
        const unitName = unit ? unit.name : 'خزانة';

        if (doorInfo) {
          return {
            type: 'door',
            unitId: foundUnitId,
            unitName,
            doorIndex: doorInfo.doorIndex,
            distanceMm: Math.round(hit.distance),
          };
        }
        if (drawerInfo) {
          return {
            type: 'drawer',
            unitId: foundUnitId,
            unitName,
            drawerIndex: drawerInfo.drawerIndex,
            distanceMm: Math.round(hit.distance),
          };
        }
        return {
          type: 'cabinet',
          unitId: foundUnitId,
          unitName,
          distanceMm: Math.round(hit.distance),
        };
      }
    }
    return null;
  }

  /**
   * Toggle door/drawer of targeted object in center of view, or nearest cabinet
   */
  public interactCenterOrNearest(): boolean {
    const targeted = this.getCenterTargetedInteractable();
    if (targeted) {
      const mesh = this.cabinetMeshes.get(targeted.unitId);
      if (mesh) {
        if (targeted.type === 'door' && targeted.doorIndex !== undefined) {
          mesh.toggleDoor(targeted.doorIndex);
          if (this.callbacks.onDoorToggle) this.callbacks.onDoorToggle(targeted.unitId, targeted.doorIndex);
          return true;
        }
        if (targeted.type === 'drawer' && targeted.drawerIndex !== undefined) {
          mesh.toggleDrawer(targeted.drawerIndex);
          if (this.callbacks.onDrawerToggle) this.callbacks.onDrawerToggle(targeted.unitId, targeted.drawerIndex);
          return true;
        }
        const openState = mesh.toggleUnitOpenClose();
        if (this.callbacks.onUnitInteractToggle) this.callbacks.onUnitInteractToggle(targeted.unitId, openState);
        return true;
      }
    }

    // If no direct center hit, find closest cabinet within 3 meters of player position
    const playerPos = this.isWalkMode ? this.walkPosition : this.camera.position;
    let closestUnitId: string | null = null;
    let closestDist = Infinity;

    for (const unit of this.project.units) {
      const uPos = new THREE.Vector3(unit.positionX, unit.positionY, unit.positionZ);
      const dist = playerPos.distanceTo(uPos);
      if (dist < 3200 && dist < closestDist) {
        closestDist = dist;
        closestUnitId = unit.id;
      }
    }

    if (closestUnitId) {
      const mesh = this.cabinetMeshes.get(closestUnitId);
      if (mesh) {
        const openState = mesh.toggleUnitOpenClose();
        if (this.callbacks.onUnitInteractToggle) this.callbacks.onUnitInteractToggle(closestUnitId, openState);
        return true;
      }
    }

    // Fallback: toggle all doors in room
    this.toggleAllDoorsAndDrawers();
    return true;
  }

  public dispose(): void {
    this.isDisposed = true;
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    this.renderer.dispose();
    if (this.container.contains(this.renderer.domElement)) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
