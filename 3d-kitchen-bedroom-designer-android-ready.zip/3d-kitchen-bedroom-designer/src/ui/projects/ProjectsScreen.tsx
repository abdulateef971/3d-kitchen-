import React, { useState } from 'react';
import { Project, ProjectType } from '../../types';
import { projectRepository } from '../../domain/storage/projectRepository';
import {
  FolderKanban,
  Search,
  Plus,
  Trash2,
  Copy,
  Edit2,
  ArrowRight,
  Sparkles,
  Layers,
  Box,
  Calendar,
  Clock,
  Download,
  Upload,
  AlertTriangle,
  X,
} from 'lucide-react';

interface ProjectsScreenProps {
  onOpenProject: (project: Project) => void;
  onCreateNewProject: (type: ProjectType) => void;
  onBackToHome: () => void;
}

export const ProjectsScreen: React.FC<ProjectsScreenProps> = ({
  onOpenProject,
  onCreateNewProject,
  onBackToHome,
}) => {
  const [projects, setProjects] = useState<Project[]>(() => projectRepository.getAllProjects());
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'kitchen' | 'bedroom'>('all');
  const [editingProjectId, setEditingProjectId] = useState<string | null>(null);
  const [newName, setNewName] = useState('');

  const [projectToDelete, setProjectToDelete] = useState<Project | null>(null);

  const refreshProjects = () => {
    setProjects(projectRepository.getAllProjects());
  };

  const handleRequestDelete = (project: Project, e: React.MouseEvent) => {
    e.stopPropagation();
    setProjectToDelete(project);
  };

  const handleConfirmDelete = () => {
    if (projectToDelete) {
      projectRepository.deleteProject(projectToDelete.projectId);
      setProjectToDelete(null);
      refreshProjects();
    }
  };

  const handleDuplicate = (project: Project, e: React.MouseEvent) => {
    e.stopPropagation();
    projectRepository.duplicateProject(project.projectId);
    refreshProjects();
  };

  const handleRenameSubmit = (id: string, e: React.FormEvent) => {
    e.preventDefault();
    if (newName.trim()) {
      const proj = projects.find((p) => p.projectId === id);
      if (proj) {
        projectRepository.saveProject({ ...proj, name: newName.trim() });
      }
      setEditingProjectId(null);
      refreshProjects();
    }
  };

  const handleExportJSON = (project: Project, e: React.MouseEvent) => {
    e.stopPropagation();
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(project, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${project.name.replace(/\s+/g, '_')}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const parsed = JSON.parse(evt.target?.result as string) as Project;
        parsed.projectId = `project_${Date.now()}`;
        parsed.name = `${parsed.name} (مستورد)`;
        projectRepository.saveProject(parsed);
        refreshProjects();
      } catch (err) {
        alert('الملف غير صالح لمشروع 3D CAD');
      }
    };
    reader.readAsText(file);
  };

  const filteredProjects = projects.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.notes && p.notes.toLowerCase().includes(searchQuery.toLowerCase()));
    if (!matchesSearch) return false;
    if (activeFilter === 'all') return true;
    return p.type === activeFilter;
  });

  return (
    <div className="min-h-screen bg-[#0F0F0F] text-[#E5E5E5] p-6 md:p-10 font-['Cairo',sans-serif]">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#333333] pb-6">
          <div className="flex items-center gap-3">
            <button
              onClick={onBackToHome}
              className="p-2 rounded-lg bg-[#1E1E1E] hover:bg-[#2A2A2A] text-gray-300 transition border border-[#333333]"
            >
              <ArrowRight className="w-4 h-4" />
            </button>
            <div>
              <h1 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2.5">
                <FolderKanban className="w-6 h-6 text-blue-400" />
                مشاريعي المحفوظة (My Projects)
              </h1>
              <p className="text-xs text-gray-400 mt-0.5">
                إدارة وتعديل وتصدير مخططات المطابخ وغرف النوم الثلاثية الأبعاد
              </p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3 flex-wrap">
            <label className="cursor-pointer px-3.5 py-2 rounded-lg bg-[#1E1E1E] hover:bg-[#2A2A2A] border border-[#333333] text-gray-300 text-xs font-semibold flex items-center gap-2 transition">
              <Upload className="w-3.5 h-3.5 text-blue-400" />
              استيراد ملف JSON
              <input type="file" accept=".json" onChange={handleImportJSON} className="hidden" />
            </label>

            <button
              onClick={() => onCreateNewProject('kitchen')}
              className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-2 shadow-md shadow-blue-600/25 transition"
            >
              <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
              مشروع جديد
            </button>
          </div>
        </div>

        {/* Filter & Search Bar */}
        <div className="p-3.5 bg-[#1E1E1E] rounded-xl border border-[#333333] flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="relative w-full sm:w-80">
            <Search className="w-3.5 h-3.5 text-gray-500 absolute right-3 top-2.5" />
            <input
              type="text"
              placeholder="ابحث عن مشروع بالاسم..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#121212] border border-[#383838] rounded-lg pr-9 pl-3.5 py-1.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition"
            />
          </div>

          <div className="flex items-center gap-1.5 w-full sm:w-auto text-xs">
            <button
              onClick={() => setActiveFilter('all')}
              className={`px-3 py-1.5 rounded-lg font-bold transition flex-1 sm:flex-initial text-xs ${
                activeFilter === 'all'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-[#121212] text-gray-400 hover:bg-[#252525] border border-[#333333]'
              }`}
            >
              الكل ({projects.length})
            </button>
            <button
              onClick={() => setActiveFilter('kitchen')}
              className={`px-3 py-1.5 rounded-lg font-bold transition flex-1 sm:flex-initial text-xs ${
                activeFilter === 'kitchen'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-[#121212] text-gray-400 hover:bg-[#252525] border border-[#333333]'
              }`}
            >
              المطابخ
            </button>
            <button
              onClick={() => setActiveFilter('bedroom')}
              className={`px-3 py-1.5 rounded-lg font-bold transition flex-1 sm:flex-initial text-xs ${
                activeFilter === 'bedroom'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-[#121212] text-gray-400 hover:bg-[#252525] border border-[#333333]'
              }`}
            >
              غرف النوم والخزائن
            </button>
          </div>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project) => (
            <div
              key={project.projectId}
              onClick={() => onOpenProject(project)}
              className="group bg-[#1E1E1E] hover:bg-[#252525] border border-[#333333] hover:border-blue-500/60 rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition duration-200 cursor-pointer flex flex-col"
            >
              {/* Thumbnail / 3D Canvas Preview */}
              <div className="relative w-full h-44 bg-[#121212] flex items-center justify-center overflow-hidden border-b border-[#333333]">
                {project.thumbnail ? (
                  <img
                    src={project.thumbnail}
                    alt={project.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center text-gray-600 gap-1.5">
                    <Box className="w-10 h-10 text-gray-700 group-hover:text-blue-500/40 transition" />
                    <span className="text-[10px] font-mono text-gray-500">3D CAD Model</span>
                  </div>
                )}

                {/* Badge */}
                <div className="absolute top-3 right-3">
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                      project.type === 'kitchen'
                        ? 'bg-blue-600/20 text-blue-400 border-blue-500/30'
                        : 'bg-amber-600/20 text-amber-400 border-amber-500/30'
                    }`}
                  >
                    {project.type === 'kitchen' ? 'مطبخ بارامتري' : 'غرفة نوم / خزانة'}
                  </span>
                </div>

                {/* Units Counter */}
                <div className="absolute bottom-3 left-3 bg-[#1E1E1E]/90 backdrop-blur-md px-2 py-0.5 rounded border border-[#333333] text-[10px] text-gray-300 font-mono flex items-center gap-1">
                  <Layers className="w-3 h-3 text-blue-400" />
                  {project.units.length} وحدات
                </div>
              </div>

              {/* Card Body */}
              <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  {editingProjectId === project.projectId ? (
                    <form onSubmit={(e) => handleRenameSubmit(project.projectId, e)} className="flex gap-2">
                      <input
                        type="text"
                        value={newName}
                        onChange={(e) => setNewName(e.target.value)}
                        className="bg-[#121212] border border-blue-500 rounded px-2 py-1 text-xs text-white flex-1 focus:outline-none"
                        autoFocus
                      />
                      <button type="submit" className="px-2.5 py-1 bg-blue-600 text-white font-bold text-xs rounded">
                        حفظ
                      </button>
                    </form>
                  ) : (
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="font-bold text-sm text-white group-hover:text-blue-400 transition">
                        {project.name}
                      </h3>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setEditingProjectId(project.projectId);
                          setNewName(project.name);
                        }}
                        className="text-gray-500 hover:text-gray-300 p-1"
                      >
                        <Edit2 className="w-3 h-3" />
                      </button>
                    </div>
                  )}

                  <p className="text-xs text-gray-400 mt-1 line-clamp-2 leading-relaxed">
                    {project.description ||
                      `أبعاد الغرفة: ${(project.room.width / 1000).toFixed(1)} × ${(project.room.length / 1000).toFixed(1)} متر`}
                  </p>
                </div>

                {/* Card Footer */}
                <div className="pt-3 border-t border-[#333333] flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1 text-[10px] text-gray-500">
                    <Clock className="w-3 h-3" />
                    <span>{new Date(project.updatedAt).toLocaleDateString('ar-SA')}</span>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={(e) => handleExportJSON(project, e)}
                      title="تصدير JSON"
                      className="p-1.5 rounded text-gray-400 hover:text-blue-400 hover:bg-[#2A2A2A] transition"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={(e) => handleDuplicate(project, e)}
                      title="نسخ المشروع"
                      className="p-1.5 rounded text-gray-400 hover:text-amber-400 hover:bg-[#2A2A2A] transition"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={(e) => handleRequestDelete(project, e)}
                      title="حذف المشروع"
                      className="p-1.5 rounded text-gray-400 hover:text-rose-400 hover:bg-[#2A2A2A] transition"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Dedicated Custom Delete Confirmation Modal (Reliable in all iframes & browsers) */}
      {projectToDelete && (
        <div
          onClick={() => setProjectToDelete(null)}
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-150"
          dir="rtl"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-[#181C24] border border-[#3A4556] rounded-2xl p-5 max-w-md w-full shadow-2xl space-y-4 text-right"
          >
            <div className="flex items-center justify-between border-b border-[#2B3545] pb-3">
              <div className="flex items-center gap-2.5 text-rose-400">
                <AlertTriangle className="w-5 h-5 text-rose-500 shrink-0" />
                <h3 className="font-bold text-base text-white">تأكيد حذف المشروع</h3>
              </div>
              <button
                onClick={() => setProjectToDelete(null)}
                className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-[#222834] transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 text-sm text-gray-300 leading-relaxed">
              <p>
                هل أنت متأكد من رغبتك في حذف المشروع:
              </p>
              <div className="bg-[#10141B] p-3 rounded-xl border border-[#2B3545] text-white font-bold flex items-center justify-between">
                <span>{projectToDelete.name}</span>
                <span className="text-xs font-mono text-gray-400">({projectToDelete.units.length} وحدات)</span>
              </div>
              <p className="text-xs text-rose-400/90 font-semibold">
                ⚠️ تنبيه: سيتم حذف هذا المشروع نهائياً من الذاكرة المحلية ولن تتمكن من استرجاعه.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-[#2B3545]">
              <button
                onClick={() => setProjectToDelete(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-gray-300 hover:text-white bg-[#222A38] hover:bg-[#2A3446] border border-[#354358] transition"
              >
                إلغاء التراجع
              </button>
              <button
                onClick={handleConfirmDelete}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 shadow-lg shadow-rose-600/30 flex items-center gap-1.5 transition"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>نعم، احذف المشروع</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
