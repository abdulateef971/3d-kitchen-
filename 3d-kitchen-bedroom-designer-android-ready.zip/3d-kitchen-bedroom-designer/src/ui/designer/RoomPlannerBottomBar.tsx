import React, { useState } from 'react';
import {
  Search,
  Plus,
  Box,
  Layout,
  MoreHorizontal,
  Disc,
  Grid,
  Footprints,
  Compass,
  DoorOpen,
} from 'lucide-react';
import { RoomPlannerWalkAnalog } from './RoomPlannerWalkAnalog';
import { RoomPlannerDPad } from './RoomPlannerDPad';

export interface RoomPlannerBottomBarProps {
  onOpen2DPlan?: () => void;
  onOpenCatalog: () => void;
  onQuickSearch?: () => void;
  onSearch?: () => void;
  onWalk: (forward: number, right: number, speedMultiplier?: number) => void;
  onRotate?: (direction: 'left' | 'right') => void;
  onRotateCamera?: (direction: any) => void;
  onRotateContinuous?: (normalizedX: number, normalizedY: number, speedMultiplier?: number) => void;
  onPanContinuous?: (normalizedX: number, normalizedY: number, speedMultiplier?: number) => void;
  onStopMotion?: () => void;
  onToggleWalkMode: () => void;
  isWalkMode?: boolean;
  isWalking?: boolean;
  viewMode?: '3d' | '2d';
  onToggleViewMode?: () => void;
  onOpenMoreMenu?: () => void;
  onToggleDoors?: () => void;
  areDoorsOpen?: boolean;
  onToggleWide05?: () => void;
  isWide05?: boolean;
}

export const RoomPlannerBottomBar: React.FC<RoomPlannerBottomBarProps> = ({
  onOpen2DPlan,
  onOpenCatalog,
  onQuickSearch,
  onSearch,
  onWalk,
  onRotate,
  onRotateCamera,
  onRotateContinuous,
  onPanContinuous,
  onStopMotion = () => {},
  onToggleWalkMode,
  isWalkMode,
  isWalking,
  viewMode = '3d',
  onToggleViewMode,
  onOpenMoreMenu,
  onToggleDoors,
  areDoorsOpen = false,
  onToggleWide05,
  isWide05 = false,
}) => {
  const [controlType, setControlType] = useState<'analog' | 'dpad'>('analog');
  const [showJoystick, setShowJoystick] = useState<boolean>(false);
  const activeWalk = isWalkMode ?? isWalking ?? false;
  const handleSearch = onQuickSearch || onSearch || onOpenCatalog;

  const handleRotateDirection = (dir: 'left' | 'right') => {
    if (onRotate) {
      onRotate(dir);
    } else if (onRotateCamera) {
      try {
        onRotateCamera(dir);
      } catch {
        onRotateCamera(dir === 'left' ? -0.1 : 0.1);
      }
    }
  };

  const handleSwitchView = () => {
    if (onToggleViewMode) {
      onToggleViewMode();
    } else if (onOpen2DPlan) {
      onOpen2DPlan();
    }
  };

  return (
    <div
      id="room-planner-bottom-bar"
      className="absolute bottom-4 sm:bottom-6 inset-x-0 z-30 px-3 sm:px-6 flex flex-col items-center pointer-events-none select-none max-w-7xl mx-auto gap-3"
    >
      {/* ----------------------------------------------------------------- */}
      {/* 1. OPTIONAL FLOATING ANALOG JOYSTICK (When walking / navigating)  */}
      {/* ----------------------------------------------------------------- */}
      {viewMode === '3d' && (activeWalk || showJoystick) && (
        <div className="pointer-events-auto flex flex-col items-center animate-in fade-in slide-in-from-bottom-3 duration-200 mb-2">
          {controlType === 'analog' ? (
            <RoomPlannerWalkAnalog
              onWalk={onWalk}
              onRotate={handleRotateDirection}
              onRotateContinuous={onRotateContinuous}
              onPanContinuous={onPanContinuous}
              onStop={onStopMotion}
              onToggleWalkMode={onToggleWalkMode}
              onClose={() => {
                setShowJoystick(false);
                if (activeWalk) onToggleWalkMode?.();
              }}
              isWalkMode={activeWalk}
            />
          ) : (
            <RoomPlannerDPad
              onWalk={onWalk}
              onRotate={handleRotateDirection}
              onStop={onStopMotion}
              onCenterClick={onToggleWalkMode}
              isWalkMode={activeWalk}
            />
          )}

          {/* Subtle Switcher */}
          <button
            type="button"
            onClick={() => setControlType((prev) => (prev === 'analog' ? 'dpad' : 'analog'))}
            className="mt-1 px-3 py-0.5 rounded-full bg-black/70 border border-white/10 text-[9px] font-bold text-zinc-300 hover:text-white transition flex items-center gap-1 shadow-lg"
          >
            {controlType === 'analog' ? (
              <>
                <Disc className="w-2.5 h-2.5 text-amber-400" />
                <span>عصا أنالوج (انقر للتبديل لأزرار D-Pad)</span>
              </>
            ) : (
              <>
                <Grid className="w-2.5 h-2.5 text-blue-400" />
                <span>أزرار (انقر للتبديل للأنالوج)</span>
              </>
            )}
          </button>
        </div>
      )}

      {/* ----------------------------------------------------------------- */}
      {/* 2. MAIN BOTTOM ACTIONS BAR (Organized, Non-Overlapping Layout)   */}
      {/* ----------------------------------------------------------------- */}
      <div className="w-full flex items-center justify-between pointer-events-auto gap-2 max-w-5xl mx-auto">
        {/* LEFT: Search & Add Catalog */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            id="btn-quick-search-catalog"
            onClick={handleSearch}
            className="w-11 h-11 rounded-full bg-[#1C1C1E]/90 hover:bg-[#2C2C2E] text-zinc-300 hover:text-white border border-white/10 shadow-2xl flex items-center justify-center transition active:scale-95"
            title="بحث في المكتبة"
          >
            <Search className="w-4 h-4 text-zinc-300" />
          </button>

          <button
            type="button"
            id="btn-add-furniture-catalog"
            onClick={onOpenCatalog}
            className="h-11 px-4 rounded-full bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm shadow-2xl shadow-blue-900/50 flex items-center gap-1.5 transition active:scale-95 border border-blue-400/30"
            title="إضافة قطع أثاث وخزائن"
          >
            <Plus className="w-4 h-4" />
            <span>+ إضافة</span>
          </button>
        </div>

        {/* CENTER: Walk Mode + Camera 0.5x + Doors */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Prominent Walk Mode Button (User Request: زر المشي المنظم دائماً) */}
          {viewMode === '3d' && (
            <button
              type="button"
              id="btn-bottombar-walk-mode"
              onClick={() => {
                onToggleWalkMode?.();
                setShowJoystick((prev) => !prev);
              }}
              className={`h-11 px-3.5 sm:px-4 rounded-full border shadow-2xl flex items-center gap-1.5 transition active:scale-95 text-xs font-bold ${
                showJoystick || activeWalk
                  ? 'bg-amber-500 text-zinc-950 font-black border-amber-300 shadow-amber-500/40 ring-2 ring-amber-300/60 scale-105'
                  : 'bg-[#1C1C1E]/90 hover:bg-[#2C2C2E] text-zinc-200 hover:text-white border-white/15'
              }`}
              title="المشي والتجول الافتراضي داخل الغرفة"
            >
              <Footprints className="w-4 h-4" />
              <span>وضع المشي</span>
              <span
                className={`w-2 h-2 rounded-full ${
                  showJoystick || activeWalk ? 'bg-zinc-950 animate-pulse' : 'bg-emerald-400'
                }`}
              />
            </button>
          )}

          {/* 0.5x Ultra-Wide Angle Camera Button */}
          {onToggleWide05 && viewMode === '3d' && (
            <button
              type="button"
              id="btn-bottombar-wide-05"
              onClick={onToggleWide05}
              className={`h-11 px-3 sm:px-3.5 rounded-full border shadow-2xl flex items-center gap-1.5 transition active:scale-95 text-xs font-bold ${
                isWide05
                  ? 'bg-blue-600 hover:bg-blue-500 text-white border-blue-300 shadow-blue-900/50 ring-2 ring-blue-400/50'
                  : 'bg-[#1C1C1E]/90 hover:bg-[#2C2C2E] text-zinc-300 hover:text-white border-white/10'
              }`}
              title="كاميرا 0.5x بزاوية واسعة جداً"
            >
              <span className="font-mono text-xs font-black text-amber-300">0.5x</span>
              <span className="hidden sm:inline">كاميرا واسعة</span>
            </button>
          )}

          {/* Door Open / Close Button in Bottom Bar */}
          {onToggleDoors && viewMode === '3d' && (
            <button
              type="button"
              id="btn-bottombar-toggle-doors"
              onClick={onToggleDoors}
              className={`h-11 px-3 sm:px-3.5 rounded-full border shadow-2xl flex items-center gap-1.5 transition active:scale-95 text-xs font-bold ${
                areDoorsOpen
                  ? 'bg-amber-500 hover:bg-amber-400 text-white border-amber-300 shadow-amber-950/50 animate-pulse'
                  : 'bg-[#1C1C1E]/90 hover:bg-[#2C2C2E] text-amber-300 hover:text-white border-amber-500/30'
              }`}
              title="فتح وإغلاق جميع الأبواب والأدراج"
            >
              <DoorOpen className="w-4 h-4 text-amber-400" />
              <span className="hidden sm:inline">{areDoorsOpen ? 'إغلاق الأبواب' : 'الأبواب'}</span>
            </button>
          )}
        </div>

        {/* RIGHT: 2D / 3D Switcher & More Menu */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            id="btn-switch-plan-mode"
            onClick={handleSwitchView}
            className={`h-11 px-4 sm:px-5 rounded-full font-black text-xs border shadow-2xl flex items-center gap-1.5 transition active:scale-95 ${
              viewMode === '3d'
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white border-emerald-400/50 shadow-emerald-950/60 ring-2 ring-emerald-400/40 animate-pulse'
                : 'bg-blue-600 hover:bg-blue-500 text-white border-blue-400/50 shadow-blue-950/60 ring-2 ring-blue-400/40'
            }`}
            title={viewMode === '2d' ? 'التبديل إلى المنظور ثلاثي الأبعاد 3D' : 'فتح المخطط الهندسي ثنائي الأبعاد 2D'}
          >
            {viewMode === '2d' ? (
              <>
                <Box className="w-4 h-4 text-white" />
                <span className="tracking-wide">منظور 3D</span>
              </>
            ) : (
              <>
                <Layout className="w-4 h-4 text-white" />
                <span className="tracking-wide">📐 مخطط 2D</span>
              </>
            )}
          </button>

          {onOpenMoreMenu && (
            <button
              type="button"
              onClick={onOpenMoreMenu}
              className="w-11 h-11 rounded-full bg-[#1C1C1E]/90 hover:bg-[#2C2C2E] text-zinc-300 hover:text-white border border-white/10 shadow-2xl flex items-center justify-center transition active:scale-95"
              title="المزيد من الخيارات"
            >
              <MoreHorizontal className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
