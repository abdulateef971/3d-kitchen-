import React, { useState } from 'react';
import { CatalogItemTemplate, CabinetCategory } from '../../types';
import { CATALOG_TEMPLATES } from '../../domain/catalog/unitsCatalog';
import { UnitShapePreview } from './UnitShapePreview';
import {
  X,
  Search,
  Plus,
  Sparkles,
  Filter,
  Box,
  Layers,
  Flame,
  ChefHat,
  FolderOpen,
  ArrowRight,
  Maximize2,
} from 'lucide-react';

interface RPZCatalogPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTemplate: (template: CatalogItemTemplate) => void;
  isDocked?: boolean;
}

type TabType =
  | 'all'
  | 'spices_oils'
  | 'dishes_plates'
  | 'sinks'
  | 'fridges'
  | 'corner_units'
  | 'bedroom'
  | 'kitchen_base'
  | 'kitchen_wall'
  | 'kitchen_tall';

export const RPZCatalogPanel: React.FC<RPZCatalogPanelProps> = ({
  isOpen,
  onClose,
  onSelectTemplate,
  isDocked = false,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('all');
  const [searchQuery, setSearchQuery] = useState('');

  if (!isOpen) return null;

  const filteredTemplates = CATALOG_TEMPLATES.filter((item) => {
    const matchesSearch =
      item.nameAr.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.descriptionAr.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.badge && item.badge.toLowerCase().includes(searchQuery.toLowerCase()));

    if (!matchesSearch) return false;

    if (activeTab === 'all') return true;
    if (activeTab === 'spices_oils') return item.subCategory === 'spices_oils';
    if (activeTab === 'dishes_plates') return item.subCategory === 'dishes_plates';
    if (activeTab === 'sinks') return item.subCategory === 'sinks';
    if (activeTab === 'fridges') return item.subCategory === 'fridges';
    if (activeTab === 'corner_units') return item.subCategory === 'corner_units' || item.category === 'kitchen_corner';
    if (activeTab === 'bedroom')
      return (
        item.category === 'bedroom_wardrobe' ||
        item.category === 'bedroom_drawer' ||
        item.category === 'bedroom_nightstand' ||
        item.category === 'bedroom_dressing' ||
        item.category === 'bedroom_bed' ||
        item.category === 'bedroom_shelves'
      );
    if (activeTab === 'kitchen_base')
      return item.category === 'kitchen_base' && !['spices_oils', 'dishes_plates', 'sinks', 'fridges'].includes(item.subCategory || '');
    if (activeTab === 'kitchen_wall')
      return item.category === 'kitchen_wall' && !['dishes_plates', 'corner_units'].includes(item.subCategory || '');
    if (activeTab === 'kitchen_tall')
      return (item.category === 'kitchen_tall' || item.category === 'kitchen_appliance') &&
        !['spices_oils', 'fridges'].includes(item.subCategory || '');

    return true;
  });

  const cornerCount = CATALOG_TEMPLATES.filter(
    (i) => i.subCategory === 'corner_units' || i.category === 'kitchen_corner'
  ).length;

  const categoryTabs = [
    { id: 'all', label: `الكل (${CATALOG_TEMPLATES.length})` },
    { id: 'corner_units', label: `وحدات الزوايا والركن (${cornerCount})` },
    { id: 'spices_oils', label: 'سلال الزيوت والبهارات' },
    { id: 'dishes_plates', label: 'سلال المواعين والصحون' },
    { id: 'sinks', label: 'أحواض ومغاسل' },
    { id: 'fridges', label: 'ثلاجات وتبريد' },
    { id: 'bedroom', label: 'غرف نوم ودواليب' },
    { id: 'kitchen_base', label: 'مطابخ سفلية' },
    { id: 'kitchen_wall', label: 'مطابخ جدارية' },
    { id: 'kitchen_tall', label: 'أفران وخزائن طولية' },
  ];

  return (
    <div
      onPointerDown={(e) => e.stopPropagation()}
      onClick={(e) => e.stopPropagation()}
      className={
        isDocked
          ? 'w-80 md:w-96 bg-[#181818] border-r border-[#333333] flex flex-col h-full z-30 shadow-2xl shrink-0 font-[\'Cairo\',sans-serif]'
          : 'fixed inset-0 z-50 flex justify-start bg-black/80 backdrop-blur-sm animate-in fade-in duration-200 font-[\'Cairo\',sans-serif]'
      }
    >
      <div
        className={
          isDocked
            ? 'flex flex-col h-full w-full'
            : 'w-full max-w-lg md:max-w-xl bg-[#181818] border-l border-[#333333] shadow-2xl flex flex-col h-full animate-in slide-in-from-left duration-300'
        }
      >
        {/* Header - SketchUp / RPZ Style */}
        <div className="px-4 py-3 border-b border-[#2C2C2C] flex items-center justify-between bg-[#222222] shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center shadow-inner">
              <Box className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xs font-bold text-white tracking-wide">
                  أداة المكاتب والوحدات (RPZ Library)
                </h2>
                <span className="text-[10px] bg-blue-600/30 text-blue-300 border border-blue-500/40 px-1.5 py-0.2 rounded font-mono">
                  CAD v2.5
                </span>
              </div>
              <p className="text-[10px] text-gray-400">
                عرض شكل الوحدة مع اسمها ومقاساتها لإدراجها بالمشهد
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            title="إغلاق اللوحة"
            className="p-1.5 text-gray-400 hover:text-white rounded hover:bg-[#333333] transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search & Filter Bar */}
        <div className="p-3 border-b border-[#2C2C2C] space-y-2 bg-[#1C1C1C] shrink-0">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-gray-400 absolute right-3 top-2.5" />
            <input
              type="text"
              placeholder="ابحث بالاسم أو القياس (مثال: حوض، فرن، 900mm، دولاب)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#121212] border border-[#3A3A3A] rounded-lg pr-9 pl-3 py-1.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition font-sans"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute left-2.5 top-2 text-gray-400 hover:text-white text-xs"
              >
                ×
              </button>
            )}
          </div>

          {/* Category Tabs Scrollbar */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin scrollbar-thumb-[#444] text-[11px]">
            {categoryTabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabType)}
                className={`px-2.5 py-1 rounded-lg font-semibold whitespace-nowrap transition border flex items-center gap-1 text-[11px] ${
                  activeTab === tab.id
                    ? 'bg-blue-600 border-blue-500 text-white shadow-sm'
                    : 'bg-[#242424] border-[#333] text-gray-400 hover:text-gray-200 hover:bg-[#2C2C2C]'
                }`}
              >
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Units Grid with Visual Shapes + Names (RPZ Style) */}
        <div className="p-3 overflow-y-auto space-y-2.5 flex-1 divide-y divide-[#252525]">
          <div className="text-[10px] text-gray-500 pb-1 flex items-center justify-between font-mono">
            <span>الوحدات المتوفرة: {filteredTemplates.length}</span>
            <span>نظام القياس: مليمتر (mm)</span>
          </div>

          {filteredTemplates.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
              {filteredTemplates.map((item) => (
                <div
                  key={item.templateId}
                  className="group relative p-2.5 bg-[#141414] hover:bg-[#1C1C1C] border border-[#2D2D2D] hover:border-blue-500/70 rounded-xl transition duration-150 flex flex-col justify-between shadow-sm cursor-pointer"
                  onClick={() => onSelectTemplate(item)}
                >
                  {/* Visual Unit Shape Icon + Metadata Header */}
                  <div className="flex items-center gap-3">
                    {/* Architectural 2D/3D Shape Diagram */}
                    <div className="w-14 h-14 rounded-lg bg-[#1F1F1F] group-hover:bg-[#252525] border border-[#333] group-hover:border-blue-500/40 p-1 flex items-center justify-center shrink-0 transition shadow-inner">
                      <UnitShapePreview template={item} className="w-12 h-12" />
                    </div>

                    {/* Unit Name and Category */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 justify-between">
                        <h4 className="font-bold text-white text-xs group-hover:text-blue-400 transition truncate">
                          {item.nameAr}
                        </h4>
                      </div>
                      <span className="text-[10px] text-gray-400 block truncate font-sans">
                        {item.name}
                      </span>
                      {item.badge && (
                        <span className="inline-block text-[9px] font-bold px-1.5 py-0.2 mt-1 rounded bg-blue-950/60 text-blue-300 border border-blue-800/40">
                          {item.badge}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-[10px] text-gray-400 mt-2 line-clamp-1 leading-normal">
                    {item.descriptionAr}
                  </p>

                  {/* Dimensions & Quick Insert Action */}
                  <div className="flex items-center justify-between pt-2 mt-2 border-t border-[#252525] text-[10px]">
                    <div className="flex items-center gap-1 font-mono text-gray-400 text-[9px]">
                      <span className="bg-[#202020] px-1 py-0.5 rounded border border-[#333]">
                        {item.defaultWidth}×{item.defaultHeight}×{item.defaultDepth}
                      </span>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectTemplate(item);
                      }}
                      className="px-2 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white font-bold text-[10px] flex items-center gap-1 shadow transition"
                    >
                      <Plus className="w-3 h-3 stroke-[3]" />
                      إدراج
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16 text-gray-500 space-y-2">
              <Box className="w-10 h-10 mx-auto opacity-30 text-gray-400" />
              <p className="text-xs">لم يتم العثور على وحدة مطابقة</p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setActiveTab('all');
                }}
                className="text-[11px] text-blue-400 hover:underline"
              >
                إعادة ضبط البحث
              </button>
            </div>
          )}
        </div>

        {/* Footer info bar */}
        <div className="px-4 py-2.5 bg-[#1C1C1C] border-t border-[#2C2C2C] flex items-center justify-between text-[10px] text-gray-400 shrink-0">
          <span className="flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-400" />
            انقر على أي وحدة لإضافتها وتثبيتها تلقائياً
          </span>
          <button
            onClick={onClose}
            className="px-3 py-1 rounded bg-[#2A2A2A] hover:bg-[#333] text-gray-300 text-[10px]"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
