import React, { useState, useMemo } from 'react';
import {
  X,
  Search,
  ChevronLeft,
  ChevronRight,
  Info,
  Plus,
  Filter,
  Sparkles,
  Lightbulb,
  Check,
  ArrowRight,
  SlidersHorizontal,
} from 'lucide-react';
import { CatalogItemTemplate } from '../../types';
import { CATALOG_TEMPLATES } from '../../domain/catalog/unitsCatalog';
import { UnitShapePreview } from './UnitShapePreview';
import { ItemDetailsModal } from './ItemDetailsModal';

interface RoomPlannerCatalogModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTemplate: (template: CatalogItemTemplate) => void;
  initialSearch?: string;
  onOpenAIGenerator?: () => void;
}

// Level 1 Root Category Definition (matching Screenshot 9)
interface RootCategory {
  id: string;
  nameAr: string;
  nameEn: string;
  icon: string;
  subcategories: SubCategoryDef[];
}

interface SubCategoryDef {
  id: string;
  nameAr: string;
  nameEn: string;
  icon: string;
  filterMatch: (item: CatalogItemTemplate) => boolean;
}

// Root Categories structured precisely as shown in Screenshots 5, 6, 7, 8, 9, 10
const ROOT_CATEGORIES: RootCategory[] = [
  {
    id: 'construction',
    nameAr: 'بناء',
    nameEn: 'Construction',
    icon: '🧱',
    subcategories: [
      {
        id: 'walls_doors',
        nameAr: 'أبواب ونوافذ',
        nameEn: 'Doors & Windows',
        icon: '🚪',
        filterMatch: (item) => (item.category as string) === 'construction' || item.templateId.includes('door') || item.templateId.includes('window'),
      },
      {
        id: 'floors_moldings',
        nameAr: 'أرضيات وكرانيش',
        nameEn: 'Flooring & Moldings',
        icon: '🪵',
        filterMatch: (item) => (item.category as string) === 'construction' || item.templateId.includes('floor'),
      },
    ],
  },
  {
    id: 'electronics',
    nameAr: 'أجهزة إلكترونية',
    nameEn: 'Appliances',
    icon: '🔌',
    subcategories: [
      {
        id: 'kitchen_appliances',
        nameAr: 'أدوات المطبخ (ثلاجة، موقد، فرن)',
        nameEn: 'Kitchen Appliances',
        icon: '🍳',
        filterMatch: (item) => (item.category as string) === 'appliance' || item.category === 'kitchen_appliance' || item.templateId.includes('fridge') || item.templateId.includes('oven') || item.templateId.includes('cooktop') || item.templateId.includes('hood') || item.templateId.includes('cooking_station'),
      },
      {
        id: 'washers_dryers',
        nameAr: 'غسالات / نشافات',
        nameEn: 'Washers & Dryers',
        icon: '🧺',
        filterMatch: (item) => item.templateId.includes('wash') || item.templateId.includes('dryer') || item.nameAr.includes('غسالة'),
      },
      {
        id: 'tv_media',
        nameAr: 'تلفزيون / ميديا',
        nameEn: 'TV & Media',
        icon: '📺',
        filterMatch: (item) => item.templateId.includes('tv') || item.nameAr.includes('تلفزيون'),
      },
      {
        id: 'climate',
        nameAr: 'إلكترونيات المناخ',
        nameEn: 'Climate & AC',
        icon: '❄️',
        filterMatch: (item) => item.templateId.includes('ac') || item.nameAr.includes('مكيف'),
      },
      {
        id: 'office_electronics',
        nameAr: 'إلكترونيات المكتب',
        nameEn: 'Office Electronics',
        icon: '💻',
        filterMatch: (item) => item.templateId.includes('pc') || item.templateId.includes('desk'),
      },
      {
        id: 'audio',
        nameAr: 'معدات الصوت',
        nameEn: 'Audio Systems',
        icon: '🔊',
        filterMatch: (item) => item.templateId.includes('audio') || item.templateId.includes('sound'),
      },
    ],
  },
  {
    id: 'cabinets_shelves',
    nameAr: 'خزائن، رفوف',
    nameEn: 'Cabinets & Shelves',
    icon: '🗄️',
    subcategories: [
      {
        id: 'wall_cabinets',
        nameAr: 'خزائن حائط المطبخ',
        nameEn: 'Kitchen Wall Cabinets',
        icon: '📦',
        filterMatch: (item) => item.category === 'kitchen_wall',
      },
      {
        id: 'base_cabinets',
        nameAr: 'خزائن قاعدة المطبخ',
        nameEn: 'Kitchen Base Cabinets',
        icon: '🗄️',
        filterMatch: (item) => item.category === 'kitchen_base' || item.category === 'kitchen_corner',
      },
      {
        id: 'tall_cabinets',
        nameAr: 'خزائن مطبخ عالية',
        nameEn: 'Kitchen Tall Pantries',
        icon: '🏛️',
        filterMatch: (item) => item.category === 'kitchen_tall',
      },
      {
        id: 'open_shelves',
        nameAr: 'أرفف حائطية مفتوحة',
        nameEn: 'Open Shelving',
        icon: '📚',
        filterMatch: (item) => item.category === 'bedroom_shelves' || item.templateId.includes('shelf'),
      },
      {
        id: 'wardrobes',
        nameAr: 'دواليب وخزائن ملابس',
        nameEn: 'Wardrobes & Closets',
        icon: '🚪',
        filterMatch: (item) => item.category === 'bedroom_wardrobe' || item.category === 'bedroom_dressing',
      },
    ],
  },
  {
    id: 'tables_chairs',
    nameAr: 'طاولات وكراسي',
    nameEn: 'Tables & Chairs',
    icon: '🪑',
    subcategories: [
      {
        id: 'dining_tables',
        nameAr: 'طاولة الطعام',
        nameEn: 'Dining Tables',
        icon: '🍽️',
        filterMatch: (item) => item.templateId.includes('table') || item.nameAr.includes('طاولة'),
      },
      {
        id: 'kitchen_island',
        nameAr: 'منطقة وسط المطبخ (جزيرة)',
        nameEn: 'Kitchen Island',
        icon: '🏝️',
        filterMatch: (item) => item.templateId.includes('island') || item.nameAr.includes('جزيرة') || item.subCategory === 'island',
      },
      {
        id: 'bar_stools',
        nameAr: 'كرسي بار / طاولة الحانة',
        nameEn: 'Bar Stools & Pub Table',
        icon: '🍸',
        filterMatch: (item) => item.templateId.includes('bar') || item.templateId.includes('stool'),
      },
      {
        id: 'desks',
        nameAr: 'مكتب وطاولات جانبية',
        nameEn: 'Desks & Side Tables',
        icon: '🖥️',
        filterMatch: (item) => item.templateId.includes('desk') || item.category === 'bedroom_nightstand',
      },
      {
        id: 'coffee_tables',
        nameAr: 'منضدة قهوة',
        nameEn: 'Coffee Tables',
        icon: '☕',
        filterMatch: (item) => item.templateId.includes('coffee'),
      },
    ],
  },
  {
    id: 'decorations',
    nameAr: 'زينة',
    nameEn: 'Decorations',
    icon: '🪴',
    subcategories: [
      {
        id: 'plants_vases',
        nameAr: 'النباتات والمزهريات',
        nameEn: 'Plants & Vases',
        icon: '🌿',
        filterMatch: (item) => (item.category as string) === 'decor' || item.templateId.includes('plant'),
      },
      {
        id: 'wall_art',
        nameAr: 'جدارية ولوحات',
        nameEn: 'Wall Art',
        icon: '🖼️',
        filterMatch: (item) => item.templateId.includes('art') || item.templateId.includes('painting'),
      },
      {
        id: 'rugs',
        nameAr: 'سجاد',
        nameEn: 'Rugs & Carpets',
        icon: '🧶',
        filterMatch: (item) => item.templateId.includes('rug') || item.templateId.includes('carpet'),
      },
      {
        id: 'mirrors',
        nameAr: 'مرايا',
        nameEn: 'Mirrors',
        icon: '🪞',
        filterMatch: (item) => item.templateId.includes('mirror'),
      },
      {
        id: 'curtains',
        nameAr: 'الستائر والفواصل',
        nameEn: 'Curtains & Drapes',
        icon: '🪟',
        filterMatch: (item) => item.templateId.includes('curtain'),
      },
    ],
  },
  {
    id: 'seating',
    nameAr: 'أثاث جلوس',
    nameEn: 'Seating Furniture',
    icon: '🛋️',
    subcategories: [
      {
        id: 'sofas',
        nameAr: 'كنبة ومجالس',
        nameEn: 'Sofas & Couches',
        icon: '🛋️',
        filterMatch: (item) => item.templateId.includes('sofa') || item.nameAr.includes('كنب'),
      },
      {
        id: 'armchairs',
        nameAr: 'كرسي ذو ذراعين / مريح',
        nameEn: 'Armchairs',
        icon: '🪑',
        filterMatch: (item) => item.templateId.includes('armchair') || item.templateId.includes('chair'),
      },
      {
        id: 'poufs',
        nameAr: 'بوف ، مسند للقدمين',
        nameEn: 'Ottomans & Poufs',
        icon: '⚪',
        filterMatch: (item) => item.templateId.includes('pouf') || item.templateId.includes('ottoman'),
      },
      {
        id: 'chaise',
        nameAr: 'تشيز لاونج',
        nameEn: 'Chaise Lounge',
        icon: '🛌',
        filterMatch: (item) => item.templateId.includes('chaise') || item.category === 'bedroom_bed',
      },
    ],
  },
  {
    id: 'kitchen_sets',
    nameAr: 'مجموعات المطبخ',
    nameEn: 'Kitchen Sets',
    icon: '🍳',
    subcategories: [
      {
        id: 'complete_sets',
        nameAr: 'أطقم المطبخ المتكاملة',
        nameEn: 'Full Kitchen Sets',
        icon: '✨',
        filterMatch: (item) => item.category === 'kitchen_base' || item.category === 'kitchen_wall',
      },
      {
        id: 'base_units',
        nameAr: 'خزائن قاعدة المطبخ',
        nameEn: 'Base Units',
        icon: '🗄️',
        filterMatch: (item) => item.category === 'kitchen_base' || item.category === 'kitchen_corner',
      },
      {
        id: 'wall_units',
        nameAr: 'خزائن حائط المطبخ',
        nameEn: 'Wall Units',
        icon: '📦',
        filterMatch: (item) => item.category === 'kitchen_wall',
      },
      {
        id: 'countertops',
        nameAr: 'أسطح مطبخ (رخام وجرانيت)',
        nameEn: 'Kitchen Countertops',
        icon: '🪨',
        filterMatch: (item) => item.templateId.includes('countertop') || item.nameAr.includes('رخام'),
      },
      {
        id: 'backsplashes',
        nameAr: 'واقي المطبخ (باك سبلاش)',
        nameEn: 'Backsplash',
        icon: '🧱',
        filterMatch: (item) => item.templateId.includes('backsplash'),
      },
      {
        id: 'tall_pantries',
        nameAr: 'خزائن مطبخ عالية',
        nameEn: 'High Pantries',
        icon: '🏛️',
        filterMatch: (item) => item.category === 'kitchen_tall',
      },
    ],
  },
  {
    id: 'lighting',
    nameAr: 'إضاءة',
    nameEn: 'Lighting',
    icon: '💡',
    subcategories: [
      {
        id: 'ceiling_lights',
        nameAr: 'إضاءة السقف وسبوت لايت',
        nameEn: 'Ceiling Spotlights',
        icon: '💡',
        filterMatch: (item) => (item.category as string) === 'lighting' || item.templateId.includes('spot') || item.templateId.includes('ceiling'),
      },
      {
        id: 'pendants',
        nameAr: 'نجف وثريات معلقة',
        nameEn: 'Pendant Chandeliers',
        icon: '✨',
        filterMatch: (item) => item.templateId.includes('pendant') || item.templateId.includes('chandelier'),
      },
      {
        id: 'led_strips',
        nameAr: 'إضاءة ليد مخفية أسفل الخزائن',
        nameEn: 'Under Cabinet LED',
        icon: '〰️',
        filterMatch: (item) => item.templateId.includes('led') || item.templateId.includes('strip'),
      },
    ],
  },
  {
    id: 'kitchen_utensils',
    nameAr: 'أدوات المطبخ',
    nameEn: 'Kitchen Organizers',
    icon: '🧂',
    subcategories: [
      {
        id: 'spice_racks',
        nameAr: 'سلال الزيوت والبهارات والصوص',
        nameEn: 'Spice & Oil Pull-outs',
        icon: '🍶',
        filterMatch: (item) => item.subCategory === 'spices_oils' || item.accessoryType === 'wire_basket_spice' || item.templateId.includes('spice'),
      },
      {
        id: 'dish_racks',
        nameAr: 'سلال المواعين والصحون والأطباق',
        nameEn: 'Dish Pull-outs',
        icon: '🍽️',
        filterMatch: (item) => item.subCategory === 'dishes_plates' || item.accessoryType === 'wire_basket_dishes' || item.templateId.includes('dish'),
      },
      {
        id: 'sinks',
        nameAr: 'أحواض ومغاسل المطبخ',
        nameEn: 'Kitchen Sinks',
        icon: '🚰',
        filterMatch: (item) => item.subCategory === 'sink' || item.accessoryType === 'sink' || item.templateId.includes('sink'),
      },
    ],
  },
  {
    id: 'more',
    nameAr: 'المزيد',
    nameEn: 'More',
    icon: '✨',
    subcategories: [
      {
        id: 'bedroom_all',
        nameAr: 'أثاث غرف النوم والتسريحات',
        nameEn: 'Bedroom Furniture',
        icon: '🛏️',
        filterMatch: (item) => item.category.startsWith('bedroom_'),
      },
    ],
  },
];

const DIMENSION_CHIPS = [
  { label: 'الكل', widthMm: null },
  { label: '30 سنتيمتر', widthMm: 300 },
  { label: '38 سنتيمتر', widthMm: 380 },
  { label: '45 سنتيمتر', widthMm: 450 },
  { label: '60 سنتيمتر', widthMm: 600 },
  { label: '80 سنتيمتر', widthMm: 800 },
  { label: '90 سنتيمتر', widthMm: 900 },
];

export const RoomPlannerCatalogModal: React.FC<RoomPlannerCatalogModalProps> = ({
  isOpen,
  onClose,
  onSelectTemplate,
  initialSearch = '',
  onOpenAIGenerator,
}) => {
  // Room Type Tabs (مطبخ | غرف اخرى)
  const [roomTab, setRoomTab] = useState<'kitchen' | 'other'>('kitchen');

  // Navigation Drill-Down State
  const [selectedRootCategory, setSelectedRootCategory] = useState<RootCategory | null>(null);
  const [selectedSubCategory, setSelectedSubCategory] = useState<SubCategoryDef | null>(null);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState(initialSearch);
  const [selectedWidthFilter, setSelectedWidthFilter] = useState<number | null>(null);
  const [activeTag, setActiveTag] = useState<'popular' | 'new' | 'advice'>('popular');

  // Info Details Modal State
  const [inspectingTemplate, setInspectingTemplate] = useState<CatalogItemTemplate | null>(null);

  // Filter templates based on current view or search
  const displayedItems = useMemo(() => {
    if (!isOpen) return [];
    let list = CATALOG_TEMPLATES;

    // Search query overrides
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      return list.filter(
        (item) =>
          item.nameAr.toLowerCase().includes(q) ||
          item.name.toLowerCase().includes(q) ||
          item.descriptionAr.toLowerCase().includes(q) ||
          (item.badge && item.badge.toLowerCase().includes(q))
      );
    }

    // Filter by category / subcategory
    if (selectedSubCategory) {
      list = list.filter(selectedSubCategory.filterMatch);
    } else if (selectedRootCategory) {
      // Any item matching any of the root category's subcategories
      list = list.filter((item) => selectedRootCategory.subcategories.some((sub) => sub.filterMatch(item)));
    }

    // Filter by dimension chip
    if (selectedWidthFilter !== null) {
      list = list.filter((item) => Math.abs(item.defaultWidth - selectedWidthFilter) < 30);
    }

    return list;
  }, [isOpen, searchQuery, selectedRootCategory, selectedSubCategory, selectedWidthFilter]);

  const handleGoBack = () => {
    if (selectedSubCategory) {
      setSelectedSubCategory(null);
    } else if (selectedRootCategory) {
      setSelectedRootCategory(null);
    }
  };

  const getHeaderTitle = () => {
    if (searchQuery.trim()) return `نتائج البحث: "${searchQuery}"`;
    if (selectedSubCategory) return selectedSubCategory.nameAr;
    if (selectedRootCategory) return selectedRootCategory.nameAr;
    return roomTab === 'kitchen' ? 'مطبخ' : 'غرف أخرى';
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
        <div
          id="room-planner-catalog-drawer"
          className="w-full max-w-2xl bg-[#1C1C1E] border-t border-white/15 rounded-t-3xl shadow-2xl flex flex-col h-[85vh] max-h-[85vh] animate-in slide-in-from-bottom duration-300 overflow-hidden"
        >
          {/* Drawer Drag Pill */}
          <div className="w-12 h-1 rounded-full bg-zinc-600/80 mx-auto mt-2.5 mb-1 cursor-pointer" />

          {/* ----------------------------------------------------------------- */}
          {/* HEADER (Back arrow, Title, Search, Close)                          */}
          {/* ----------------------------------------------------------------- */}
          <div className="px-5 py-3 border-b border-white/10 flex items-center justify-between gap-3">
            {/* Back Button (if drilled down) */}
            {(selectedRootCategory || selectedSubCategory || searchQuery) ? (
              <button
                type="button"
                onClick={() => {
                  if (searchQuery) setSearchQuery('');
                  else handleGoBack();
                }}
                className="p-1.5 rounded-full hover:bg-white/10 text-zinc-300 hover:text-white transition"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            ) : (
              <div className="w-8" />
            )}

            {/* Title */}
            <h2 className="text-base font-bold text-white tracking-wide text-center flex-1 truncate">
              {getHeaderTitle()}
            </h2>

            {/* Close button */}
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-white/10 text-zinc-400 hover:text-white transition"
              title="إغلاق المكتبة"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* ----------------------------------------------------------------- */}
          {/* SEARCH BAR & ROOM TABS (Matching Screenshot 9)                     */}
          {/* ----------------------------------------------------------------- */}
          {!selectedSubCategory && (
            <div className="px-5 pt-3 pb-2 border-b border-white/10 space-y-2.5 bg-[#171719]">
              {/* Search input */}
              <div className="relative">
                <Search className="w-4 h-4 text-zinc-400 absolute right-3.5 top-3" />
                <input
                  type="text"
                  placeholder="ابحث عن وحدة (حوض، فرن، دولاب، سلة بهارات...)"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-[#121214] border border-white/10 rounded-full pr-10 pl-4 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-400 transition"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="absolute left-3.5 top-2.5 text-zinc-400 hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Room Tabs: مطبخ vs غرف اخرى + AI Generator */}
              {!selectedRootCategory && !searchQuery && (
                <div className="flex items-center justify-between gap-2 pt-1">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setRoomTab('kitchen')}
                      className={`px-4 py-1.5 rounded-full text-xs font-bold transition ${
                        roomTab === 'kitchen'
                          ? 'bg-amber-400 text-zinc-950 shadow-md'
                          : 'bg-zinc-800 text-zinc-400 hover:text-white'
                      }`}
                    >
                      مطبخ
                    </button>
                    <button
                      type="button"
                      onClick={() => setRoomTab('other')}
                      className={`px-4 py-1.5 rounded-full text-xs font-bold transition ${
                        roomTab === 'other'
                          ? 'bg-amber-400 text-zinc-950 shadow-md'
                          : 'bg-zinc-800 text-zinc-400 hover:text-white'
                      }`}
                    >
                      غرف اخرى
                    </button>
                  </div>

                  {onOpenAIGenerator && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenAIGenerator();
                      }}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white text-xs font-bold shadow-lg transition active:scale-95"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                      <span>توليد وحدة بالذكاء الاصطناعي</span>
                    </button>
                  )}
                </div>
              )}
            </div>
          )}

          {/* ----------------------------------------------------------------- */}
          {/* LEVEL 3: UNIT ITEMS FILTER CHIPS (Matching Screenshots 3 & 4)      */}
          {/* ----------------------------------------------------------------- */}
          {(selectedSubCategory || searchQuery) && (
            <div className="px-5 py-2.5 border-b border-white/10 bg-[#171719] space-y-2">
              {/* Dimension Chips */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[11px]">
                {DIMENSION_CHIPS.map((chip) => {
                  const isSelected = selectedWidthFilter === chip.widthMm;
                  return (
                    <button
                      key={chip.label}
                      type="button"
                      onClick={() => setSelectedWidthFilter(chip.widthMm)}
                      className={`px-3 py-1 rounded-full whitespace-nowrap font-semibold transition ${
                        isSelected
                          ? 'bg-white text-zinc-950 font-bold shadow'
                          : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
                      }`}
                    >
                      {chip.label}
                    </button>
                  );
                })}
              </div>

              {/* Filter Pills (شائع، جديد، تصفية، نصيحة) */}
              <div className="flex items-center gap-2 text-[11px]">
                <button
                  type="button"
                  onClick={() => setActiveTag('popular')}
                  className={`px-3 py-1 rounded-full font-bold transition ${
                    activeTag === 'popular' ? 'bg-zinc-950 text-white border border-white/20' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  شائع
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTag('new')}
                  className={`px-3 py-1 rounded-full font-bold transition ${
                    activeTag === 'new' ? 'bg-zinc-950 text-white border border-white/20' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  جديد
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTag('advice')}
                  className="mr-auto text-amber-400 hover:text-amber-300 flex items-center gap-1 font-semibold text-[11px]"
                >
                  <Lightbulb className="w-3.5 h-3.5" />
                  <span>احتاج إلى نصيحة</span>
                </button>
              </div>
            </div>
          )}

          {/* ----------------------------------------------------------------- */}
          {/* BODY CONTENT (View switches depending on drill-down level)         */}
          {/* ----------------------------------------------------------------- */}
          <div className="flex-1 overflow-y-auto p-4">
            {/* VIEW 1: ROOT CATEGORIES (Matching Screenshot 9) */}
            {!selectedRootCategory && !searchQuery && (
              <div className="grid grid-cols-2 gap-3">
                {ROOT_CATEGORIES.map((cat) => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setSelectedRootCategory(cat)}
                    className="group relative p-4 rounded-2xl bg-zinc-900/90 hover:bg-zinc-800/90 border border-white/10 hover:border-amber-400/40 transition-all duration-200 flex flex-col justify-between h-28 text-right shadow-lg active:scale-98"
                  >
                    <div className="text-2xl">{cat.icon}</div>
                    <div>
                      <h3 className="text-sm font-bold text-white group-hover:text-amber-400 transition-colors">
                        {cat.nameAr}
                      </h3>
                      <span className="text-[11px] text-zinc-500 font-medium">{cat.nameEn}</span>
                    </div>
                  </button>
                ))}
              </div>
            )}

            {/* VIEW 2: SUBCATEGORIES (Matching Screenshots 5, 6, 7, 8, 10) */}
            {selectedRootCategory && !selectedSubCategory && !searchQuery && (
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {selectedRootCategory.subcategories.map((sub) => (
                    <button
                      key={sub.id}
                      type="button"
                      onClick={() => setSelectedSubCategory(sub)}
                      className="group p-3.5 rounded-2xl bg-zinc-900/90 hover:bg-zinc-800/90 border border-white/10 hover:border-amber-400/40 transition-all flex items-center justify-between text-right shadow active:scale-98"
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-xl">{sub.icon}</span>
                        <div>
                          <h4 className="text-xs font-bold text-white group-hover:text-amber-400 transition-colors">
                            {sub.nameAr}
                          </h4>
                          <span className="text-[10px] text-zinc-500">{sub.nameEn}</span>
                        </div>
                      </div>
                      <ChevronLeft className="w-4 h-4 text-zinc-500 group-hover:text-white transition-transform group-hover:-translate-x-1" />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* VIEW 3: UNITS ITEM GRID (Matching Screenshots 3 & 4) */}
            {(selectedSubCategory || searchQuery) && (
              <div>
                {displayedItems.length === 0 ? (
                  <div className="py-12 text-center text-zinc-500">
                    <p className="text-xs">لم يتم العثور على وحدات مطابقة للبحث أو المقاس المحدد.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {displayedItems.map((item) => (
                      <div
                        key={item.templateId}
                        className="group relative rounded-2xl bg-zinc-900 border border-white/10 hover:border-amber-400/50 transition-all duration-200 p-3 flex flex-col justify-between shadow-lg"
                      >
                        {/* Info Button (ℹ️) */}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setInspectingTemplate(item);
                          }}
                          className="absolute top-2 left-2 z-10 w-6 h-6 rounded-full bg-black/50 hover:bg-black text-zinc-400 hover:text-white flex items-center justify-center transition"
                          title="عرض التفاصيل والمقاسات"
                        >
                          <Info className="w-3.5 h-3.5" />
                        </button>

                        {/* 3D Visual Preview */}
                        <div
                          onClick={() => {
                            onSelectTemplate(item);
                            onClose();
                          }}
                          className="h-28 flex items-center justify-center cursor-pointer overflow-hidden p-1 rounded-xl bg-[#141416] group-hover:bg-[#18181C] transition-colors"
                        >
                          <UnitShapePreview template={item} className="w-20 h-20 group-hover:scale-105 transition-transform duration-200" />
                        </div>

                        {/* Title and Dimensions */}
                        <div
                          onClick={() => {
                            onSelectTemplate(item);
                            onClose();
                          }}
                          className="mt-2 text-right cursor-pointer"
                        >
                          <h4 className="text-xs font-bold text-white line-clamp-1 group-hover:text-amber-400 transition-colors">
                            {item.nameAr || item.name}
                          </h4>
                          <div className="flex items-center justify-between text-[10px] text-zinc-400 mt-1">
                            <span>{item.defaultWidth / 10} × {item.defaultHeight / 10} سم</span>
                            {item.badge && (
                              <span className="px-1.5 py-0.2 rounded bg-amber-400/15 text-amber-300 font-semibold text-[9px]">
                                {item.badge}
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Direct Add Button */}
                        <button
                          type="button"
                          onClick={() => {
                            onSelectTemplate(item);
                            onClose();
                          }}
                          className="mt-2.5 w-full py-1.5 rounded-xl bg-zinc-800 hover:bg-amber-400 hover:text-zinc-950 text-zinc-200 text-xs font-bold transition-all flex items-center justify-center gap-1 shadow-sm active:scale-95"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>إضافة</span>
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Item Details Specs Modal */}
      {inspectingTemplate && (
        <ItemDetailsModal
          template={inspectingTemplate}
          onClose={() => setInspectingTemplate(null)}
          onAdd={(tpl) => {
            onSelectTemplate(tpl);
            onClose();
          }}
        />
      )}
    </>
  );
};
