import React, { useRef, useState, useEffect, useCallback } from 'react';
import {
  MousePointer,
  PenTool,
  Pencil,
  Undo2,
  Ruler,
  Plus,
  Trash2,
  Copy,
  RotateCw,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Check,
  X,
  Sliders,
  Sparkles,
  DoorOpen,
  EyeOff,
  Move,
  Box,
  Compass,
  Layers,
} from 'lucide-react';
import { Project, RoomConfig, CustomWall, WallOpening, ParametricCabinet } from '../../types';
import { resolveCabinetMovement } from '../../domain/collision/CollisionManager';

interface FreehandStroke {
  id: string;
  points: Array<{ x: number; z: number }>;
  color: string;
  width: number;
}

export interface FloorPlan2DViewProps {
  project: Project;
  onUpdateRoom: (room: RoomConfig, recordHistory?: boolean) => void;
  onUpdateUnit?: (unit: ParametricCabinet) => void;
  onDuplicateUnit?: (unit: ParametricCabinet) => void;
  onDeleteUnit?: (unitId: string) => void;
  onSnapAndMergeUnit?: (side: 'left' | 'right', unitId?: string) => void;
  onSwitchTo3D: () => void;
  onOpenCatalog?: () => void;
  selectedUnitId?: string | null;
  onSelectUnit?: (id: string | null) => void;
  selectedCustomWallId?: string | null;
  onSelectCustomWall?: (id: string | null) => void;
  onOpenProperties?: () => void;
  onToggleDoors?: () => void;
  areDoorsOpen?: boolean;
}

export const FloorPlan2DView: React.FC<FloorPlan2DViewProps> = ({
  project,
  onUpdateRoom,
  onUpdateUnit,
  onDuplicateUnit,
  onDeleteUnit,
  onSnapAndMergeUnit,
  onSwitchTo3D,
  onOpenCatalog,
  selectedUnitId,
  onSelectUnit,
  selectedCustomWallId,
  onSelectCustomWall,
  onOpenProperties,
  onToggleDoors,
  areDoorsOpen = false,
}) => {
  const room = project.room;
  const units = project.units || [];

  // Active Tool: 'select' | 'draw_wall' | 'freehand' | 'add_door' | 'add_window'
  const [activeTool, setActiveTool] = useState<'select' | 'draw_wall' | 'freehand' | 'add_door' | 'add_window'>('select');

  // Freehand drawing state (User Request: زر رسم اليدوي في مخطط 2d)
  const [freehandStrokes, setFreehandStrokes] = useState<FreehandStroke[]>([]);
  const [currentStroke, setCurrentStroke] = useState<FreehandStroke | null>(null);
  const [freehandColor, setFreehandColor] = useState<string>('#ef4444');
  const [freehandStrokeWidth, setFreehandStrokeWidth] = useState<number>(30); // in mm on blueprint

  // Room dimension inputs in meters
  const [inputWidthM, setInputWidthM] = useState<string>(
    ((room.width || 6000) / 1000).toFixed(1).replace('.0', '')
  );
  const [inputLengthM, setInputLengthM] = useState<string>(
    ((room.length || 5000) / 1000).toFixed(1).replace('.0', '')
  );

  // Sync inputs when project room changes
  useEffect(() => {
    setInputWidthM(((room.width || 6000) / 1000).toFixed(1).replace('.0', ''));
    setInputLengthM(((room.length || 5000) / 1000).toFixed(1).replace('.0', ''));
  }, [room.width, room.length]);

  // Canvas References and Transforms
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [zoom, setZoom] = useState<number>(0.12); // pixels per mm
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState<boolean>(false);
  const [panStart, setPanStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Dragging states
  const [isDraggingUnit, setIsDraggingUnit] = useState<boolean>(false);
  const [dragUnitStart, setDragUnitStart] = useState<{
    unitId: string;
    startMouseX: number;
    startMouseZ: number;
    origX: number;
    origZ: number;
  } | null>(null);

  // Wall drawing preview & drag-to-draw
  const [wallStartMm, setWallStartMm] = useState<{ x: number; z: number } | null>(null);
  const [isDraggingWall, setIsDraggingWall] = useState<boolean>(false);
  const [mouseMm, setMouseMm] = useState<{ x: number; z: number }>({ x: 0, z: 0 });

  // Notification / Feedback banner
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);

  const showFeedback = (msg: string) => {
    setFeedbackMessage(msg);
    setTimeout(() => setFeedbackMessage(null), 3000);
  };

  const roomWidth = room.width || 6000;
  const roomLength = room.length || 5000;
  const customWalls = room.customWalls || [];
  const openings = room.openings || [];

  const selectedUnit = units.find((u) => u.id === selectedUnitId) || null;
  const selectedWall = customWalls.find((w) => w.id === selectedCustomWallId) || null;

  // Openings management (Doors & Windows on walls)
  const [selectedOpeningId, setSelectedOpeningId] = useState<string | null>(null);
  const [isDraggingOpening, setIsDraggingOpening] = useState<boolean>(false);
  const [hoveredOpeningId, setHoveredOpeningId] = useState<string | null>(null);
  const selectedOpening = openings.find((o) => o.id === selectedOpeningId) || null;

  const getOpeningWallIndex = (op: WallOpening): number => {
    if (typeof op.wallIndex === 'number') return op.wallIndex;
    if (op.wall === 'north') return 0;
    if (op.wall === 'east') return 1;
    if (op.wall === 'south') return 2;
    if (op.wall === 'west') return 3;
    return 0;
  };

  const getOpeningDist = (op: WallOpening, rW: number, rL: number): number => {
    if (typeof op.distanceFromStart === 'number') return op.distanceFromStart;
    if (typeof op.position === 'number') return op.position;
    const wIdx = getOpeningWallIndex(op);
    const wallLen = wIdx === 0 || wIdx === 2 ? rW : rL;
    return wallLen / 2;
  };

  // Accurate Opening Geometry calculation matching 3D coordinates exactly
  const getOpeningGeometry = useCallback((op: WallOpening, rW: number, rL: number) => {
    const wallIdx = getOpeningWallIndex(op);
    const wallLength = wallIdx === 0 || wallIdx === 2 ? rW : rL;
    const width = op.width || (op.type === 'door' ? 900 : 1200);
    const halfW = rW / 2;
    const halfL = rL / 2;

    let startDist = typeof op.distanceFromStart === 'number'
      ? op.distanceFromStart
      : typeof op.position === 'number'
      ? op.position
      : (wallLength - width) / 2;

    startDist = Math.max(0, Math.min(wallLength - width, startDist));
    const centerDist = startDist + width / 2;
    const endDist = startDist + width;

    let worldCenterX = 0;
    let worldCenterZ = 0;
    let wallName: 'north' | 'east' | 'south' | 'west' = 'north';
    const isHorizontal = wallIdx === 0 || wallIdx === 2;

    if (wallIdx === 0) {
      wallName = 'north';
      worldCenterX = -halfW + centerDist;
      worldCenterZ = -halfL;
    } else if (wallIdx === 1) {
      wallName = 'east';
      worldCenterX = halfW;
      worldCenterZ = -halfL + centerDist;
    } else if (wallIdx === 2) {
      wallName = 'south';
      worldCenterX = -halfW + centerDist;
      worldCenterZ = halfL;
    } else {
      wallName = 'west';
      worldCenterX = -halfW;
      worldCenterZ = -halfL + centerDist;
    }

    return {
      op,
      wallIdx,
      wallName,
      wallLength,
      startDist,
      centerDist,
      endDist,
      width,
      worldCenterX,
      worldCenterZ,
      isHorizontal,
    };
  }, []);

  // Convert World (mm) to Screen (px)
  const worldToScreen = useCallback(
    (xMm: number, zMm: number, canvas: HTMLCanvasElement) => {
      const cx = canvas.width / 2 + pan.x;
      const cy = canvas.height / 2 + pan.y;
      return {
        x: cx + xMm * zoom,
        y: cy + zMm * zoom,
      };
    },
    [pan, zoom]
  );

  // Convert Screen (px) to World (mm)
  const screenToWorld = useCallback(
    (screenX: number, screenY: number, canvas: HTMLCanvasElement) => {
      const cx = canvas.width / 2 + pan.x;
      const cy = canvas.height / 2 + pan.y;
      return {
        x: (screenX - cx) / zoom,
        z: (screenY - cy) / zoom,
      };
    },
    [pan, zoom]
  );

  // Center and fit view to container
  const handleFitView = useCallback(() => {
    if (!containerRef.current) return;
    const cw = containerRef.current.clientWidth;
    const ch = containerRef.current.clientHeight;
    if (cw <= 0 || ch <= 0) return;
    const targetZoom = Math.min((cw * 0.72) / (roomWidth + 1000), (ch * 0.72) / (roomLength + 1000));
    setZoom(Math.max(0.06, Math.min(0.25, targetZoom)));
    setPan({ x: 0, y: 0 });
  }, [roomWidth, roomLength]);

  // Robust Hit Test for Openings (Window / Door) with generous padding
  const findOpeningAtScreenPoint = useCallback(
    (mouseX: number, mouseY: number, canvas: HTMLCanvasElement): WallOpening | null => {
      for (const op of openings) {
        const geom = getOpeningGeometry(op, roomWidth, roomLength);
        const pt = worldToScreen(geom.worldCenterX, geom.worldCenterZ, canvas);
        const opWPx = geom.width * zoom;
        const wallThickPx = Math.max(18, 200 * zoom);
        const pad = 26; // 26px generous click/touch tolerance for easy grabbing

        if (geom.isHorizontal) {
          if (
            Math.abs(mouseX - pt.x) <= opWPx / 2 + pad &&
            Math.abs(mouseY - pt.y) <= wallThickPx / 2 + pad
          ) {
            return op;
          }
        } else {
          if (
            Math.abs(mouseX - pt.x) <= wallThickPx / 2 + pad &&
            Math.abs(mouseY - pt.y) <= opWPx / 2 + pad
          ) {
            return op;
          }
        }
      }
      return null;
    },
    [openings, roomWidth, roomLength, zoom, worldToScreen, getOpeningGeometry]
  );

  // Smooth Drag and Drop controller for Openings (Window / Door)
  // Supports sliding along wall, magnetic center snapping, and transferring across walls
  const moveOpeningWithPointer = useCallback(
    (worldPos: { x: number; z: number }, openingId: string) => {
      const op = openings.find((o) => o.id === openingId);
      if (!op) return;

      const halfW = roomWidth / 2;
      const halfL = roomLength / 2;

      // Distances from mouse world mm to the 4 perimeter walls
      const dNorth = Math.abs(worldPos.z - (-halfL));
      const dEast = Math.abs(worldPos.x - halfW);
      const dSouth = Math.abs(worldPos.z - halfL);
      const dWest = Math.abs(worldPos.x - (-halfW));

      // Hysteresis bonus for current wall: 300mm so it doesn't jump walls accidentally
      const currentWallIdx = getOpeningWallIndex(op);
      const bonus = 300;

      const weightedNorth = dNorth - (currentWallIdx === 0 ? bonus : 0);
      const weightedEast = dEast - (currentWallIdx === 1 ? bonus : 0);
      const weightedSouth = dSouth - (currentWallIdx === 2 ? bonus : 0);
      const weightedWest = dWest - (currentWallIdx === 3 ? bonus : 0);

      const minVal = Math.min(weightedNorth, weightedEast, weightedSouth, weightedWest);
      let targetWallIdx = currentWallIdx;
      if (minVal === weightedNorth) targetWallIdx = 0;
      else if (minVal === weightedEast) targetWallIdx = 1;
      else if (minVal === weightedSouth) targetWallIdx = 2;
      else if (minVal === weightedWest) targetWallIdx = 3;

      const wallLen = targetWallIdx === 0 || targetWallIdx === 2 ? roomWidth : roomLength;
      const wallName: 'north' | 'east' | 'south' | 'west' =
        targetWallIdx === 0 ? 'north' : targetWallIdx === 1 ? 'east' : targetWallIdx === 2 ? 'south' : 'west';

      // Calculate center distance along the target wall
      let targetCenterDist = 0;
      if (targetWallIdx === 0) {
        targetCenterDist = worldPos.x - (-halfW);
      } else if (targetWallIdx === 1) {
        targetCenterDist = worldPos.z - (-halfL);
      } else if (targetWallIdx === 2) {
        targetCenterDist = worldPos.x - (-halfW);
      } else {
        targetCenterDist = worldPos.z - (-halfL);
      }

      const opW = op.width || (op.type === 'door' ? 900 : 1200);
      let targetStartDist = targetCenterDist - opW / 2;

      // Magnetic snap to center of wall if within 80mm
      const wallCenterStart = (wallLen - opW) / 2;
      if (Math.abs(targetStartDist - wallCenterStart) < 80) {
        targetStartDist = wallCenterStart;
      } else {
        // Grid snap to 50mm
        targetStartDist = Math.round(targetStartDist / 50) * 50;
      }

      const minAllowed = 50;
      const maxAllowed = Math.max(minAllowed, wallLen - opW - 50);
      const clampedStartDist = Math.max(minAllowed, Math.min(maxAllowed, targetStartDist));

      const updated = openings.map((o) =>
        o.id === openingId
          ? {
              ...o,
              distanceFromStart: clampedStartDist,
              position: clampedStartDist,
              wallIndex: targetWallIdx,
              wall: wallName,
            }
          : o
      );

      // Live update 2D and 3D preview smoothly during drag
      onUpdateRoom({ ...room, openings: updated }, false);
    },
    [openings, room, roomWidth, roomLength, onUpdateRoom]
  );

  useEffect(() => {
    handleFitView();
  }, [handleFitView]);

  // Apply room dimensions
  const handleApplyDimensions = () => {
    const wMm = Math.max(2000, Math.min(25000, parseFloat(inputWidthM) * 1000 || 6000));
    const lMm = Math.max(2000, Math.min(25000, parseFloat(inputLengthM) * 1000 || 5000));
    onUpdateRoom({
      ...room,
      width: wMm,
      length: lMm,
    });
    showFeedback(`تم تحديث أبعاد الغرفة إلى ${(wMm / 1000).toFixed(1)}م × ${(lMm / 1000).toFixed(1)}م`);
  };

  // Quick Room Presets
  const handleApplyPreset = (type: 'rect' | 'l_shape' | 'u_shape' | 'island') => {
    if (type === 'rect') {
      onUpdateRoom({
        ...room,
        width: 6000,
        length: 5000,
        customWalls: [],
      });
      showFeedback('تم تطبيق قالب الغرفة المستطيلة 6م × 5م');
    } else if (type === 'l_shape') {
      const partition: CustomWall = {
        id: `wall_preset_${Date.now()}`,
        nameAr: 'جدار زاوية L',
        startX: 1000,
        startZ: 0,
        length: 2500,
        thickness: 180,
        height: 2800,
        rotationY: 90,
        color: '#E5E7EB',
      };
      onUpdateRoom({
        ...room,
        width: 6000,
        length: 5000,
        customWalls: [partition],
      });
      showFeedback('تم تطبيق قالب مطبخ شكل L');
    } else if (type === 'u_shape') {
      const wall1: CustomWall = {
        id: `wall_u1_${Date.now()}`,
        nameAr: 'جدار فاصل جانبي 1',
        startX: -1500,
        startZ: 1000,
        length: 2000,
        thickness: 180,
        height: 2800,
        rotationY: 0,
        color: '#E5E7EB',
      };
      const wall2: CustomWall = {
        id: `wall_u2_${Date.now()}`,
        nameAr: 'جدار فاصل جانبي 2',
        startX: 1500,
        startZ: 1000,
        length: 2000,
        thickness: 180,
        height: 2800,
        rotationY: 0,
        color: '#E5E7EB',
      };
      onUpdateRoom({
        ...room,
        width: 6500,
        length: 5500,
        customWalls: [wall1, wall2],
      });
      showFeedback('تم تطبيق قالب مطبخ شكل U');
    } else if (type === 'island') {
      const islandPartition: CustomWall = {
        id: `wall_island_${Date.now()}`,
        nameAr: 'قاطع مدخل الجزيرة',
        startX: 0,
        startZ: 1500,
        length: 2200,
        thickness: 150,
        height: 900,
        rotationY: 0,
        color: '#E5E7EB',
      };
      onUpdateRoom({
        ...room,
        width: 6500,
        length: 5500,
        customWalls: [islandPartition],
      });
      showFeedback('تم تجهيز مساحة الجزيرة الوسطية');
    }
  };

  // Add Wall Opening (Door / Window)
  const handleAddOpening = (type: 'door' | 'window') => {
    const width = type === 'door' ? 900 : 1200;
    const startDist = Math.max(50, Math.round((roomWidth - width) / 2));
    const newId = `${type}_${Date.now()}`;
    const newOpening: WallOpening = {
      id: newId,
      wallIndex: 0,
      wall: 'north',
      distanceFromStart: startDist,
      position: startDist,
      type: type,
      width: width,
      height: type === 'door' ? 2100 : 1200,
      sillHeight: type === 'door' ? 0 : 900,
      name: type === 'door' ? 'باب معماري' : 'نافذة معمارية',
    };
    onUpdateRoom(
      {
        ...room,
        openings: [...openings, newOpening],
      },
      true
    );
    setSelectedOpeningId(newId);
    onSelectUnit?.(null);
    onSelectCustomWall?.(null);
    showFeedback(
      type === 'door'
        ? '🚪 تمت إضافة باب جديد - يمكنك سحبه بالماوس أو اللمس لنقله إلى أي جدار'
        : '🪟 تمت إضافة نافذة جديدة - يمكنك الآن سحبها وإفلاتها مباشرة على أي جدار بالماوس أو اللمس'
    );
  };

  // Add Quick Partition Wall
  const handleAddQuickPartitionWall = () => {
    const newWall: CustomWall = {
      id: `wall_${Date.now()}`,
      nameAr: 'جدار فاصل معماري',
      startX: 0,
      startZ: 0,
      length: 2000,
      thickness: 180,
      height: 2800,
      rotationY: 0,
      color: '#E5E7EB',
    };
    onUpdateRoom({
      ...room,
      customWalls: [...customWalls, newWall],
    });
    onSelectCustomWall?.(newWall.id);
    onSelectUnit?.(null);
    showFeedback('تمت إضافة جدار فاصل بطول 2.0م - يمكنك تحريكه وتدويره');
  };

  // Main Canvas Rendering Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Handle High-DPI screens
    const dpr = window.devicePixelRatio || 1;
    const cw = canvas.parentElement?.clientWidth || 800;
    const ch = canvas.parentElement?.clientHeight || 600;

    if (canvas.width !== cw * dpr || canvas.height !== ch * dpr) {
      canvas.width = cw * dpr;
      canvas.height = ch * dpr;
    }

    ctx.save();
    ctx.scale(dpr, dpr);

    // 1. Background Fill (Sophisticated CAD Blueprint Charcoal)
    ctx.fillStyle = '#141416';
    ctx.fillRect(0, 0, cw, ch);

    // 2. Blueprint Grid Lines
    const cx = cw / 2 + pan.x;
    const cy = ch / 2 + pan.y;

    // Minor Grid: 200mm
    const stepMinor = 200 * zoom;
    if (stepMinor > 10) {
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      const startX = cx % stepMinor;
      for (let x = startX; x < cw; x += stepMinor) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, ch);
      }
      const startY = cy % stepMinor;
      for (let y = startY; y < ch; y += stepMinor) {
        ctx.moveTo(0, y);
        ctx.lineTo(cw, y);
      }
      ctx.stroke();
    }

    // Major Grid: 1000mm (1 Meter)
    const stepMajor = 1000 * zoom;
    if (stepMajor > 20) {
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      const startX = cx % stepMajor;
      for (let x = startX; x < cw; x += stepMajor) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, ch);
      }
      const startY = cy % stepMajor;
      for (let y = startY; y < ch; y += stepMajor) {
        ctx.moveTo(0, y);
        ctx.lineTo(cw, y);
      }
      ctx.stroke();
    }

    // 3. Room Floor Surface
    const halfW = roomWidth / 2;
    const halfL = roomLength / 2;
    const topLeft = worldToScreen(-halfW, -halfL, { width: cw, height: ch } as any);
    const roomPxW = roomWidth * zoom;
    const roomPxH = roomLength * zoom;

    // Room Floor
    ctx.fillStyle = '#1C1C20';
    ctx.fillRect(topLeft.x, topLeft.y, roomPxW, roomPxH);

    // Room Perimeter Inner Border
    ctx.strokeStyle = 'rgba(59, 130, 246, 0.2)';
    ctx.lineWidth = 1;
    ctx.strokeRect(topLeft.x, topLeft.y, roomPxW, roomPxH);

    // 4. Exterior Walls (Solid CAD Walls with Thickness)
    const wallThickPx = 200 * zoom;
    ctx.fillStyle = '#2A2B30';
    ctx.strokeStyle = '#4B5563';
    ctx.lineWidth = 2;

    // North Wall
    ctx.fillRect(topLeft.x - wallThickPx, topLeft.y - wallThickPx, roomPxW + wallThickPx * 2, wallThickPx);
    ctx.strokeRect(topLeft.x - wallThickPx, topLeft.y - wallThickPx, roomPxW + wallThickPx * 2, wallThickPx);

    // South Wall
    ctx.fillRect(topLeft.x - wallThickPx, topLeft.y + roomPxH, roomPxW + wallThickPx * 2, wallThickPx);
    ctx.strokeRect(topLeft.x - wallThickPx, topLeft.y + roomPxH, roomPxW + wallThickPx * 2, wallThickPx);

    // West Wall
    ctx.fillRect(topLeft.x - wallThickPx, topLeft.y, wallThickPx, roomPxH);
    ctx.strokeRect(topLeft.x - wallThickPx, topLeft.y, wallThickPx, roomPxH);

    // East Wall
    ctx.fillRect(topLeft.x + roomPxW, topLeft.y, wallThickPx, roomPxH);
    ctx.strokeRect(topLeft.x + roomPxW, topLeft.y, wallThickPx, roomPxH);

    // 5. Openings (Doors & Windows on walls)
    openings.forEach((op) => {
      const geom = getOpeningGeometry(op, roomWidth, roomLength);
      const isSelected = op.id === selectedOpeningId;
      const isHovered = op.id === hoveredOpeningId;
      const opWPx = geom.width * zoom;
      const currentWallThick = Math.max(18, wallThickPx);
      const pt = worldToScreen(geom.worldCenterX, geom.worldCenterZ, { width: cw, height: ch } as any);
      const centerX = pt.x;
      const centerY = pt.y;
      const isHorizontal = geom.isHorizontal;

      // 1. Cutout in wall
      ctx.fillStyle = '#141416';
      if (isHorizontal) {
        ctx.fillRect(centerX - opWPx / 2, centerY - currentWallThick / 2, opWPx, currentWallThick);
      } else {
        ctx.fillRect(centerX - currentWallThick / 2, centerY - opWPx / 2, currentWallThick, opWPx);
      }

      if (op.type === 'door') {
        // Door leaf & swing arc
        ctx.strokeStyle = isSelected ? '#3B82F6' : '#F59E0B';
        ctx.lineWidth = isSelected ? 2.5 : 1.8;

        if (isHorizontal) {
          const hingeX = centerX - opWPx / 2;
          const hingeY = geom.wallIdx === 0 ? topLeft.y : topLeft.y + roomPxH;
          const swingDir = geom.wallIdx === 0 ? 1 : -1;
          ctx.beginPath();
          ctx.arc(hingeX, hingeY, opWPx, 0, (Math.PI / 2) * swingDir, swingDir < 0);
          ctx.stroke();

          ctx.beginPath();
          ctx.moveTo(hingeX, hingeY);
          ctx.lineTo(hingeX, hingeY + opWPx * swingDir);
          ctx.stroke();
        } else {
          const hingeX = geom.wallIdx === 3 ? topLeft.x : topLeft.x + roomPxW;
          const hingeY = centerY - opWPx / 2;
          const swingDir = geom.wallIdx === 3 ? 1 : -1;
          ctx.beginPath();
          ctx.arc(hingeX, hingeY, opWPx, 0, (Math.PI / 2) * swingDir, swingDir < 0);
          ctx.stroke();

          ctx.beginPath();
          ctx.moveTo(hingeX, hingeY);
          ctx.lineTo(hingeX + opWPx * swingDir, hingeY);
          ctx.stroke();
        }

        // Center drag handle badge for door
        ctx.save();
        ctx.beginPath();
        ctx.arc(centerX, centerY, 10, 0, Math.PI * 2);
        ctx.fillStyle = isSelected ? '#D97706' : '#78350F';
        ctx.fill();
        ctx.strokeStyle = isSelected ? '#FDE68A' : '#F59E0B';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.fillStyle = '#FFFFFF';
        ctx.font = 'bold 8px system-ui';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(isHorizontal ? '⬌' : '⬍', centerX, centerY);
        ctx.restore();
      } else {
        // Architectural Window with double-glazed panes, sill, and aluminum frame
        ctx.save();
        ctx.translate(centerX, centerY);
        if (!isHorizontal) ctx.rotate(Math.PI / 2);

        const halfWPx = opWPx / 2;
        const halfHPx = currentWallThick / 2;

        // Window Sill (عتبة النافذة)
        ctx.strokeStyle = isSelected ? '#38BDF8' : '#94A3B8';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(-halfWPx - 4, halfHPx + 2);
        ctx.lineTo(halfWPx + 4, halfHPx + 2);
        ctx.stroke();

        // Translucent glass fill
        ctx.fillStyle = isSelected
          ? 'rgba(56, 189, 248, 0.35)'
          : isHovered
          ? 'rgba(56, 189, 248, 0.22)'
          : 'rgba(56, 189, 248, 0.12)';
        ctx.fillRect(-halfWPx, -halfHPx + 2, opWPx, currentWallThick - 4);

        // Window Outer Frame
        ctx.strokeStyle = isSelected ? '#0284C7' : isHovered ? '#38BDF8' : '#0F172A';
        ctx.lineWidth = isSelected ? 3 : 2;
        ctx.strokeRect(-halfWPx, -halfHPx + 2, opWPx, currentWallThick - 4);

        // Double Glass Glazing Panes
        ctx.strokeStyle = isSelected ? '#38BDF8' : '#7DD3FC';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        // Pane 1
        ctx.moveTo(-halfWPx + 2, -halfHPx / 3);
        ctx.lineTo(halfWPx - 2, -halfHPx / 3);
        // Pane 2
        ctx.moveTo(-halfWPx + 2, halfHPx / 3);
        ctx.lineTo(halfWPx - 2, halfHPx / 3);
        ctx.stroke();

        // Center Drag Handle Badge
        const badgeRadius = Math.min(13, Math.max(9, opWPx / 6));
        ctx.beginPath();
        ctx.arc(0, 0, badgeRadius, 0, Math.PI * 2);
        ctx.fillStyle = isSelected ? '#0284C7' : isHovered ? '#0EA5E9' : 'rgba(15, 23, 42, 0.9)';
        ctx.fill();
        ctx.strokeStyle = isSelected ? '#BAE6FD' : '#38BDF8';
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // Drag icon / arrow inside badge
        ctx.fillStyle = '#FFFFFF';
        ctx.font = 'bold 9px system-ui, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('⬌', 0, 0);

        ctx.restore();
      }

      // Selection & Drag Halo / Dimension lines
      if (isSelected || isHovered) {
        ctx.save();

        // Glowing Dashed Box
        ctx.strokeStyle = isSelected ? '#38BDF8' : '#0EA5E9';
        ctx.lineWidth = isSelected ? 2 : 1.5;
        ctx.setLineDash([4, 3]);
        const pad = 6;
        if (isHorizontal) {
          ctx.strokeRect(centerX - opWPx / 2 - pad, centerY - currentWallThick / 2 - pad, opWPx + pad * 2, currentWallThick + pad * 2);
        } else {
          ctx.strokeRect(centerX - currentWallThick / 2 - pad, centerY - opWPx / 2 - pad, currentWallThick + pad * 2, opWPx + pad * 2);
        }
        ctx.setLineDash([]);

        // Window Title Pill Badge
        const labelY = isHorizontal ? centerY - currentWallThick / 2 - 16 : centerY - opWPx / 2 - 16;
        const labelText = `${op.type === 'door' ? '🚪 باب' : '🪟 نافذة'} (${(geom.width / 1000).toFixed(2)}م) • اسحب بالماوس/اللمس`;
        ctx.font = 'bold 10px system-ui, sans-serif';
        const textW = ctx.measureText(labelText).width;
        ctx.fillStyle = 'rgba(15, 23, 42, 0.92)';
        ctx.beginPath();
        ctx.roundRect(centerX - textW / 2 - 8, labelY - 9, textW + 16, 18, 9);
        ctx.fill();
        ctx.strokeStyle = isSelected ? '#38BDF8' : '#0EA5E9';
        ctx.lineWidth = 1;
        ctx.stroke();

        ctx.fillStyle = isSelected ? '#38BDF8' : '#E2E8F0';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(labelText, centerX, labelY);

        // Center Magnetic Snap Indicator
        const isCentered = Math.abs(geom.startDist - (geom.wallLength - geom.width) / 2) < 20;
        if (isCentered) {
          const snapY = isHorizontal ? centerY + currentWallThick / 2 + 16 : centerY + opWPx / 2 + 16;
          ctx.fillStyle = '#22C55E';
          ctx.font = 'bold 10px system-ui';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('🎯 منتصف الجدار (Center)', centerX, snapY);
        }

        ctx.restore();
      } else {
        // Quiet distance tag
        ctx.fillStyle = '#94A3B8';
        ctx.font = 'bold 9px monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        const labelText = `${op.type === 'door' ? '🚪' : '🪟'} ${(geom.startDist / 1000).toFixed(2)}م`;
        ctx.fillText(labelText, centerX, centerY + (isHorizontal ? currentWallThick / 2 + 10 : 0));
      }
    });

    // 6. Custom Partition Walls
    customWalls.forEach((w) => {
      const isSelected = w.id === selectedCustomWallId;
      const rad = ((w.rotationY || 0) * Math.PI) / 180;
      const cos = Math.cos(rad);
      const sin = Math.sin(rad);

      const p1 = worldToScreen(w.startX, w.startZ, { width: cw, height: ch } as any);
      const p2 = worldToScreen(w.startX + w.length * cos, w.startZ + w.length * sin, { width: cw, height: ch } as any);

      const thickPx = (w.thickness || 180) * zoom;

      ctx.save();
      ctx.strokeStyle = isSelected ? '#3B82F6' : '#9CA3AF';
      ctx.lineWidth = Math.max(4, thickPx);
      ctx.lineCap = 'square';
      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.stroke();

      // Wall Length Label
      const midX = (p1.x + p2.x) / 2;
      const midY = (p1.y + p2.y) / 2;
      ctx.fillStyle = isSelected ? '#60A5FA' : '#E5E7EB';
      ctx.font = 'bold 10px monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'bottom';
      ctx.fillText(`${(w.length / 1000).toFixed(2)}م`, midX, midY - 6);

      ctx.restore();
    });

    // 6.5 Live Drag & Drop Wall Preview (User Request: رسم جدار بالسحب والافلات)
    if (wallStartMm) {
      const p1 = worldToScreen(wallStartMm.x, wallStartMm.z, { width: cw, height: ch } as any);
      const p2 = worldToScreen(mouseMm.x, mouseMm.z, { width: cw, height: ch } as any);
      const dx = mouseMm.x - wallStartMm.x;
      const dz = mouseMm.z - wallStartMm.z;
      const previewLen = Math.hypot(dx, dz);
      const angleDeg = Math.round((Math.atan2(dz, dx) * 180) / Math.PI);

      ctx.save();
      // Thick dashed preview wall
      ctx.strokeStyle = '#A855F7';
      ctx.lineWidth = Math.max(6, 180 * zoom);
      ctx.setLineDash([8, 6]);
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.stroke();

      // Start & End Point Handles
      ctx.fillStyle = '#C084FC';
      ctx.beginPath();
      ctx.arc(p1.x, p1.y, 7, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(p2.x, p2.y, 7, 0, Math.PI * 2);
      ctx.fill();

      // Dimension Badge
      const midX = (p1.x + p2.x) / 2;
      const midY = (p1.y + p2.y) / 2;
      ctx.fillStyle = '#7E22CE';
      ctx.beginPath();
      if (typeof ctx.roundRect === 'function') {
        ctx.roundRect(midX - 55, midY - 26, 110, 22, 6);
      } else {
        ctx.rect(midX - 55, midY - 26, 110, 22);
      }
      ctx.fill();
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 11px monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(`${(previewLen / 1000).toFixed(2)}م (${angleDeg}°)`, midX, midY - 15);

      ctx.restore();
    }

    // 7. Render Parametric Cabinets
    units.forEach((u) => {
      const isSelected = u.id === selectedUnitId;
      const rad = ((u.rotationY || 0) * Math.PI) / 180;

      const p = worldToScreen(u.positionX, u.positionZ, { width: cw, height: ch } as any);
      const wPx = u.width * zoom;
      const dPx = u.depth * zoom;

      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(rad);

      // Cabinet Body Base
      const isAppliance = u.subCategory === 'appliances' || u.applianceType;
      const isTall = u.category === 'tall' || u.height > 1500;
      const isWall = u.category === 'wall' || u.positionY > 1000;

      if (isSelected) {
        // Glowing outline for selected unit
        ctx.shadowColor = '#3B82F6';
        ctx.shadowBlur = 12;
        ctx.strokeStyle = '#60A5FA';
        ctx.lineWidth = 2.5;
      } else {
        ctx.shadowBlur = 0;
        ctx.strokeStyle = isAppliance ? '#64748B' : isTall ? '#78716C' : '#334155';
        ctx.lineWidth = 1.5;
      }

      // Fill color
      ctx.fillStyle = isSelected
        ? '#1E293B'
        : isAppliance
        ? '#0F172A'
        : isTall
        ? '#1C1917'
        : isWall
        ? '#18181B'
        : '#1E293B';

      ctx.fillRect(-wPx / 2, -dPx / 2, wPx, dPx);
      ctx.strokeRect(-wPx / 2, -dPx / 2, wPx, dPx);

      // Countertop Overhang & Front Indicator (Yellow/Amber line for front edge)
      ctx.strokeStyle = '#F59E0B';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-wPx / 2, dPx / 2);
      ctx.lineTo(wPx / 2, dPx / 2);
      ctx.stroke();

      // Front direction arrow
      ctx.fillStyle = '#F59E0B';
      ctx.beginPath();
      ctx.moveTo(0, dPx / 2 + 4);
      ctx.lineTo(-4, dPx / 2 - 2);
      ctx.lineTo(4, dPx / 2 - 2);
      ctx.closePath();
      ctx.fill();

      // Sink or Hob or Combo Cooking Station symbol details
      if (u.accessoryType === 'combo_cooking_station_900' || u.accessoryType === 'combo_cooking_station_1000') {
        // Draw 15cm side oil racks
        const rackPx = (u.accessoryType === 'combo_cooking_station_1000' ? 200 : 150) * zoom;
        ctx.strokeStyle = '#F59E0B';
        ctx.lineWidth = 1;
        ctx.setLineDash([2, 2]);
        // Left rack divider
        ctx.beginPath();
        ctx.moveTo(-wPx / 2 + rackPx, -dPx / 2);
        ctx.lineTo(-wPx / 2 + rackPx, dPx / 2);
        ctx.stroke();
        // Right rack divider
        ctx.beginPath();
        ctx.moveTo(wPx / 2 - rackPx, -dPx / 2);
        ctx.lineTo(wPx / 2 - rackPx, dPx / 2);
        ctx.stroke();
        ctx.setLineDash([]);

        // 5-Burner Gas Cooktop in Center
        const centerW = wPx - 2 * rackPx;
        ctx.strokeStyle = '#EF4444';
        ctx.lineWidth = 1.2;
        // Central wok burner
        ctx.beginPath();
        ctx.arc(0, 0, Math.min(10, centerW * 0.14), 0, Math.PI * 2);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(0, 0, Math.min(5, centerW * 0.07), 0, Math.PI * 2);
        ctx.stroke();
        // 4 corner burners
        const bx = centerW * 0.28;
        const bz = dPx * 0.22;
        [[-bx, -bz], [-bx, bz], [bx, -bz], [bx, bz]].forEach(([cx, cz]) => {
          ctx.beginPath();
          ctx.arc(cx, cz, Math.min(6, centerW * 0.09), 0, Math.PI * 2);
          ctx.stroke();
        });
      } else if (u.sinkConfig?.enabled || u.applianceType === 'single_sink' || u.applianceType === 'double_sink') {
        ctx.strokeStyle = '#38BDF8';
        ctx.lineWidth = 1;
        ctx.strokeRect(-wPx * 0.35, -dPx * 0.35, wPx * 0.7, dPx * 0.7);
        ctx.beginPath();
        ctx.arc(0, 0, 3, 0, Math.PI * 2);
        ctx.stroke();
      } else if (u.hobConfig?.enabled || u.applianceType === 'induction_hob' || u.applianceType === 'gas_hob') {
        ctx.strokeStyle = '#EF4444';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(-wPx * 0.2, 0, Math.min(10, wPx * 0.15), 0, Math.PI * 2);
        ctx.arc(wPx * 0.2, 0, Math.min(10, wPx * 0.15), 0, Math.PI * 2);
        ctx.stroke();
      }

      // Unit Label
      ctx.shadowBlur = 0;
      ctx.fillStyle = isSelected ? '#FFFFFF' : '#E2E8F0';
      ctx.font = `bold ${Math.max(9, Math.min(12, 11 * (zoom / 0.12)))}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      const shortName = u.nameAr || u.name || 'خزانة';
      const cleanName = shortName.length > 14 ? shortName.substring(0, 14) + '..' : shortName;
      ctx.fillText(cleanName, 0, -4);

      // Dimension Tag (e.g. 80×60)
      ctx.fillStyle = isSelected ? '#93C5FD' : '#94A3B8';
      ctx.font = `${Math.max(8, Math.min(10, 9 * (zoom / 0.12)))}px monospace`;
      ctx.fillText(`${(u.width / 10).toFixed(0)}×${(u.depth / 10).toFixed(0)}سم`, 0, 8);

      ctx.restore();
    });

    // 8. Dynamic Live Distance Guides when dragging
    if (isDraggingUnit && selectedUnit) {
      const u = selectedUnit;
      const halfUW = u.width / 2;
      const halfUD = u.depth / 2;

      const distNorth = Math.max(0, -halfL - (u.positionZ - halfUD));
      const distSouth = Math.max(0, halfL - (u.positionZ + halfUD));
      const distWest = Math.max(0, -halfW - (u.positionX - halfUW));
      const distEast = Math.max(0, halfW - (u.positionX + halfUW));

      const centerScreen = worldToScreen(u.positionX, u.positionZ, { width: cw, height: ch } as any);

      ctx.save();
      ctx.strokeStyle = '#10B981';
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 4]);

      // Guide to North wall
      const northP = worldToScreen(u.positionX, -halfL, { width: cw, height: ch } as any);
      ctx.beginPath();
      ctx.moveTo(centerScreen.x, centerScreen.y);
      ctx.lineTo(northP.x, northP.y);
      ctx.stroke();

      // Guide to West wall
      const westP = worldToScreen(-halfW, u.positionZ, { width: cw, height: ch } as any);
      ctx.beginPath();
      ctx.moveTo(centerScreen.x, centerScreen.y);
      ctx.lineTo(westP.x, westP.y);
      ctx.stroke();

      // Guide labels
      ctx.fillStyle = '#10B981';
      ctx.font = 'bold 11px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(`${(Math.abs(u.positionZ - (-halfL)) / 1000).toFixed(2)}م شمال`, centerScreen.x + 40, (centerScreen.y + northP.y) / 2);
      ctx.fillText(`${(Math.abs(u.positionX - (-halfW)) / 1000).toFixed(2)}م غرب`, (centerScreen.x + westP.x) / 2, centerScreen.y - 12);

      ctx.restore();
    }

    // 9. Wall Exterior Dimension Callouts
    ctx.fillStyle = '#9CA3AF';
    ctx.font = 'bold 12px monospace';
    ctx.textAlign = 'center';

    // Top Dimension (Width)
    ctx.fillText(
      `عرض الغرفة: ${(roomWidth / 1000).toFixed(2)} م`,
      topLeft.x + roomPxW / 2,
      topLeft.y - wallThickPx - 14
    );

    // Left Dimension (Length)
    ctx.save();
    ctx.translate(topLeft.x - wallThickPx - 16, topLeft.y + roomPxH / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.fillText(`طول الغرفة: ${(roomLength / 1000).toFixed(2)} م`, 0, 0);
    ctx.restore();

    // 10. Freehand Drawing Strokes (User Request: رسم يدوي)
    const allStrokes = currentStroke ? [...freehandStrokes, currentStroke] : freehandStrokes;
    allStrokes.forEach((stroke) => {
      if (!stroke.points || stroke.points.length === 0) return;
      ctx.beginPath();
      ctx.strokeStyle = stroke.color || '#ef4444';
      ctx.lineWidth = Math.max(2, (stroke.width || 30) * zoom);
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      const first = worldToScreen(stroke.points[0].x, stroke.points[0].z, canvas);
      ctx.moveTo(first.x, first.y);
      if (stroke.points.length === 1) {
        ctx.lineTo(first.x + 0.1, first.y + 0.1);
      } else {
        for (let i = 1; i < stroke.points.length; i++) {
          const pt = worldToScreen(stroke.points[i].x, stroke.points[i].z, canvas);
          ctx.lineTo(pt.x, pt.y);
        }
      }
      ctx.stroke();
    });

    ctx.restore();
  }, [
    zoom,
    pan,
    roomWidth,
    roomLength,
    customWalls,
    openings,
    units,
    selectedUnitId,
    selectedCustomWallId,
    isDraggingUnit,
    worldToScreen,
    freehandStrokes,
    currentStroke,
  ]);

  // Canvas Mouse Down: Select, Drag, Pan, or Draw Wall
  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    // Right Click or Space/Alt key: Pan
    if (e.button === 2 || e.altKey || e.shiftKey) {
      setIsPanning(true);
      setPanStart({ x: mouseX - pan.x, y: mouseY - pan.y });
      return;
    }

    const worldPos = screenToWorld(mouseX, mouseY, canvas);

    if (activeTool === 'freehand') {
      const newStroke: FreehandStroke = {
        id: `stroke_${Date.now()}`,
        points: [{ x: worldPos.x, z: worldPos.z }],
        color: freehandColor,
        width: freehandStrokeWidth,
      };
      setCurrentStroke(newStroke);
      return;
    }

    if (activeTool === 'draw_wall') {
      const snapped = { x: Math.round(worldPos.x / 100) * 100, z: Math.round(worldPos.z / 100) * 100 };
      if (!wallStartMm) {
        setWallStartMm(snapped);
        setIsDraggingWall(true);
      } else {
        // Complete Wall on click
        const endX = snapped.x;
        const endZ = snapped.z;
        const dx = endX - wallStartMm.x;
        const dz = endZ - wallStartMm.z;
        const length = Math.round(Math.hypot(dx, dz));
        if (length >= 300) {
          const angleDeg = Math.round((Math.atan2(dz, dx) * 180) / Math.PI);
          const newWall: CustomWall = {
            id: `wall_${Date.now()}`,
            nameAr: 'جدار فاصل معماري',
            startX: wallStartMm.x,
            startZ: wallStartMm.z,
            length: length,
            thickness: 180,
            height: 2800,
            rotationY: angleDeg,
            color: '#E5E7EB',
          };
          onUpdateRoom({
            ...room,
            customWalls: [...customWalls, newWall],
          });
          onSelectCustomWall?.(newWall.id);
          onSelectUnit?.(null);
          showFeedback(`تم رسم جدار بطول ${(length / 1000).toFixed(2)}م`);
        }
        setWallStartMm(null);
        setIsDraggingWall(false);
        setActiveTool('select');
      }
      return;
    }

    // Check if clicked on an Opening (Window / Door on wall)
    const clickedOpening = findOpeningAtScreenPoint(mouseX, mouseY, canvas);
    if (clickedOpening) {
      setSelectedOpeningId(clickedOpening.id);
      setIsDraggingOpening(true);
      onSelectUnit?.(null);
      onSelectCustomWall?.(null);
      return;
    }

    // Check if clicked on a Cabinet
    let clickedUnit: ParametricCabinet | null = null;
    for (let i = units.length - 1; i >= 0; i--) {
      const u = units[i];
      const isRotated = Math.abs(u.rotationY % 180) === 90;
      const halfW = (isRotated ? u.depth : u.width) / 2;
      const halfD = (isRotated ? u.width : u.depth) / 2;

      if (
        worldPos.x >= u.positionX - halfW &&
        worldPos.x <= u.positionX + halfW &&
        worldPos.z >= u.positionZ - halfD &&
        worldPos.z <= u.positionZ + halfD
      ) {
        clickedUnit = u;
        break;
      }
    }

    if (clickedUnit) {
      onSelectUnit?.(clickedUnit.id);
      onSelectCustomWall?.(null);
      setSelectedOpeningId(null);
      setIsDraggingUnit(true);
      setDragUnitStart({
        unitId: clickedUnit.id,
        startMouseX: worldPos.x,
        startMouseZ: worldPos.z,
        origX: clickedUnit.positionX,
        origZ: clickedUnit.positionZ,
      });
      return;
    }

    // Check if clicked on a Custom Wall
    let clickedWall: CustomWall | null = null;
    for (const w of customWalls) {
      const rad = ((w.rotationY || 0) * Math.PI) / 180;
      const cos = Math.cos(rad);
      const sin = Math.sin(rad);
      const p1x = w.startX;
      const p1z = w.startZ;
      const p2x = w.startX + w.length * cos;
      const p2z = w.startZ + w.length * sin;

      // Distance from point to line segment
      const l2 = (p2x - p1x) ** 2 + (p2z - p1z) ** 2;
      const t = Math.max(0, Math.min(1, ((worldPos.x - p1x) * (p2x - p1x) + (worldPos.z - p1z) * (p2z - p1z)) / l2));
      const projX = p1x + t * (p2x - p1x);
      const projZ = p1z + t * (p2z - p1z);
      const dist = Math.hypot(worldPos.x - projX, worldPos.z - projZ);

      if (dist <= (w.thickness || 180) + 150) {
        clickedWall = w;
        break;
      }
    }

    if (clickedWall) {
      onSelectCustomWall?.(clickedWall.id);
      onSelectUnit?.(null);
      setSelectedOpeningId(null);
      return;
    }

    // Clicked on empty space: start panning or deselect
    setIsPanning(true);
    setPanStart({ x: mouseX - pan.x, y: mouseY - pan.y });
    onSelectUnit?.(null);
    onSelectCustomWall?.(null);
    setSelectedOpeningId(null);
  };

  // Canvas Mouse Move: Dragging Unit, Drawing, or Panning
  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    if (isPanning) {
      setPan({ x: mouseX - panStart.x, y: mouseY - panStart.y });
      return;
    }

    const worldPos = screenToWorld(mouseX, mouseY, canvas);
    setMouseMm(worldPos);

    if (activeTool === 'freehand' && currentStroke) {
      setCurrentStroke((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          points: [...prev.points, { x: worldPos.x, z: worldPos.z }],
        };
      });
      return;
    }

    if (isDraggingOpening && selectedOpeningId) {
      moveOpeningWithPointer(worldPos, selectedOpeningId);
      return;
    }

    if (!isDraggingOpening && !isDraggingUnit && !isDraggingWall && !isPanning) {
      const hovered = findOpeningAtScreenPoint(mouseX, mouseY, canvas);
      setHoveredOpeningId(hovered ? hovered.id : null);
    }

    if (isDraggingUnit && dragUnitStart && selectedUnit) {
      const deltaX = worldPos.x - dragUnitStart.startMouseX;
      const deltaZ = worldPos.z - dragUnitStart.startMouseZ;

      const targetX = Math.round((dragUnitStart.origX + deltaX) / 50) * 50;
      const targetZ = Math.round((dragUnitStart.origZ + deltaZ) / 50) * 50;

      // Smart Collision solver with walls and units
      const resolved = resolveCabinetMovement(
        selectedUnit,
        { x: targetX, y: selectedUnit.positionY, z: targetZ },
        units,
        room
      );

      if (resolved.collided) {
        onUpdateUnit?.({
          ...selectedUnit,
          positionX: resolved.position.x,
          positionZ: resolved.position.z,
        });
      } else {
        onUpdateUnit?.({
          ...selectedUnit,
          positionX: targetX,
          positionZ: targetZ,
        });
      }
    }
  };

  // Canvas Mouse Up
  const handleCanvasMouseUp = () => {
    setIsPanning(false);

    if (isDraggingOpening && selectedOpeningId) {
      const op = openings.find((o) => o.id === selectedOpeningId);
      if (op) {
        const wallIdx = getOpeningWallIndex(op);
        const wallArabic =
          wallIdx === 0
            ? 'الجدار الشمالي (الخلفي)'
            : wallIdx === 1
            ? 'الجدار الشرقي (الأيمن)'
            : wallIdx === 2
            ? 'الجدار الجنوبي (الأمامي)'
            : 'الجدار الغربي (الأيسر)';
        const distM = ((op.distanceFromStart || 0) / 1000).toFixed(2);
        showFeedback(
          op.type === 'door'
            ? `🚪 تم تثبيت مكان الباب على ${wallArabic} (${distM}م)`
            : `🪟 تم تثبيت مكان النافذة على ${wallArabic} (${distM}م) بالسحب والإفلات`
        );
        onUpdateRoom({ ...room, openings }, true);
      }
    }
    setIsDraggingOpening(false);

    // Complete Drag & Drop Wall on release (User Request: رسم جدار بالسحب والافلات)
    if (activeTool === 'draw_wall' && wallStartMm && isDraggingWall) {
      const canvas = canvasRef.current;
      if (canvas) {
        const dx = mouseMm.x - wallStartMm.x;
        const dz = mouseMm.z - wallStartMm.z;
        const length = Math.round(Math.hypot(dx, dz));

        // If user dragged a meaningful distance (>= 300mm), create wall immediately
        if (length >= 300) {
          const angleDeg = Math.round((Math.atan2(dz, dx) * 180) / Math.PI);
          const newWall: CustomWall = {
            id: `wall_${Date.now()}`,
            nameAr: 'جدار فاصل معماري',
            startX: wallStartMm.x,
            startZ: wallStartMm.z,
            length: length,
            thickness: 180,
            height: 2800,
            rotationY: angleDeg,
            color: '#E5E7EB',
          };
          onUpdateRoom({
            ...room,
            customWalls: [...customWalls, newWall],
          });
          onSelectCustomWall?.(newWall.id);
          onSelectUnit?.(null);
          showFeedback(`تم رسم جدار بالسحب والإفلات بطول ${(length / 1000).toFixed(2)}م`);
          setWallStartMm(null);
          setActiveTool('select');
        }
      }
    }

    // Complete Freehand Stroke on release (User Request: زر رسم اليدوي في مخطط 2d)
    if (activeTool === 'freehand' && currentStroke) {
      if (currentStroke.points.length > 0) {
        setFreehandStrokes((prev) => [...prev, currentStroke]);
      }
      setCurrentStroke(null);
    }

    setIsDraggingWall(false);
    setIsDraggingUnit(false);
    setIsDraggingOpening(false);
    setDragUnitStart(null);
  };

  // Touch Handlers for Mobile & Tablet (Dragging Units, Walls, Openings, and Freehand)
  const handleCanvasTouchStart = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (e.touches.length !== 1) return;
    const touch = e.touches[0];
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mouseX = touch.clientX - rect.left;
    const mouseY = touch.clientY - rect.top;
    const worldPos = screenToWorld(mouseX, mouseY, canvas);

    if (activeTool === 'freehand') {
      const newStroke: FreehandStroke = {
        id: `stroke_${Date.now()}`,
        points: [{ x: worldPos.x, z: worldPos.z }],
        color: freehandColor,
        width: freehandStrokeWidth,
      };
      setCurrentStroke(newStroke);
      return;
    }

    if (activeTool === 'draw_wall') {
      const snapped = { x: Math.round(worldPos.x / 100) * 100, z: Math.round(worldPos.z / 100) * 100 };
      setWallStartMm(snapped);
      setMouseMm(snapped);
      setIsDraggingWall(true);
      return;
    }

    // Touch hit test for Openings (Window / Door)
    const clickedOpening = findOpeningAtScreenPoint(mouseX, mouseY, canvas);
    if (clickedOpening) {
      setSelectedOpeningId(clickedOpening.id);
      setIsDraggingOpening(true);
      onSelectUnit?.(null);
      onSelectCustomWall?.(null);
      return;
    }

    // Touch hit test for Units
    let clickedUnit: ParametricCabinet | null = null;
    for (let i = units.length - 1; i >= 0; i--) {
      const u = units[i];
      const isRotated = Math.abs(u.rotationY % 180) === 90;
      const hW = (isRotated ? u.depth : u.width) / 2;
      const hD = (isRotated ? u.width : u.depth) / 2;
      if (
        worldPos.x >= u.positionX - hW &&
        worldPos.x <= u.positionX + hW &&
        worldPos.z >= u.positionZ - hD &&
        worldPos.z <= u.positionZ + hD
      ) {
        clickedUnit = u;
        break;
      }
    }
    if (clickedUnit) {
      onSelectUnit?.(clickedUnit.id);
      onSelectCustomWall?.(null);
      setSelectedOpeningId(null);
      setIsDraggingUnit(true);
      setDragUnitStart({
        unitId: clickedUnit.id,
        startMouseX: worldPos.x,
        startMouseZ: worldPos.z,
        origX: clickedUnit.positionX,
        origZ: clickedUnit.positionZ,
      });
      return;
    }

    // Default Touch: Pan
    setIsPanning(true);
    setPanStart({ x: mouseX - pan.x, y: mouseY - pan.y });
  };

  const handleCanvasTouchMove = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (e.touches.length !== 1) return;
    const touch = e.touches[0];
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mouseX = touch.clientX - rect.left;
    const mouseY = touch.clientY - rect.top;

    if (isPanning) {
      setPan({ x: mouseX - panStart.x, y: mouseY - panStart.y });
      return;
    }

    const worldPos = screenToWorld(mouseX, mouseY, canvas);

    if (activeTool === 'freehand' && currentStroke) {
      setCurrentStroke((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          points: [...prev.points, { x: worldPos.x, z: worldPos.z }],
        };
      });
      return;
    }

    if (activeTool === 'draw_wall' && wallStartMm) {
      setMouseMm(worldPos);
      return;
    }

    if (isDraggingOpening && selectedOpeningId) {
      moveOpeningWithPointer(worldPos, selectedOpeningId);
      return;
    }

    if (isDraggingUnit && dragUnitStart && selectedUnit) {
      const deltaX = worldPos.x - dragUnitStart.startMouseX;
      const deltaZ = worldPos.z - dragUnitStart.startMouseZ;
      const targetX = Math.round((dragUnitStart.origX + deltaX) / 50) * 50;
      const targetZ = Math.round((dragUnitStart.origZ + deltaZ) / 50) * 50;

      const resolved = resolveCabinetMovement(
        selectedUnit,
        { x: targetX, y: selectedUnit.positionY, z: targetZ },
        units,
        room
      );

      if (resolved.collided) {
        onUpdateUnit?.({
          ...selectedUnit,
          positionX: resolved.position.x,
          positionZ: resolved.position.z,
        });
      } else {
        onUpdateUnit?.({
          ...selectedUnit,
          positionX: targetX,
          positionZ: targetZ,
        });
      }
    }
  };

  const handleCanvasTouchEnd = () => {
    handleCanvasMouseUp();
  };

  // Canvas Wheel: Zoom
  const handleCanvasWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 1.15 : 0.87;
    setZoom((prev) => Math.max(0.04, Math.min(0.5, prev * zoomFactor)));
  };

  // Nudge unit movement
  const handleNudgeUnit = (dx: number, dz: number) => {
    if (!selectedUnit) return;
    const resolved = resolveCabinetMovement(
      selectedUnit,
      { x: selectedUnit.positionX + dx, y: selectedUnit.positionY, z: selectedUnit.positionZ + dz },
      units,
      room
    );
    onUpdateUnit?.({
      ...selectedUnit,
      positionX: resolved.position.x,
      positionZ: resolved.position.z,
    });
  };

  // Rotate unit 90 degrees
  const handleRotateUnit = () => {
    if (selectedUnit) {
      const newRot = ((selectedUnit.rotationY || 0) + 90) % 360;
      onUpdateUnit?.({
        ...selectedUnit,
        rotationY: newRot,
      });
    } else if (selectedWall) {
      const newRot = ((selectedWall.rotationY || 0) + 90) % 360;
      const updated = customWalls.map((w) => (w.id === selectedWall.id ? { ...w, rotationY: newRot } : w));
      onUpdateRoom({ ...room, customWalls: updated });
    }
  };

  return (
    <div ref={containerRef} className="relative w-full h-full overflow-hidden select-none bg-[#141416]">
      {/* ----------------------------------------------------------------- */}
      {/* 1. TOP 2D BLUEPRINT TOOLBAR                                       */}
      {/* ----------------------------------------------------------------- */}
      <div className="absolute top-4 inset-x-4 z-30 pointer-events-none flex items-center justify-between gap-3">
        {/* Left Side: Zoom and View Controls */}
        <div className="pointer-events-auto flex items-center gap-1.5 p-1.5 rounded-full bg-[#1C1C1E]/95 backdrop-blur-md border border-white/10 shadow-2xl">
          <button
            type="button"
            onClick={() => setZoom((prev) => Math.min(0.45, prev * 1.25))}
            className="w-8 h-8 rounded-full hover:bg-white/10 text-zinc-300 hover:text-white flex items-center justify-center transition active:scale-95"
            title="تكبير (+)"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setZoom((prev) => Math.max(0.04, prev * 0.8))}
            className="w-8 h-8 rounded-full hover:bg-white/10 text-zinc-300 hover:text-white flex items-center justify-center transition active:scale-95"
            title="تصغير (-)"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={handleFitView}
            className="w-8 h-8 rounded-full hover:bg-white/10 text-zinc-300 hover:text-white flex items-center justify-center transition active:scale-95"
            title="ملاءمة الشاشة بالكامل"
          >
            <Maximize2 className="w-4 h-4 text-blue-400" />
          </button>

          <div className="w-px h-5 bg-white/10 mx-1" />

          {/* Door Toggle Button inside 2D */}
          {onToggleDoors && (
            <button
              type="button"
              onClick={onToggleDoors}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-bold transition active:scale-95 ${
                areDoorsOpen ? 'bg-amber-500 text-white' : 'bg-white/5 hover:bg-white/10 text-amber-300'
              }`}
              title="فتح وإغلاق الأبواب"
            >
              <DoorOpen className="w-3.5 h-3.5" />
              <span>{areDoorsOpen ? 'إغلاق الأبواب' : 'فتح الأبواب'}</span>
            </button>
          )}
        </div>

        {/* Center: Tools (Select, Partition Wall, Openings, Room Dimensions) */}
        <div className="pointer-events-auto flex items-center gap-2 p-1.5 rounded-full bg-[#1C1C1E]/95 backdrop-blur-md border border-white/10 shadow-2xl text-xs font-bold overflow-x-auto max-w-[95vw]">
          {/* Branded Section Header: أدوات مخطط 2D */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30 shrink-0 font-black">
            <Compass className="w-3.5 h-3.5 text-blue-400" />
            <span>أدوات مخطط 2D</span>
          </div>

          {/* Tool: Select */}
          <button
            type="button"
            onClick={() => {
              setActiveTool('select');
              setWallStartMm(null);
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full transition active:scale-95 shrink-0 ${
              activeTool === 'select' ? 'bg-blue-600 text-white shadow-lg' : 'text-zinc-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <MousePointer className="w-3.5 h-3.5" />
            <span>تحديد وتحريك</span>
          </button>

          {/* Tool: Draw Wall by Drag & Drop (User Request: رسم جدار بالسحب والافلات) */}
          <button
            type="button"
            onClick={() => {
              setActiveTool((prev) => (prev === 'draw_wall' ? 'select' : 'draw_wall'));
              setWallStartMm(null);
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full transition active:scale-95 shrink-0 ${
              activeTool === 'draw_wall'
                ? 'bg-purple-600 text-white shadow-lg shadow-purple-900/40 ring-2 ring-purple-400'
                : 'text-zinc-300 hover:text-white hover:bg-white/5'
            }`}
            title="رسم جدار بالسحب والإفلات مباشرة على المخطط"
          >
            <PenTool className="w-3.5 h-3.5 text-purple-300" />
            <span>رسم جدار بالسحب</span>
          </button>

          {/* Tool: Manual Freehand Drawing (User Request: واضف زر رسم اليدوي في مخطط 2d) */}
          <button
            type="button"
            id="btn-tool-freehand"
            onClick={() => {
              setActiveTool((prev) => (prev === 'freehand' ? 'select' : 'freehand'));
              setWallStartMm(null);
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full transition active:scale-95 shrink-0 ${
              activeTool === 'freehand'
                ? 'bg-amber-600 text-white shadow-lg shadow-amber-900/40 ring-2 ring-amber-400'
                : 'text-zinc-300 hover:text-white hover:bg-white/5'
            }`}
            title="رسم يدوي حر بالقلم والملاحظات على المخطط"
          >
            <Pencil className="w-3.5 h-3.5 text-amber-300" />
            <span>رسم يدوي</span>
          </button>

          {/* Tool: Add Partition Wall */}
          <button
            type="button"
            onClick={handleAddQuickPartitionWall}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-zinc-300 hover:text-white hover:bg-white/5 transition active:scale-95 shrink-0"
            title="إضافة جدار فاصل معماري للمطبخ"
          >
            <PenTool className="w-3.5 h-3.5 text-purple-400" />
            <span>+ جدار فاصل</span>
          </button>

          {/* Tool: Add Door Opening */}
          <button
            type="button"
            onClick={() => handleAddOpening('door')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-zinc-300 hover:text-white hover:bg-white/5 transition active:scale-95 shrink-0 bg-amber-500/10 border border-amber-500/20"
            title="إضافة فتحة باب على الجدار والتحكم بمكانها"
          >
            <Plus className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-amber-300">+ باب</span>
          </button>

          {/* Tool: Add Window Opening */}
          <button
            type="button"
            onClick={() => handleAddOpening('window')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-zinc-300 hover:text-white hover:bg-white/5 transition active:scale-95 shrink-0 bg-cyan-500/10 border border-cyan-500/20"
            title="إضافة نافذة على الجدار والتحكم بمكانها"
          >
            <Plus className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-cyan-300">+ نافذة</span>
          </button>

          {/* Tool: Add Cabinet from Catalog (User Request: التحكم بمكان الوحدات من داخل مخطط 2d) */}
          {onOpenCatalog && (
            <button
              type="button"
              onClick={onOpenCatalog}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-zinc-300 hover:text-white hover:bg-white/5 transition active:scale-95 shrink-0 bg-blue-500/10 border border-blue-500/20"
              title="إضافة خزائن ووحدات وأجهزة من الكتالوج مباشرة"
            >
              <Plus className="w-3.5 h-3.5 text-blue-400" />
              <span className="text-blue-300">+ خزانة</span>
            </button>
          )}

          <div className="w-px h-5 bg-white/10 mx-1" />

          {/* Room Dimensions Inputs */}
          <div className="hidden lg:flex items-center gap-2 px-2 text-zinc-300 font-mono text-[11px]">
            <span>الغرفة:</span>
            <input
              type="number"
              step="0.1"
              value={inputWidthM}
              onChange={(e) => setInputWidthM(e.target.value)}
              className="w-12 px-1.5 py-0.5 bg-black/40 border border-white/10 rounded text-center text-white"
            />
            <span>×</span>
            <input
              type="number"
              step="0.1"
              value={inputLengthM}
              onChange={(e) => setInputLengthM(e.target.value)}
              className="w-12 px-1.5 py-0.5 bg-black/40 border border-white/10 rounded text-center text-white"
            />
            <span>م</span>
            <button
              type="button"
              onClick={handleApplyDimensions}
              className="px-2 py-0.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-[10px] font-bold"
            >
              تطبيق
            </button>
          </div>
        </div>

        {/* Right Side: Quick Return to 3D View */}
        <div className="pointer-events-auto flex items-center gap-2 shrink-0">
          <button
            type="button"
            id="btn-return-3d"
            onClick={onSwitchTo3D}
            className="flex items-center gap-2 px-4 py-2 rounded-full bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-2xl shadow-blue-900/50 transition active:scale-95 border border-blue-400/30 shrink-0"
            title="الرجوع إلى المنظور ثلاثي الأبعاد 3D"
          >
            <Box className="w-4 h-4" />
            <span>3D العودة للمنظور</span>
          </button>
        </div>
      </div>

      {/* ----------------------------------------------------------------- */}
      {/* 2. PRESETS PILL (Below Topbar, positioned neatly in corner)       */}
      {/* ----------------------------------------------------------------- */}
      <div className="absolute top-16 right-6 z-20 pointer-events-auto hidden xl:flex items-center gap-1.5 p-1 rounded-2xl bg-[#1C1C1E]/80 backdrop-blur-md border border-white/10 text-[11px] font-bold text-zinc-300 shadow-xl">
        <span className="px-2 text-zinc-500">نماذج:</span>
        <button
          type="button"
          onClick={() => handleApplyPreset('rect')}
          className="px-2.5 py-1 rounded-xl hover:bg-white/10 transition active:scale-95"
        >
          مستطيل 6×5
        </button>
        <button
          type="button"
          onClick={() => handleApplyPreset('l_shape')}
          className="px-2.5 py-1 rounded-xl hover:bg-white/10 transition active:scale-95"
        >
          شكل L
        </button>
        <button
          type="button"
          onClick={() => handleApplyPreset('u_shape')}
          className="px-2.5 py-1 rounded-xl hover:bg-white/10 transition active:scale-95"
        >
          شكل U
        </button>
        <button
          type="button"
          onClick={() => handleApplyPreset('island')}
          className="px-2.5 py-1 rounded-xl hover:bg-white/10 transition active:scale-95"
        >
          مع جزيرة
        </button>
      </div>

      {/* ----------------------------------------------------------------- */}
      {/* 3. DYNAMIC SUB-BAR CONTAINER (Stacked vertically, never overlapping) */}
      {/* ----------------------------------------------------------------- */}
      <div className="absolute top-16 inset-x-0 z-30 pointer-events-none flex flex-col items-center gap-2 px-4">
        {/* Toast Feedback Notification */}
        {feedbackMessage && (
          <div className="pointer-events-auto px-4 py-2 bg-blue-600 text-white text-xs font-bold rounded-xl shadow-2xl animate-in fade-in border border-blue-400">
            {feedbackMessage}
          </div>
        )}

        {/* Live Drag & Drop Wall Instructional Banner */}
        {activeTool === 'draw_wall' && (
          <div className="pointer-events-auto flex items-center gap-3 px-4 py-2 rounded-2xl bg-[#1C1C1E]/95 backdrop-blur-md border border-purple-500/50 shadow-2xl text-xs font-bold text-white animate-in fade-in slide-in-from-top-2">
            <div className="flex items-center gap-1.5 text-purple-300 font-bold border-l border-white/10 pl-2">
              <PenTool className="w-4 h-4 text-purple-400 animate-pulse" />
              <span>وضع رسم الجدار بالسحب:</span>
            </div>
            <span className="text-zinc-200">
              {wallStartMm ? 'اسحب إلى نقطة النهاية، ثم ارفع يدك لإتمام رسم الجدار' : 'انقر واسحب بالفأرة أو بإصبعك على المخطط لتحديد طول وزاوية الجدار، ثم أفلت للإضافة'}
            </span>
            <button
              type="button"
              onClick={() => {
                setActiveTool('select');
                setWallStartMm(null);
                setIsDraggingWall(false);
              }}
              className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-zinc-300 hover:text-white transition text-[11px]"
            >
              إلغاء
            </button>
          </div>
        )}

        {/* Freehand Tool Floating Options Bar */}
        {activeTool === 'freehand' && (
          <div className="pointer-events-auto flex items-center gap-3 px-4 py-2 rounded-2xl bg-[#1C1C1E]/95 backdrop-blur-md border border-amber-500/40 shadow-2xl text-xs font-bold text-white animate-in fade-in slide-in-from-top-2 flex-wrap justify-center">
            <div className="flex items-center gap-1.5 text-amber-400 font-bold border-l border-white/10 pl-2">
              <Pencil className="w-3.5 h-3.5" />
              <span>قلم الرسم الحر</span>
            </div>

            {/* Color Choices */}
            <div className="flex items-center gap-1.5">
              {[
                { color: '#ef4444', label: 'أحمر' },
                { color: '#3b82f6', label: 'أزرق' },
                { color: '#10b981', label: 'أخضر' },
                { color: '#f59e0b', label: 'برتقالي' },
                { color: '#ffffff', label: 'أبيض' },
              ].map((c) => (
                <button
                  key={c.color}
                  type="button"
                  onClick={() => setFreehandColor(c.color)}
                  style={{ backgroundColor: c.color }}
                  className={`w-5 h-5 rounded-full border transition active:scale-90 ${
                    freehandColor === c.color ? 'ring-2 ring-white scale-110 border-black' : 'border-white/30 opacity-70 hover:opacity-100'
                  }`}
                  title={c.label}
                />
              ))}
            </div>

            <div className="w-px h-4 bg-white/15" />

            {/* Stroke Width */}
            <div className="flex items-center gap-1 bg-black/40 p-0.5 rounded-lg border border-white/10 text-[11px]">
              <button
                type="button"
                onClick={() => setFreehandStrokeWidth(15)}
                className={`px-2 py-0.5 rounded transition ${freehandStrokeWidth === 15 ? 'bg-amber-600 text-white' : 'text-zinc-400 hover:text-white'}`}
              >
                رفيع
              </button>
              <button
                type="button"
                onClick={() => setFreehandStrokeWidth(30)}
                className={`px-2 py-0.5 rounded transition ${freehandStrokeWidth === 30 ? 'bg-amber-600 text-white' : 'text-zinc-400 hover:text-white'}`}
              >
                متوسط
              </button>
              <button
                type="button"
                onClick={() => setFreehandStrokeWidth(60)}
                className={`px-2 py-0.5 rounded transition ${freehandStrokeWidth === 60 ? 'bg-amber-600 text-white' : 'text-zinc-400 hover:text-white'}`}
              >
                عريض
              </button>
            </div>

            <div className="w-px h-4 bg-white/15" />

            {/* Undo Stroke */}
            <button
              type="button"
              disabled={freehandStrokes.length === 0}
              onClick={() => setFreehandStrokes((prev) => prev.slice(0, -1))}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 disabled:pointer-events-none text-zinc-300 hover:text-white transition active:scale-95"
              title="تراجع عن آخر خطوة رسم"
            >
              <Undo2 className="w-3.5 h-3.5" />
              <span>تراجع ({freehandStrokes.length})</span>
            </button>

            {/* Clear All Strokes */}
            {freehandStrokes.length > 0 && (
              <button
                type="button"
                onClick={() => setFreehandStrokes([])}
                className="flex items-center gap-1 px-2 py-1 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30 transition active:scale-95"
                title="مسح كل الرسومات اليدوية"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>مسح</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => setActiveTool('select')}
              className="p-1 rounded-lg hover:bg-white/10 text-zinc-400 hover:text-white transition"
              title="إنهاء وضع الرسم اليدوي"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* ----------------------------------------------------------------- */}
      {/* 4. MAIN BLUEPRINT CANVAS                                          */}
      {/* ----------------------------------------------------------------- */}
      <canvas
        ref={canvasRef}
        onMouseDown={handleCanvasMouseDown}
        onMouseMove={handleCanvasMouseMove}
        onMouseUp={handleCanvasMouseUp}
        onTouchStart={handleCanvasTouchStart}
        onTouchMove={handleCanvasTouchMove}
        onTouchEnd={handleCanvasTouchEnd}
        onWheel={handleCanvasWheel}
        onContextMenu={(e) => e.preventDefault()}
        className={`w-full h-full touch-none ${
          isDraggingOpening || isDraggingUnit || isDraggingWall
            ? 'cursor-grabbing'
            : hoveredOpeningId
            ? 'cursor-grab'
            : activeTool === 'draw_wall'
            ? 'cursor-crosshair'
            : activeTool === 'freehand'
            ? 'cursor-crosshair'
            : isPanning
            ? 'cursor-grab'
            : 'cursor-default'
        }`}
      />

      {/* ----------------------------------------------------------------- */}
      {/* 5. FLOATING BOTTOM BAR FOR SELECTED ITEM (Unit or Wall)           */}
      {/* ----------------------------------------------------------------- */}
      {(selectedUnit || selectedWall) && (
        <div className="absolute bottom-5 inset-x-0 z-40 flex justify-center pointer-events-none px-3">
          <div className="pointer-events-auto bg-[#18181B]/95 backdrop-blur-xl rounded-2xl shadow-2xl border border-white/15 p-2.5 flex flex-col md:flex-row items-center gap-2.5 text-xs text-white animate-in fade-in slide-in-from-bottom-3 max-w-full overflow-x-auto no-scrollbar">
            {/* 1. Unit Info & Dimensions Badge (تفاصيل الوحدة) */}
            <div className="flex items-center justify-between w-full md:w-auto gap-2.5 px-2 py-1 rounded-xl bg-white/5 border border-white/10 shrink-0">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse" />
                <div className="flex flex-col text-right">
                  <span className="font-bold text-zinc-100 text-xs">
                    {selectedWall ? selectedWall.nameAr : selectedUnit?.nameAr || selectedUnit?.name || 'خزانة'}
                  </span>
                  <span className="text-zinc-400 font-mono text-[10px]">
                    {selectedWall
                      ? `${(selectedWall.length / 1000).toFixed(2)}م`
                      : `${((selectedUnit?.width || 0) / 10).toFixed(0)} × ${((selectedUnit?.depth || 0) / 10).toFixed(0)} سم`}
                  </span>
                </div>
              </div>

              {/* Close / Deselect for Mobile */}
              <button
                type="button"
                onClick={() => {
                  onSelectUnit?.(null);
                  onSelectCustomWall?.(null);
                }}
                className="p-1 rounded-lg hover:bg-white/10 text-zinc-400 hover:text-white transition md:hidden"
                title="إلغاء التحديد"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Separator */}
            <div className="hidden md:block w-px h-7 bg-white/15 shrink-0" />

            {/* 2. Position Movement Controls (أزرار التحكم بمكان الوحدة) */}
            <div className="flex items-center gap-1.5 px-2 py-1 rounded-xl bg-white/5 border border-white/10 shrink-0">
              <span className="text-[11px] font-bold text-amber-400 ml-1 select-none">تحريك:</span>
              <button
                type="button"
                onClick={() => handleNudgeUnit(0, -100)}
                className="w-7 h-7 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-white font-black text-xs flex items-center justify-center transition active:scale-90 border border-white/10"
                title="تحريك لأعلى 10 سم"
              >
                ↑
              </button>
              <button
                type="button"
                onClick={() => handleNudgeUnit(0, 100)}
                className="w-7 h-7 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-white font-black text-xs flex items-center justify-center transition active:scale-90 border border-white/10"
                title="تحريك لأسفل 10 سم"
              >
                ↓
              </button>
              <button
                type="button"
                onClick={() => handleNudgeUnit(-100, 0)}
                className="w-7 h-7 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-white font-black text-xs flex items-center justify-center transition active:scale-90 border border-white/10"
                title="تحريك لليسار 10 سم"
              >
                ←
              </button>
              <button
                type="button"
                onClick={() => handleNudgeUnit(100, 0)}
                className="w-7 h-7 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-white font-black text-xs flex items-center justify-center transition active:scale-90 border border-white/10"
                title="تحريك لليمين 10 سم"
              >
                →
              </button>
            </div>

            {/* Separator */}
            <div className="hidden md:block w-px h-7 bg-white/15 shrink-0" />

            {/* 3. Action Buttons (تدوير، خصائص، نسخ، حذف) */}
            <div className="flex items-center gap-1.5 shrink-0">
              {/* Rotate Button */}
              <button
                type="button"
                onClick={handleRotateUnit}
                className="px-2.5 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold flex items-center gap-1 transition active:scale-95 border border-white/10"
                title="تدوير 90 درجة"
              >
                <RotateCw className="w-3.5 h-3.5 text-purple-400" />
                <span>تدوير</span>
              </button>

              {/* Door Toggle Button for Selected Unit */}
              {selectedUnit && (
                <button
                  type="button"
                  onClick={() => {
                    if (onToggleDoors) onToggleDoors();
                  }}
                  className="px-2.5 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-bold flex items-center gap-1 transition active:scale-95 border border-amber-500/30"
                  title="فتح وإغلاق أبواب الوحدة"
                >
                  <DoorOpen className="w-3.5 h-3.5 text-amber-400" />
                  <span>فتح/إغلاق</span>
                </button>
              )}

              {/* Snap and Merge Right / Left with Continuous Countertop */}
              {selectedUnit && onSnapAndMergeUnit && (
                <div className="flex items-center gap-1 bg-indigo-950/60 p-1 rounded-xl border border-indigo-500/30">
                  <button
                    type="button"
                    onClick={() => onSnapAndMergeUnit('right', selectedUnit.id)}
                    className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold flex items-center gap-1 text-xs transition active:scale-95 shadow-sm"
                    title="دمج بالوحدة المجاورة يميناً وتوحيد سطح الرخام كسطح واحد متصل بدون فواصل"
                  >
                    <span>دمج يمين</span>
                    <span>👉</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onSnapAndMergeUnit('left', selectedUnit.id)}
                    className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold flex items-center gap-1 text-xs transition active:scale-95 shadow-sm"
                    title="دمج بالوحدة المجاورة يساراً وتوحيد سطح الرخام كسطح واحد متصل بدون فواصل"
                  >
                    <span>👈</span>
                    <span>دمج يسار</span>
                  </button>
                </div>
              )}

              {/* Unit Properties Button */}
              {selectedUnit && onOpenProperties && (
                <button
                  type="button"
                  onClick={onOpenProperties}
                  className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold flex items-center gap-1.5 shadow-md shadow-blue-900/50 transition active:scale-95"
                  title="تعديل خصائص وأبعاد وخامات وأجهزة الخزانة"
                >
                  <Sliders className="w-3.5 h-3.5" />
                  <span>الخصائص</span>
                </button>
              )}

              {/* Duplicate */}
              {selectedUnit && onDuplicateUnit && (
                <button
                  type="button"
                  onClick={() => onDuplicateUnit(selectedUnit)}
                  className="p-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-emerald-400 transition active:scale-95 border border-white/10"
                  title="نسخ القطعة"
                >
                  <Copy className="w-4 h-4" />
                </button>
              )}

              {/* Delete */}
              <button
                type="button"
                onClick={() => {
                  if (selectedWall) {
                    onUpdateRoom({
                      ...room,
                      customWalls: customWalls.filter((w) => w.id !== selectedWall.id),
                    });
                    onSelectCustomWall?.(null);
                  } else if (selectedUnit && onDeleteUnit) {
                    onDeleteUnit(selectedUnit.id);
                    onSelectUnit?.(null);
                  }
                }}
                className="p-1.5 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-400 transition active:scale-95 border border-red-500/30"
                title="حذف"
              >
                <Trash2 className="w-4 h-4" />
              </button>

              {/* Close / Deselect for Desktop */}
              <button
                type="button"
                onClick={() => {
                  onSelectUnit?.(null);
                  onSelectCustomWall?.(null);
                }}
                className="hidden md:flex p-1.5 rounded-xl hover:bg-white/10 text-zinc-400 hover:text-white transition"
                title="إلغاء التحديد"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ----------------------------------------------------------------- */}
      {/* 6. FLOATING CONTROL CARD FOR SELECTED OPENING (Door / Window)     */}
      {/* ----------------------------------------------------------------- */}
      {selectedOpening && (
        <div className="absolute bottom-6 inset-x-0 z-40 flex justify-center pointer-events-none px-4">
          <div className="pointer-events-auto bg-zinc-900/95 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/15 p-4 flex flex-col gap-3 text-xs text-white max-w-lg w-full animate-in fade-in slide-in-from-bottom-4">
            {/* Header: Title and Delete/Close */}
            <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
              <div className="flex items-center gap-2">
                <span
                  className={`w-3 h-3 rounded-full ${
                    selectedOpening.type === 'door' ? 'bg-amber-400' : 'bg-cyan-400'
                  }`}
                />
                <span className="font-bold text-sm">
                  {selectedOpening.type === 'door' ? '🚪 إعدادات وموقع الباب' : '🪟 إعدادات وموقع النافذة'}
                </span>
                <span className="text-zinc-400 text-[11px] font-mono">
                  ({(getOpeningDist(selectedOpening, roomWidth, roomLength) / 1000).toFixed(2)}م على الجدار)
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    onUpdateRoom({
                      ...room,
                      openings: openings.filter((o) => o.id !== selectedOpening.id),
                    });
                    setSelectedOpeningId(null);
                    showFeedback('تم حذف الفتحة من الجدار');
                  }}
                  className="px-2.5 py-1 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30 flex items-center gap-1 transition active:scale-95 text-xs font-bold"
                  title="حذف الفتحة من الجدار"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>حذف</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedOpeningId(null)}
                  className="p-1 rounded-xl hover:bg-white/10 text-zinc-400 hover:text-white transition"
                  title="إغلاق"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Tip banner for drag and drop */}
            <div className="flex items-center gap-2 px-3 py-2 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-[11px] leading-tight">
              <span className="text-sm shrink-0">💡</span>
              <span>
                <strong>طريقة التحكم بالسحب:</strong> اضغط مع الاستمرار على{' '}
                {selectedOpening.type === 'door' ? 'الباب' : 'النافذة'} واسحبها مباشرة بالماوس أو إصبعك لأي مكان على أي جدار وسيلتصق بسلاسة، أو استعن بالأدوات أدناه.
              </span>
            </div>

            {/* Wall Selector: North (خلفي) | East (أيمن) | South (أمامي) | West (أيسر) */}
            <div className="flex flex-col gap-1.5">
              <span className="text-zinc-400 text-[11px] font-medium">الجدار المثبت عليه الفتحة:</span>
              <div className="grid grid-cols-4 gap-1.5 text-xs">
                {[
                  { idx: 0, label: 'خلفي (شمال)', wall: 'north' },
                  { idx: 1, label: 'أيمن (شرق)', wall: 'east' },
                  { idx: 2, label: 'أمامي (جنوب)', wall: 'south' },
                  { idx: 3, label: 'أيسر (غرب)', wall: 'west' },
                ].map((w) => {
                  const currIdx = getOpeningWallIndex(selectedOpening);
                  const isCurrent = currIdx === w.idx;
                  return (
                    <button
                      key={w.idx}
                      type="button"
                      onClick={() => {
                        const targetLen = w.idx === 0 || w.idx === 2 ? roomWidth : roomLength;
                        const opW = selectedOpening.width || (selectedOpening.type === 'door' ? 900 : 1200);
                        const newDist = Math.max(50, Math.round((targetLen - opW) / 2));
                        const updated = openings.map((o) =>
                          o.id === selectedOpening.id
                            ? {
                                ...o,
                                wallIndex: w.idx,
                                wall: w.wall as 'north' | 'east' | 'south' | 'west',
                                distanceFromStart: newDist,
                                position: newDist,
                              }
                            : o
                        );
                        onUpdateRoom({ ...room, openings: updated }, true);
                        showFeedback(`تم نقل ${selectedOpening.type === 'door' ? 'الباب' : 'النافذة'} إلى الجدار ال${w.label}`);
                      }}
                      className={`py-1.5 px-2 rounded-xl font-bold transition text-center ${
                        isCurrent
                          ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                          : 'bg-white/5 hover:bg-white/10 text-zinc-300'
                      }`}
                    >
                      {w.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Position Slider & Quick Alignment on Wall */}
            {(() => {
              const geom = getOpeningGeometry(selectedOpening, roomWidth, roomLength);
              const wallLen = geom.wallLength;
              const opW = geom.width;
              const currentDist = geom.startDist;
              const minAllowed = 50;
              const maxAllowed = Math.max(minAllowed, wallLen - opW - 50);
              const isCentered = Math.abs(currentDist - Math.round((wallLen - opW) / 2)) < 20;

              return (
                <div className="flex flex-col gap-2 bg-black/30 p-2.5 rounded-2xl border border-white/5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-zinc-300 font-bold">الموقع على طول الجدار:</span>
                    <span className="font-mono text-blue-400 font-bold">
                      {currentDist} ملم ({((currentDist) / 1000).toFixed(2)} متر)
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => {
                        const nextDist = Math.max(minAllowed, currentDist - 100);
                        const updated = openings.map((o) =>
                          o.id === selectedOpening.id
                            ? { ...o, distanceFromStart: nextDist, position: nextDist }
                            : o
                        );
                        onUpdateRoom({ ...room, openings: updated }, true);
                      }}
                      className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 font-bold flex items-center justify-center transition active:scale-95"
                      title="تحريك 10 سم للخلف"
                    >
                      -
                    </button>
                    <input
                      type="range"
                      min={minAllowed}
                      max={maxAllowed}
                      step={50}
                      value={currentDist}
                      onChange={(e) => {
                        const val = Number(e.target.value);
                        const updated = openings.map((o) =>
                          o.id === selectedOpening.id
                            ? { ...o, distanceFromStart: val, position: val }
                            : o
                        );
                        onUpdateRoom({ ...room, openings: updated }, false);
                      }}
                      onMouseUp={() => onUpdateRoom({ ...room, openings }, true)}
                      onTouchEnd={() => onUpdateRoom({ ...room, openings }, true)}
                      className="flex-1 accent-blue-500 cursor-pointer h-2 bg-white/10 rounded-lg appearance-none"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const nextDist = Math.min(maxAllowed, currentDist + 100);
                        const updated = openings.map((o) =>
                          o.id === selectedOpening.id
                            ? { ...o, distanceFromStart: nextDist, position: nextDist }
                            : o
                        );
                        onUpdateRoom({ ...room, openings: updated }, true);
                      }}
                      className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 font-bold flex items-center justify-center transition active:scale-95"
                      title="تحريك 10 سم للأمام"
                    >
                      +
                    </button>
                  </div>

                  {/* Quick Centering Button */}
                  <div className="flex items-center justify-between gap-2 pt-1 border-t border-white/5 text-[11px]">
                    <button
                      type="button"
                      onClick={() => {
                        const centerDist = Math.round((wallLen - opW) / 2);
                        const updated = openings.map((o) =>
                          o.id === selectedOpening.id
                            ? { ...o, distanceFromStart: centerDist, position: centerDist }
                            : o
                        );
                        onUpdateRoom({ ...room, openings: updated }, true);
                        showFeedback(`🎯 تم ضبط موقع ${selectedOpening.type === 'door' ? 'الباب' : 'النافذة'} في منتصف الجدار تماماً`);
                      }}
                      className={`flex-1 py-1 px-2.5 rounded-xl border font-bold flex items-center justify-center gap-1.5 transition active:scale-95 ${
                        isCentered
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                          : 'bg-white/5 hover:bg-white/10 text-zinc-300 border-white/10'
                      }`}
                    >
                      <span>🎯</span>
                      <span>{isCentered ? 'في منتصف الجدار تماماً' : 'توسيط في منتصف الجدار'}</span>
                    </button>
                  </div>
                </div>
              );
            })()}

            {/* Width and Height controls */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="flex items-center justify-between bg-black/30 p-2 rounded-xl border border-white/5">
                <span className="text-zinc-400">العرض:</span>
                <div className="flex items-center gap-1.5 font-mono">
                  <button
                    type="button"
                    onClick={() => {
                      const newW = Math.max(600, (selectedOpening.width || 900) - 100);
                      const updated = openings.map((o) =>
                        o.id === selectedOpening.id ? { ...o, width: newW } : o
                      );
                      onUpdateRoom({ ...room, openings: updated });
                    }}
                    className="w-6 h-6 rounded bg-white/10 hover:bg-white/20 flex items-center justify-center font-bold"
                  >
                    -
                  </button>
                  <span className="font-bold text-white px-1">
                    {selectedOpening.width || (selectedOpening.type === 'door' ? 900 : 1200)}ملم
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      const newW = Math.min(2600, (selectedOpening.width || 900) + 100);
                      const updated = openings.map((o) =>
                        o.id === selectedOpening.id ? { ...o, width: newW } : o
                      );
                      onUpdateRoom({ ...room, openings: updated });
                    }}
                    className="w-6 h-6 rounded bg-white/10 hover:bg-white/20 flex items-center justify-center font-bold"
                  >
                    +
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between bg-black/30 p-2 rounded-xl border border-white/5">
                <span className="text-zinc-400">الارتفاع:</span>
                <div className="flex items-center gap-1.5 font-mono">
                  <button
                    type="button"
                    onClick={() => {
                      const newH = Math.max(600, (selectedOpening.height || 2100) - 100);
                      const updated = openings.map((o) =>
                        o.id === selectedOpening.id ? { ...o, height: newH } : o
                      );
                      onUpdateRoom({ ...room, openings: updated });
                    }}
                    className="w-6 h-6 rounded bg-white/10 hover:bg-white/20 flex items-center justify-center font-bold"
                  >
                    -
                  </button>
                  <span className="font-bold text-white px-1">
                    {selectedOpening.height || (selectedOpening.type === 'door' ? 2100 : 1200)}ملم
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      const newH = Math.min(2800, (selectedOpening.height || 2100) + 100);
                      const updated = openings.map((o) =>
                        o.id === selectedOpening.id ? { ...o, height: newH } : o
                      );
                      onUpdateRoom({ ...room, openings: updated });
                    }}
                    className="w-6 h-6 rounded bg-white/10 hover:bg-white/20 flex items-center justify-center font-bold"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
