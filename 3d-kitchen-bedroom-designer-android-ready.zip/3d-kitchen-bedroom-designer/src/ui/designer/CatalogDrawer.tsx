import React, { useState } from 'react';
import { CatalogItemTemplate, CabinetCategory } from '../../types';
import { CATALOG_TEMPLATES } from '../../domain/catalog/unitsCatalog';
import { UnitShapePreview } from './UnitShapePreview';
import { X, Search, Plus, Sparkles, Filter, Check, Box } from 'lucide-react';

interface CatalogDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTemplate: (template: CatalogItemTemplate) => void;
}

type TabType = 'all' | 'kitchen_base' | 'kitchen_wall' | 'kitchen_tall' | 'bedroom_wardrobe' | 'bedroom_other';

export const CatalogDrawer: React.FC<CatalogDrawerProps> = ({
  isOpen,
  onClose,
  onSelectTemplate,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('all');
  const [searchQuery, setSearchQuery] = useState('');

  if (!isOpen) return null;

  const filteredTemplates = CATALOG_TEMPLATES.filter((item) => {
    const matchesSearch =
      item.nameAr.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.descriptionAr.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (activeTab === 'all') return true;
    if (activeTab === 'kitchen_base') return item.category === 'kitchen_base' || item.category === 'kitchen_corner';
    if (activeTab === 'kitchen_wall') return item.category === 'kitchen_wall';
    if (activeTab === 'kitchen_tall') return item.category === 'kitchen_tall';
    if (activeTab === 'bedroom_wardrobe') return item.category === 'bedroom_wardrobe';
    if (activeTab === 'bedroom_other')
      return (
        item.category === 'bedroom_drawer' ||
        item.category === 'bedroom_nightstand' ||
        item.category === 'bedroom_dressing' ||
        item.category === 'bedroom_bed' ||
        item.category === 'bedroom_shelves'
      );

    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex justify-start bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-[#1E1E1E] border-l border-[#333333] shadow-2xl flex flex-col h-full animate-in slide-in-from-left duration-300">
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-[#333333] flex items-center justify-between bg-[#252525]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded bg-blue-600/15 text-blue-400 border border-blue-500/30 flex items-center justify-center">
              <Box className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white tracking-wide">مكتبة الوحدات (Units Catalog)</h2>
              <p className="text-[11px] text-gray-400">اختر وحدة لإدراجها مباشرة في المشهد 3D</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-white rounded hover:bg-[#333333] transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search & Tabs */}
        <div className="p-3.5 border-b border-[#333333] space-y-2.5 bg-[#181818]">
          {/* Search bar */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-gray-500 absolute right-3 top-2.5" />
            <input
              type="text"
              placeholder="ابحث عن وحدة (حوض، فرن، دولاب، درج...)"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#121212] border border-[#383838] rounded-lg pr-9 pl-3 py-1.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition font-sans"
            />
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto pb-0.5 scrollbar-none text-[11px]">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-2.5 py-1 rounded font-semibold whitespace-nowrap transition ${
                activeTab === 'all'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-[#252525] text-gray-400 hover:bg-[#2e2e2e] hover:text-gray-200 border border-[#333333]'
              }`}
            >
              الكل ({CATALOG_TEMPLATES.length})
            </button>
            <button
              onClick={() => setActiveTab('kitchen_base')}
              className={`px-2.5 py-1 rounded font-semibold whitespace-nowrap transition ${
                activeTab === 'kitchen_base'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-[#252525] text-gray-400 hover:bg-[#2e2e2e] hover:text-gray-200 border border-[#333333]'
              }`}
            >
              مطابخ سفلية
            </button>
            <button
              onClick={() => setActiveTab('kitchen_wall')}
              className={`px-2.5 py-1 rounded font-semibold whitespace-nowrap transition ${
                activeTab === 'kitchen_wall'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-[#252525] text-gray-400 hover:bg-[#2e2e2e] hover:text-gray-200 border border-[#333333]'
              }`}
            >
              مطابخ جدارية
            </button>
            <button
              onClick={() => setActiveTab('kitchen_tall')}
              className={`px-2.5 py-1 rounded font-semibold whitespace-nowrap transition ${
                activeTab === 'kitchen_tall'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-[#252525] text-gray-400 hover:bg-[#2e2e2e] hover:text-gray-200 border border-[#333333]'
              }`}
            >
              أعمدة وخزائن طويلة
            </button>
            <button
              onClick={() => setActiveTab('bedroom_wardrobe')}
              className={`px-2.5 py-1 rounded font-semibold whitespace-nowrap transition ${
                activeTab === 'bedroom_wardrobe'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-[#252525] text-gray-400 hover:bg-[#2e2e2e] hover:text-gray-200 border border-[#333333]'
              }`}
            >
              دواليب غرف النوم
            </button>
            <button
              onClick={() => setActiveTab('bedroom_other')}
              className={`px-2.5 py-1 rounded font-semibold whitespace-nowrap transition ${
                activeTab === 'bedroom_other'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-[#252525] text-gray-400 hover:bg-[#2e2e2e] hover:text-gray-200 border border-[#333333]'
              }`}
            >
              تسريحات وكومودينو
            </button>
          </div>
        </div>

        {/* Units Grid List */}
        <div className="p-3.5 overflow-y-auto space-y-2.5 flex-1">
          {filteredTemplates.length > 0 ? (
            filteredTemplates.map((item) => (
              <div
                key={item.templateId}
                className="group p-3 bg-[#121212] hover:bg-[#181818] border border-[#333333] hover:border-blue-500/60 rounded-xl transition duration-150 flex flex-col gap-2 shadow-sm"
              >
                <div className="flex items-start gap-3">
                  {/* Unit Shape Preview */}
                  <div className="w-14 h-14 rounded-lg bg-[#1F1F1F] border border-[#333] p-1 flex items-center justify-center shrink-0 group-hover:border-blue-500/40 transition">
                    <UnitShapePreview template={item} className="w-12 h-12" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-white text-xs group-hover:text-blue-400 transition truncate">
                        {item.nameAr}
                      </h4>
                      {item.badge && (
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-600/20 text-blue-400 border border-blue-500/30 shrink-0">
                          {item.badge}
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-gray-400 block truncate font-sans">
                      {item.name}
                    </span>
                    <p className="text-[11px] text-gray-400 mt-0.5 line-clamp-2 leading-relaxed">
                      {item.descriptionAr}
                    </p>
                  </div>
                </div>

                {/* Default Dimensions Pill */}
                <div className="flex items-center justify-between pt-2 border-t border-[#252525] text-[11px]">
                  <div className="flex items-center gap-1.5 font-mono text-gray-400 text-[10px]">
                    <span className="bg-[#1E1E1E] px-1.5 py-0.5 rounded border border-[#333333]">
                      W:{item.defaultWidth}mm
                    </span>
                    <span className="bg-[#1E1E1E] px-1.5 py-0.5 rounded border border-[#333333]">
                      H:{item.defaultHeight}mm
                    </span>
                    <span className="bg-[#1E1E1E] px-1.5 py-0.5 rounded border border-[#333333]">
                      D:{item.defaultDepth}mm
                    </span>
                  </div>

                  <button
                    onClick={() => {
                      onSelectTemplate(item);
                      onClose();
                    }}
                    className="px-2.5 py-1 rounded bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs flex items-center gap-1 shadow transition"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    إضافة
                  </button>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-12 text-gray-500">
              <Box className="w-10 h-10 mx-auto mb-2 opacity-30" />
              <p className="text-xs">لم يتم العثور على وحدات مطابقة للبحث</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
