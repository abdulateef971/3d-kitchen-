import React, { useState, useEffect, useRef, useCallback } from 'react';
import { SceneManager } from '../../rendering/SceneManager';
import {
  X,
  Video,
  Square,
  DoorOpen,
  DoorClosed,
  Zap,
  Footprints,
  Compass,
  Volume2,
  VolumeX,
  RotateCcw,
  Maximize2,
  Sliders,
  Sparkles,
  ArrowLeftRight,
  Download,
  Play,
  Lightbulb,
} from 'lucide-react';
import { AnalogJoystick } from './AnalogJoystick';
import { gameAudio } from './GameAudio';

interface GameModeOverlayProps {
  sceneManager: SceneManager | null;
  onExitGameMode: () => void;
  projectName: string;
}

export const GameModeOverlay: React.FC<GameModeOverlayProps> = ({
  sceneManager,
  onExitGameMode,
  projectName,
}) => {
  // Movement & Camera State
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(1.2);
  const [isSprint, setIsSprint] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [isFlashlightOn, setIsFlashlightOn] = useState<boolean>(false);

  // Target interactable under crosshair
  const [targetedObject, setTargetedObject] = useState<{
    type: 'door' | 'drawer' | 'cabinet';
    unitId: string;
    unitName: string;
    doorIndex?: number;
    drawerIndex?: number;
    distanceMm: number;
  } | null>(null);

  // Video recording states
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordingTime, setRecordingTime] = useState<number>(0);
  const [recordedVideoUrl, setRecordedVideoUrl] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const recordingTimerRef = useRef<any>(null);

  // Controls Swapping (Left = Move, Right = Look OR swapped)
  const [isSwapped, setIsSwapped] = useState<boolean>(() => {
    try {
      return localStorage.getItem('rpz_game_swapped') === 'true';
    } catch {
      return false;
    }
  });

  // Pressed keys ref for smooth 60fps movement
  const keysPressedRef = useRef<{ [key: string]: boolean }>({});
  const animationFrameRef = useRef<number | null>(null);
  const lastFootstepTimeRef = useRef<number>(0);

  // Toggle Joysticks Layout
  const handleToggleSwap = () => {
    setIsSwapped((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('rpz_game_swapped', String(next));
      } catch (_) {}
      return next;
    });
  };

  // 1. Initial Scene Setup for Game Mode
  useEffect(() => {
    if (!sceneManager) return;
    // Enter Walk Mode with Collision Detection and Interact Mode enabled
    sceneManager.setWalkMode(true, true);
    sceneManager.setCameraCollision(true);
    sceneManager.setInteractMode(true);

    return () => {
      // Restore interact mode when exiting
      sceneManager?.setInteractMode(false);
    };
  }, [sceneManager]);

  // 2. Continuous Keyboard Movement Loop (WASD + Arrows)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Prevent browser scrolling on arrow keys or space
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) {
        e.preventDefault();
      }

      keysPressedRef.current[e.code] = true;

      // Interaction key E or F
      if (e.code === 'KeyE' || e.code === 'KeyF') {
        e.preventDefault();
        handleInteract();
      }

      // Toggle Run on Shift
      if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') {
        setIsSprint(true);
      }

      // Exit on Escape
      if (e.code === 'Escape') {
        onExitGameMode();
      }

      // Open/Close all on O / C
      if (e.code === 'KeyO') {
        handleOpenAllDoors();
      }
      if (e.code === 'KeyC') {
        handleCloseAllDoors();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keysPressedRef.current[e.code] = false;
      if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') {
        setIsSprint(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    // Continuous RAF movement loop
    let lastTime = performance.now();
    const updateLoop = () => {
      const now = performance.now();
      const delta = Math.min((now - lastTime) / 1000, 0.1);
      lastTime = now;

      const keys = keysPressedRef.current;
      let forward = 0;
      let right = 0;

      if (keys['KeyW'] || keys['ArrowUp']) forward += 1;
      if (keys['KeyS'] || keys['ArrowDown']) forward -= 1;
      if (keys['KeyA'] || keys['ArrowLeft']) right -= 1;
      if (keys['KeyD'] || keys['ArrowRight']) right += 1;

      if (forward !== 0 || right !== 0) {
        const sprintFactor = isSprint ? 2.0 : 1.0;
        const moveSpeed = 45 * speedMultiplier * sprintFactor;

        // Normalize diagonal
        const mag = Math.hypot(forward, right);
        if (mag > 0) {
          forward /= mag;
          right /= mag;
        }

        sceneManager?.walkContinuous(forward, right, moveSpeed);

        // Sound effect for footsteps every 380ms
        if (soundEnabled && now - lastFootstepTimeRef.current > (isSprint ? 260 : 380)) {
          gameAudio.playFootstep();
          lastFootstepTimeRef.current = now;
        }
      }

      // Check targeted object in crosshairs periodically
      if (sceneManager) {
        const targeted = sceneManager.getCenterTargetedInteractable();
        setTargetedObject(targeted);
      }

      animationFrameRef.current = requestAnimationFrame(updateLoop);
    };

    animationFrameRef.current = requestAnimationFrame(updateLoop);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, [sceneManager, speedMultiplier, isSprint, soundEnabled, onExitGameMode]);

  // 3. Interact Function (Open/Close Door or Drawer)
  const handleInteract = useCallback(() => {
    if (!sceneManager) return;
    const toggled = sceneManager.interactCenterOrNearest();
    if (toggled && soundEnabled) {
      gameAudio.playDoorToggle(true);
    }
  }, [sceneManager, soundEnabled]);

  // 4. Open All Doors & Drawers
  const handleOpenAllDoors = () => {
    if (!sceneManager) return;
    sceneManager.openAllDoorsAndDrawers();
    if (soundEnabled) gameAudio.playDoorToggle(true);
  };

  // 5. Close All Doors & Drawers
  const handleCloseAllDoors = () => {
    if (!sceneManager) return;
    sceneManager.closeAllDoorsAndDrawers();
    if (soundEnabled) gameAudio.playDoorToggle(false);
  };

  // 6. Video Recording Engine
  const startVideoRecording = () => {
    if (!sceneManager) return;
    try {
      const canvas = sceneManager.getCanvas();
      if (!canvas) {
        alert('تعذر الوصول إلى مشهد الكاميرا');
        return;
      }

      const stream = canvas.captureStream(30);
      recordedChunksRef.current = [];

      const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
        ? 'video/webm;codecs=vp9'
        : 'video/webm';

      const recorder = new MediaRecorder(stream, {
        mimeType,
        videoBitsPerSecond: 8000000, // 8 Mbps high quality
      });
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          recordedChunksRef.current.push(event.data);
        }
      };

      recorder.onstop = () => {
        const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
        const videoUrl = URL.createObjectURL(blob);
        setRecordedVideoUrl(videoUrl);
        setIsRecording(false);
        if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
      };

      recorder.start(200);
      setIsRecording(true);
      setRecordingTime(0);
      if (soundEnabled) gameAudio.playRecordBeep(true);

      recordingTimerRef.current = setInterval(() => {
        setRecordingTime((prev) => prev + 1);
      }, 1000);
    } catch (err) {
      console.error('Failed to start recording:', err);
      alert('المتصفح لا يدعم تسجيل الشاشة المباشر');
    }
  };

  const stopVideoRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      if (soundEnabled) gameAudio.playRecordBeep(false);
    }
    if (recordingTimerRef.current) {
      clearInterval(recordingTimerRef.current);
    }
  };

  // Format MM:SS
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div
      className="fixed inset-0 z-50 pointer-events-none select-none flex flex-col justify-between font-['Cairo',sans-serif]"
      dir="rtl"
    >
      {/* ========================================================================= */}
      {/* 1. TOP GAME HUD (Status, Recording, Project Info, Exit)                    */}
      {/* ========================================================================= */}
      <div className="p-3 sm:p-5 flex items-center justify-between w-full pointer-events-auto">
        {/* Right side: Exit Button & Project Name */}
        <div className="flex items-center gap-2 sm:gap-3 bg-[#111622]/90 backdrop-blur-md border border-[#2D3A50] px-3.5 py-2 rounded-2xl shadow-2xl">
          <button
            onClick={onExitGameMode}
            className="px-3 py-1.5 rounded-xl bg-red-600/30 hover:bg-red-600 text-red-300 hover:text-white border border-red-500/50 text-xs font-bold flex items-center gap-1.5 transition active:scale-95 shadow-md"
            title="الخروج من وضع اللعبة والعودة للوضع الهندسي CAD (Esc)"
          >
            <X className="w-4 h-4" />
            <span>خروج (Esc)</span>
          </button>

          <div className="h-5 w-[1px] bg-[#2A3547] hidden sm:block" />

          <div className="flex flex-col">
            <span className="text-xs font-bold text-white flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>{projectName}</span>
            </span>
            <span className="text-[10px] text-emerald-400 font-mono hidden sm:inline">
              🎮 وضع الاستكشاف والتجول التفاعلي كاللعبة
            </span>
          </div>
        </div>

        {/* Center: Live Video Recording Badge */}
        {isRecording && (
          <div className="bg-red-950/90 text-red-200 border border-red-500/80 px-4 py-2 rounded-full shadow-2xl backdrop-blur-md flex items-center gap-2.5 animate-pulse font-mono font-bold text-xs">
            <span className="w-3 h-3 rounded-full bg-red-500 shadow-[0_0_12px_rgba(239,68,68,0.8)]" />
            <span>تسجيل جاري {formatTime(recordingTime)}</span>
          </div>
        )}

        {/* Left side: Quick Video Recording, Sound, Lights */}
        <div className="flex items-center gap-2 bg-[#111622]/90 backdrop-blur-md border border-[#2D3A50] p-1.5 rounded-2xl shadow-2xl">
          {/* Record Video Button */}
          {!isRecording ? (
            <button
              onClick={startVideoRecording}
              className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold flex items-center gap-2 transition active:scale-95 shadow-lg shadow-red-900/40"
              title="بدء تسجيل فيديو عالي الدقة أثناء المشي والتفاعل"
            >
              <Video className="w-4 h-4 text-white" />
              <span className="hidden sm:inline">تسجيل فيديو 🎥</span>
            </button>
          ) : (
            <button
              onClick={stopVideoRecording}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-2 transition active:scale-95 shadow-lg shadow-emerald-900/40"
              title="إيقاف التسجيل وحفظ الفيديو"
            >
              <Square className="w-4 h-4 fill-white text-white" />
              <span>حفظ الفيديو ⏹</span>
            </button>
          )}

          {/* Sound Toggle */}
          <button
            onClick={() => setSoundEnabled((prev) => !prev)}
            className={`p-2 rounded-xl transition ${
              soundEnabled ? 'text-blue-300 hover:bg-blue-900/40' : 'text-gray-500 hover:bg-gray-800'
            }`}
            title={soundEnabled ? 'كتم المؤثرات الصوتية' : 'تفعيل المؤثرات الصوتية للأبواب والخطوات'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Swap Controls */}
          <button
            onClick={handleToggleSwap}
            className="p-2 rounded-xl text-amber-300 hover:bg-amber-950/40 transition"
            title="تبديل أماكن أزرار التحكم وعصي الأنالوج يميناً ويساراً ⇄"
          >
            <ArrowLeftRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. CENTER CROSSHAIR & DOOR INTERACTION PROMPT                            */}
      {/* ========================================================================= */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none flex flex-col items-center gap-3">
        {/* Modern FPS Dynamic Crosshair */}
        <div className="relative flex items-center justify-center">
          <div
            className={`w-3.5 h-3.5 rounded-full border-2 transition-all duration-200 ${
              targetedObject
                ? 'border-emerald-400 bg-emerald-400/40 scale-125 shadow-[0_0_15px_rgba(52,211,153,0.8)]'
                : 'border-white/70 bg-transparent'
            }`}
          />
          {/* Subtle crosshair hair lines */}
          <div className="absolute w-6 h-[1px] bg-white/40 pointer-events-none" />
          <div className="absolute h-6 w-[1px] bg-white/40 pointer-events-none" />
        </div>

        {/* Interactive Floating Prompt when aiming at a cabinet door */}
        {targetedObject && (
          <div
            onClick={(e) => {
              e.stopPropagation();
              handleInteract();
            }}
            className="pointer-events-auto cursor-pointer bg-[#0F141E]/95 backdrop-blur-xl border border-emerald-500/80 px-4 py-2 rounded-2xl shadow-2xl flex items-center gap-2.5 text-white animate-in zoom-in-95 duration-150 active:scale-95 hover:border-emerald-300"
          >
            <div className="w-7 h-7 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <DoorOpen className="w-4 h-4" />
            </div>
            <div className="flex flex-col text-right">
              <div className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
                <span className="bg-emerald-500 text-[#0F141E] px-1.5 py-0.2 rounded font-mono font-black text-[10px]">
                  E
                </span>
                <span>انقر أو اضغط [E] لفتح / إغلاق الباب</span>
              </div>
              <span className="text-[10px] text-gray-300 font-medium">
                {targetedObject.unitName} ({targetedObject.distanceMm} مم)
              </span>
            </div>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 3. BOTTOM GAME CONTROLS & DUAL ANALOG JOYSTICKS                          */}
      {/* ========================================================================= */}
      <div className="p-3 sm:p-5 w-full flex items-end justify-between pointer-events-auto">
        {/* Left Analog Pod: Movement (or Look if swapped) */}
        <div className="flex flex-col items-center gap-1.5">
          <div className="p-1 rounded-full bg-[#111622]/90 backdrop-blur-md border border-[#2D3A50] shadow-2xl">
            <AnalogJoystick
              size={88}
              stickSize={38}
              speedMultiplier={speedMultiplier * (isSprint ? 1.8 : 1.0)}
              theme={!isSwapped ? 'emerald' : 'blue'}
              label={!isSwapped ? 'المشي والحركة' : 'تدوير الرؤية'}
              activeLabel={!isSwapped ? '🚶 مشي...' : '🔄 تدوير...'}
              onMove={(normX, normY) => {
                if (!isSwapped) {
                  // Left stick = Move
                  const forward = -normY;
                  const right = normX;
                  const sprintFactor = isSprint ? 2.0 : 1.0;
                  sceneManager?.walkContinuous(forward, right, 35 * speedMultiplier * sprintFactor);
                } else {
                  // Swapped: Left stick = Look
                  sceneManager?.rotateCameraContinuous(normX, normY, 0.04 * speedMultiplier);
                }
              }}
              onStop={() => {}}
            />
          </div>
          <span className="text-[10px] font-bold text-gray-400 font-mono">
            {!isSwapped ? 'عصا المشي (Move)' : 'عصا الرؤية (Look)'}
          </span>
        </div>

        {/* Center Bottom: In-Game Action Bar (Open/Close Doors, Sprint, Help) */}
        <div className="flex flex-col items-center gap-2">
          {/* Quick Door Action Buttons */}
          <div className="flex items-center gap-1.5 sm:gap-2 bg-[#111622]/95 backdrop-blur-xl border border-[#2D3A50] p-1.5 rounded-2xl shadow-2xl">
            {/* Primary Action Button: Toggle Door */}
            <button
              onClick={handleInteract}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-emerald-950/50 transition active:scale-95"
              title="فتح أو إغلاق الباب الموجه إليه أو الأقرب إليك (مفتاح E)"
            >
              <DoorOpen className="w-4 h-4 text-emerald-200" />
              <span>فتح/إغلاق الباب [E]</span>
            </button>

            {/* Open All Doors */}
            <button
              onClick={handleOpenAllDoors}
              className="px-2.5 py-2 rounded-xl bg-[#1C2433] hover:bg-[#28354A] text-gray-200 text-xs font-bold flex items-center gap-1.5 transition active:scale-95"
              title="فتح كافة الأبواب والدواليب في المطبخ/الغرفة دفعة واحدة"
            >
              <DoorOpen className="w-3.5 h-3.5 text-blue-400" />
              <span className="hidden sm:inline">فتح الكل [O]</span>
            </button>

            {/* Close All Doors */}
            <button
              onClick={handleCloseAllDoors}
              className="px-2.5 py-2 rounded-xl bg-[#1C2433] hover:bg-[#28354A] text-gray-200 text-xs font-bold flex items-center gap-1.5 transition active:scale-95"
              title="إغلاق كافة الأبواب والدواليب دفعة واحدة"
            >
              <DoorClosed className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">إغلاق الكل [C]</span>
            </button>

            {/* Sprint Toggle */}
            <button
              onClick={() => setIsSprint((prev) => !prev)}
              className={`px-2.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition active:scale-95 ${
                isSprint
                  ? 'bg-amber-500 text-white font-black shadow-md shadow-amber-900/40'
                  : 'bg-[#1C2433] hover:bg-[#28354A] text-gray-300'
              }`}
              title="التبديل بين المشي الهادئ والركض السريع (Shift)"
            >
              <Footprints className="w-3.5 h-3.5" />
              <span>{isSprint ? 'ركض ⚡' : 'مشي 🚶'}</span>
            </button>
          </div>

          {/* Desktop Keyboard Helper Hints */}
          <div className="hidden md:flex items-center gap-3 text-[10px] text-gray-400 font-mono bg-black/40 px-3 py-1 rounded-full backdrop-blur-sm border border-white/10">
            <span>[W,A,S,D / الأسهم] للحركة</span>
            <span>•</span>
            <span>[Shift] للركض</span>
            <span>•</span>
            <span>[E / F] فتح الأبواب</span>
            <span>•</span>
            <span>[سحب الفأرة] للالتفاف 360°</span>
          </div>
        </div>

        {/* Right Analog Pod: Look Around (or Move if swapped) */}
        <div className="flex flex-col items-center gap-1.5">
          <div className="p-1 rounded-full bg-[#111622]/90 backdrop-blur-md border border-[#2D3A50] shadow-2xl">
            <AnalogJoystick
              size={88}
              stickSize={38}
              speedMultiplier={speedMultiplier}
              theme={isSwapped ? 'emerald' : 'blue'}
              label={isSwapped ? 'المشي والحركة' : 'تدوير الرؤية'}
              activeLabel={isSwapped ? '🚶 مشي...' : '🔄 تدوير...'}
              onMove={(normX, normY) => {
                if (isSwapped) {
                  // Swapped: Right stick = Move
                  const forward = -normY;
                  const right = normX;
                  const sprintFactor = isSprint ? 2.0 : 1.0;
                  sceneManager?.walkContinuous(forward, right, 35 * speedMultiplier * sprintFactor);
                } else {
                  // Right stick = Look (Yaw & Pitch)
                  sceneManager?.rotateCameraContinuous(normX, normY, 0.04 * speedMultiplier);
                }
              }}
              onStop={() => {}}
            />
          </div>
          <span className="text-[10px] font-bold text-gray-400 font-mono">
            {isSwapped ? 'عصا المشي (Move)' : 'عصا الرؤية (Look)'}
          </span>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 4. RECORDED VIDEO REVIEW & DOWNLOAD POPUP MODAL                          */}
      {/* ========================================================================= */}
      {recordedVideoUrl && (
        <div
          onPointerDown={(e) => e.stopPropagation()}
          onClick={(e) => e.stopPropagation()}
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 pointer-events-auto font-['Cairo',sans-serif]"
          dir="rtl"
        >
          <div className="bg-[#121620] border border-[#2B384E] rounded-3xl p-5 sm:p-6 w-full max-w-lg shadow-2xl flex flex-col gap-4 text-white animate-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-[#253043] pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-red-600/30 border border-red-500/50 flex items-center justify-center text-red-400">
                  <Video className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">فيديو جولة اللعبة المسجل</h3>
                  <span className="text-[10px] text-gray-400 font-mono">
                    تم التقاط الفيديو بنجاح بدقة عالية وسلاسة 30fps
                  </span>
                </div>
              </div>
              <button
                onClick={() => setRecordedVideoUrl(null)}
                className="p-1.5 rounded-xl hover:bg-gray-800 text-gray-400 hover:text-white transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Video Player */}
            <div className="relative rounded-2xl overflow-hidden bg-black aspect-video border border-[#232D3F] shadow-inner">
              <video
                src={recordedVideoUrl}
                controls
                autoPlay
                loop
                playsInline
                className="w-full h-full object-contain"
              />
            </div>

            {/* Action Buttons: Download & Close */}
            <div className="flex items-center justify-between gap-3 pt-2">
              <button
                onClick={() => setRecordedVideoUrl(null)}
                className="flex-1 py-2.5 rounded-xl bg-[#1C2536] hover:bg-[#253147] text-gray-300 hover:text-white font-bold text-xs transition"
              >
                متابعة اللعب والاستكشاف
              </button>

              <a
                href={recordedVideoUrl}
                download={`Walkthrough_${projectName.replace(/\s+/g, '_')}_${Date.now()}.webm`}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/60 transition active:scale-95"
              >
                <Download className="w-4 h-4" />
                <span>تحميل الفيديو (WebM)</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
