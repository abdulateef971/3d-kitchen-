import React from 'react';
import { LightingConfig } from '../../types';
import {
  X,
  Sun,
  Moon,
  Sunset,
  Lightbulb,
  Sparkles,
  Zap,
  Sliders,
  RotateCcw,
  Check,
  Flame,
  Snowflake,
  SunMedium,
  Monitor,
} from 'lucide-react';

interface LightingModalProps {
  isOpen: boolean;
  onClose: () => void;
  lighting: LightingConfig;
  onUpdateLighting: (lighting: LightingConfig) => void;
}

export const LightingModal: React.FC<LightingModalProps> = ({
  isOpen,
  onClose,
  lighting,
  onUpdateLighting,
}) => {
  if (!isOpen) return null;

  const handleApplyPreset = (preset: 'day' | 'golden_hour' | 'evening' | 'night' | 'studio') => {
    if (preset === 'day') {
      onUpdateLighting({
        ...lighting,
        presetMode: 'day',
        ambientEnabled: true,
        ambientIntensity: 0.85,
        ambientColor: '#ffffff',
        sunIntensity: 1.5,
        sunColor: '#fffdfa',
        ceilingSpotlights: true,
        ceilingIntensity: 0.4,
        ceilingSpotlightColor: '#fffbeb',
        underCabinetLed: false,
        underCabinetIntensity: 0.6,
        underCabinetLedColor: '#fef08a',
        cabinetInteriorLed: false,
        shadowsEnabled: true,
      });
    } else if (preset === 'golden_hour') {
      onUpdateLighting({
        ...lighting,
        presetMode: 'golden_hour',
        ambientEnabled: true,
        ambientIntensity: 0.65,
        ambientColor: '#fef3c7',
        sunIntensity: 1.4,
        sunColor: '#f59e0b',
        ceilingSpotlights: true,
        ceilingIntensity: 0.6,
        ceilingSpotlightColor: '#fed7aa',
        underCabinetLed: true,
        underCabinetIntensity: 0.9,
        underCabinetLedColor: '#fef08a',
        cabinetInteriorLed: true,
        cabinetInteriorIntensity: 0.7,
        cabinetInteriorLedColor: '#fed7aa',
        shadowsEnabled: true,
      });
    } else if (preset === 'evening') {
      onUpdateLighting({
        ...lighting,
        presetMode: 'evening',
        ambientEnabled: true,
        ambientIntensity: 0.45,
        ambientColor: '#cbd5e1',
        sunIntensity: 0.25,
        sunColor: '#94a3b8',
        ceilingSpotlights: true,
        ceilingIntensity: 0.85,
        ceilingSpotlightColor: '#fff7ed',
        underCabinetLed: true,
        underCabinetIntensity: 1.1,
        underCabinetLedColor: '#fef08a',
        cabinetInteriorLed: true,
        cabinetInteriorIntensity: 0.8,
        cabinetInteriorLedColor: '#fef3c7',
        shadowsEnabled: true,
      });
    } else if (preset === 'night') {
      onUpdateLighting({
        ...lighting,
        presetMode: 'night',
        ambientEnabled: true,
        ambientIntensity: 0.2,
        ambientColor: '#1e293b',
        sunIntensity: 0.08,
        sunColor: '#38bdf8', // Cool moonlight
        ceilingSpotlights: true,
        ceilingIntensity: 1.2,
        ceilingSpotlightColor: '#fff7ed',
        underCabinetLed: true,
        underCabinetIntensity: 1.4,
        underCabinetLedColor: '#fef08a',
        cabinetInteriorLed: true,
        cabinetInteriorIntensity: 1.0,
        cabinetInteriorLedColor: '#fef3c7',
        shadowsEnabled: true,
      });
    } else if (preset === 'studio') {
      onUpdateLighting({
        ...lighting,
        presetMode: 'studio',
        ambientEnabled: true,
        ambientIntensity: 0.75,
        ambientColor: '#ffffff',
        sunIntensity: 1.1,
        sunColor: '#ffffff',
        ceilingSpotlights: true,
        ceilingIntensity: 0.8,
        ceilingSpotlightColor: '#ffffff',
        underCabinetLed: true,
        underCabinetIntensity: 0.9,
        underCabinetLedColor: '#ffffff',
        cabinetInteriorLed: true,
        cabinetInteriorIntensity: 0.8,
        cabinetInteriorLedColor: '#ffffff',
        shadowsEnabled: true,
      });
    }
  };

  const handleToggle = (key: keyof LightingConfig) => {
    onUpdateLighting({
      ...lighting,
      [key]: !lighting[key],
    });
  };

  const handleSlider = (key: keyof LightingConfig, val: number) => {
    onUpdateLighting({
      ...lighting,
      [key]: val,
    });
  };

  const handleColor = (key: keyof LightingConfig, color: string) => {
    onUpdateLighting({
      ...lighting,
      [key]: color,
    });
  };

  const handleResetDefaults = () => {
    onUpdateLighting({
      ambientEnabled: true,
      ambientIntensity: 0.7,
      ambientColor: '#ffffff',
      sunIntensity: 1.2,
      sunColor: '#fffbeb',
      ceilingSpotlights: true,
      ceilingSpotlightColor: '#fff7ed',
      ceilingIntensity: 0.8,
      cabinetInteriorLed: true,
      cabinetInteriorLedColor: '#fef3c7',
      cabinetInteriorIntensity: 0.75,
      underCabinetLed: true,
      underCabinetLedColor: '#fef08a',
      underCabinetIntensity: 0.85,
      shadowsEnabled: true,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200 font-['Cairo',sans-serif]">
      <div className="relative w-full max-w-2xl bg-[#1E1E1E] border border-[#333333] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-[#333333] flex items-center justify-between bg-[#252525]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center shadow-inner">
              <Lightbulb className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white tracking-wide">
                نظام الإضاءة الشامل (3D Lighting Architecture)
              </h2>
              <p className="text-[11px] text-gray-400">
                التحكم بإضاءة الغرفة، السقف، الخزائن الداخلية، وأشرطة LED المودرن
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleResetDefaults}
              title="استعادة الإعدادات الافتراضية"
              className="p-1.5 px-2 rounded bg-[#333333] hover:bg-[#444444] text-gray-300 hover:text-white text-xs flex items-center gap-1 transition"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>افتراضي</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-gray-400 hover:text-white rounded hover:bg-[#333333] transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4 text-xs">
          {/* Day & Night Mood Simulation (محاكاة تأثير الإضاءة النهارية والليلية على الخامات) */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-zinc-900 to-[#18181b] border border-amber-500/30 shadow-lg space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <SunMedium className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-white text-xs block">
                    محاكاة أوقات اليوم على الخامات (Day & Night Simulation)
                  </span>
                  <span className="text-[10px] text-zinc-400">
                    تبديل فوري لتأثير أشعة الشمس والإنارة الداخلية على أسطح الخشب والرخام واللميع
                  </span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-1">
              {[
                {
                  id: 'day' as const,
                  label: 'نهار طبيعي',
                  desc: 'شمس ساطعة 100%',
                  icon: <Sun className="w-4 h-4 text-amber-400" />,
                  bg: 'from-amber-500/20 to-orange-500/10 border-amber-500/40 text-amber-200',
                },
                {
                  id: 'golden_hour' as const,
                  label: 'العصر الذهبي',
                  desc: 'غروب دافئ وظلال طويلة',
                  icon: <Sunset className="w-4 h-4 text-orange-400" />,
                  bg: 'from-orange-500/20 to-amber-600/10 border-orange-500/40 text-orange-200',
                },
                {
                  id: 'evening' as const,
                  label: 'مساء هادئ',
                  desc: 'شفق مسائي مع LED',
                  icon: <Lightbulb className="w-4 h-4 text-yellow-300" />,
                  bg: 'from-indigo-950/40 to-yellow-950/20 border-yellow-500/30 text-yellow-200',
                },
                {
                  id: 'night' as const,
                  label: 'إضاءة ليلية فاخرة',
                  desc: 'توهج سبوت لايت وLED',
                  icon: <Moon className="w-4 h-4 text-blue-400" />,
                  bg: 'from-blue-950/40 to-purple-950/30 border-blue-400/40 text-blue-200',
                },
                {
                  id: 'studio' as const,
                  label: 'استوديو محايد',
                  desc: 'إضاءة 5000K لفحص الخامة',
                  icon: <Monitor className="w-4 h-4 text-zinc-300" />,
                  bg: 'from-zinc-800 to-zinc-900 border-zinc-600 text-zinc-200',
                },
              ].map((item) => {
                const isActive = lighting.presetMode === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleApplyPreset(item.id)}
                    className={`p-2.5 rounded-xl border flex flex-col items-center text-center gap-1.5 transition-all active:scale-95 bg-gradient-to-b ${item.bg} ${
                      isActive
                        ? 'ring-2 ring-amber-400 border-amber-400 shadow-md shadow-amber-500/20'
                        : 'opacity-80 hover:opacity-100'
                    }`}
                  >
                    <div className="p-1 rounded-md bg-black/40">{item.icon}</div>
                    <span className="font-bold text-[11px] leading-tight">{item.label}</span>
                    <span className="text-[9px] opacity-75">{item.desc}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 1. Under-Cabinet LED Strip Light (شريط LED أسفل الخزائن العلوية) */}
          <div className="p-4 rounded-xl bg-[#141414] border border-[#333333] space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-white block text-xs">
                    شريط LED أسفل الخزائن (Under-Cabinet LED)
                  </span>
                  <span className="text-[10px] text-gray-400">
                    إنارة خطية موجهة تسقط على أسطح الرخام والباكسبلاش
                  </span>
                </div>
              </div>
              <button
                onClick={() => handleToggle('underCabinetLed')}
                className={`px-3 py-1 rounded-full text-xs font-bold transition flex items-center gap-1.5 ${
                  lighting.underCabinetLed
                    ? 'bg-amber-500 text-black shadow-md shadow-amber-500/30'
                    : 'bg-[#2A2A2A] text-gray-400 hover:text-white'
                }`}
              >
                {lighting.underCabinetLed ? <Check className="w-3 h-3 stroke-[3]" /> : null}
                {lighting.underCabinetLed ? 'مفعل' : 'معطل'}
              </button>
            </div>

            {lighting.underCabinetLed && (
              <div className="space-y-3 pt-2 border-t border-[#252525]">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-gray-400">شدة إضاءة الشريط (Intensity):</span>
                  <span className="font-mono text-amber-400 font-bold">
                    {Math.round((lighting.underCabinetIntensity || 0.85) * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="2.0"
                  step="0.05"
                  value={lighting.underCabinetIntensity ?? 0.85}
                  onChange={(e) => handleSlider('underCabinetIntensity', parseFloat(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer h-1.5 bg-[#2A2A2A] rounded-lg"
                />

                {/* Color Temperature Presets */}
                <div className="space-y-1.5 pt-1">
                  <span className="text-gray-400 block text-[11px]">حرارة ولون الإضاءة (Light Color Temp):</span>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                    {[
                      { name: 'أصفر دافئ (3000K)', color: '#fef08a', icon: Flame },
                      { name: 'أبيض طبيعي (4000K)', color: '#fef9c3', icon: SunMedium },
                      { name: 'ناصع نهاري (6000K)', color: '#ffffff', icon: Snowflake },
                      { name: 'نيون سماوي مودرن', color: '#a5f3fc', icon: Zap },
                    ].map((preset) => {
                      const IconComp = preset.icon;
                      const isSel = lighting.underCabinetLedColor === preset.color;
                      return (
                        <button
                          key={preset.color}
                          onClick={() => handleColor('underCabinetLedColor', preset.color)}
                          className={`p-2 rounded-lg text-[10px] font-bold flex items-center gap-1.5 border transition ${
                            isSel
                              ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                              : 'bg-[#1C1C1C] border-[#333] text-gray-400 hover:text-white'
                          }`}
                        >
                          <span
                            className="w-3 h-3 rounded-full border border-black/40 shadow-sm"
                            style={{ backgroundColor: preset.color }}
                          />
                          <span>{preset.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* 2. Cabinet Interior LED Lights (إضاءة الخزائن الداخلية) */}
          <div className="p-4 rounded-xl bg-[#141414] border border-[#333333] space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded bg-blue-500/20 text-blue-400 flex items-center justify-center">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-white block text-xs">
                    إضاءة الخزائن الداخلية (Cabinet Interior LED)
                  </span>
                  <span className="text-[10px] text-gray-400">
                    توهج داخلي للأرفف الزجاجية، دواليب الملابس، ووحدات العرض
                  </span>
                </div>
              </div>
              <button
                onClick={() => handleToggle('cabinetInteriorLed')}
                className={`px-3 py-1 rounded-full text-xs font-bold transition flex items-center gap-1.5 ${
                  lighting.cabinetInteriorLed
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                    : 'bg-[#2A2A2A] text-gray-400 hover:text-white'
                }`}
              >
                {lighting.cabinetInteriorLed ? <Check className="w-3 h-3 stroke-[3]" /> : null}
                {lighting.cabinetInteriorLed ? 'مفعل' : 'معطل'}
              </button>
            </div>

            {lighting.cabinetInteriorLed && (
              <div className="space-y-3 pt-2 border-t border-[#252525]">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-gray-400">شدة الإضاءة الداخلية (Intensity):</span>
                  <span className="font-mono text-blue-400 font-bold">
                    {Math.round((lighting.cabinetInteriorIntensity || 0.75) * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="1.8"
                  step="0.05"
                  value={lighting.cabinetInteriorIntensity ?? 0.75}
                  onChange={(e) => handleSlider('cabinetInteriorIntensity', parseFloat(e.target.value))}
                  className="w-full accent-blue-500 cursor-pointer h-1.5 bg-[#2A2A2A] rounded-lg"
                />

                <div className="space-y-1.5 pt-1">
                  <span className="text-gray-400 block text-[11px]">لون الإضاءة الداخلية:</span>
                  <div className="flex gap-2">
                    {[
                      { name: 'ذهبي دافئ', color: '#fef3c7' },
                      { name: 'أبيض كريستال', color: '#ffffff' },
                      { name: 'كهرماني كلاسيك', color: '#fed7aa' },
                      { name: 'أزرق جليدي', color: '#e0f2fe' },
                    ].map((c) => (
                      <button
                        key={c.color}
                        onClick={() => handleColor('cabinetInteriorLedColor', c.color)}
                        className={`px-2.5 py-1 rounded text-[10px] font-semibold flex items-center gap-1.5 border transition ${
                          lighting.cabinetInteriorLedColor === c.color
                            ? 'bg-blue-500/20 border-blue-500 text-blue-300'
                            : 'bg-[#1C1C1C] border-[#333] text-gray-400 hover:text-white'
                        }`}
                      >
                        <span
                          className="w-2.5 h-2.5 rounded-full"
                          style={{ backgroundColor: c.color }}
                        />
                        {c.name}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* 3. Ceiling Lights & Spotlights (إضاءة السقف) */}
          <div className="p-4 rounded-xl bg-[#141414] border border-[#333333] space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <Lightbulb className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-white block text-xs">
                    إضاءة السقف والسبوت لايت (Ceiling Spotlights)
                  </span>
                  <span className="text-[10px] text-gray-400">
                    شبكة سبوت لايت بالسقف مع مخاريط ضوئية وظلال ناعمة
                  </span>
                </div>
              </div>
              <button
                onClick={() => handleToggle('ceilingSpotlights')}
                className={`px-3 py-1 rounded-full text-xs font-bold transition flex items-center gap-1.5 ${
                  lighting.ceilingSpotlights
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                    : 'bg-[#2A2A2A] text-gray-400 hover:text-white'
                }`}
              >
                {lighting.ceilingSpotlights ? <Check className="w-3 h-3 stroke-[3]" /> : null}
                {lighting.ceilingSpotlights ? 'مفعل' : 'معطل'}
              </button>
            </div>

            {lighting.ceilingSpotlights && (
              <div className="space-y-3 pt-2 border-t border-[#252525]">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-gray-400">شدة إضاءة السقف (Intensity):</span>
                  <span className="font-mono text-emerald-400 font-bold">
                    {Math.round((lighting.ceilingIntensity || 0.8) * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="2.0"
                  step="0.05"
                  value={lighting.ceilingIntensity ?? 0.8}
                  onChange={(e) => handleSlider('ceilingIntensity', parseFloat(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer h-1.5 bg-[#2A2A2A] rounded-lg"
                />
              </div>
            )}
          </div>

          {/* 4. Ambient & Sun Environment (الإضاءة المحيطية والشمس) */}
          <div className="p-4 rounded-xl bg-[#141414] border border-[#333333] space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded bg-amber-600/20 text-amber-400 flex items-center justify-center">
                  <Sun className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-white block text-xs">
                    الإضاءة المحيطية والظلال (Ambient & Sun Shadows)
                  </span>
                  <span className="text-[10px] text-gray-400">
                    الإنارة النهارية العامة وحساب الظلال الواقعية للأجسام
                  </span>
                </div>
              </div>
              <button
                onClick={() => handleToggle('ambientEnabled')}
                className={`px-3 py-1 rounded-full text-xs font-bold transition flex items-center gap-1.5 ${
                  lighting.ambientEnabled ?? true
                    ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30'
                    : 'bg-[#2A2A2A] text-gray-400 hover:text-white'
                }`}
              >
                {(lighting.ambientEnabled ?? true) ? <Check className="w-3 h-3 stroke-[3]" /> : null}
                {(lighting.ambientEnabled ?? true) ? 'مفعل' : 'معطل'}
              </button>
            </div>

            <div className="space-y-3 pt-2 border-t border-[#252525]">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-gray-400">السطوع المحيطي (Ambient Intensity):</span>
                <span className="font-mono text-gray-300 font-bold">
                  {Math.round(lighting.ambientIntensity * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="0.0"
                max="1.0"
                step="0.05"
                value={lighting.ambientIntensity}
                onChange={(e) => handleSlider('ambientIntensity', parseFloat(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer h-1.5 bg-[#2A2A2A] rounded-lg"
              />

              <div className="flex items-center justify-between pt-1">
                <span className="text-gray-400 text-[11px]">الظلال الواقعية ثلاثية الأبعاد (Soft Shadows):</span>
                <button
                  onClick={() => handleToggle('shadowsEnabled')}
                  className={`px-3 py-1 rounded text-xs font-bold border transition ${
                    lighting.shadowsEnabled
                      ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400'
                      : 'bg-[#2A2A2A] border-[#444] text-gray-400'
                  }`}
                >
                  {lighting.shadowsEnabled ? 'مفعلة' : 'معطلة'}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-[#333333] flex justify-end bg-[#252525]">
          <button
            onClick={onClose}
            className="px-5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md transition"
          >
            تطبيق وحفظ الإضاءة
          </button>
        </div>
      </div>
    </div>
  );
};
