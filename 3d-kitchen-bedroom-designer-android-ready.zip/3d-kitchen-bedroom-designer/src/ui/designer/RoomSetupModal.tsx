import React, { useState } from 'react';
import { RoomConfig, WallOpening, CustomWall } from '../../types';
import {
  X,
  Check,
  Home,
  Sparkles,
  LayoutGrid,
  Eye,
  Plus,
  Trash2,
  Wand2,
  Zap,
  Bed,
  Refrigerator,
  DoorClosed,
  Square,
  Move,
  Layers,
  Palette,
  Sliders,
  Trees,
  PenTool,
} from 'lucide-react';
import { MATERIALS_CATALOG } from '../../domain/materials/materialsCatalog';
import { AutoRoomLayoutType } from '../../domain/room/autoRoomBuilder';

interface RoomSetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  roomConfig: RoomConfig;
  onSave: (config: RoomConfig) => void;
  onAutoBuild?: (config: RoomConfig, layoutType: AutoRoomLayoutType) => void;
  onSelectOpeningForDpad?: (openingId: string) => void;
  onOpenFloorPlan2D?: () => void;
}

export const RoomSetupModal: React.FC<RoomSetupModalProps> = ({
  isOpen,
  onClose,
  roomConfig,
  onSave,
  onAutoBuild,
  onSelectOpeningForDpad,
  onOpenFloorPlan2D,
}) => {
  const [config, setConfig] = useState<RoomConfig>({ ...roomConfig });
  const [activeTab, setActiveTab] = useState<'walls' | 'openings' | 'custom_walls' | 'auto_build'>('openings');
  const [selectedLayoutType, setSelectedLayoutType] = useState<AutoRoomLayoutType>('l_kitchen');
  const [wallFinishCategory, setWallFinishCategory] = useState<'paint' | 'ceramic_wall' | 'floor_tiles'>('paint');

  if (!isOpen) return null;

  const floorMaterials = MATERIALS_CATALOG.filter(
    (m) => m.category === 'ceramic_floor' || m.category === 'marble' || m.category === 'wood'
  );
  const wallPaints = MATERIALS_CATALOG.filter((m) => m.category === 'paint');
  const wallCeramics = MATERIALS_CATALOG.filter((m) => m.category === 'ceramic_wall');

  // Quick Preset Adders for Windows
  const handleAddWindowPreset = (preset: 'single' | 'panorama' | 'kitchen') => {
    let width = 1000;
    let height = 1200;
    let sillHeight = 1000;
    let name = 'نافذة مفردة';

    if (preset === 'panorama') {
      width = 1800;
      height = 1400;
      sillHeight = 900;
      name = 'نافذة بانورامية مزدوجة';
    } else if (preset === 'kitchen') {
      width = 1200;
      height = 900;
      sillHeight = 1100;
      name = 'شباك مطبخ علوي';
    }

    const wallLength = config.width;
    const dist = Math.max(100, Math.min(wallLength - width - 100, config.width / 2 - width / 2));

    const newOpening: WallOpening = {
      id: `win_${Date.now()}`,
      name,
      type: 'window',
      wallIndex: 0, // North wall by default
      distanceFromStart: Math.round(dist),
      width,
      height,
      sillHeight,
      windowStyle: preset === 'panorama' ? 'panoramic' : preset,
    };

    setConfig({
      ...config,
      openings: [...(config.openings || []), newOpening],
    });
  };

  // Quick Preset Adders for Doors
  const handleAddDoorPreset = (preset: 'wood' | 'sliding' | 'aluminum') => {
    let width = 900;
    let height = 2150;
    let name = 'باب غرفة خشبي';

    if (preset === 'sliding') {
      width = 1800;
      height = 2200;
      name = 'باب سحاب زجاجي (بلكونة)';
    } else if (preset === 'aluminum') {
      width = 850;
      height = 2100;
      name = 'باب مطبخ ألمنيوم';
    }

    const wallLength = config.length;
    const dist = Math.max(100, Math.min(wallLength - width - 100, 300));

    const newOpening: WallOpening = {
      id: `door_${Date.now()}`,
      name,
      type: 'door',
      wallIndex: 1, // East wall by default
      distanceFromStart: Math.round(dist),
      width,
      height,
      sillHeight: 0,
      doorStyle: preset === 'wood' ? 'wood_classic' : preset === 'sliding' ? 'glass_sliding' : 'aluminum_modern',
    };

    setConfig({
      ...config,
      openings: [...(config.openings || []), newOpening],
    });
  };

  const handleRemoveOpening = (id: string) => {
    setConfig({
      ...config,
      openings: (config.openings || []).filter((o) => o.id !== id),
    });
  };

  const handleOpeningChange = (idx: number, patch: Partial<WallOpening>) => {
    const updated = [...(config.openings || [])];
    updated[idx] = { ...updated[idx], ...patch };
    setConfig({ ...config, openings: updated });
  };

  const handleDpadControlDirect = (openingId: string) => {
    onSave(config);
    if (onSelectOpeningForDpad) {
      onSelectOpeningForDpad(openingId);
    }
    onClose();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(config);
    onClose();
  };

  const wallOptions = [
    { id: 0, label: 'الجدار الخلفي (North - خلف المطبخ)' },
    { id: 1, label: 'الجدار الأيمن (East - يمين المشهد)' },
    { id: 2, label: 'الجدار الأمامي (South - واجهة المشهد)' },
    { id: 3, label: 'الجدار الأيسر (West - يسار المشهد)' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm font-['Cairo',sans-serif]">
      <div className="relative w-full max-w-3xl bg-[#12161E] border border-[#2D3848] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] text-gray-100" dir="rtl">
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-[#252E3E] flex items-center justify-between bg-[#161C26]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white tracking-wide">
                إدارة وتعديل الجدران، الأبواب، والنوافذ
              </h2>
              <p className="text-[11px] text-gray-400">
                تخصيص أبعاد الغرفة، إضافة أبواب ونوافذ مع التحكم بها عبر الـ D-Pad
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-white rounded-lg hover:bg-[#202938] transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-4 pt-3 pb-1 border-b border-[#232C3B] bg-[#0E121A] text-xs overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('openings')}
            className={`px-3.5 py-2 rounded-xl font-bold flex items-center gap-2 transition ${
              activeTab === 'openings'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'text-gray-400 hover:text-gray-200 hover:bg-[#18202D]'
            }`}
          >
            <DoorClosed className="w-4 h-4 text-cyan-300" />
            <span>الأبواب والنوافذ ({config.openings?.length || 0})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('walls')}
            className={`px-3.5 py-2 rounded-xl font-bold flex items-center gap-2 transition ${
              activeTab === 'walls'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'text-gray-400 hover:text-gray-200 hover:bg-[#18202D]'
            }`}
          >
            <LayoutGrid className="w-4 h-4 text-amber-300" />
            <span>أبعاد وخصائص الجدران</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('custom_walls')}
            className={`px-3.5 py-2 rounded-xl font-bold flex items-center gap-2 transition ${
              activeTab === 'custom_walls'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'text-gray-400 hover:text-gray-200 hover:bg-[#18202D]'
            }`}
          >
            <Layers className="w-4 h-4 text-emerald-300" />
            <span>القواطع والجدران المخصصة ({config.customWalls?.length || 0})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('auto_build')}
            className={`px-3.5 py-2 rounded-xl font-bold flex items-center gap-2 transition ${
              activeTab === 'auto_build'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-gray-400 hover:text-gray-200 hover:bg-[#18202D]'
            }`}
          >
            <Wand2 className="w-4 h-4 text-purple-300" />
            <span>البناء التلقائي</span>
          </button>

          {onOpenFloorPlan2D && (
            <button
              type="button"
              onClick={onOpenFloorPlan2D}
              className="mr-auto px-3.5 py-2 rounded-xl font-bold flex items-center gap-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-lg shadow-cyan-600/30 transition border border-cyan-400/40"
              title="رسم وتعديل الجدران بمخطط 2D احترافي"
            >
              <PenTool className="w-4 h-4 text-cyan-200" />
              <span>رسم جدران 2D (CAD)</span>
            </button>
          )}
        </div>

        {/* Form Content */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-5 flex-1 text-xs">
          {/* ========================================================================= */}
          {/* TAB 1: WINDOWS & DOORS                                                    */}
          {/* ========================================================================= */}
          {activeTab === 'openings' && (
            <div className="space-y-4">
              {/* Quick Add Presets Bar */}
              <div className="bg-[#161C26] p-3 rounded-2xl border border-[#283548] space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-gray-200 flex items-center gap-1.5">
                    <Plus className="w-4 h-4 text-blue-400" />
                    إضافة نافذة أو باب جديد بسرعة:
                  </span>
                  <span className="text-[10px] text-gray-400">قوالب جاهزة بمقاسات معيارية</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {/* Window Presets */}
                  <button
                    type="button"
                    onClick={() => handleAddWindowPreset('single')}
                    className="p-2 rounded-xl bg-[#0E121A] hover:bg-blue-600/20 border border-[#252E3E] hover:border-blue-500/50 text-right transition group"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-xs text-blue-300 group-hover:text-white">
                        + نافذة مفردة
                      </span>
                      <Square className="w-3.5 h-3.5 text-blue-400" />
                    </div>
                    <span className="text-[10px] text-gray-400 block font-mono">1000 × 1200 mm</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleAddWindowPreset('panorama')}
                    className="p-2 rounded-xl bg-[#0E121A] hover:bg-cyan-600/20 border border-[#252E3E] hover:border-cyan-500/50 text-right transition group"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-xs text-cyan-300 group-hover:text-white">
                        + شباك بانوراما
                      </span>
                      <Square className="w-3.5 h-3.5 text-cyan-400" />
                    </div>
                    <span className="text-[10px] text-gray-400 block font-mono">1800 × 1400 mm</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleAddWindowPreset('kitchen')}
                    className="p-2 rounded-xl bg-[#0E121A] hover:bg-emerald-600/20 border border-[#252E3E] hover:border-emerald-500/50 text-right transition group"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-xs text-emerald-300 group-hover:text-white">
                        + شباك حوض جلي
                      </span>
                      <Square className="w-3.5 h-3.5 text-emerald-400" />
                    </div>
                    <span className="text-[10px] text-gray-400 block font-mono">1200 × 900 mm</span>
                  </button>

                  {/* Door Presets */}
                  <button
                    type="button"
                    onClick={() => handleAddDoorPreset('wood')}
                    className="p-2 rounded-xl bg-[#0E121A] hover:bg-amber-600/20 border border-[#252E3E] hover:border-amber-500/50 text-right transition group"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-xs text-amber-300 group-hover:text-white">
                        + باب غرفة خشبي
                      </span>
                      <DoorClosed className="w-3.5 h-3.5 text-amber-400" />
                    </div>
                    <span className="text-[10px] text-gray-400 block font-mono">900 × 2150 mm</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleAddDoorPreset('sliding')}
                    className="p-2 rounded-xl bg-[#0E121A] hover:bg-purple-600/20 border border-[#252E3E] hover:border-purple-500/50 text-right transition group"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-xs text-purple-300 group-hover:text-white">
                        + باب سحاب زجاجي
                      </span>
                      <DoorClosed className="w-3.5 h-3.5 text-purple-400" />
                    </div>
                    <span className="text-[10px] text-gray-400 block font-mono">1800 × 2200 mm</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleAddDoorPreset('aluminum')}
                    className="p-2 rounded-xl bg-[#0E121A] hover:bg-slate-600/20 border border-[#252E3E] hover:border-slate-500/50 text-right transition group"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-xs text-slate-300 group-hover:text-white">
                        + باب ألمنيوم مطبخ
                      </span>
                      <DoorClosed className="w-3.5 h-3.5 text-slate-400" />
                    </div>
                    <span className="text-[10px] text-gray-400 block font-mono">850 × 2100 mm</span>
                  </button>
                </div>
              </div>

              {/* List of Existing Openings */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-xs text-white flex items-center gap-2">
                    <DoorClosed className="w-4 h-4 text-cyan-400" />
                    الأبواب والنوافذ الحالية في الغرفة ({config.openings?.length || 0}):
                  </h3>
                  <span className="text-[10px] text-gray-400">
                    يمكنك تحريك أي باب أو نافذة على الجدار مباشرة باستخدام الـ D-Pad
                  </span>
                </div>

                {config.openings && config.openings.length > 0 ? (
                  <div className="space-y-3">
                    {config.openings.map((op, idx) => (
                      <div
                        key={op.id}
                        className="p-3.5 bg-[#161C26] border border-[#283548] rounded-2xl shadow-md space-y-3 transition hover:border-[#384860]"
                      >
                        {/* Top row: Type badge, name, wall select, action buttons */}
                        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#232C3B] pb-2.5">
                          <div className="flex items-center gap-2">
                            <span
                              className={`px-2 py-0.5 rounded-lg text-[10px] font-bold flex items-center gap-1 ${
                                op.type === 'door'
                                  ? 'bg-amber-600/20 text-amber-300 border border-amber-500/40'
                                  : 'bg-cyan-600/20 text-cyan-300 border border-cyan-500/40'
                              }`}
                            >
                              {op.type === 'door' ? (
                                <DoorClosed className="w-3.5 h-3.5" />
                              ) : (
                                <Square className="w-3.5 h-3.5" />
                              )}
                              <span>{op.type === 'door' ? 'باب' : 'نافذة'}</span>
                            </span>
                            <input
                              type="text"
                              value={op.name || (op.type === 'door' ? 'باب' : 'نافذة')}
                              onChange={(e) => handleOpeningChange(idx, { name: e.target.value })}
                              className="bg-[#0E121A] border border-[#283548] rounded-lg px-2 py-1 text-white font-bold text-xs"
                              placeholder="اسم الفتحة"
                            />
                          </div>

                          {/* Wall Selector */}
                          <div className="flex items-center gap-1.5">
                            <span className="text-[10px] text-gray-400">الجدار:</span>
                            <select
                              value={op.wallIndex ?? 0}
                              onChange={(e) =>
                                handleOpeningChange(idx, { wallIndex: Number(e.target.value) })
                              }
                              className="bg-[#0E121A] border border-[#283548] rounded-lg px-2 py-1 text-xs text-cyan-300 font-bold focus:border-blue-500 focus:outline-none"
                            >
                              {wallOptions.map((w) => (
                                <option key={w.id} value={w.id}>
                                  {w.label}
                                </option>
                              ))}
                            </select>
                          </div>

                          {/* D-Pad & Delete Buttons */}
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => handleDpadControlDirect(op.id)}
                              className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1 shadow-sm transition active:scale-95"
                              title="التحكم بالفتحة فوراً عبر الـ D-Pad"
                            >
                              <Move className="w-3.5 h-3.5" />
                              <span>تحريك بـ D-Pad 🎮</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => handleRemoveOpening(op.id)}
                              className="p-1.5 text-gray-400 hover:text-red-400 hover:bg-red-950/30 rounded-lg transition"
                              title="حذف الفتحة"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {/* Dimensions and Position row */}
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-[11px]">
                          <div>
                            <span className="text-gray-400 block mb-1">العرض (Width):</span>
                            <div className="relative">
                              <input
                                type="number"
                                min="400"
                                max="4000"
                                step="50"
                                value={op.width}
                                onChange={(e) =>
                                  handleOpeningChange(idx, { width: Number(e.target.value) })
                                }
                                className="w-full bg-[#0E121A] border border-[#283548] rounded-lg px-2.5 py-1.5 text-white font-mono"
                              />
                              <span className="absolute left-2 top-1.5 text-[9px] text-gray-500">mm</span>
                            </div>
                          </div>

                          <div>
                            <span className="text-gray-400 block mb-1">الارتفاع (Height):</span>
                            <div className="relative">
                              <input
                                type="number"
                                min="400"
                                max="3500"
                                step="50"
                                value={op.height}
                                onChange={(e) =>
                                  handleOpeningChange(idx, { height: Number(e.target.value) })
                                }
                                className="w-full bg-[#0E121A] border border-[#283548] rounded-lg px-2.5 py-1.5 text-white font-mono"
                              />
                              <span className="absolute left-2 top-1.5 text-[9px] text-gray-500">mm</span>
                            </div>
                          </div>

                          <div>
                            <span className="text-gray-400 block mb-1">المسافة من البداية:</span>
                            <div className="relative">
                              <input
                                type="number"
                                min="0"
                                max="15000"
                                step="50"
                                value={Math.round(op.distanceFromStart)}
                                onChange={(e) =>
                                  handleOpeningChange(idx, {
                                    distanceFromStart: Number(e.target.value),
                                  })
                                }
                                className="w-full bg-[#0E121A] border border-[#283548] rounded-lg px-2.5 py-1.5 text-white font-mono"
                              />
                              <span className="absolute left-2 top-1.5 text-[9px] text-gray-500">mm</span>
                            </div>
                          </div>

                          <div>
                            <span className="text-gray-400 block mb-1">
                              {op.type === 'window' ? 'جلسة الشباك (Sill):' : 'الارتفاع عن الأرض:'}
                            </span>
                            <div className="relative">
                              <input
                                type="number"
                                min="0"
                                max="2500"
                                step="50"
                                value={Math.round(op.sillHeight || 0)}
                                onChange={(e) =>
                                  handleOpeningChange(idx, {
                                    sillHeight: Number(e.target.value),
                                  })
                                }
                                className="w-full bg-[#0E121A] border border-[#283548] rounded-lg px-2.5 py-1.5 text-white font-mono"
                              />
                              <span className="absolute left-2 top-1.5 text-[9px] text-gray-500">mm</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-6 bg-[#161C26] border border-[#283548] rounded-2xl text-center space-y-2">
                    <DoorClosed className="w-8 h-8 text-gray-500 mx-auto" />
                    <p className="text-xs text-gray-300 font-bold">لا توجد نوافذ أو أبواب مضافة بعد</p>
                    <p className="text-[11px] text-gray-500">
                      استخدم أزرار القوالب الجاهزة أعلاه لإضافة نافذة أو باب على أي جدار في الغرفة
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 2: ROOM DIMENSIONS & WALLS CUSTOMIZATION                              */}
          {/* ========================================================================= */}
          {activeTab === 'walls' && (
            <div className="space-y-4">
              {/* Room Dimensions in mm */}
              <div className="space-y-2.5">
                <h3 className="font-bold text-white flex items-center gap-2">
                  <LayoutGrid className="w-4 h-4 text-blue-400" />
                  أبعاد الغرفة الرئيسية (بالمليمتر mm)
                </h3>
                <div className="grid grid-cols-3 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] text-gray-400">العرض (Width - X)</label>
                    <div className="relative">
                      <input
                        type="number"
                        min="2000"
                        max="15000"
                        step="100"
                        value={config.width}
                        onChange={(e) =>
                          setConfig({ ...config, width: Math.max(1000, Number(e.target.value)) })
                        }
                        className="w-full bg-[#0E121A] border border-[#283548] rounded-xl px-2.5 py-1.5 text-white font-mono focus:border-blue-500 focus:outline-none"
                      />
                      <span className="absolute left-2.5 top-1.5 text-[10px] text-gray-500">mm</span>
                    </div>
                    <span className="text-[10px] text-blue-400 font-mono">
                      {(config.width / 1000).toFixed(2)} متر
                    </span>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] text-gray-400">الطول / العمق (Length - Z)</label>
                    <div className="relative">
                      <input
                        type="number"
                        min="2000"
                        max="15000"
                        step="100"
                        value={config.length}
                        onChange={(e) =>
                          setConfig({ ...config, length: Math.max(1000, Number(e.target.value)) })
                        }
                        className="w-full bg-[#0E121A] border border-[#283548] rounded-xl px-2.5 py-1.5 text-white font-mono focus:border-blue-500 focus:outline-none"
                      />
                      <span className="absolute left-2.5 top-1.5 text-[10px] text-gray-500">mm</span>
                    </div>
                    <span className="text-[10px] text-blue-400 font-mono">
                      {(config.length / 1000).toFixed(2)} متر
                    </span>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] text-gray-400">الارتفاع (Height - Y)</label>
                    <div className="relative">
                      <input
                        type="number"
                        min="2200"
                        max="5000"
                        step="50"
                        value={config.height}
                        onChange={(e) =>
                          setConfig({ ...config, height: Math.max(1500, Number(e.target.value)) })
                        }
                        className="w-full bg-[#0E121A] border border-[#283548] rounded-xl px-2.5 py-1.5 text-white font-mono focus:border-blue-500 focus:outline-none"
                      />
                      <span className="absolute left-2.5 top-1.5 text-[10px] text-gray-500">mm</span>
                    </div>
                    <span className="text-[10px] text-blue-400 font-mono">
                      {(config.height / 1000).toFixed(2)} متر
                    </span>
                  </div>
                </div>
              </div>

              {/* Wall & Floor Materials Selection Studio */}
              <div className="space-y-3 bg-[#161C26] p-4 rounded-2xl border border-[#283548]">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#283548] pb-3">
                  <div>
                    <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                      <Palette className="w-4 h-4 text-amber-400" />
                      تشطيبات ودهانات الجدران وسيراميك الأرضيات
                    </h4>
                    <p className="text-[11px] text-gray-400">
                      اختر دهانات الجدران، سيراميك الحوائط، وبورسلان الأرضيات من الكتالوج المتطور
                    </p>
                  </div>

                  {/* Subtabs for Paints, Wall Tiles, and Floor Tiles */}
                  <div className="flex items-center gap-1 bg-[#0E121A] p-1 rounded-xl border border-[#283548]">
                    <button
                      type="button"
                      onClick={() => setWallFinishCategory('paint')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                        wallFinishCategory === 'paint'
                          ? 'bg-blue-600 text-white shadow-sm'
                          : 'text-gray-400 hover:text-white'
                      }`}
                    >
                      🎨 دهانات الجدران
                    </button>
                    <button
                      type="button"
                      onClick={() => setWallFinishCategory('ceramic_wall')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                        wallFinishCategory === 'ceramic_wall'
                          ? 'bg-blue-600 text-white shadow-sm'
                          : 'text-gray-400 hover:text-white'
                      }`}
                    >
                      🧱 سيراميك الجدران
                    </button>
                    <button
                      type="button"
                      onClick={() => setWallFinishCategory('floor_tiles')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                        wallFinishCategory === 'floor_tiles'
                          ? 'bg-amber-600 text-white shadow-sm'
                          : 'text-gray-400 hover:text-white'
                      }`}
                    >
                      🏛️ سيراميك الأرضيات
                    </button>
                  </div>
                </div>

                {/* 1. Wall Paints Gallery */}
                {wallFinishCategory === 'paint' && (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-48 overflow-y-auto p-1 custom-scrollbar">
                      {wallPaints.map((paint) => {
                        const isSelected = (config.wallMaterialId === paint.id) || (!config.wallMaterialId && paint.id === 'paint_cotton_white');
                        return (
                          <button
                            key={paint.id}
                            type="button"
                            onClick={() => {
                              setConfig({
                                ...config,
                                wallMaterialId: paint.id,
                                wallColor: paint.color,
                              });
                            }}
                            className={`p-2 rounded-xl border flex items-center gap-2 text-right transition ${
                              isSelected
                                ? 'bg-blue-600/20 border-blue-500 shadow-md ring-1 ring-blue-500'
                                : 'bg-[#0E121A] border-[#283548] hover:border-blue-500/40 text-gray-300'
                            }`}
                          >
                            <span
                              className="w-6 h-6 rounded-full border border-white/20 shrink-0 shadow-inner"
                              style={{ backgroundColor: paint.color }}
                            />
                            <div className="min-w-0 flex-1">
                              <p className="text-[11px] font-bold text-white truncate">{paint.nameAr}</p>
                              <span className="text-[9px] text-gray-400 font-mono">{paint.color}</span>
                            </div>
                            {isSelected && <Check className="w-3.5 h-3.5 text-blue-400 shrink-0" />}
                          </button>
                        );
                      })}
                    </div>

                    <div className="flex items-center gap-3 pt-1 border-t border-[#283548]/60">
                      <span className="text-[11px] text-gray-400">تخصيص لون دهان يدوي:</span>
                      <input
                        type="color"
                        value={config.wallColor}
                        onChange={(e) => setConfig({ ...config, wallColor: e.target.value })}
                        className="w-8 h-8 rounded-lg cursor-pointer bg-transparent border-0"
                      />
                      <input
                        type="text"
                        value={config.wallColor}
                        onChange={(e) => setConfig({ ...config, wallColor: e.target.value })}
                        className="w-28 bg-[#0E121A] border border-[#283548] rounded-lg px-2 py-1 text-xs font-mono text-white"
                      />
                    </div>
                  </div>
                )}

                {/* 2. Wall Ceramic & Tiles Gallery */}
                {wallFinishCategory === 'ceramic_wall' && (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-48 overflow-y-auto p-1 custom-scrollbar">
                      {wallCeramics.map((tile) => {
                        const isSelected = config.wallMaterialId === tile.id;
                        return (
                          <button
                            key={tile.id}
                            type="button"
                            onClick={() => {
                              setConfig({
                                ...config,
                                wallMaterialId: tile.id,
                                wallColor: tile.color,
                              });
                            }}
                            className={`p-2 rounded-xl border flex items-center gap-2 text-right transition ${
                              isSelected
                                ? 'bg-blue-600/20 border-blue-500 shadow-md ring-1 ring-blue-500'
                                : 'bg-[#0E121A] border-[#283548] hover:border-blue-500/40 text-gray-300'
                            }`}
                          >
                            <span
                              className="w-6 h-6 rounded-lg border border-white/20 shrink-0 shadow-inner"
                              style={{ backgroundColor: tile.color }}
                            />
                            <div className="min-w-0 flex-1">
                              <p className="text-[11px] font-bold text-white truncate">{tile.nameAr}</p>
                              <span className="text-[9px] text-gray-400 font-mono">{tile.name}</span>
                            </div>
                            {isSelected && <Check className="w-3.5 h-3.5 text-blue-400 shrink-0" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* 3. Floor Ceramic & Porcelain Gallery */}
                {wallFinishCategory === 'floor_tiles' && (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-48 overflow-y-auto p-1 custom-scrollbar">
                      {floorMaterials.map((tile) => {
                        const isSelected = config.floorMaterialId === tile.id;
                        return (
                          <button
                            key={tile.id}
                            type="button"
                            onClick={() => {
                              setConfig({
                                ...config,
                                floorMaterialId: tile.id,
                                floorColor: tile.color,
                              });
                            }}
                            className={`p-2 rounded-xl border flex items-center gap-2 text-right transition ${
                              isSelected
                                ? 'bg-amber-600/20 border-amber-500 shadow-md ring-1 ring-amber-500'
                                : 'bg-[#0E121A] border-[#283548] hover:border-amber-500/40 text-gray-300'
                            }`}
                          >
                            <span
                              className="w-6 h-6 rounded-lg border border-white/20 shrink-0 shadow-inner"
                              style={{ backgroundColor: tile.color }}
                            />
                            <div className="min-w-0 flex-1">
                              <p className="text-[11px] font-bold text-white truncate">{tile.nameAr}</p>
                              <span className="text-[9px] text-gray-400 font-mono">{tile.color}</span>
                            </div>
                            {isSelected && <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                          </button>
                        );
                      })}
                    </div>

                    <div className="flex items-center gap-3 pt-1 border-t border-[#283548]/60">
                      <span className="text-[11px] text-gray-400">تخصيص لون أرضية يدوي:</span>
                      <input
                        type="color"
                        value={config.floorColor}
                        onChange={(e) => setConfig({ ...config, floorColor: e.target.value })}
                        className="w-8 h-8 rounded-lg cursor-pointer bg-transparent border-0"
                      />
                      <input
                        type="text"
                        value={config.floorColor}
                        onChange={(e) => setConfig({ ...config, floorColor: e.target.value })}
                        className="w-28 bg-[#0E121A] border border-[#283548] rounded-lg px-2 py-1 text-xs font-mono text-white"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Individual Wall Visibility Toggles */}
              <div className="space-y-2 bg-[#161C26] p-3.5 rounded-2xl border border-[#283548]">
                <label className="text-xs font-bold text-gray-200 flex items-center gap-1.5">
                  <Eye className="w-4 h-4 text-blue-400" />
                  التحكم في رؤية الجدران في المشهد 3D (Wall Visibility)
                </label>
                <p className="text-[10px] text-gray-400">
                  إخفاء الجدار يسمح برؤية المطبخ والوحدات من زاوية كاميرا خارجية مفتوحة بسهولة
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] pt-1">
                  <label className="flex items-center gap-2 p-2.5 rounded-xl bg-[#0E121A] border border-[#283548] cursor-pointer hover:border-blue-500/40 transition">
                    <input
                      type="checkbox"
                      checked={config.showNorthWall}
                      onChange={(e) => setConfig({ ...config, showNorthWall: e.target.checked })}
                      className="rounded text-blue-600"
                    />
                    <span>الجدار الخلفي (North)</span>
                  </label>
                  <label className="flex items-center gap-2 p-2.5 rounded-xl bg-[#0E121A] border border-[#283548] cursor-pointer hover:border-blue-500/40 transition">
                    <input
                      type="checkbox"
                      checked={config.showEastWall}
                      onChange={(e) => setConfig({ ...config, showEastWall: e.target.checked })}
                      className="rounded text-blue-600"
                    />
                    <span>الجدار الأيمن (East)</span>
                  </label>
                  <label className="flex items-center gap-2 p-2.5 rounded-xl bg-[#0E121A] border border-[#283548] cursor-pointer hover:border-blue-500/40 transition">
                    <input
                      type="checkbox"
                      checked={config.showSouthWall}
                      onChange={(e) => setConfig({ ...config, showSouthWall: e.target.checked })}
                      className="rounded text-blue-600"
                    />
                    <span>الجدار الأمامي (South)</span>
                  </label>
                  <label className="flex items-center gap-2 p-2.5 rounded-xl bg-[#0E121A] border border-[#283548] cursor-pointer hover:border-blue-500/40 transition">
                    <input
                      type="checkbox"
                      checked={config.showWestWall}
                      onChange={(e) => setConfig({ ...config, showWestWall: e.target.checked })}
                      className="rounded text-blue-600"
                    />
                    <span>الجدار الأيسر (West)</span>
                  </label>
                </div>
              </div>

              {/* Natural Surrounding Landscape Selection */}
              <div className="space-y-2 bg-[#161C26] p-3.5 rounded-2xl border border-[#283548]">
                <label className="text-[11px] font-bold text-gray-200 flex items-center gap-2">
                  <Trees className="w-4 h-4 text-emerald-400" />
                  <span>المنظر الطبيعي المحيط بالغرفة (يظهر من النوافذ والأبواب):</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => setConfig({ ...config, environment: 'forest' })}
                    className={`p-2.5 rounded-xl border text-right transition ${
                      (config.environment || 'forest') === 'forest'
                        ? 'bg-emerald-600/30 border-emerald-500 text-white shadow-md'
                        : 'bg-[#0E121A] border-[#283548] text-gray-400 hover:text-white'
                    }`}
                  >
                    <div className="font-bold text-xs text-emerald-300">🌲 غابة صنوبر</div>
                    <span className="text-[10px] text-gray-400">أشجار وطبيعة خضراء</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setConfig({ ...config, environment: 'garden' })}
                    className={`p-2.5 rounded-xl border text-right transition ${
                      config.environment === 'garden'
                        ? 'bg-emerald-600/30 border-emerald-500 text-white shadow-md'
                        : 'bg-[#0E121A] border-[#283548] text-gray-400 hover:text-white'
                    }`}
                  >
                    <div className="font-bold text-xs text-emerald-300">🏡 حديقة فيلا</div>
                    <span className="text-[10px] text-gray-400">حديقة وأزهار ومروج</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setConfig({ ...config, environment: 'studio' })}
                    className={`p-2.5 rounded-xl border text-right transition ${
                      config.environment === 'studio'
                        ? 'bg-blue-600/30 border-blue-500 text-white shadow-md'
                        : 'bg-[#0E121A] border-[#283548] text-gray-400 hover:text-white'
                    }`}
                  >
                    <div className="font-bold text-xs text-blue-300">🏢 استوديو هادئ</div>
                    <span className="text-[10px] text-gray-400">أرضية رمادية محايدة</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setConfig({ ...config, environment: 'none' })}
                    className={`p-2.5 rounded-xl border text-right transition ${
                      config.environment === 'none'
                        ? 'bg-purple-600/30 border-purple-500 text-white shadow-md'
                        : 'bg-[#0E121A] border-[#283548] text-gray-400 hover:text-white'
                    }`}
                  >
                    <div className="font-bold text-xs text-purple-300">🌌 بدون محيط</div>
                    <span className="text-[10px] text-gray-400">خلفية CAD داكنة</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 3: CUSTOM PARTITIONS & WALLS                                          */}
          {/* ========================================================================= */}
          {activeTab === 'custom_walls' && (
            <div className="space-y-3">
              {/* CAD 2D Wall Drawing Mode Banner */}
              {onOpenFloorPlan2D && (
                <div className="bg-gradient-to-r from-cyan-950/70 to-blue-950/70 p-3.5 rounded-2xl border border-cyan-500/40 flex items-center justify-between shadow-lg">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-cyan-600/30 border border-cyan-400/50 text-cyan-300">
                      <PenTool className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-xs text-white">رسم وتوصيل الجدران بمخطط 2D تفاعلي</h4>
                      <p className="text-[11px] text-cyan-200/80">
                        استخدم الماوس أو اللمس لرسم القواطع والجدران الداخلية بأطوال وزوايا دقيقة مع السحب والإفلات
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={onOpenFloorPlan2D}
                    className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-1.5 transition shadow-md shadow-cyan-600/30 shrink-0"
                  >
                    <PenTool className="w-4 h-4" />
                    <span>افتح لوحة الرسم 2D</span>
                  </button>
                </div>
              )}

              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-xs text-white">إضافة جدران وقواطع مخصصة (Custom Partitions)</h3>
                  <p className="text-[10px] text-gray-400">
                    إنشاء جدران داخلية وقواطع جبسم بورد للفصل بين مناطق المطبخ والصالة
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const newWall: CustomWall = {
                      id: `wall_${Date.now()}`,
                      startX: 0,
                      startZ: 0,
                      length: 2000,
                      height: config.height,
                      thickness: 120,
                      rotationY: 0,
                      color: config.wallColor,
                    };
                    setConfig({
                      ...config,
                      customWalls: [...(config.customWalls || []), newWall],
                    });
                  }}
                  className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1.5 transition shadow"
                >
                  <Plus className="w-4 h-4" />
                  إضافة قاطع جديد
                </button>
              </div>

              {config.customWalls && config.customWalls.length > 0 ? (
                <div className="space-y-2.5">
                  {config.customWalls.map((wall, wIdx) => (
                    <div
                      key={wall.id}
                      className="p-3 bg-[#161C26] border border-[#283548] rounded-2xl flex flex-col gap-2.5 text-xs"
                    >
                      <div className="flex items-center justify-between border-b border-[#252E3E] pb-2">
                        <span className="font-bold text-white text-xs">قاطع جدار #{wIdx + 1}</span>
                        <button
                          type="button"
                          onClick={() => {
                            setConfig({
                              ...config,
                              customWalls: config.customWalls?.filter((w) => w.id !== wall.id),
                            });
                          }}
                          className="p-1 text-gray-400 hover:text-red-400 rounded-lg hover:bg-red-950/20 transition"
                          title="حذف القاطع"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                        <div>
                          <span className="text-gray-400 block mb-1">الطول mm:</span>
                          <input
                            type="number"
                            value={wall.length}
                            onChange={(e) => {
                              const updated = [...(config.customWalls || [])];
                              updated[wIdx].length = Number(e.target.value);
                              setConfig({ ...config, customWalls: updated });
                            }}
                            className="w-full bg-[#0E121A] border border-[#283548] rounded-lg px-2 py-1 text-white font-mono"
                          />
                        </div>

                        <div>
                          <span className="text-gray-400 block mb-1">الارتفاع mm:</span>
                          <input
                            type="number"
                            value={wall.height}
                            onChange={(e) => {
                              const updated = [...(config.customWalls || [])];
                              updated[wIdx].height = Number(e.target.value);
                              setConfig({ ...config, customWalls: updated });
                            }}
                            className="w-full bg-[#0E121A] border border-[#283548] rounded-lg px-2 py-1 text-white font-mono"
                          />
                        </div>

                        <div>
                          <span className="text-gray-400 block mb-1">السماكة mm:</span>
                          <input
                            type="number"
                            value={wall.thickness}
                            onChange={(e) => {
                              const updated = [...(config.customWalls || [])];
                              updated[wIdx].thickness = Number(e.target.value);
                              setConfig({ ...config, customWalls: updated });
                            }}
                            className="w-full bg-[#0E121A] border border-[#283548] rounded-lg px-2 py-1 text-white font-mono"
                          />
                        </div>

                        <div>
                          <span className="text-gray-400 block mb-1">زاوية الدوران:</span>
                          <select
                            value={wall.rotationY}
                            onChange={(e) => {
                              const updated = [...(config.customWalls || [])];
                              updated[wIdx].rotationY = Number(e.target.value);
                              setConfig({ ...config, customWalls: updated });
                            }}
                            className="w-full bg-[#0E121A] border border-[#283548] rounded-lg px-2 py-1 text-white font-bold"
                          >
                            <option value="0">0° أفقي</option>
                            <option value="90">90° رأسي</option>
                            <option value="45">45° مائل</option>
                            <option value="180">180° معكوس</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-6 bg-[#161C26] border border-[#283548] rounded-2xl text-center space-y-1.5">
                  <Layers className="w-8 h-8 text-gray-500 mx-auto" />
                  <p className="text-xs text-gray-300 font-bold">لا توجد قواطع أو جدران إضافية</p>
                  <p className="text-[11px] text-gray-500">
                    يمكنك إضافة قواطع داخلية للفصل بين أركان المطبخ أو تصميم جزر بار ديكورية
                  </p>
                </div>
              )}
            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 4: AUTO BUILD WIZARD                                                  */}
          {/* ========================================================================= */}
          {activeTab === 'auto_build' && (
            <div className="p-4 bg-gradient-to-br from-[#1b2333] to-[#141a26] border border-blue-500/40 rounded-2xl shadow-lg space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-blue-600/30 text-blue-400 border border-blue-400/40 flex items-center justify-center">
                    <Wand2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-xs">
                      بناء وتأثيث الغرفة تلقائياً (Auto-Build Room)
                    </h4>
                    <p className="text-[10px] text-gray-400">
                      يقوم بإنشاء الجدران وتوزيع الوحدات والسلال والأجهزة هندسياً حسب الأبعاد
                    </p>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-blue-600/20 text-blue-300 text-[10px] border border-blue-500/30 font-bold">
                  توليد فوري
                </span>
              </div>

              {/* Layout Presets Selection */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedLayoutType('l_kitchen')}
                  className={`p-2.5 rounded-xl border text-right transition flex flex-col justify-between ${
                    selectedLayoutType === 'l_kitchen'
                      ? 'bg-blue-600/30 border-blue-400 text-white shadow-md'
                      : 'bg-[#11161f] border-[#293549] text-gray-400 hover:bg-[#1b2434] hover:text-gray-200'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-xs text-blue-300">مطبخ زاوية L</span>
                    <Zap className="w-3.5 h-3.5 text-blue-400" />
                  </div>
                  <span className="text-[10px] text-gray-400 leading-tight">
                    وحدة ركن + حوض + سلة زيوت وسلة مواعين + ثلاجة
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedLayoutType('u_kitchen')}
                  className={`p-2.5 rounded-xl border text-right transition flex flex-col justify-between ${
                    selectedLayoutType === 'u_kitchen'
                      ? 'bg-blue-600/30 border-blue-400 text-white shadow-md'
                      : 'bg-[#11161f] border-[#293549] text-gray-400 hover:bg-[#1b2434] hover:text-gray-200'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-xs text-blue-300">مطبخ متكامل U</span>
                    <Refrigerator className="w-3.5 h-3.5 text-blue-400" />
                  </div>
                  <span className="text-[10px] text-gray-400 leading-tight">
                    زاويتين ركن + سلال هيدروليك + مساحة تحضير واسعة
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedLayoutType('linear_kitchen')}
                  className={`p-2.5 rounded-xl border text-right transition flex flex-col justify-between ${
                    selectedLayoutType === 'linear_kitchen'
                      ? 'bg-blue-600/30 border-blue-400 text-white shadow-md'
                      : 'bg-[#11161f] border-[#293549] text-gray-400 hover:bg-[#1b2434] hover:text-gray-200'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-xs text-blue-300">مطبخ خطي مستقيم</span>
                    <Sparkles className="w-3.5 h-3.5 text-blue-400" />
                  </div>
                  <span className="text-[10px] text-gray-400 leading-tight">
                    مثالي للمساحات الطولية مع ثلاجة وحوض وسلال
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedLayoutType('bedroom')}
                  className={`p-2.5 rounded-xl border text-right transition flex flex-col justify-between ${
                    selectedLayoutType === 'bedroom'
                      ? 'bg-blue-600/30 border-blue-400 text-white shadow-md'
                      : 'bg-[#11161f] border-[#293549] text-gray-400 hover:bg-[#1b2434] hover:text-gray-200'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-xs text-blue-300">غرفة نوم ماستر</span>
                    <Bed className="w-3.5 h-3.5 text-blue-400" />
                  </div>
                  <span className="text-[10px] text-gray-400 leading-tight">
                    دولاب ملابس بمرايا + سرير كينج + كمودينات وتسريحة
                  </span>
                </button>
              </div>

              {/* Trigger Button */}
              <button
                type="button"
                onClick={() => {
                  if (onAutoBuild) {
                    onAutoBuild(config, selectedLayoutType);
                    onClose();
                  } else {
                    onSave(config);
                    onClose();
                  }
                }}
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30 transition active:scale-[0.99]"
              >
                <Wand2 className="w-4 h-4" />
                تأكيد وبناء الغرفة تلقائياً بالأبعاد المحددة ({config.width} × {config.length} × {config.height} مم)
              </button>
            </div>
          )}

          {/* Footer Actions */}
          <div className="pt-3 border-t border-[#252E3E] flex items-center justify-between gap-2.5">
            <span className="text-[11px] text-gray-400">
              إجمالي الأبواب والنوافذ: {config.openings?.length || 0}
            </span>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-[#1A222F] hover:bg-[#253244] text-gray-300 text-xs font-semibold transition border border-[#2D3848]"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-lg shadow-blue-600/30 flex items-center gap-1.5 transition active:scale-95"
              >
                <Check className="w-4 h-4" />
                تطبيق التغييرات على المشهد 3D
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
