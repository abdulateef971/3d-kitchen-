import React from 'react';
import { CatalogItemTemplate } from '../../types';

interface UnitShapePreviewProps {
  template: CatalogItemTemplate;
  className?: string;
}

/**
 * 2D/3D Isometric Architectural Vector Icon for RPZ Cabinet Library
 * Accurately depicts unit type, doors, drawers, accessories, sinks, ovens, hoods, and wardrobes.
 */
export const UnitShapePreview: React.FC<UnitShapePreviewProps> = ({ template, className = 'w-14 h-14' }) => {
  const { category, subCategory, defaultDoors, defaultDrawers, accessoryType, templateId } = template;

  // 00. INTEGRATED COOKING STATION COMBO (محطة طهي وفرن وسلتي زيوت ودرج وسطح مرمر وطباخ)
  if (
    accessoryType === 'combo_cooking_station_900' ||
    accessoryType === 'combo_cooking_station_1000' ||
    templateId.includes('cooking_station')
  ) {
    return (
      <svg viewBox="0 0 64 64" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* Plinth Base */}
        <rect x="6" y="57" width="52" height="4" rx="1" fill="#18181B" />
        
        {/* Carcase Body */}
        <rect x="6" y="16" width="52" height="41" rx="2" fill="#27272A" stroke="#52525B" strokeWidth="1.2" />

        {/* Left 15cm Oil Pull-out Rack */}
        <rect x="7.5" y="17.5" width="10" height="38" rx="1" fill="#18181B" stroke="#71717A" strokeWidth="0.8" />
        <line x1="14" y1="28" x2="14" y2="44" stroke="#F59E0B" strokeWidth="1.5" strokeLinecap="round" />
        <circle cx="12.5" cy="24" r="1.5" fill="#34D399" />
        <circle cx="12.5" cy="50" r="1.5" fill="#FBBF24" />

        {/* Right 15cm Oil Pull-out Rack */}
        <rect x="46.5" y="17.5" width="10" height="38" rx="1" fill="#18181B" stroke="#71717A" strokeWidth="0.8" />
        <line x1="50" y1="28" x2="50" y2="44" stroke="#F59E0B" strokeWidth="1.5" strokeLinecap="round" />
        <circle cx="51.5" cy="24" r="1.5" fill="#34D399" />
        <circle cx="51.5" cy="50" r="1.5" fill="#FBBF24" />

        {/* Center Top Drawer */}
        <rect x="19" y="17.5" width="26" height="9" rx="1" fill="#3F3F46" stroke="#71717A" strokeWidth="0.8" />
        <line x1="27" y1="22" x2="37" y2="22" stroke="#E4E4E7" strokeWidth="1.5" strokeLinecap="round" />

        {/* Center Built-in Oven */}
        <rect x="19" y="28" width="26" height="27.5" rx="1" fill="#09090B" stroke="#71717A" strokeWidth="0.8" />
        {/* Oven Glass Window */}
        <rect x="22" y="36" width="20" height="15" rx="1" fill="#18181B" stroke="#52525B" strokeWidth="0.8" />
        {/* Oven Handle */}
        <line x1="24" y1="32" x2="40" y2="32" stroke="#E4E4E7" strokeWidth="1.5" strokeLinecap="round" />
        {/* Digital display & dials */}
        <circle cx="23" cy="30" r="1" fill="#9CA3AF" />
        <circle cx="41" cy="30" r="1" fill="#9CA3AF" />
        <rect x="30" y="29.5" width="4" height="1.5" fill="#EF4444" />

        {/* Luxury Marble Countertop Slab */}
        <rect x="4" y="12" width="56" height="4.5" rx="1" fill="#E2E8F0" stroke="#CBD5E1" strokeWidth="0.8" />
        <path d="M12 13.5 Q 24 14.5 36 13 Q 48 14 54 13.5" stroke="#94A3B8" strokeWidth="0.6" fill="none" opacity="0.7" />

        {/* 5-Burner Gas Cooktop on top */}
        <rect x="10" y="7" width="44" height="5" rx="1" fill="#1E293B" stroke="#64748B" strokeWidth="0.8" />
        {/* Central Wok Burner with flame glow */}
        <circle cx="32" cy="9.5" r="2.2" fill="#F59E0B" stroke="#DC2626" strokeWidth="0.6" />
        {/* 4 Corner Burners */}
        <circle cx="18" cy="9.5" r="1.4" fill="#64748B" stroke="#000" strokeWidth="0.5" />
        <circle cx="25" cy="9.5" r="1.4" fill="#64748B" stroke="#000" strokeWidth="0.5" />
        <circle cx="39" cy="9.5" r="1.4" fill="#64748B" stroke="#000" strokeWidth="0.5" />
        <circle cx="46" cy="9.5" r="1.4" fill="#64748B" stroke="#000" strokeWidth="0.5" />
      </svg>
    );
  }

  // 0a. WIRE SPICE & OIL PULL-OUT BASKET (سلات زيوت وبهارات)
  if (accessoryType === 'wire_basket_spice' || templateId.includes('spice') || templateId.includes('oil') || template.name.toLowerCase().includes('spice')) {
    return (
      <svg viewBox="0 0 64 64" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="18" y="16" width="28" height="42" rx="2" fill="#242424" stroke="#666" strokeWidth="1.5" />
        <rect x="16" y="14" width="32" height="4" rx="1" fill="#D1D5DB" />
        {/* Chrome Wire Frame */}
        <rect x="22" y="22" width="20" height="15" rx="1" fill="#383838" stroke="#38BDF8" strokeWidth="1" strokeDasharray="2 1" />
        {/* Bottles */}
        <rect x="25" y="24" width="4" height="11" rx="0.5" fill="#FBBF24" />
        <rect x="31" y="24" width="4" height="11" rx="0.5" fill="#34D399" />
        <rect x="37" y="24" width="3.5" height="11" rx="0.5" fill="#F87171" />
        {/* Bottom Tier Bottles */}
        <rect x="22" y="40" width="20" height="14" rx="1" fill="#383838" stroke="#38BDF8" strokeWidth="1" strokeDasharray="2 1" />
        <rect x="26" y="42" width="5" height="10" rx="0.5" fill="#E5E7EB" />
        <rect x="34" y="42" width="5" height="10" rx="0.5" fill="#FBBF24" />
        {/* Front Handle */}
        <line x1="32" y1="20" x2="32" y2="28" stroke="#F3F4F6" strokeWidth="2" strokeLinecap="round" />
        <rect x="20" y="58" width="24" height="3" fill="#1F2937" />
      </svg>
    );
  }

  // 0b. WIRE DISH & PLATE RACK (سلات مواعين وصحون)
  if (accessoryType === 'wire_basket_dishes' || templateId.includes('dish') || templateId.includes('plate') || template.name.toLowerCase().includes('dish')) {
    return (
      <svg viewBox="0 0 64 64" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="8" y="18" width="48" height="40" rx="2" fill="#242424" stroke="#666" strokeWidth="1.5" />
        <rect x="6" y="16" width="52" height="4" rx="1" fill="#D1D5DB" />
        {/* Wire Basket Drawer */}
        <rect x="11" y="22" width="42" height="16" rx="1" fill="#333333" stroke="#94A3B8" strokeWidth="1" strokeDasharray="2 2" />
        {/* Standing Ceramic Plates in slots */}
        <ellipse cx="20" cy="30" rx="2" ry="5" fill="#F8FAFC" stroke="#94A3B8" strokeWidth="0.8" />
        <ellipse cx="26" cy="30" rx="2" ry="5" fill="#F8FAFC" stroke="#94A3B8" strokeWidth="0.8" />
        <ellipse cx="32" cy="30" rx="2" ry="5" fill="#F8FAFC" stroke="#94A3B8" strokeWidth="0.8" />
        <ellipse cx="38" cy="30" rx="2" ry="5" fill="#F8FAFC" stroke="#94A3B8" strokeWidth="0.8" />
        <ellipse cx="44" cy="30" rx="2" ry="5" fill="#F8FAFC" stroke="#94A3B8" strokeWidth="0.8" />
        {/* Lower Pot / Pan Basket */}
        <rect x="11" y="40" width="42" height="16" rx="1" fill="#333333" stroke="#94A3B8" strokeWidth="1" strokeDasharray="2 2" />
        <ellipse cx="25" cy="48" rx="8" ry="3" fill="#4B5563" stroke="#D1D5DB" strokeWidth="0.8" />
        <ellipse cx="39" cy="48" rx="6" ry="3" fill="#4B5563" stroke="#D1D5DB" strokeWidth="0.8" />
        <rect x="12" y="58" width="40" height="3" fill="#1F2937" />
      </svg>
    );
  }

  // 0c. CORNER CABINET (L-Shape / Diagonal / Carousel) (وحدات الزاوية والركن)
  if (category === 'kitchen_corner' || accessoryType === 'corner_carousel' || accessoryType === 'corner_magic' || templateId.includes('corner')) {
    const isWallCorner = category === 'kitchen_wall' || templateId.includes('wall');
    return (
      <svg viewBox="0 0 64 64" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* L-Shape Isometric Cabinet outline */}
        <path d="M12 16 H36 V30 H52 V54 H12 Z" fill="#2A2A2A" stroke="#38BDF8" strokeWidth="1.5" strokeLinejoin="round" />
        {/* Diagonal Corner Chamfer / Carousel hint */}
        <path d="M36 30 L52 54" stroke="#F59E0B" strokeWidth="1.5" strokeDasharray="2 2" />
        <circle cx="30" cy="36" r="10" stroke="#93C5FD" strokeWidth="1" strokeDasharray="3 2" fill="none" />
        <circle cx="30" cy="36" r="2.5" fill="#F59E0B" />
        {/* Bi-fold doors seam */}
        <line x1="24" y1="16" x2="24" y2="54" stroke="#666" strokeWidth="1" />
        <line x1="12" y1="35" x2="36" y2="35" stroke="#666" strokeWidth="1" />
        {/* Angle Badge */}
        <text x="16" y="28" fill="#38BDF8" fontSize="8" fontWeight="bold" fontFamily="monospace">90°</text>
      </svg>
    );
  }

  // 0d. BEDROOM BED & HEADBOARD (سرير غرف نوم)
  if (category === 'bedroom_bed' || accessoryType === 'bed_headboard' || templateId.includes('bed')) {
    return (
      <svg viewBox="0 0 64 64" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* Upholstered Headboard */}
        <rect x="8" y="10" width="48" height="20" rx="3" fill="#475569" stroke="#94A3B8" strokeWidth="1.5" />
        {/* Tufted pattern */}
        <line x1="16" y1="10" x2="16" y2="30" stroke="#64748B" strokeWidth="1" strokeDasharray="2 2" />
        <line x1="24" y1="10" x2="24" y2="30" stroke="#64748B" strokeWidth="1" strokeDasharray="2 2" />
        <line x1="32" y1="10" x2="32" y2="30" stroke="#64748B" strokeWidth="1" strokeDasharray="2 2" />
        <line x1="40" y1="10" x2="40" y2="30" stroke="#64748B" strokeWidth="1" strokeDasharray="2 2" />
        <line x1="48" y1="10" x2="48" y2="30" stroke="#64748B" strokeWidth="1" strokeDasharray="2 2" />
        {/* Mattress Base */}
        <rect x="12" y="26" width="40" height="28" rx="2" fill="#E2E8F0" stroke="#CBD5E1" strokeWidth="1" />
        {/* Pillows */}
        <rect x="16" y="28" width="14" height="8" rx="2" fill="#FFFFFF" stroke="#94A3B8" strokeWidth="0.8" />
        <rect x="34" y="28" width="14" height="8" rx="2" fill="#FFFFFF" stroke="#94A3B8" strokeWidth="0.8" />
        {/* Duvet / Blanket fold */}
        <path d="M12 38 H52 V54 H12 Z" fill="#93C5FD" fillOpacity="0.4" stroke="#60A5FA" strokeWidth="1" />
      </svg>
    );
  }

  // 1. SINK UNIT (Single, Double, Granite, Workstation, Farmhouse)
  if (
    accessoryType === 'sink' ||
    accessoryType === 'sink_double' ||
    accessoryType === 'sink_granite' ||
    accessoryType === 'sink_workstation' ||
    accessoryType === 'sink_farmhouse' ||
    templateId.includes('sink')
  ) {
    return (
      <svg viewBox="0 0 64 64" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* Carcase */}
        <rect x="8" y="18" width="48" height="40" rx="2" fill="#2A2A2A" stroke="#555" strokeWidth="1.5" />
        {/* Double Doors */}
        <rect x="10" y="24" width="21" height="32" rx="1" fill="#383838" stroke="#666" strokeWidth="1" />
        <rect x="33" y="24" width="21" height="32" rx="1" fill="#383838" stroke="#666" strokeWidth="1" />
        {/* Handles */}
        <line x1="28" y1="36" x2="28" y2="44" stroke="#D1D5DB" strokeWidth="1.5" strokeLinecap="round" />
        <line x1="36" y1="36" x2="36" y2="44" stroke="#D1D5DB" strokeWidth="1.5" strokeLinecap="round" />
        {/* Countertop */}
        <rect x="6" y="16" width="52" height="4" rx="1" fill="#E5E7EB" stroke="#9CA3AF" strokeWidth="1" />
        {/* Sink Basin */}
        <rect x="18" y="17" width="28" height="3" rx="1" fill="#60A5FA" />
        {/* Faucet */}
        <path d="M32 16 V8 Q32 5 36 5 Q38 5 38 8 V11" stroke="#93C5FD" strokeWidth="1.5" strokeLinecap="round" fill="none" />
        {/* Plinth */}
        <rect x="12" y="58" width="40" height="3" fill="#1F2937" />
      </svg>
    );
  }

  // 2. OVEN & COOKTOP
  if (accessoryType === 'oven' || accessoryType === 'cooktop' || accessoryType === 'cooktop_gas' || templateId.includes('oven')) {
    return (
      <svg viewBox="0 0 64 64" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="8" y="18" width="48" height="40" rx="2" fill="#1E1E1E" stroke="#555" strokeWidth="1.5" />
        {/* Countertop */}
        <rect x="6" y="16" width="52" height="4" rx="1" fill="#D1D5DB" />
        {/* Cooktop Burners */}
        <circle cx="22" cy="18" r="2" fill="#F87171" />
        <circle cx="42" cy="18" r="2" fill="#F87171" />
        {/* Oven Glass Door */}
        <rect x="12" y="24" width="40" height="32" rx="2" fill="#111827" stroke="#9CA3AF" strokeWidth="1" />
        <rect x="16" y="30" width="32" height="20" rx="1" fill="#374151" stroke="#F59E0B" strokeWidth="1" strokeDasharray="2 2" />
        {/* Oven Handle */}
        <line x1="18" y1="27" x2="46" y2="27" stroke="#E5E7EB" strokeWidth="2" strokeLinecap="round" />
        {/* Knobs */}
        <circle cx="18" cy="21" r="1.5" fill="#9CA3AF" />
        <circle cx="26" cy="21" r="1.5" fill="#9CA3AF" />
        <circle cx="38" cy="21" r="1.5" fill="#9CA3AF" />
        <circle cx="46" cy="21" r="1.5" fill="#9CA3AF" />
        {/* Plinth */}
        <rect x="12" y="58" width="40" height="3" fill="#1F2937" />
      </svg>
    );
  }

  // 3. COOKER HOOD
  if (accessoryType === 'hood' || accessoryType === 'hood_pyramid' || templateId.includes('hood')) {
    return (
      <svg viewBox="0 0 64 64" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* Chimney */}
        <rect x="24" y="6" width="16" height="24" fill="#4B5563" stroke="#6B7280" strokeWidth="1" />
        {/* Pyramid Hood Canopy */}
        <path d="M10 44 L22 30 H42 L54 44 Z" fill="#374151" stroke="#9CA3AF" strokeWidth="1.5" />
        <rect x="8" y="44" width="48" height="6" rx="1" fill="#4B5563" stroke="#D1D5DB" strokeWidth="1" />
        {/* Light Glow */}
        <polygon points="12,50 4,62 60,62 52,50" fill="url(#hoodGlow)" opacity="0.2" />
        <defs>
          <linearGradient id="hoodGlow" x1="32" y1="50" x2="32" y2="62" gradientUnits="userSpaceOnUse">
            <stop stopColor="#FDE047" />
            <stop offset="1" stopColor="#FDE047" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>
    );
  }

  // 4. REFRIGERATOR
  if (accessoryType === 'refrigerator' || accessoryType === 'refrigerator_french' || templateId.includes('fridge')) {
    return (
      <svg viewBox="0 0 64 64" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="12" y="6" width="40" height="54" rx="3" fill="#374151" stroke="#9CA3AF" strokeWidth="1.5" />
        {/* Top Doors / French Doors */}
        <rect x="14" y="8" width="17" height="30" rx="1" fill="#4B5563" stroke="#6B7280" />
        <rect x="33" y="8" width="17" height="30" rx="1" fill="#4B5563" stroke="#6B7280" />
        {/* Water Dispenser */}
        <rect x="17" y="16" width="10" height="12" rx="1" fill="#1F2937" stroke="#60A5FA" strokeWidth="0.8" />
        {/* Bottom Freezer Drawer */}
        <rect x="14" y="40" width="36" height="18" rx="1" fill="#4B5563" stroke="#6B7280" />
        {/* Handles */}
        <line x1="30" y1="12" x2="30" y2="34" stroke="#E5E7EB" strokeWidth="1.5" strokeLinecap="round" />
        <line x1="34" y1="12" x2="34" y2="34" stroke="#E5E7EB" strokeWidth="1.5" strokeLinecap="round" />
        <line x1="20" y1="44" x2="44" y2="44" stroke="#E5E7EB" strokeWidth="1.5" strokeLinecap="round" />
      </svg>
    );
  }

  // 5. DRAWERS UNITS (3 or 4 Drawers)
  if (defaultDrawers && defaultDrawers >= 2) {
    const is3 = defaultDrawers === 3;
    return (
      <svg viewBox="0 0 64 64" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="8" y="18" width="48" height="40" rx="2" fill="#2A2A2A" stroke="#555" strokeWidth="1.5" />
        {/* Countertop */}
        <rect x="6" y="16" width="52" height="4" rx="1" fill="#D1D5DB" />
        {is3 ? (
          <>
            {/* Top small drawer */}
            <rect x="10" y="22" width="44" height="10" rx="1" fill="#3B3B3B" stroke="#666" />
            <line x1="26" y1="27" x2="38" y2="27" stroke="#E5E7EB" strokeWidth="1.5" strokeLinecap="round" />
            {/* Middle deep drawer */}
            <rect x="10" y="34" width="44" height="11" rx="1" fill="#3B3B3B" stroke="#666" />
            <line x1="26" y1="39.5" x2="38" y2="39.5" stroke="#E5E7EB" strokeWidth="1.5" strokeLinecap="round" />
            {/* Bottom deep drawer */}
            <rect x="10" y="47" width="44" height="11" rx="1" fill="#3B3B3B" stroke="#666" />
            <line x1="26" y1="52.5" x2="38" y2="52.5" stroke="#E5E7EB" strokeWidth="1.5" strokeLinecap="round" />
          </>
        ) : (
          <>
            {/* 4 Drawers */}
            <rect x="10" y="22" width="44" height="7.5" rx="1" fill="#3B3B3B" stroke="#666" />
            <line x1="27" y1="25.5" x2="37" y2="25.5" stroke="#E5E7EB" strokeWidth="1.2" strokeLinecap="round" />
            <rect x="10" y="31" width="44" height="7.5" rx="1" fill="#3B3B3B" stroke="#666" />
            <line x1="27" y1="34.5" x2="37" y2="34.5" stroke="#E5E7EB" strokeWidth="1.2" strokeLinecap="round" />
            <rect x="10" y="40" width="44" height="7.5" rx="1" fill="#3B3B3B" stroke="#666" />
            <line x1="27" y1="43.5" x2="37" y2="43.5" stroke="#E5E7EB" strokeWidth="1.2" strokeLinecap="round" />
            <rect x="10" y="49" width="44" height="7.5" rx="1" fill="#3B3B3B" stroke="#666" />
            <line x1="27" y1="52.5" x2="37" y2="52.5" stroke="#E5E7EB" strokeWidth="1.2" strokeLinecap="round" />
          </>
        )}
        {/* Plinth */}
        <rect x="12" y="58" width="40" height="3" fill="#1F2937" />
      </svg>
    );
  }

  // 6. 1 DRAWER + 1 DOOR
  if (defaultDrawers === 1 && defaultDoors === 1) {
    return (
      <svg viewBox="0 0 64 64" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="10" y="18" width="44" height="40" rx="2" fill="#2A2A2A" stroke="#555" strokeWidth="1.5" />
        <rect x="8" y="16" width="48" height="4" rx="1" fill="#D1D5DB" />
        {/* Top Drawer */}
        <rect x="12" y="22" width="40" height="9" rx="1" fill="#3B3B3B" stroke="#666" />
        <line x1="26" y1="26.5" x2="38" y2="26.5" stroke="#E5E7EB" strokeWidth="1.5" strokeLinecap="round" />
        {/* Bottom Door */}
        <rect x="12" y="33" width="40" height="23" rx="1" fill="#383838" stroke="#666" />
        <line x1="46" y1="40" x2="46" y2="48" stroke="#E5E7EB" strokeWidth="1.5" strokeLinecap="round" />
        <rect x="14" y="58" width="36" height="3" fill="#1F2937" />
      </svg>
    );
  }

  // 7. WALL GLASS CABINET
  if (templateId.includes('glass') || template.name.toLowerCase().includes('glass')) {
    return (
      <svg viewBox="0 0 64 64" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="10" y="12" width="44" height="42" rx="2" fill="#1F2937" stroke="#60A5FA" strokeWidth="1.5" />
        {/* Glass Frame Doors */}
        <rect x="12" y="14" width="19" height="38" rx="1" fill="#374151" stroke="#4B5563" />
        <rect x="15" y="17" width="13" height="32" rx="1" fill="#93C5FD" fillOpacity="0.25" stroke="#60A5FA" strokeWidth="0.8" />
        <line x1="15" y1="33" x2="28" y2="33" stroke="#60A5FA" strokeWidth="0.8" strokeOpacity="0.7" />

        <rect x="33" y="14" width="19" height="38" rx="1" fill="#374151" stroke="#4B5563" />
        <rect x="36" y="17" width="13" height="32" rx="1" fill="#93C5FD" fillOpacity="0.25" stroke="#60A5FA" strokeWidth="0.8" />
        <line x1="36" y1="33" x2="49" y2="33" stroke="#60A5FA" strokeWidth="0.8" strokeOpacity="0.7" />

        {/* LED Glow under */}
        <rect x="12" y="54" width="40" height="2" fill="#FDE047" opacity="0.8" />
      </svg>
    );
  }

  // 8. WALL LIFT UP (AVENTOS)
  if (templateId.includes('lift') || template.name.toLowerCase().includes('lift')) {
    return (
      <svg viewBox="0 0 64 64" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="6" y="16" width="52" height="36" rx="2" fill="#262626" stroke="#555" strokeWidth="1.5" />
        {/* Top flap */}
        <rect x="8" y="18" width="48" height="15" rx="1" fill="#3B3B3B" stroke="#666" />
        <line x1="26" y1="30" x2="38" y2="30" stroke="#E5E7EB" strokeWidth="1.5" strokeLinecap="round" />
        {/* Bottom flap */}
        <rect x="8" y="35" width="48" height="15" rx="1" fill="#3B3B3B" stroke="#666" />
        <line x1="26" y1="47" x2="38" y2="47" stroke="#E5E7EB" strokeWidth="1.5" strokeLinecap="round" />
        <path d="M52 24 L56 20 M52 41 L56 37" stroke="#F59E0B" strokeWidth="1.5" strokeLinecap="round" />
      </svg>
    );
  }

  // 9. KITCHEN TALL PANTRY / TALL OVEN
  if (category === 'kitchen_tall') {
    return (
      <svg viewBox="0 0 64 64" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="14" y="6" width="36" height="54" rx="2" fill="#262626" stroke="#666" strokeWidth="1.5" />
        {/* Top door */}
        <rect x="16" y="8" width="32" height="16" rx="1" fill="#383838" stroke="#555" />
        {/* Middle appliance / microwave slot */}
        <rect x="16" y="26" width="32" height="14" rx="1" fill="#111827" stroke="#F59E0B" strokeWidth="1" />
        <line x1="20" y1="33" x2="44" y2="33" stroke="#9CA3AF" strokeWidth="1" strokeDasharray="1 1" />
        {/* Bottom deep drawers/door */}
        <rect x="16" y="42" width="32" height="16" rx="1" fill="#383838" stroke="#555" />
        <line x1="42" y1="12" x2="42" y2="20" stroke="#E5E7EB" strokeWidth="1.5" strokeLinecap="round" />
        <line x1="42" y1="46" x2="42" y2="54" stroke="#E5E7EB" strokeWidth="1.5" strokeLinecap="round" />
        <rect x="16" y="60" width="32" height="2" fill="#1F2937" />
      </svg>
    );
  }

  // 10. BEDROOM WARDROBE (MASTER / SLIDING)
  if (category === 'bedroom_wardrobe') {
    const isSliding = templateId.includes('sliding');
    return (
      <svg viewBox="0 0 64 64" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="10" y="6" width="44" height="54" rx="2" fill="#2A2A2A" stroke="#777" strokeWidth="1.5" />
        {isSliding ? (
          <>
            {/* Sliding Door 1 */}
            <rect x="12" y="8" width="22" height="50" rx="1" fill="#3E3E3E" stroke="#555" />
            <line x1="30" y1="20" x2="30" y2="46" stroke="#D1D5DB" strokeWidth="2" strokeLinecap="round" />
            {/* Sliding Door 2 (Overlapping) */}
            <rect x="30" y="8" width="22" height="50" rx="1" fill="#343434" stroke="#888" strokeWidth="1.2" />
            <line x1="34" y1="20" x2="34" y2="46" stroke="#D1D5DB" strokeWidth="2" strokeLinecap="round" />
            {/* Top track */}
            <line x1="10" y1="8" x2="54" y2="8" stroke="#A855F7" strokeWidth="1.5" />
          </>
        ) : (
          <>
            {/* 3 Hinged Doors */}
            <rect x="12" y="8" width="12.5" height="50" rx="1" fill="#3A3A3A" stroke="#555" />
            <line x1="22" y1="28" x2="22" y2="38" stroke="#E5E7EB" strokeWidth="1.5" strokeLinecap="round" />
            <rect x="26" y="8" width="12.5" height="50" rx="1" fill="#3A3A3A" stroke="#555" />
            <line x1="28" y1="28" x2="28" y2="38" stroke="#E5E7EB" strokeWidth="1.5" strokeLinecap="round" />
            <rect x="40" y="8" width="12.5" height="50" rx="1" fill="#3A3A3A" stroke="#555" />
            <line x1="49" y1="28" x2="49" y2="38" stroke="#E5E7EB" strokeWidth="1.5" strokeLinecap="round" />
          </>
        )}
      </svg>
    );
  }

  // 11. NIGHTSTAND / DRESSING VANITY / CHEST
  if (category === 'bedroom_nightstand' || category === 'bedroom_dressing' || category === 'bedroom_drawer') {
    return (
      <svg viewBox="0 0 64 64" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="12" y="24" width="40" height="34" rx="2" fill="#2D2D2D" stroke="#666" strokeWidth="1.5" />
        {/* Countertop */}
        <rect x="10" y="22" width="44" height="4" rx="1" fill="#E5E7EB" />
        {/* Drawers */}
        <rect x="14" y="28" width="36" height="12" rx="1" fill="#3F3F3F" stroke="#555" />
        <circle cx="32" cy="34" r="1.5" fill="#E5E7EB" />
        <rect x="14" y="42" width="36" height="13" rx="1" fill="#3F3F3F" stroke="#555" />
        <circle cx="32" cy="48.5" r="1.5" fill="#E5E7EB" />
        {/* Legs */}
        <line x1="16" y1="58" x2="14" y2="63" stroke="#D97706" strokeWidth="2" strokeLinecap="round" />
        <line x1="48" y1="58" x2="50" y2="63" stroke="#D97706" strokeWidth="2" strokeLinecap="round" />
      </svg>
    );
  }

  // 12. DEFAULT BASE/WALL CABINET (1 or 2 Doors)
  const isDouble = defaultDoors === 2;
  const isWall = category === 'kitchen_wall';

  return (
    <svg viewBox="0 0 64 64" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect
        x={isWall ? "10" : "8"}
        y={isWall ? "12" : "18"}
        width={isWall ? "44" : "48"}
        height={isWall ? "44" : "40"}
        rx="2"
        fill="#2A2A2A"
        stroke="#555"
        strokeWidth="1.5"
      />
      {!isWall && <rect x="6" y="16" width="52" height="4" rx="1" fill="#D1D5DB" />}
      {isDouble ? (
        <>
          <rect x={isWall ? "12" : "10"} y={isWall ? "14" : "24"} width={isWall ? "19" : "21"} height={isWall ? "40" : "32"} rx="1" fill="#383838" stroke="#666" />
          <line x1={isWall ? "27" : "28"} y1="36" x2={isWall ? "27" : "28"} y2="44" stroke="#D1D5DB" strokeWidth="1.5" strokeLinecap="round" />
          <rect x={isWall ? "33" : "33"} y={isWall ? "14" : "24"} width={isWall ? "19" : "21"} height={isWall ? "40" : "32"} rx="1" fill="#383838" stroke="#666" />
          <line x1={isWall ? "37" : "36"} y1="36" x2={isWall ? "37" : "36"} y2="44" stroke="#D1D5DB" strokeWidth="1.5" strokeLinecap="round" />
        </>
      ) : (
        <>
          <rect x={isWall ? "12" : "10"} y={isWall ? "14" : "24"} width={isWall ? "40" : "44"} height={isWall ? "40" : "32"} rx="1" fill="#383838" stroke="#666" />
          <line x1={isWall ? "46" : "48"} y1="36" x2={isWall ? "46" : "48"} y2="44" stroke="#D1D5DB" strokeWidth="1.5" strokeLinecap="round" />
        </>
      )}
      {!isWall && <rect x="12" y="58" width="40" height="3" fill="#1F2937" />}
    </svg>
  );
};
