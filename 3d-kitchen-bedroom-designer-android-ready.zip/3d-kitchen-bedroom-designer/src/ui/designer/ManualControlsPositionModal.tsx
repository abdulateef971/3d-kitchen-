import React from 'react';
import {
  X,
  ArrowLeftRight,
  Sliders,
  Check,
  RotateCcw,
  Footprints,
  Compass,
  Layers,
  Smartphone,
  Move,
} from 'lucide-react';

export interface ControlsLayoutConfig {
  walkSide: 'left' | 'right' | 'hidden';
  rotateSide: 'left' | 'right' | 'hidden';
  actionSide: 'left' | 'right';
  toolsSide: 'left' | 'right';
  verticalOffset: 'low' | 'medium' | 'high';
}

interface ManualControlsPositionModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: ControlsLayoutConfig;
  onChangeConfig: (newConfig: ControlsLayoutConfig) => void;
  onQuickSwap: () => void;
}

export const ManualControlsPositionModal: React.FC<ManualControlsPositionModalProps> = ({
  isOpen,
  onClose,
  config,
  onChangeConfig,
  onQuickSwap,
}) => {
  if (!isOpen) return null;

  const update = (partial: Partial<ControlsLayoutConfig>) => {
    const updated = { ...config, ...partial };
    onChangeConfig(updated);
  };

  const handleApplyPreset = (preset: 'default' | 'inverted' | 'rightHand' | 'leftHand') => {
    if (preset === 'default') {
      onChangeConfig({
        walkSide: 'right',
        rotateSide: 'left',
        actionSide: 'right',
        toolsSide: 'left',
        verticalOffset: 'medium',
      });
    } else if (preset === 'inverted') {
      onChangeConfig({
        walkSide: 'left',
        rotateSide: 'right',
        actionSide: 'left',
        toolsSide: 'right',
        verticalOffset: 'medium',
      });
    } else if (preset === 'rightHand') {
      onChangeConfig({
        walkSide: 'right',
        rotateSide: 'right',
        actionSide: 'right',
        toolsSide: 'left',
        verticalOffset: 'medium',
      });
    } else if (preset === 'leftHand') {
      onChangeConfig({
        walkSide: 'left',
        rotateSide: 'left',
        actionSide: 'left',
        toolsSide: 'right',
        verticalOffset: 'medium',
      });
    }
  };

  return (
    <div
      onPointerDown={(e) => e.stopPropagation()}
      onClick={onClose}
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 font-['Cairo',sans-serif]"
      dir="rtl"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="bg-[#121620] border border-[#2B384E] rounded-3xl p-5 sm:p-6 w-full max-w-lg shadow-2xl flex flex-col gap-4 text-white animate-in zoom-in-95 duration-200"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#253043] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center shadow-lg shadow-amber-900/40 text-white font-black">
              <ArrowLeftRight className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-white">
                تبديل وتخصيص أماكن الأزرار يدوياً
              </h2>
              <p className="text-[11px] text-gray-400">
                حدد بدقة موقع كل عصا أنالوج وزر إجراءات على الشاشة حسب رغبتك
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-gray-800 text-gray-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Instant Swap Button */}
        <button
          onClick={onQuickSwap}
          className="w-full py-2.5 px-4 rounded-2xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/50 text-xs font-bold flex items-center justify-center gap-2 shadow-md transition active:scale-98"
        >
          <ArrowLeftRight className="w-4 h-4" />
          <span>عكس أماكن أزرار المشي والتدوير فوراً ⇄</span>
        </button>

        {/* Presets Grid */}
        <div className="flex flex-col gap-1.5">
          <span className="text-[11px] font-bold text-gray-300">أوضاع سريعة جاهزة:</span>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-xs">
            <button
              onClick={() => handleApplyPreset('default')}
              className="p-2 rounded-xl bg-[#171E2B] hover:bg-[#222B3D] border border-[#2B374A] text-center transition"
            >
              <span className="block font-bold text-white text-[11px]">الافتراضي</span>
              <span className="text-[9px] text-gray-400">مشي يمين • تدوير يسار</span>
            </button>

            <button
              onClick={() => handleApplyPreset('inverted')}
              className="p-2 rounded-xl bg-[#171E2B] hover:bg-[#222B3D] border border-[#2B374A] text-center transition"
            >
              <span className="block font-bold text-amber-300 text-[11px]">المعكوس ⇄</span>
              <span className="text-[9px] text-gray-400">مشي يسار • تدوير يمين</span>
            </button>

            <button
              onClick={() => handleApplyPreset('rightHand')}
              className="p-2 rounded-xl bg-[#171E2B] hover:bg-[#222B3D] border border-[#2B374A] text-center transition"
            >
              <span className="block font-bold text-blue-300 text-[11px]">اليد اليمنى</span>
              <span className="text-[9px] text-gray-400">كل الأزرار يميناً</span>
            </button>

            <button
              onClick={() => handleApplyPreset('leftHand')}
              className="p-2 rounded-xl bg-[#171E2B] hover:bg-[#222B3D] border border-[#2B374A] text-center transition"
            >
              <span className="block font-bold text-emerald-300 text-[11px]">اليد اليسرى</span>
              <span className="text-[9px] text-gray-400">كل الأزرار يساراً</span>
            </button>
          </div>
        </div>

        {/* Granular Manual Element Settings */}
        <div className="bg-[#0E121B] border border-[#232C3C] rounded-2xl p-3 flex flex-col gap-3">
          <span className="text-xs font-bold text-gray-200">التخصيص اليدوي لكل عنصر:</span>

          {/* 1. Walk Joystick Position */}
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-emerald-400 font-bold">
              <Footprints className="w-4 h-4" />
              <span>عصا المشي والتنقل:</span>
            </div>
            <div className="flex items-center gap-1 bg-[#171E2A] p-0.5 rounded-xl border border-[#2A3648]">
              <button
                onClick={() => update({ walkSide: 'left' })}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                  config.walkSide === 'left' ? 'bg-emerald-600 text-white shadow-sm' : 'text-gray-400'
                }`}
              >
                اليسار
              </button>
              <button
                onClick={() => update({ walkSide: 'right' })}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                  config.walkSide === 'right' ? 'bg-emerald-600 text-white shadow-sm' : 'text-gray-400'
                }`}
              >
                اليمين
              </button>
              <button
                onClick={() => update({ walkSide: 'hidden' })}
                className={`px-2 py-1 rounded-lg text-[10px] font-bold transition ${
                  config.walkSide === 'hidden' ? 'bg-red-600 text-white' : 'text-gray-500'
                }`}
              >
                إخفاء
              </button>
            </div>
          </div>

          {/* 2. Rotate Joystick Position */}
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-blue-400 font-bold">
              <Compass className="w-4 h-4" />
              <span>عصا التدوير 360° والكاميرا:</span>
            </div>
            <div className="flex items-center gap-1 bg-[#171E2A] p-0.5 rounded-xl border border-[#2A3648]">
              <button
                onClick={() => update({ rotateSide: 'left' })}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                  config.rotateSide === 'left' ? 'bg-blue-600 text-white shadow-sm' : 'text-gray-400'
                }`}
              >
                اليسار
              </button>
              <button
                onClick={() => update({ rotateSide: 'right' })}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                  config.rotateSide === 'right' ? 'bg-blue-600 text-white shadow-sm' : 'text-gray-400'
                }`}
              >
                اليمين
              </button>
              <button
                onClick={() => update({ rotateSide: 'hidden' })}
                className={`px-2 py-1 rounded-lg text-[10px] font-bold transition ${
                  config.rotateSide === 'hidden' ? 'bg-red-600 text-white' : 'text-gray-500'
                }`}
              >
                إخفاء
              </button>
            </div>
          </div>

          {/* 3. Action Toolbar (Zoom / Fit / Reset) */}
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-purple-400 font-bold">
              <Sliders className="w-4 h-4" />
              <span>أزرار التقريب والإجراءات السريعة:</span>
            </div>
            <div className="flex items-center gap-1 bg-[#171E2A] p-0.5 rounded-xl border border-[#2A3648]">
              <button
                onClick={() => update({ actionSide: 'left' })}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                  config.actionSide === 'left' ? 'bg-purple-600 text-white shadow-sm' : 'text-gray-400'
                }`}
              >
                اليسار
              </button>
              <button
                onClick={() => update({ actionSide: 'right' })}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                  config.actionSide === 'right' ? 'bg-purple-600 text-white shadow-sm' : 'text-gray-400'
                }`}
              >
                اليمين
              </button>
            </div>
          </div>

          {/* 4. CAD Tools Side */}
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-cyan-400 font-bold">
              <Layers className="w-4 h-4" />
              <span>شريط أدوات الرسم CAD:</span>
            </div>
            <div className="flex items-center gap-1 bg-[#171E2A] p-0.5 rounded-xl border border-[#2A3648]">
              <button
                onClick={() => update({ toolsSide: 'left' })}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                  config.toolsSide === 'left' ? 'bg-cyan-600 text-white shadow-sm' : 'text-gray-400'
                }`}
              >
                اليسار
              </button>
              <button
                onClick={() => update({ toolsSide: 'right' })}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                  config.toolsSide === 'right' ? 'bg-cyan-600 text-white shadow-sm' : 'text-gray-400'
                }`}
              >
                اليمين
              </button>
            </div>
          </div>

          {/* 5. Vertical Height from Bottom */}
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-gray-300 font-bold">
              <Move className="w-4 h-4" />
              <span>ارتفاع الأزرار عن الأسفل:</span>
            </div>
            <div className="flex items-center gap-1 bg-[#171E2A] p-0.5 rounded-xl border border-[#2A3648]">
              <button
                onClick={() => update({ verticalOffset: 'low' })}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                  config.verticalOffset === 'low' ? 'bg-gray-600 text-white' : 'text-gray-400'
                }`}
              >
                منخفض
              </button>
              <button
                onClick={() => update({ verticalOffset: 'medium' })}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                  config.verticalOffset === 'medium' ? 'bg-blue-600 text-white' : 'text-gray-400'
                }`}
              >
                متوسط
              </button>
              <button
                onClick={() => update({ verticalOffset: 'high' })}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                  config.verticalOffset === 'high' ? 'bg-indigo-600 text-white' : 'text-gray-400'
                }`}
              >
                مرتفع
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-2 flex items-center justify-between">
          <button
            onClick={() => handleApplyPreset('default')}
            className="text-xs text-gray-400 hover:text-white flex items-center gap-1"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>إعادة ضبط للافتراضي</span>
          </button>

          <button
            onClick={onClose}
            className="px-6 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md shadow-blue-900/40 transition"
          >
            حفظ وإغلاق ✓
          </button>
        </div>
      </div>
    </div>
  );
};
