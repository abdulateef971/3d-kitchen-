import React, { useState } from 'react';
import {
  X,
  Undo2,
  Share2,
  FolderOpen,
  Sparkles,
  HelpCircle,
  SunMedium,
  Palette,
  Check,
  ChevronDown,
  Compass,
  Footprints,
  Gamepad2,
  Box,
  Layout,
  Camera,
  Video,
  Layers,
  DoorOpen,
  Sliders,
} from 'lucide-react';

export interface RoomPlannerHeaderProps {
  onClose?: () => void;
  onBack?: () => void;
  onUndo?: () => void;
  canUndo?: boolean;
  onShareOrExport?: () => void;
  onExport?: () => void;
  onOpenStyleQuiz?: () => void;
  onOpenHelp?: () => void;
  onOpenHelpGuide?: () => void;
  onOpenLighting?: () => void;
  onOpenMaterials?: () => void;
  onOpenProjectSwitcher?: () => void;
  onSave?: () => void;
  onOpenRoomSetup?: () => void;
  onOpenGameMode?: () => void;
  onOpenVideoWalkthrough?: () => void;
  onCaptureSnapshot?: () => void;
  onToggleDoors?: () => void;
  areDoorsOpen?: boolean;
  onOpenUnitProperties?: () => void;
  onOpenAIGenerator?: () => void;
  selectedUnitName?: string | null;
  cameraMode?: '360' | 'walk';
  onChangeCameraMode?: (mode: '360' | 'walk') => void;
  onCameraModeChange?: (mode: '360' | 'walk') => void;
  viewMode?: '3d' | '2d';
  onChangeViewMode?: (mode: '3d' | '2d') => void;
  projectName?: string;
  projectDimensions?: string;
  onToggleWide05?: () => void;
  isWide05?: boolean;
}

export const RoomPlannerHeader: React.FC<RoomPlannerHeaderProps> = ({
  onClose,
  onBack,
  onUndo,
  canUndo = true,
  onShareOrExport,
  onExport,
  onOpenStyleQuiz,
  onOpenHelp,
  onOpenHelpGuide,
  onOpenLighting,
  onOpenMaterials,
  onOpenProjectSwitcher,
  onSave,
  onOpenRoomSetup,
  onOpenGameMode,
  onOpenVideoWalkthrough,
  onCaptureSnapshot,
  onToggleDoors,
  areDoorsOpen = false,
  onOpenUnitProperties,
  onOpenAIGenerator,
  selectedUnitName,
  cameraMode = '360',
  onChangeCameraMode,
  onCameraModeChange,
  viewMode = '3d',
  onChangeViewMode,
  projectName = 'مطبخي العصري',
  projectDimensions = '6م × 5م',
  onToggleWide05,
  isWide05 = false,
}) => {
  const [isExtrasOpen, setIsExtrasOpen] = useState(false);

  const handleCloseAction = onClose || onBack || (() => {});
  const handleExportAction = onShareOrExport || onExport || onSave || (() => {});
  const handleHelpAction = onOpenHelp || onOpenHelpGuide || (() => {});

  const handleViewSwitch = (mode: '3d' | '2d') => {
    onChangeViewMode?.(mode);
  };

  return (
    <header
      id="room-planner-header"
      className="absolute top-3 inset-x-0 z-40 px-3 sm:px-6 flex items-center justify-between pointer-events-none select-none max-w-7xl mx-auto gap-2"
    >
      {/* ----------------------------------------------------------------- */}
      {/* 1. LEFT SIDE: Home, Camera, 'إضافات' Shortcut Button, Fast Tools */}
      {/* ----------------------------------------------------------------- */}
      <div className="pointer-events-auto flex items-center gap-2">
        {/* Home / Back Button */}
        <button
          type="button"
          id="btn-close-designer"
          onClick={handleCloseAction}
          className="w-10 h-10 rounded-full bg-[#1C1C1E]/90 hover:bg-[#2C2C2E] text-zinc-300 hover:text-white border border-white/10 shadow-xl flex items-center justify-center transition-all active:scale-95 shrink-0"
          title="العودة للمشاريع الرئيسية"
          aria-label="Back"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Camera Snapshot Button */}
        <button
          type="button"
          id="btn-camera-snapshot"
          onClick={onCaptureSnapshot || handleExportAction}
          className="w-10 h-10 rounded-full bg-[#1C1C1E]/90 hover:bg-[#2C2C2E] text-zinc-300 hover:text-white border border-white/10 shadow-xl flex items-center justify-center transition-all active:scale-95 shrink-0"
          title="التقاط لقطة شاشة عالية الدقة"
        >
          <Camera className="w-4 h-4 text-blue-400" />
        </button>

        {/* 0.5x Camera Button in Header (User Request: مع كامر 0.5) */}
        {onToggleWide05 && viewMode === '3d' && (
          <button
            type="button"
            id="btn-header-wide-05"
            onClick={onToggleWide05}
            className={`h-10 px-3 rounded-full border shadow-xl flex items-center gap-1.5 transition-all active:scale-95 shrink-0 text-xs font-black ${
              isWide05
                ? 'bg-blue-600 hover:bg-blue-500 text-white border-blue-300 shadow-blue-900/50 ring-2 ring-blue-400/50'
                : 'bg-[#1C1C1E]/90 hover:bg-[#2C2C2E] text-zinc-300 hover:text-white border-white/10'
            }`}
            title="كاميرا 0.5x بزاوية واسعة جداً (Ultra-Wide 88° FOV)"
          >
            <span className="font-mono text-xs font-black text-amber-300">0.5x</span>
            <span className="hidden md:inline text-[11px]">كاميرا</span>
          </button>
        )}

        {/* زر مختصر باسم "إضافات" لإظهار أو إخفاء كافة الأدوات على الشاشة (User Request) */}
        <div className="relative">
          <button
            type="button"
            id="btn-extras-menu-toggle"
            onClick={() => setIsExtrasOpen(!isExtrasOpen)}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-full border text-xs font-bold transition-all shadow-xl active:scale-95 shrink-0 ${
              isExtrasOpen
                ? 'bg-blue-600 text-white border-blue-400 shadow-blue-900/50'
                : 'bg-[#1C1C1E]/90 hover:bg-[#2C2C2E] text-zinc-200 border-white/15'
            }`}
            title="إظهار / إخفاء قائمة الإضافات والأدوات"
          >
            <Layers className="w-4 h-4 text-blue-400" />
            <span>إضافات</span>
            <ChevronDown
              className={`w-3.5 h-3.5 transition-transform duration-200 ${
                isExtrasOpen ? 'rotate-180 text-white' : 'text-zinc-400'
              }`}
            />
          </button>

          {/* القائمة المنبثقة الشاملة للإضافات (Extras Dropdown/Modal) */}
          {isExtrasOpen && (
            <div
              className="absolute top-12 right-0 sm:right-auto sm:left-0 z-50 w-72 sm:w-80 bg-[#18181B]/95 backdrop-blur-2xl border border-white/20 rounded-2xl shadow-2xl p-2.5 animate-in fade-in zoom-in-95 duration-150 text-right space-y-1"
              dir="rtl"
            >
              <div className="px-2.5 py-1.5 border-b border-white/10 flex items-center justify-between">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-blue-400" />
                  قائمة الإضافات والأدوات
                </span>
                <button
                  type="button"
                  onClick={() => setIsExtrasOpen(false)}
                  className="text-zinc-400 hover:text-white p-1 rounded-md"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-1 gap-1 max-h-[70vh] overflow-y-auto pt-1">
                {/* 1. Interior Lighting (نهار / ليل) */}
                {onOpenLighting && (
                  <button
                    type="button"
                    onClick={() => {
                      onOpenLighting();
                      setIsExtrasOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 p-2 rounded-xl hover:bg-white/10 text-right text-xs transition"
                  >
                    <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                      <SunMedium className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="font-bold text-white block">إعدادات الإضاءة (نهار / ليل)</span>
                      <span className="text-[10px] text-zinc-400">محاكاة تأثير الإضاءة النهارية والليلية على الخامات</span>
                    </div>
                  </button>
                )}

                {/* 2. Realistic Materials */}
                {onOpenMaterials && (
                  <button
                    type="button"
                    onClick={() => {
                      onOpenMaterials();
                      setIsExtrasOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 p-2 rounded-xl hover:bg-white/10 text-right text-xs transition"
                  >
                    <div className="w-7 h-7 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
                      <Palette className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="font-bold text-white block">خامات وتكسيات واقعية (+25)</span>
                      <span className="text-[10px] text-zinc-400">أخشاب، رخام طبيعي، وألوان مطفية ولميعة</span>
                    </div>
                  </button>
                )}

                {/* 3. AI Unit Generator */}
                {onOpenAIGenerator && (
                  <button
                    type="button"
                    onClick={() => {
                      onOpenAIGenerator();
                      setIsExtrasOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 p-2 rounded-xl hover:bg-purple-500/10 text-right text-xs transition"
                  >
                    <div className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center shrink-0">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="font-bold text-white block">توليد وحدات وأجهزة بالـ AI</span>
                      <span className="text-[10px] text-purple-300">تصميم وحدات مطابخ وأجهزة مدمجة بالذكاء الاصطناعي</span>
                    </div>
                  </button>
                )}

                {/* 4. Toggle Doors */}
                {onToggleDoors && (
                  <button
                    type="button"
                    onClick={() => {
                      onToggleDoors();
                      setIsExtrasOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 p-2 rounded-xl hover:bg-white/10 text-right text-xs transition"
                  >
                    <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                      <DoorOpen className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="font-bold text-white block">
                        {areDoorsOpen ? 'إغلاق جميع الأبواب والأدراج' : 'فتح جميع الأبواب والأدراج'}
                      </span>
                      <span className="text-[10px] text-zinc-400">معاينة تفاعلية لداخل الخزائن والأرفف</span>
                    </div>
                  </button>
                )}

                {/* 5. Unit Properties (if selected) */}
                {selectedUnitName && onOpenUnitProperties && (
                  <button
                    type="button"
                    onClick={() => {
                      onOpenUnitProperties();
                      setIsExtrasOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 p-2 rounded-xl hover:bg-blue-600/20 text-right text-xs transition border border-blue-500/30"
                  >
                    <div className="w-7 h-7 rounded-lg bg-blue-600/30 text-blue-300 flex items-center justify-center shrink-0">
                      <Sliders className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="font-bold text-white block">خصائص: {selectedUnitName}</span>
                      <span className="text-[10px] text-blue-300">تعديل الأبعاد، الأرفف، الأبواب، والخامات</span>
                    </div>
                  </button>
                )}

                {/* 6. Video Walkthrough */}
                {onOpenVideoWalkthrough && (
                  <button
                    type="button"
                    onClick={() => {
                      onOpenVideoWalkthrough();
                      setIsExtrasOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 p-2 rounded-xl hover:bg-white/10 text-right text-xs transition"
                  >
                    <div className="w-7 h-7 rounded-lg bg-red-500/20 text-red-400 flex items-center justify-center shrink-0">
                      <Video className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="font-bold text-white block">استوديو تصوير الفيديو والرندر</span>
                      <span className="text-[10px] text-zinc-400">جولة سينمائية 360 درجة عالية الدقة</span>
                    </div>
                  </button>
                )}

                {/* 7. Room Setup */}
                {onOpenRoomSetup && (
                  <button
                    type="button"
                    onClick={() => {
                      onOpenRoomSetup();
                      setIsExtrasOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 p-2 rounded-xl hover:bg-white/10 text-right text-xs transition"
                  >
                    <div className="w-7 h-7 rounded-lg bg-zinc-800 text-zinc-300 flex items-center justify-center shrink-0">
                      <Box className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="font-bold text-white block">أبعاد وجدران الغرفة</span>
                      <span className="text-[10px] text-zinc-400">تعديل الطول والعرض والارتفاع ولون الجدار</span>
                    </div>
                  </button>
                )}

                {/* 8. AI Style Quiz */}
                {onOpenStyleQuiz && (
                  <button
                    type="button"
                    onClick={() => {
                      onOpenStyleQuiz();
                      setIsExtrasOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 p-2 rounded-xl hover:bg-white/10 text-right text-xs transition"
                  >
                    <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="font-bold text-white block">المصمم الداخلي الذكي (Style Quiz)</span>
                      <span className="text-[10px] text-zinc-400">اقتراح أنماط وتنسيق ألوان تلقائي</span>
                    </div>
                  </button>
                )}

                {/* 9. Help Guide */}
                {handleHelpAction && (
                  <button
                    type="button"
                    onClick={() => {
                      handleHelpAction();
                      setIsExtrasOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 p-2 rounded-xl hover:bg-white/10 text-right text-xs transition"
                  >
                    <div className="w-7 h-7 rounded-lg bg-zinc-800 text-zinc-300 flex items-center justify-center shrink-0">
                      <HelpCircle className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="font-bold text-white block">دليل الاستخدام والمساعدة</span>
                      <span className="text-[10px] text-zinc-400">شرح أدوات المصمم وطرق التحكم</span>
                    </div>
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Pill: خامات وتكسيات (+25) (Direct desktop access) */}
        {onOpenMaterials && (
          <button
            type="button"
            onClick={onOpenMaterials}
            className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/40 text-xs font-bold text-blue-300 transition shadow-lg active:scale-95"
            title="مكتبة الخامات والتكسيات الرخامية والخشبية"
          >
            <Palette className="w-3.5 h-3.5 text-blue-400" />
            <span>خامات وتكسيات (+25)</span>
          </button>
        )}

        {/* AI Unit Generator Button (Direct desktop access) */}
        {onOpenAIGenerator && (
          <button
            type="button"
            id="btn-header-ai-generator"
            onClick={onOpenAIGenerator}
            className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white text-xs font-bold transition-all shadow-xl shadow-purple-950/40 border border-purple-400/40 active:scale-95 shrink-0"
            title="إنشاء وتوليد وحدات مطبخ وأجهزة كهربائية بالذكاء الاصطناعي"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
            <span>وحدات وأجهزة AI</span>
          </button>
        )}

        {/* Door Open / Close Button (Direct desktop access) */}
        {onToggleDoors && (
          <button
            type="button"
            id="btn-toggle-all-doors"
            onClick={onToggleDoors}
            className={`hidden sm:flex items-center gap-1.5 px-3.5 py-1.5 rounded-full border text-xs font-bold transition-all shadow-xl active:scale-95 shrink-0 ${
              areDoorsOpen
                ? 'bg-amber-500 hover:bg-amber-400 text-white border-amber-300 shadow-amber-900/50'
                : 'bg-[#1C1C1E]/90 hover:bg-[#2C2C2E] text-amber-300 hover:text-amber-200 border-amber-500/30'
            }`}
            title="فتح وإغلاق جميع الأبواب والأدراج في المطبخ"
          >
            <DoorOpen className="w-4 h-4 text-amber-400" />
            <span>{areDoorsOpen ? 'إغلاق الأبواب' : 'فتح الأبواب'}</span>
          </button>
        )}
      </div>

      {/* ----------------------------------------------------------------- */}
      {/* 2. RIGHT SIDE: 3D/2D Switcher Capsule & Project Info Status Pill  */}
      {/* ----------------------------------------------------------------- */}
      <div className="pointer-events-auto flex items-center gap-2">
        {/* Segmented Switch: [ 3D منظور ] [ 👣 المشي ] [ 2D مخطط ] */}
        <div className="p-1 rounded-full bg-[#1C1C1E]/90 backdrop-blur-xl border border-white/15 shadow-2xl flex items-center gap-1">
          {/* 3D Perspective Button */}
          <button
            type="button"
            id="btn-view-3d"
            onClick={() => {
              if (cameraMode === 'walk') {
                const fn = onChangeCameraMode || onCameraModeChange;
                fn?.('360');
              }
              handleViewSwitch('3d');
            }}
            className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 ${
              viewMode === '3d' && cameraMode !== 'walk'
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/50'
                : 'text-zinc-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Box className="w-3.5 h-3.5" />
            <span>3D منظور</span>
          </button>

          {/* Walk Mode Button in Header */}
          <button
            type="button"
            id="btn-header-walk-mode"
            onClick={() => {
              if (viewMode !== '3d') handleViewSwitch('3d');
              const fn = onChangeCameraMode || onCameraModeChange;
              fn?.(cameraMode === 'walk' ? '360' : 'walk');
            }}
            className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 ${
              viewMode === '3d' && cameraMode === 'walk'
                ? 'bg-amber-500 text-zinc-950 font-black shadow-lg shadow-amber-500/40 ring-1 ring-amber-300'
                : 'text-zinc-300 hover:text-white hover:bg-white/5'
            }`}
            title="وضع المشي والتجول الداخلي بالقدمين"
          >
            <Footprints className="w-3.5 h-3.5" />
            <span>المشي</span>
            {viewMode === '3d' && cameraMode === 'walk' && (
              <span className="w-1.5 h-1.5 rounded-full bg-zinc-950 animate-pulse" />
            )}
          </button>

          {/* 2D Floor Plan Button (Unmistakable and prominent) */}
          <button
            type="button"
            id="btn-view-2d"
            onClick={() => handleViewSwitch('2d')}
            className={`px-3.5 py-1.5 rounded-full text-xs font-extrabold transition-all flex items-center gap-1.5 ${
              viewMode === '2d'
                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/60 ring-2 ring-emerald-400/50'
                : 'bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 shadow-sm'
            }`}
            title="الانتقال إلى المخطط ثنائي الأبعاد 2D"
          >
            <Layout className="w-3.5 h-3.5 text-emerald-400" />
            <span>2D مخطط</span>
          </button>
        </div>

        {/* Project Info Pill: "مطبخي العصري 6م × 5م / ✓ متزامن" */}
        <button
          type="button"
          onClick={onOpenProjectSwitcher}
          className="hidden sm:flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#1C1C1E]/90 hover:bg-[#2C2C2E] border border-white/10 text-xs text-zinc-200 transition-all shadow-lg active:scale-95"
          title="بيانات المشروع وحالته السحابية"
        >
          <span className="font-bold text-white max-w-[120px] truncate">{projectName}</span>
          {projectDimensions && (
            <span className="text-zinc-400 font-mono text-[11px]">{projectDimensions}</span>
          )}
          <span className="text-emerald-400 font-bold text-[11px] flex items-center gap-1">
            <Check className="w-3 h-3 text-emerald-400" />
            <span>متزامن</span>
          </span>
        </button>

        {/* Undo Button */}
        {onUndo && (
          <button
            type="button"
            id="btn-undo"
            onClick={onUndo}
            disabled={!canUndo}
            className="w-10 h-10 rounded-full bg-[#1C1C1E]/90 hover:bg-[#2C2C2E] text-zinc-300 hover:text-white border border-white/10 shadow-xl flex items-center justify-center transition-all disabled:opacity-30 disabled:pointer-events-none active:scale-95 shrink-0"
            title="تراجع عن الخطوة السابقة (Ctrl+Z)"
          >
            <Undo2 className="w-4 h-4" />
          </button>
        )}
      </div>
    </header>
  );
};
