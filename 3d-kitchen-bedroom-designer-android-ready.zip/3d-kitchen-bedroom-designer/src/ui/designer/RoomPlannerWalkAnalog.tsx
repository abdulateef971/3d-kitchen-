import React, { useRef, useState, useEffect, useCallback } from 'react';
import { Footprints, RotateCcw, RotateCw, Gauge, Zap, X } from 'lucide-react';

export interface RoomPlannerWalkAnalogProps {
  onWalk: (normForward: number, normRight: number, speedMultiplier?: number) => void;
  onRotate?: (direction: 'left' | 'right') => void;
  onRotateContinuous?: (normalizedX: number, normalizedY: number, speedMultiplier?: number) => void;
  onPanContinuous?: (normalizedX: number, normalizedY: number, speedMultiplier?: number) => void;
  onStop?: () => void;
  onToggleWalkMode?: () => void;
  onClose?: () => void;
  isWalkMode?: boolean;
  size?: number;
  stickSize?: number;
  defaultMode?: 'walk' | 'rotate' | 'pan';
}

export const RoomPlannerWalkAnalog: React.FC<RoomPlannerWalkAnalogProps> = ({
  onWalk,
  onRotate,
  onRotateContinuous,
  onPanContinuous,
  onStop,
  onToggleWalkMode,
  onClose,
  isWalkMode = false,
  size = 114,
  stickSize = 46,
  defaultMode = 'rotate',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [stickPos, setStickPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isActive, setIsActive] = useState<boolean>(false);
  const [navMode, setNavMode] = useState<'walk' | 'rotate' | 'pan'>(() => (isWalkMode ? 'walk' : defaultMode));
  const [speedLevel, setSpeedLevel] = useState<'0.5x' | '1x' | '2x'>('0.5x');
  const animFrameRef = useRef<number | null>(null);
  const currentVectorRef = useRef<{ f: number; r: number }>({ f: 0, r: 0 });
  const pointerStartRef = useRef<{ x: number; y: number; time: number }>({ x: 0, y: 0, time: 0 });
  const isDraggingRef = useRef<boolean>(false);

  // Sync mode when walk mode toggles externally
  useEffect(() => {
    if (isWalkMode && navMode !== 'walk') {
      setNavMode('walk');
    }
  }, [isWalkMode]);

  const maxRadius = (size - stickSize) / 2;

  const updateVectorFromClientCoords = useCallback(
    (clientX: number, clientY: number) => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;

      let dx = clientX - centerX;
      let dy = clientY - centerY;
      const distance = Math.hypot(dx, dy);

      if (distance > maxRadius) {
        const angle = Math.atan2(dy, dx);
        dx = Math.cos(angle) * maxRadius;
        dy = Math.sin(angle) * maxRadius;
      }

      setStickPos({ x: dx, y: dy });

      // Dead zone of 3px
      if (distance < 3) {
        currentVectorRef.current = { f: 0, r: 0 };
        return;
      }

      // Proportional vector:
      const normF = -(dy / maxRadius);
      const normR = dx / maxRadius;

      currentVectorRef.current = { f: normF, r: normR };
    },
    [maxRadius]
  );

  // Speed factor (0.5x provides slow, controlled analog rotation)
  const speedMultiplier = speedLevel === '0.5x' ? 0.45 : speedLevel === '1x' ? 0.9 : 1.8;

  // Continuous animation frame loop
  useEffect(() => {
    if (!isActive) {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
        animFrameRef.current = null;
      }
      return;
    }

    const loop = () => {
      const { f, r } = currentVectorRef.current;
      if (f !== 0 || r !== 0) {
        if (navMode === 'walk') {
          onWalk(f, r, speedMultiplier);
        } else if (navMode === 'rotate') {
          // Drag right -> rotate right, Drag up -> rotate up
          if (onRotateContinuous) {
            onRotateContinuous(r, -f, speedMultiplier);
          } else {
            onRotate?.(r > 0 ? 'right' : 'left');
          }
        } else if (navMode === 'pan') {
          if (onPanContinuous) {
            onPanContinuous(r, f, speedMultiplier);
          }
        }
      }
      animFrameRef.current = requestAnimationFrame(loop);
    };

    animFrameRef.current = requestAnimationFrame(loop);

    return () => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    };
  }, [isActive, onWalk, onRotateContinuous, onPanContinuous, onRotate, navMode, speedMultiplier]);

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();

    pointerStartRef.current = { x: e.clientX, y: e.clientY, time: Date.now() };
    isDraggingRef.current = false;
    setIsActive(true);

    try {
      (e.target as HTMLElement).setPointerCapture(e.pointerId);
    } catch {}

    updateVectorFromClientCoords(e.clientX, e.clientY);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isActive) return;
    e.preventDefault();
    e.stopPropagation();

    const distFromStart = Math.hypot(
      e.clientX - pointerStartRef.current.x,
      e.clientY - pointerStartRef.current.y
    );
    if (distFromStart > 6) {
      isDraggingRef.current = true;
    }

    updateVectorFromClientCoords(e.clientX, e.clientY);
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();

    setIsActive(false);
    isDraggingRef.current = false;
    setStickPos({ x: 0, y: 0 });
    currentVectorRef.current = { f: 0, r: 0 };

    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {}

    onStop?.();
  };

  const handleModeChange = (mode: 'walk' | 'rotate' | 'pan') => {
    setNavMode(mode);
    if (mode === 'walk' && !isWalkMode) {
      onToggleWalkMode?.();
    } else if (mode !== 'walk' && isWalkMode) {
      onToggleWalkMode?.();
    }
  };

  const cycleSpeed = () => {
    setSpeedLevel((prev) => (prev === '0.5x' ? '1x' : prev === '1x' ? '2x' : '0.5x'));
  };

  return (
    <div
      id="room-planner-walk-analog"
      className="flex flex-col items-center select-none touch-none animate-in fade-in zoom-in-95 duration-200"
    >
      {/* Mode Switcher Tabs + Speed Selector */}
      <div className="flex items-center gap-1 mb-2 pointer-events-auto bg-black/80 backdrop-blur-md p-1 rounded-2xl border border-white/15 shadow-2xl">
        <button
          type="button"
          onClick={() => handleModeChange('rotate')}
          className={`px-2.5 py-1 rounded-xl text-[10px] font-bold flex items-center gap-1 transition ${
            navMode === 'rotate'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-zinc-400 hover:text-white'
          }`}
          title="تدوير الكاميرا 360 درجة"
        >
          <RotateCw className="w-3 h-3" />
          <span>تدوير</span>
        </button>

        <button
          type="button"
          onClick={() => handleModeChange('walk')}
          className={`px-2.5 py-1 rounded-xl text-[10px] font-bold flex items-center gap-1 transition ${
            navMode === 'walk'
              ? 'bg-amber-500 text-zinc-950 font-black shadow-md'
              : 'text-zinc-400 hover:text-white'
          }`}
          title="المشي والتجول الداخلي"
        >
          <Footprints className="w-3 h-3" />
          <span>مشـي</span>
        </button>

        <button
          type="button"
          onClick={() => handleModeChange('pan')}
          className={`px-2.5 py-1 rounded-xl text-[10px] font-bold flex items-center gap-1 transition ${
            navMode === 'pan'
              ? 'bg-emerald-600 text-white shadow-md'
              : 'text-zinc-400 hover:text-white'
          }`}
          title="إزاحة الكاميرا Pan"
        >
          <span>إزاحة</span>
        </button>

        <div className="w-px h-3.5 bg-white/20 mx-0.5" />

        {/* Speed Selector (0.5x / 1x / 2x) */}
        <button
          type="button"
          onClick={cycleSpeed}
          className={`px-2 py-0.5 rounded-lg text-[10px] font-black border transition active:scale-90 ${
            speedLevel === '2x'
              ? 'bg-amber-500/20 text-amber-300 border-amber-400'
              : speedLevel === '1x'
              ? 'bg-blue-500/20 text-blue-300 border-blue-400'
              : 'bg-emerald-500/20 text-emerald-300 border-emerald-400'
          }`}
          title="سرعة تدوير وحركة الكاميرا (0.5x هادئ بطيء - 5 / 1x عادي / 2x سريع)"
        >
          ⚡ {speedLevel}
        </button>

        {onClose && (
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-white/10 text-zinc-400 hover:text-white transition active:scale-95"
            title="إغلاق عصا التحكم"
          >
            <X className="w-3 h-3" />
          </button>
        )}
      </div>

      {/* Controller Chassis: Rotating Buttons + Analog Center */}
      <div className="relative flex items-center justify-center gap-2 pointer-events-auto">
        {/* Quick Rotate Left Button */}
        {onRotate && (
          <button
            type="button"
            onClick={() => onRotate('left')}
            className="w-8 h-8 rounded-full bg-[#1C1C1E]/90 hover:bg-[#2C2C2E] text-zinc-300 hover:text-white border border-white/10 shadow-lg flex items-center justify-center transition-all active:scale-90"
            title="تدوير الكاميرا يساراً"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        )}

        {/* Main Analog Joystick Outer Housing */}
        <div
          ref={containerRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          style={{ width: `${size}px`, height: `${size}px` }}
          className={`relative rounded-full bg-[#141820]/95 backdrop-blur-xl border-2 transition-colors shadow-2xl flex items-center justify-center cursor-grab active:cursor-grabbing touch-none select-none ${
            isActive
              ? navMode === 'walk'
                ? 'border-amber-400/80 shadow-amber-500/25'
                : navMode === 'rotate'
                ? 'border-blue-400/80 shadow-blue-500/25'
                : 'border-emerald-400/80 shadow-emerald-500/25'
              : 'border-white/15 hover:border-white/25 shadow-black/60'
          }`}
          title="عصا التحكم التناظرية: اسحب في أي اتجاه"
        >
          {/* Subtle Directional Compass Indicators */}
          <span className="absolute top-1 left-1/2 -translate-x-1/2 text-[9px] font-black text-zinc-500 pointer-events-none select-none">
            ▲
          </span>
          <span className="absolute bottom-1 left-1/2 -translate-x-1/2 text-[9px] font-black text-zinc-500 pointer-events-none select-none">
            ▼
          </span>
          <span className="absolute left-1.5 top-1/2 -translate-y-1/2 text-[9px] font-black text-zinc-500 pointer-events-none select-none">
            ◀
          </span>
          <span className="absolute right-1.5 top-1/2 -translate-y-1/2 text-[9px] font-black text-zinc-500 pointer-events-none select-none">
            ▶
          </span>

          {/* Crosshair Guidelines */}
          <div className="absolute w-[1px] h-[78%] bg-white/5 pointer-events-none" />
          <div className="absolute h-[1px] w-[78%] bg-white/5 pointer-events-none" />

          {/* Concentric Guide Ring */}
          <div
            className="absolute rounded-full border border-dashed border-white/10 pointer-events-none"
            style={{ width: `${size * 0.62}px`, height: `${size * 0.62}px` }}
          />

          {/* Thumbstick Knob */}
          <div
            style={{
              width: `${stickSize}px`,
              height: `${stickSize}px`,
              transform: `translate(${stickPos.x}px, ${stickPos.y}px)`,
              transition: isActive ? 'none' : 'transform 0.18s cubic-bezier(0.2, 0.8, 0.2, 1)',
            }}
            className={`rounded-full flex items-center justify-center pointer-events-none transition-shadow shadow-xl border-2 ${
              isActive
                ? navMode === 'walk'
                  ? 'bg-gradient-to-br from-amber-400 via-orange-500 to-amber-600 border-white text-zinc-950 shadow-amber-500/40 scale-105'
                  : navMode === 'rotate'
                  ? 'bg-gradient-to-br from-blue-400 via-indigo-500 to-blue-600 border-white text-white shadow-blue-500/40 scale-105'
                  : 'bg-gradient-to-br from-emerald-400 via-teal-500 to-emerald-600 border-white text-white shadow-emerald-500/40 scale-105'
                : navMode === 'walk'
                ? 'bg-gradient-to-br from-[#2D3748] to-[#1A202C] border-amber-400/60 text-amber-400'
                : navMode === 'rotate'
                ? 'bg-gradient-to-br from-[#1E293B] to-[#0F172A] border-blue-400/60 text-blue-400'
                : 'bg-gradient-to-br from-[#064E3B] to-[#022C22] border-emerald-400/60 text-emerald-400'
            }`}
          >
            {navMode === 'walk' ? (
              <Footprints className="w-4 h-4" />
            ) : navMode === 'rotate' ? (
              <RotateCw className="w-4 h-4" />
            ) : (
              <Gauge className="w-4 h-4" />
            )}
          </div>
        </div>

        {/* Quick Rotate Right Button */}
        {onRotate && (
          <button
            type="button"
            onClick={() => onRotate('right')}
            className="w-8 h-8 rounded-full bg-[#1C1C1E]/90 hover:bg-[#2C2C2E] text-zinc-300 hover:text-white border border-white/10 shadow-lg flex items-center justify-center transition-all active:scale-90"
            title="تدوير الكاميرا يميناً"
          >
            <RotateCw className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Dynamic Caption */}
      <span className="text-[10px] font-bold mt-1 text-zinc-300 tracking-tight drop-shadow">
        {isActive
          ? navMode === 'walk'
            ? `👣 جاري المشي (${speedLevel})...`
            : navMode === 'rotate'
            ? `🔄 تدوير الكاميرا (${speedLevel})...`
            : `↔️ إزاحة الكاميرا (${speedLevel})...`
          : 'اسحب الأنالوج أو اسحب الشاشة مباشرة للتدوير'}
      </span>
    </div>
  );
};
