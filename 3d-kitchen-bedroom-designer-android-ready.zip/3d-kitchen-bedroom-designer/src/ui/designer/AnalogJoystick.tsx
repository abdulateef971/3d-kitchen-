import React, { useRef, useState, useEffect, useCallback } from 'react';

interface AnalogJoystickProps {
  onMove: (normalizedX: number, normalizedY: number) => void;
  onStop?: () => void;
  size?: number;
  stickSize?: number;
  label?: string;
  activeLabel?: string;
  speedMultiplier?: number;
  theme?: 'blue' | 'emerald' | 'amber' | 'orange' | 'purple';
}

export const AnalogJoystick: React.FC<AnalogJoystickProps> = ({
  onMove,
  onStop,
  size = 110,
  stickSize = 44,
  label = 'أنالوج التدوير',
  activeLabel,
  speedMultiplier = 1.0,
  theme = 'blue',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [stickPos, setStickPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isActive, setIsActive] = useState<boolean>(false);
  const animFrameRef = useRef<number | null>(null);
  const currentVectorRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  const maxRadius = (size - stickSize) / 2;

  const updatePosition = useCallback(
    (clientX: number, clientY: number) => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;

      let dx = clientX - centerX;
      let dy = clientY - centerY;
      const distance = Math.hypot(dx, dy);

      if (distance > maxRadius) {
        const angle = Math.atan2(dy, dx);
        dx = Math.cos(angle) * maxRadius;
        dy = Math.sin(angle) * maxRadius;
      }

      setStickPos({ x: dx, y: dy });

      // Normalized coordinates (-1.0 to 1.0)
      const normX = dx / maxRadius;
      const normY = dy / maxRadius;
      currentVectorRef.current = { x: normX, y: normY };
    },
    [maxRadius]
  );

  // Smooth continuous animation frame dispatch while active
  useEffect(() => {
    if (!isActive) {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
        animFrameRef.current = null;
      }
      return;
    }

    const loop = () => {
      if (currentVectorRef.current.x !== 0 || currentVectorRef.current.y !== 0) {
        onMove(
          currentVectorRef.current.x,
          currentVectorRef.current.y
        );
      }
      animFrameRef.current = requestAnimationFrame(loop);
    };

    animFrameRef.current = requestAnimationFrame(loop);

    return () => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    };
  }, [isActive, onMove, speedMultiplier]);

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsActive(true);
    try {
      (e.target as HTMLElement).setPointerCapture(e.pointerId);
    } catch {}
    updatePosition(e.clientX, e.clientY);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isActive) return;
    e.preventDefault();
    e.stopPropagation();
    updatePosition(e.clientX, e.clientY);
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    setIsActive(false);
    setStickPos({ x: 0, y: 0 });
    currentVectorRef.current = { x: 0, y: 0 };
    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {}
    onStop?.();
  };

  return (
    <div className="flex flex-col items-center gap-1 select-none">
      <div
        ref={containerRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        style={{ width: `${size}px`, height: `${size}px` }}
        className="relative rounded-full bg-[#10141B] border-2 border-[#334155] shadow-inner flex items-center justify-center cursor-grab active:cursor-grabbing touch-none select-none"
      >
        {/* Subtle Crosshairs */}
        <div className="absolute w-[1px] h-full bg-[#1E293B] pointer-events-none" />
        <div className="absolute h-[1px] w-full bg-[#1E293B] pointer-events-none" />

        {/* Concentric Guide Ring */}
        <div
          className="absolute rounded-full border border-dashed border-[#2A3649] pointer-events-none"
          style={{ width: `${size * 0.65}px`, height: `${size * 0.65}px` }}
        />

        {/* Analog Thumbstick Knob */}
        <div
          style={{
            width: `${stickSize}px`,
            height: `${stickSize}px`,
            transform: `translate(${stickPos.x}px, ${stickPos.y}px)`,
          }}
          className={`rounded-full flex items-center justify-center transition-shadow shadow-xl pointer-events-none ${
            isActive
              ? theme === 'orange' || theme === 'amber'
                ? 'bg-gradient-to-br from-amber-400 via-orange-500 to-red-600 shadow-orange-500/60 scale-105 border-2 border-amber-200'
                : theme === 'emerald'
                ? 'bg-gradient-to-br from-emerald-400 to-teal-700 shadow-emerald-500/60 scale-105 border-2 border-emerald-200'
                : theme === 'purple'
                ? 'bg-gradient-to-br from-purple-400 to-indigo-700 shadow-purple-500/60 scale-105 border-2 border-purple-200'
                : 'bg-gradient-to-br from-blue-500 to-indigo-700 shadow-blue-500/50 scale-105 border-2 border-white'
              : 'bg-gradient-to-br from-[#2C3647] to-[#1A2230] border-2 border-[#475569]'
          }`}
        >
          {/* Inner Gripper Ring */}
          <div
            className={`w-4 h-4 rounded-full border ${
              isActive
                ? theme === 'orange' || theme === 'amber'
                  ? 'border-amber-200 bg-amber-100/30'
                  : theme === 'emerald'
                  ? 'border-emerald-200 bg-emerald-100/30'
                  : 'border-blue-200 bg-white/20'
                : 'border-[#64748B] bg-[#0F172A]/40'
            }`}
          />
        </div>
      </div>

      <span className={`text-[10px] font-bold ${isActive ? (theme === 'orange' || theme === 'amber' ? 'text-amber-400' : theme === 'emerald' ? 'text-emerald-400' : 'text-blue-400') : 'text-gray-400'}`}>
        {isActive ? (activeLabel || 'جاري التحريك السلس...') : label}
      </span>
    </div>
  );
};
