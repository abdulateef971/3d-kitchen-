import React, { useState, useEffect } from 'react';
import { CameraPreset } from '../../types';
import {
  ZoomIn,
  ZoomOut,
  RotateCcw,
  RotateCw,
  Compass,
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Move,
  Play,
  Pause,
  Hand,
  Disc,
  Sliders,
  X,
  Footprints,
  Maximize2,
  Minimize2,
  Layers,
  Box,
  Zap,
  ArrowLeftRight,
  Check,
} from 'lucide-react';
import { AnalogJoystick } from './AnalogJoystick';
import { ManualControlsPositionModal, ControlsLayoutConfig } from './ManualControlsPositionModal';

export interface CADCameraOverlayProps {
  activePreset: CameraPreset;
  onSelectPreset: (preset: CameraPreset) => void;
  onSwitchMode?: (mode: 'walk' | 'rotate' | 'pan') => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onRotateCamera: (direction: 'left' | 'right' | 'up' | 'down') => void;
  onRotateCameraAnalog?: (normalizedX: number, normalizedY: number, speedMultiplier?: number) => void;
  onWalkAnalog?: (normForward: number, normRight: number, speedMultiplier?: number) => void;
  onPanAnalog?: (normX: number, normY: number, speedMultiplier?: number) => void;
  onPanCamera: (deltaX: number, deltaY: number) => void;
  onResetView: () => void;
  isAutoRotate: boolean;
  onToggleAutoRotate: () => void;
  isInteractMode: boolean;
  onToggleInteractMode: () => void;
  isMobileMode?: boolean;
  toolsSide?: 'left' | 'right';
  onToggleToolsSide?: () => void;
  controlsLayoutTrigger?: number;
}

export const CADCameraOverlay: React.FC<CADCameraOverlayProps> = ({
  activePreset,
  onSelectPreset,
  onSwitchMode,
  onZoomIn,
  onZoomOut,
  onRotateCamera,
  onRotateCameraAnalog,
  onWalkAnalog,
  onPanAnalog,
  onPanCamera,
  onResetView,
  isAutoRotate,
  onToggleAutoRotate,
  isInteractMode,
  onToggleInteractMode,
  isMobileMode = false,
  toolsSide = 'left',
  onToggleToolsSide,
  controlsLayoutTrigger,
}) => {
  // Whether the floating analog joystick is visible on screen
  const [isAnalogVisible, setIsAnalogVisible] = useState<boolean>(true);

  // Whether the separate Settings panel is open or hidden
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);

  // Rotation / Motion Speed Factor (Default: 1.0x)
  const [baseSpeed, setBaseSpeed] = useState<number>(1.0);

  // Analog Function Mode: 'walk' (تجول ومشي) | 'rotate' (تدوير 360°) | 'pan' (إزاحة Pan)
  const [analogMode, setAnalogMode] = useState<'walk' | 'rotate' | 'pan'>('rotate');

  // Swapped joysticks position state (Default: Left=Rotate/Pan, Right=Walk)
  const [isSwapped, setIsSwapped] = useState<boolean>(() => {
    try {
      return localStorage.getItem('rpz_controls_swapped') === 'true';
    } catch {
      return false;
    }
  });

  // Manual Controls Position Customizer Modal
  const [isManualModalOpen, setIsManualModalOpen] = useState<boolean>(false);
  const [layoutConfig, setLayoutConfig] = useState<ControlsLayoutConfig>(() => {
    try {
      const saved = localStorage.getItem('rpz_controls_layout_config');
      if (saved) return JSON.parse(saved);
    } catch {}
    const isSwappedSaved = localStorage.getItem('rpz_controls_swapped') === 'true';
    return {
      walkSide: isSwappedSaved ? 'left' : 'right',
      rotateSide: isSwappedSaved ? 'right' : 'left',
      actionSide: 'right',
      toolsSide: 'left',
      verticalOffset: 'medium',
    };
  });

  // Action Toolbar Position: 'right' | 'left' (Default: 'right')
  const [actionToolbarSide, setActionToolbarSide] = useState<'left' | 'right'>(() => {
    try {
      return (localStorage.getItem('rpz_action_side') as 'left' | 'right') || 'right';
    } catch {
      return 'right';
    }
  });

  // Walk Stride Distance Multiplier: 1.0 (Normal 100mm), 1.8 (Long 180mm), 2.8 (Fast 280mm)
  const [walkStride, setWalkStride] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('rpz_walk_stride');
      return saved ? parseFloat(saved) : 1.8;
    } catch {
      return 1.8;
    }
  });

  // Transient feedback toast when swapping controls
  const [swapFeedback, setSwapFeedback] = useState<string | null>(null);

  const handleUpdateLayoutConfig = (newConfig: ControlsLayoutConfig) => {
    setLayoutConfig(newConfig);
    const nextSwapped = newConfig.walkSide === 'left';
    setIsSwapped(nextSwapped);
    setActionToolbarSide(newConfig.actionSide);
    try {
      localStorage.setItem('rpz_controls_layout_config', JSON.stringify(newConfig));
      localStorage.setItem('rpz_controls_swapped', String(nextSwapped));
      localStorage.setItem('rpz_action_side', newConfig.actionSide);
    } catch (_) {}
  };

  const handleToggleSwap = (custom?: { swapped?: boolean; actionSide?: 'left' | 'right' }) => {
    const nextSwapped = custom?.swapped !== undefined ? custom.swapped : !isSwapped;
    const nextActionSide = custom?.actionSide !== undefined 
      ? custom.actionSide 
      : (actionToolbarSide === 'right' ? 'left' : 'right');

    setIsSwapped(nextSwapped);
    setActionToolbarSide(nextActionSide);
    setLayoutConfig((prev) => {
      const updated: ControlsLayoutConfig = {
        ...prev,
        walkSide: nextSwapped ? 'left' : 'right',
        rotateSide: nextSwapped ? 'right' : 'left',
        actionSide: nextActionSide,
      };
      try {
        localStorage.setItem('rpz_controls_layout_config', JSON.stringify(updated));
        localStorage.setItem('rpz_controls_swapped', String(nextSwapped));
        localStorage.setItem('rpz_action_side', nextActionSide);
      } catch (_) {}
      return updated;
    });

    const text = nextSwapped
      ? '⇄ تم تبديل الأماكن يدوياً: أنالوج المشي باليسار، التدوير باليمين'
      : '⇄ تم تبديل الأماكن يدوياً: أنالوج التدوير باليسار، المشي باليمين';
    setSwapFeedback(text);
    setTimeout(() => {
      setSwapFeedback(null);
    }, 2500);
  };

  useEffect(() => {
    if (controlsLayoutTrigger && controlsLayoutTrigger > 0) {
      handleToggleSwap();
    }
  }, [controlsLayoutTrigger]);

  // Run / Sprint Mode toggle - shows dedicated second running analog stick
  const [isRunMode, setIsRunMode] = useState<boolean>(false);

  // Optional D-Pad visibility inside the settings or overlay
  const [showDpad, setShowDpad] = useState<boolean>(false);

  const presets: { id: CameraPreset; labelAr: string; short: string; tooltip: string }[] = [
    { id: 'top', labelAr: '2D مسقط علوي', short: '2D', tooltip: 'مسقط أفقي ثنائي الأبعاد (CAD)' },
    { id: 'perspective', labelAr: '3D منظور حر', short: '3D', tooltip: 'منظور ثلاثي الأبعاد مجسم' },
    { id: 'eye_level', labelAr: '🚶 تجول واقعي', short: 'تجول', tooltip: 'منظور الشخص الأول داخل المطبخ' },
    { id: 'front', labelAr: 'أمامي', short: 'Front', tooltip: 'واجهة أمامية مستقيمة' },
    { id: 'side', labelAr: 'جانبي', short: 'Side', tooltip: 'مسقط جانبي' },
    { id: 'isometric', labelAr: 'أيزومتري', short: 'ISO', tooltip: 'منظور هندسي أيزومتري' },
  ];

  return (
    <>
      {/* ========================================================================= */}
      {/* 1. TOP CENTER: HOME PLANNER MODE SELECTOR (2D | 3D | 🚶 تجول)            */}
      {/* ========================================================================= */}
      <div
        onPointerDown={(e) => e.stopPropagation()}
        onClick={(e) => e.stopPropagation()}
        className="absolute top-3 left-1/2 -translate-x-1/2 z-20 select-none pointer-events-auto font-['Cairo',sans-serif]"
        dir="rtl"
      >
        <div className="bg-[#12161E]/90 backdrop-blur-md border border-[#2D3848] rounded-2xl shadow-2xl p-1 flex items-center gap-1">
          {/* Main 3 Home Planner Modes */}
          <button
            onClick={() => onSelectPreset('top')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              activePreset === 'top'
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/40'
                : 'text-gray-300 hover:text-white hover:bg-[#1E2634]'
            }`}
            title="مسقط أفقي ثنائي الأبعاد (2D Blueprint)"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>2D مسقط</span>
          </button>

          <button
            onClick={() => {
              if (onSwitchMode) {
                onSwitchMode('rotate');
              } else {
                onSelectPreset('perspective');
              }
              if (analogMode === 'walk') setAnalogMode('rotate');
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              activePreset === 'perspective'
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/40'
                : 'text-gray-300 hover:text-white hover:bg-[#1E2634]'
            }`}
            title="منظور ثلاثي الأبعاد مجسم حر (3D Orbit)"
          >
            <Box className="w-3.5 h-3.5" />
            <span>3D مجسم</span>
          </button>

          <button
            onClick={() => {
              if (onSwitchMode) {
                onSwitchMode('walk');
              } else {
                onSelectPreset('eye_level');
              }
              setAnalogMode('walk');
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              activePreset === 'eye_level'
                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/40'
                : 'text-gray-300 hover:text-white hover:bg-[#1E2634]'
            }`}
            title="تجول واقعي داخل المطبخ من مستوى العين (First-Person Walk)"
          >
            <Footprints className="w-3.5 h-3.5 text-emerald-300" />
            <span>🚶 تجول واقعي</span>
          </button>

          {/* Quick Divider */}
          <div className="h-5 w-[1px] bg-[#2A3444] mx-1" />

          {/* ISO / Other view dropdown button */}
          <button
            onClick={() => onSelectPreset(activePreset === 'isometric' ? 'perspective' : 'isometric')}
            className={`px-2 py-1.5 rounded-xl text-[11px] font-semibold transition ${
              activePreset === 'isometric'
                ? 'bg-purple-600 text-white shadow'
                : 'text-gray-400 hover:text-gray-200 hover:bg-[#1E2634]'
            }`}
            title="منظور هندسي أيزومتري"
          >
            أيزومتري
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. QUICK ACTION TOOLBAR (Zoom, Fit, Auto-Rotate, Open Doors, Swap Layout) */}
      {/* ========================================================================= */}
      <div
        onPointerDown={(e) => e.stopPropagation()}
        onClick={(e) => e.stopPropagation()}
        className={`fixed ${
          actionToolbarSide === 'left'
            ? (isMobileMode ? 'bottom-48 left-3' : 'bottom-48 left-5')
            : (isMobileMode ? 'bottom-48 right-3' : 'bottom-48 right-5')
        } z-20 flex flex-col gap-1.5 select-none pointer-events-auto font-['Cairo',sans-serif]`}
        dir="rtl"
      >
        <div className="bg-[#12161E]/90 backdrop-blur-md border border-[#2D3848] rounded-2xl p-1.5 shadow-2xl flex flex-col gap-1 text-white">
          {/* Zoom In (+) */}
          <button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onZoomIn();
            }}
            onPointerDown={(e) => e.stopPropagation()}
            title="تقريب المشهد (Zoom In +)"
            className="w-9 h-9 rounded-xl bg-[#1C2330] hover:bg-blue-600 text-blue-400 hover:text-white flex items-center justify-center transition shadow-sm border border-[#2B374A] active:scale-95"
          >
            <ZoomIn className="w-4 h-4" />
          </button>

          {/* Zoom Out (-) */}
          <button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onZoomOut();
            }}
            onPointerDown={(e) => e.stopPropagation()}
            title="إبعاد المشهد (Zoom Out -)"
            className="w-9 h-9 rounded-xl bg-[#1C2330] hover:bg-blue-600 text-blue-400 hover:text-white flex items-center justify-center transition shadow-sm border border-[#2B374A] active:scale-95"
          >
            <ZoomOut className="w-4 h-4" />
          </button>

          <div className="w-full h-[1px] bg-[#2A3444] my-0.5" />

          {/* Frame / Fit Scene (تأطير المشهد) */}
          <button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onResetView();
            }}
            onPointerDown={(e) => e.stopPropagation()}
            title="توسيط وتأطير المشهد بالكامل"
            className="w-9 h-9 rounded-xl bg-[#1C2330] hover:bg-purple-600 text-purple-400 hover:text-white flex items-center justify-center transition shadow-sm border border-[#2B374A] active:scale-95"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* 360 Auto-Rotate Toggle */}
          <button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onToggleAutoRotate();
            }}
            onPointerDown={(e) => e.stopPropagation()}
            title={isAutoRotate ? 'إيقاف الدوران التلقائي' : 'تشغيل دوران سينمائي 360°'}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition shadow-sm border active:scale-95 ${
              isAutoRotate
                ? 'bg-emerald-600 text-white border-emerald-400 animate-pulse'
                : 'bg-[#1C2330] text-emerald-400 border-[#2B374A] hover:bg-emerald-600 hover:text-white'
            }`}
          >
            {isAutoRotate ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </button>

          {/* Interactive Doors & Drawers Click-to-Open Mode */}
          <button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onToggleInteractMode();
            }}
            onPointerDown={(e) => e.stopPropagation()}
            title={isInteractMode ? 'إيقاف وضع فتح الدرف والأدراج' : 'تفعيل وضع فتح الدرف والأدراج باللمس'}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition shadow-sm border active:scale-95 ${
              isInteractMode
                ? 'bg-amber-500 text-slate-950 border-amber-300 font-bold'
                : 'bg-[#1C2330] text-amber-400 border-[#2B374A] hover:bg-amber-500 hover:text-slate-950'
            }`}
          >
            <Hand className="w-4 h-4" />
          </button>

          <div className="w-full h-[1px] bg-[#2A3444] my-0.5" />

          {/* Direct Controls Swap Button (تبديل أماكن الأزرار) */}
          <button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              handleToggleSwap();
            }}
            onPointerDown={(e) => e.stopPropagation()}
            title="تبديل أماكن أزرار الأنالوج وأدوات التحكم (يمين ⇋ يسار)"
            className="w-9 h-9 rounded-xl bg-[#1C2330] hover:bg-amber-500 text-amber-400 hover:text-slate-950 flex items-center justify-center transition shadow-sm border border-[#2B374A] active:scale-95 group"
          >
            <ArrowLeftRight className="w-4 h-4 group-hover:rotate-180 transition-transform duration-300" />
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. DUAL ANALOG CONTROLS: LEFT (ROTATE/PAN) + RIGHT (WALK) + SWAP BUTTON  */}
      {/* ========================================================================= */}
      {isAnalogVisible ? (
        <>
          {/* Left Analog Pod: Default Camera Rotate & Pan (or Walk if swapped) */}
          <div
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => e.stopPropagation()}
            className={`fixed ${
              isMobileMode ? 'bottom-20 left-3' : 'bottom-20 left-5'
            } z-30 flex flex-col items-center gap-1.5 select-none pointer-events-auto font-['Cairo',sans-serif]`}
            dir="rtl"
          >
            {/* Top action toolbar for Left Pod */}
            <div className="flex items-center gap-1 bg-[#12161E]/90 backdrop-blur-md border border-[#2D3848] px-1.5 py-0.5 rounded-full shadow-lg">
              {!isSwapped ? (
                <>
                  {/* Rotate Mode (🔄 تدوير) */}
                  <button
                    onClick={() => {
                      setAnalogMode('rotate');
                      if (onSwitchMode) onSwitchMode('rotate');
                    }}
                    title="تدوير الكاميرا 360°"
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 transition ${
                      analogMode === 'rotate'
                        ? 'bg-blue-600 text-white shadow-sm'
                        : 'text-gray-300 hover:text-white hover:bg-[#1E2634]'
                    }`}
                  >
                    <RotateCw className="w-3 h-3 text-blue-200" />
                    <span>تدوير</span>
                  </button>

                  {/* Pan Mode (✥ إزاحة) */}
                  <button
                    onClick={() => {
                      setAnalogMode('pan');
                      if (onSwitchMode) onSwitchMode('pan');
                    }}
                    title="إزاحة وتحريك المشهد (Pan)"
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 transition ${
                      analogMode === 'pan'
                        ? 'bg-purple-600 text-white shadow-sm'
                        : 'text-gray-300 hover:text-white hover:bg-[#1E2634]'
                    }`}
                  >
                    <Move className="w-3 h-3 text-purple-200" />
                    <span>إزاحة</span>
                  </button>
                </>
              ) : (
                /* Walk Mode indicator when swapped to Left */
                <span className="px-2 py-0.5 text-[10px] font-bold text-emerald-400 flex items-center gap-1">
                  <Footprints className="w-3 h-3 text-emerald-300" />
                  <span>أنالوج المشي</span>
                </span>
              )}

              {/* Swap Places Button (استبدال أماكن الأزرار) */}
              <button
                onClick={() => setIsSwapped((prev) => !prev)}
                title="استبدال أماكن أزرار الأنالوج (تبديل اليمين واليسار)"
                className="p-1 rounded-full text-amber-400 hover:text-amber-200 hover:bg-[#252E3E] transition"
              >
                <ArrowLeftRight className="w-3 h-3" />
              </button>

              {/* Settings button */}
              <button
                onClick={() => setIsSettingsOpen((prev) => !prev)}
                title="إعدادات التحكم والسرعة"
                className={`p-1 rounded-full transition ${
                  isSettingsOpen ? 'bg-blue-600 text-white' : 'text-gray-300 hover:text-white hover:bg-[#252E3E]'
                }`}
              >
                <Sliders className="w-3 h-3" />
              </button>

              {/* Minimize */}
              <button
                onClick={() => setIsAnalogVisible(false)}
                title="إخفاء عصا التحكم"
                className="p-1 text-gray-400 hover:text-white rounded-full hover:bg-[#252E3E] transition"
              >
                <Minimize2 className="w-3 h-3" />
              </button>
            </div>

            {/* Left Analog Stick */}
            <div className="relative p-1.5 rounded-full bg-[#12161E]/85 backdrop-blur-md border border-[#2D3848]/80 shadow-2xl transition hover:border-blue-500/50">
              {!isSwapped ? (
                /* Camera Rotate / Pan Analog */
                <AnalogJoystick
                  size={84}
                  stickSize={36}
                  speedMultiplier={baseSpeed}
                  theme={analogMode === 'pan' ? 'purple' : 'blue'}
                  label={analogMode === 'pan' ? 'إزاحة الكاميرا' : 'تدوير 360°'}
                  activeLabel={analogMode === 'pan' ? '✥ إزاحة...' : '🔄 تدوير...'}
                  onMove={(normX, normY) => {
                    if (analogMode === 'pan') {
                      if (onPanAnalog) {
                        onPanAnalog(normX, normY, baseSpeed);
                      } else {
                        onPanCamera(normX * 25 * baseSpeed, -normY * 25 * baseSpeed);
                      }
                    } else {
                      if (onRotateCameraAnalog) {
                        onRotateCameraAnalog(normX, normY, baseSpeed);
                      } else {
                        if (Math.abs(normX) > 0.3) onRotateCamera(normX > 0 ? 'right' : 'left');
                        if (Math.abs(normY) > 0.3) onRotateCamera(normY > 0 ? 'down' : 'up');
                      }
                    }
                  }}
                  onStop={() => {}}
                />
              ) : (
                /* Walk Analog when swapped */
                <AnalogJoystick
                  size={84}
                  stickSize={36}
                  speedMultiplier={baseSpeed}
                  theme="emerald"
                  label="أنالوج المشي"
                  activeLabel="🚶 مشي وتجول..."
                  onMove={(normX, normY) => {
                    const forward = -normY;
                    const right = normX;
                    if (onWalkAnalog) {
                      onWalkAnalog(forward, right, baseSpeed * walkStride);
                    } else {
                      onPanCamera(normX * 30 * baseSpeed * walkStride, -normY * 30 * baseSpeed * walkStride);
                    }
                  }}
                  onStop={() => {}}
                />
              )}
            </div>
          </div>

          {/* Right Analog Pod: Default Walking (or Rotate/Pan if swapped) */}
          <div
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => e.stopPropagation()}
            className={`fixed ${
              isMobileMode ? 'bottom-20 right-3' : 'bottom-20 right-5'
            } z-30 flex flex-col items-center gap-1.5 select-none pointer-events-auto font-['Cairo',sans-serif]`}
            dir="rtl"
          >
            {/* Top action toolbar for Right Pod */}
            <div className="flex items-center gap-1 bg-[#12161E]/90 backdrop-blur-md border border-[#2D3848] px-2 py-0.5 rounded-full shadow-lg">
              {isSwapped ? (
                <>
                  <button
                    onClick={() => setAnalogMode('rotate')}
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      analogMode === 'rotate' ? 'bg-blue-600 text-white' : 'text-gray-300'
                    }`}
                  >
                    تدوير
                  </button>
                  <button
                    onClick={() => setAnalogMode('pan')}
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      analogMode === 'pan' ? 'bg-purple-600 text-white' : 'text-gray-300'
                    }`}
                  >
                    إزاحة
                  </button>
                </>
              ) : (
                <span className="text-[10px] font-bold text-emerald-400 flex items-center gap-1">
                  <Footprints className="w-3 h-3 text-emerald-300" />
                  <span>أنالوج المشي</span>
                </span>
              )}
            </div>

            {/* Right Analog Stick */}
            <div className="relative p-1.5 rounded-full bg-[#12161E]/85 backdrop-blur-md border border-emerald-600/50 shadow-2xl shadow-emerald-950/40 transition hover:border-emerald-400">
              {isSwapped ? (
                <AnalogJoystick
                  size={84}
                  stickSize={36}
                  speedMultiplier={baseSpeed}
                  theme={analogMode === 'pan' ? 'purple' : 'blue'}
                  label={analogMode === 'pan' ? 'إزاحة الكاميرا' : 'تدوير 360°'}
                  activeLabel={analogMode === 'pan' ? '✥ إزاحة...' : '🔄 تدوير...'}
                  onMove={(normX, normY) => {
                    if (analogMode === 'pan') {
                      if (onPanAnalog) {
                        onPanAnalog(normX, normY, baseSpeed);
                      } else {
                        onPanCamera(normX * 25 * baseSpeed, -normY * 25 * baseSpeed);
                      }
                    } else {
                      if (onRotateCameraAnalog) {
                        onRotateCameraAnalog(normX, normY, baseSpeed);
                      } else {
                        if (Math.abs(normX) > 0.3) onRotateCamera(normX > 0 ? 'right' : 'left');
                        if (Math.abs(normY) > 0.3) onRotateCamera(normY > 0 ? 'down' : 'up');
                      }
                    }
                  }}
                  onStop={() => {}}
                />
              ) : (
                <AnalogJoystick
                  size={84}
                  stickSize={36}
                  speedMultiplier={baseSpeed}
                  theme="emerald"
                  label="أنالوج المشي"
                  activeLabel="🚶 مشي وتجول..."
                  onMove={(normX, normY) => {
                    const forward = -normY;
                    const right = normX;
                    if (onWalkAnalog) {
                      onWalkAnalog(forward, right, baseSpeed * walkStride);
                    } else {
                      onPanCamera(normX * 30 * baseSpeed * walkStride, -normY * 30 * baseSpeed * walkStride);
                    }
                  }}
                  onStop={() => {}}
                />
              )}
            </div>
          </div>
        </>
      ) : (
        /* Floating Restore Button */
        <button
          onClick={() => setIsAnalogVisible(true)}
          className="fixed bottom-20 left-5 z-30 bg-[#12161E]/90 hover:bg-[#1C2330] text-gray-300 hover:text-white border border-[#2D3848] px-3 py-1.5 rounded-full text-xs font-bold shadow-lg flex items-center gap-1.5 transition"
        >
          <Compass className="w-3.5 h-3.5 text-blue-400" />
          <span>إظهار عصا الأنالوج</span>
        </button>
      )}

      {/* ========================================================================= */}
      {/* 4. DEDICATED FLOATING BUTTON: SWAP CONTROLS & SETTINGS (User Request)     */}
      {/* ========================================================================= */}
      <div
        onPointerDown={(e) => e.stopPropagation()}
        onClick={(e) => e.stopPropagation()}
        className="fixed bottom-3 sm:bottom-5 left-1/2 -translate-x-1/2 z-30 flex items-center gap-2 select-none pointer-events-auto font-['Cairo',sans-serif]"
        dir="rtl"
      >
        {/* Quick Swap */}
        <button
          onClick={() => handleToggleSwap()}
          className="px-3 py-1.5 rounded-full bg-[#12161E]/95 hover:bg-[#1C2538] text-amber-300 hover:text-white border border-amber-500/60 hover:border-amber-400 shadow-2xl flex items-center gap-1.5 text-xs font-bold transition active:scale-95 backdrop-blur-md group"
          title="عكس أماكن أزرار المشي والتدوير فوراً بين اليمين واليسار ⇄"
        >
          <ArrowLeftRight className="w-3.5 h-3.5 text-amber-400 group-hover:rotate-180 transition-transform duration-300" />
          <span>تبديل الأزرار ⇄</span>
        </button>

        {/* Manual Button Customization Modal Button (User Request) */}
        <button
          onClick={() => setIsManualModalOpen(true)}
          className="px-3 py-1.5 rounded-full bg-gradient-to-r from-amber-600/30 to-orange-600/30 hover:from-amber-600/50 hover:to-orange-600/50 text-amber-200 hover:text-white border border-amber-400/60 shadow-2xl flex items-center gap-1.5 text-xs font-bold transition active:scale-95 backdrop-blur-md"
          title="فتح لوحة تبديل وتخصيص أماكن الأزرار يدوياً بالتفصيل"
        >
          <Sliders className="w-3.5 h-3.5 text-amber-300" />
          <span>تخصيص يدوياً ⚙</span>
        </button>

        <button
          onClick={() => setIsSettingsOpen((prev) => !prev)}
          className={`p-1.5 rounded-full bg-[#12161E]/95 hover:bg-[#1C2538] border shadow-2xl transition active:scale-95 backdrop-blur-md ${
            isSettingsOpen ? 'border-blue-400 text-blue-300 bg-blue-900/40' : 'border-[#303C4E] text-gray-300 hover:text-white'
          }`}
          title="تخصيص مفصل لأماكن الأزرار وسرعة ومسافة المشي"
        >
          <Sliders className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Layout Swap Feedback Toast Banner */}
      {swapFeedback && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-[#12161E]/95 text-amber-300 border border-amber-500/80 px-4 py-2 rounded-2xl shadow-2xl flex items-center gap-2 text-xs font-bold backdrop-blur-xl animate-in fade-in slide-in-from-top-3 duration-200 pointer-events-none">
          <ArrowLeftRight className="w-4 h-4 text-amber-400 shrink-0" />
          <span>{swapFeedback}</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. SEPARATE SETTINGS MODAL / PANEL                                        */}
      {/* ========================================================================= */}
      {isSettingsOpen && (
        <div
          onPointerDown={(e) => e.stopPropagation()}
          onClick={(e) => e.stopPropagation()}
          className="fixed bottom-20 sm:bottom-24 left-4 sm:left-6 z-40 w-[310px] max-h-[80vh] overflow-y-auto bg-[#12161E]/95 backdrop-blur-xl border border-[#303C4E] rounded-2xl shadow-2xl p-4 text-white animate-in fade-in slide-in-from-bottom-4 duration-200 font-['Cairo',sans-serif] scrollbar-thin scrollbar-thumb-gray-700"
          dir="rtl"
        >
          {/* Header with Title & Close Button */}
          <div className="flex items-center justify-between border-b border-[#252E3E] pb-2.5 mb-3">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30">
                <Sliders className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold text-gray-100">إعدادات التحكم والكاميرا</span>
            </div>
            <button
              onClick={() => setIsSettingsOpen(false)}
              className="p-1 text-gray-400 hover:text-white rounded-lg hover:bg-[#1E2736] transition"
              title="إغلاق لوحة الإعدادات"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex flex-col gap-3 text-xs">
            {/* Controls Layout & Positions Swapper (User Request) */}
            <div className="bg-[#0D1117] p-2.5 rounded-xl border border-[#232C3A] flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-amber-300">تبديل أماكن الأزرار:</span>
                <span className="text-[10px] text-gray-400 font-mono">
                  {isSwapped ? 'المشي يساراً' : 'المشي يميناً'}
                </span>
              </div>
              <button
                onClick={() => handleToggleSwap()}
                className="w-full py-1.5 px-2 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center justify-center gap-2 transition active:scale-95"
              >
                <ArrowLeftRight className="w-3.5 h-3.5" />
                <span>عكس أماكن أزرار التحكم ⇄</span>
              </button>

              <div className="grid grid-cols-2 gap-1.5 pt-1 text-[10px]">
                <div className="bg-[#161C26] p-1.5 rounded-lg border border-[#243042]">
                  <span className="text-gray-400 block mb-0.5">أنالوج المشي:</span>
                  <span className="font-bold text-emerald-400">{isSwapped ? 'الجهة اليسرى' : 'الجهة اليمنى'}</span>
                </div>
                <div className="bg-[#161C26] p-1.5 rounded-lg border border-[#243042]">
                  <span className="text-gray-400 block mb-0.5">أنالوج التدوير:</span>
                  <span className="font-bold text-blue-400">{isSwapped ? 'الجهة اليمنى' : 'الجهة اليسرى'}</span>
                </div>
              </div>

              <div className="flex items-center justify-between text-[10px] text-gray-400 pt-1 border-t border-[#232C3A]">
                <span>أزرار التقريب والإجراءات:</span>
                <button
                  onClick={() => {
                    const next = actionToolbarSide === 'right' ? 'left' : 'right';
                    setActionToolbarSide(next);
                    try { localStorage.setItem('rpz_action_side', next); } catch (_) {}
                  }}
                  className="px-2 py-0.5 rounded bg-[#1C2330] text-purple-300 hover:text-white font-bold border border-[#2B374A]"
                >
                  {actionToolbarSide === 'right' ? 'اليمين' : 'اليسار'} ⇄
                </button>
              </div>

              {onToggleToolsSide && (
                <div className="flex items-center justify-between text-[10px] text-gray-400 pt-1 border-t border-[#232C3A]">
                  <span>شريط أدوات الرسم CAD:</span>
                  <button
                    onClick={onToggleToolsSide}
                    className="px-2 py-0.5 rounded bg-[#1C2330] text-cyan-300 hover:text-white font-bold border border-[#2B374A]"
                  >
                    {toolsSide === 'right' ? 'اليمين' : 'اليسار'} ⇄
                  </button>
                </div>
              )}
            </div>

            {/* Walk Stride Distance Selector (مسافة خطوة المشي للأمام والخلف) */}
            <div className="bg-[#0D1117] p-2.5 rounded-xl border border-[#232C3A] flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-gray-300">مسافة خطوة المشي:</span>
                <span className="text-[10px] font-bold text-emerald-400">
                  {walkStride <= 1.0 ? 'عادية (100 مم)' : walkStride <= 1.8 ? 'واسعة (180 مم)' : 'سريعة جداً (280 مم)'}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-1">
                {[
                  { id: 1.0, label: 'عادية', sub: '100mm' },
                  { id: 1.8, label: 'واسعة', sub: '180mm' },
                  { id: 2.8, label: 'سريعة', sub: '280mm' },
                ].map((st) => (
                  <button
                    key={st.id}
                    onClick={() => {
                      setWalkStride(st.id);
                      try { localStorage.setItem('rpz_walk_stride', String(st.id)); } catch (_) {}
                    }}
                    className={`py-1.5 px-1 rounded-lg text-center transition border ${
                      walkStride === st.id
                        ? 'bg-emerald-600 text-white border-emerald-400 font-bold shadow-sm'
                        : 'bg-[#161C26] text-gray-400 border-[#263142] hover:text-white'
                    }`}
                  >
                    <div className="text-[10px] font-bold">{st.label}</div>
                    <div className="text-[9px] opacity-75 font-mono">{st.sub}</div>
                  </button>
                ))}
              </div>
              <span className="text-[9px] text-gray-400 leading-tight">
                * المشي بخطوات واسعة يتيح لك قطع مسافات أكبر بسلاسة ودون خطوات متقطعة.
              </span>
            </div>

            {/* 1. Mode Selection: Walk vs Rotate vs Pan */}
            <div>
              <span className="text-[11px] font-bold text-gray-300 mb-1.5 block">وظيفة عصا الأنالوج:</span>
              <div className="grid grid-cols-3 gap-1 bg-[#0D1117] p-1 rounded-xl border border-[#232C3A]">
                <button
                  onClick={() => {
                    setAnalogMode('walk');
                    if (onSwitchMode) {
                      onSwitchMode('walk');
                    } else {
                      onSelectPreset('eye_level');
                    }
                  }}
                  className={`py-1.5 px-1 rounded-lg text-[10px] font-bold flex flex-col items-center gap-1 transition ${
                    analogMode === 'walk'
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'text-gray-400 hover:text-white hover:bg-[#1A2230]'
                  }`}
                >
                  <Footprints className="w-3.5 h-3.5 text-emerald-300" />
                  <span>مشي</span>
                </button>

                <button
                  onClick={() => {
                    setAnalogMode('rotate');
                    if (onSwitchMode) {
                      onSwitchMode('rotate');
                    } else if (activePreset === 'eye_level') {
                      onSelectPreset('perspective');
                    }
                  }}
                  className={`py-1.5 px-1 rounded-lg text-[10px] font-bold flex flex-col items-center gap-1 transition ${
                    analogMode === 'rotate'
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-gray-400 hover:text-white hover:bg-[#1A2230]'
                  }`}
                >
                  <Disc className="w-3.5 h-3.5" />
                  <span>تدوير 360°</span>
                </button>

                <button
                  onClick={() => {
                    setAnalogMode('pan');
                    if (onSwitchMode) {
                      onSwitchMode('pan');
                    }
                  }}
                  className={`py-1.5 px-1 rounded-lg text-[10px] font-bold flex flex-col items-center gap-1 transition ${
                    analogMode === 'pan'
                      ? 'bg-purple-600 text-white shadow-sm'
                      : 'text-gray-400 hover:text-white hover:bg-[#1A2230]'
                  }`}
                >
                  <Move className="w-3.5 h-3.5 text-purple-300" />
                  <span>إزاحة Pan</span>
                </button>
              </div>
            </div>

            {/* 2. Speed Controller */}
            <div className="bg-[#0D1117] p-2.5 rounded-xl border border-[#232C3A] flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-gray-300">سرعة الحركة:</span>
                <span className="text-[11px] font-mono font-bold text-blue-400">
                  {baseSpeed.toFixed(1)}x
                </span>
              </div>

              {/* Quick speed buttons */}
              <div className="grid grid-cols-4 gap-1">
                {[0.5, 1.0, 1.5, 2.0].map((s) => (
                  <button
                    key={s}
                    onClick={() => {
                      setBaseSpeed(s);
                    }}
                    className={`py-1 rounded-lg font-mono text-[11px] transition border ${
                      baseSpeed === s
                        ? 'bg-blue-600 text-white border-blue-400 font-bold'
                        : 'bg-[#161C26] text-gray-400 border-[#263142] hover:text-white'
                    }`}
                  >
                    {s.toFixed(1)}x
                  </button>
                ))}
              </div>
            </div>

            {/* 3. D-Pad Directional Arrows Toggle */}
            <div className="flex items-center justify-between bg-[#0D1117] p-2.5 rounded-xl border border-[#232C3A]">
              <span className="text-[11px] font-bold text-gray-300">أزرار الأسهم D-Pad:</span>
              <button
                onClick={() => setShowDpad((prev) => !prev)}
                className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition ${
                  showDpad ? 'bg-blue-600 text-white' : 'bg-[#1C2330] text-gray-400 hover:text-white'
                }`}
              >
                {showDpad ? 'مُفعّلة' : 'مخفية'}
              </button>
            </div>

            {/* D-Pad Buttons if toggled */}
            {showDpad && (
              <div className="relative w-28 h-28 mx-auto bg-[#0A0D13] rounded-2xl border border-[#263142] p-1 flex items-center justify-center shadow-inner my-1">
                {/* Up */}
                <button
                  onClick={() => {
                    if (analogMode === 'walk' && onWalkAnalog) onWalkAnalog(1, 0, baseSpeed * walkStride * 3.5);
                    else if (analogMode === 'pan') onPanCamera(0, 50 * baseSpeed);
                    else onRotateCamera('up');
                  }}
                  title="أعلى / للأمام"
                  className="absolute top-1 left-1/2 -translate-x-1/2 w-7 h-7 rounded-md bg-[#1F2736] hover:bg-blue-600 text-gray-200 hover:text-white flex items-center justify-center shadow transition border border-[#344157]"
                >
                  <ChevronUp className="w-4 h-4" />
                </button>

                {/* Down */}
                <button
                  onClick={() => {
                    if (analogMode === 'walk' && onWalkAnalog) onWalkAnalog(-1, 0, baseSpeed * walkStride * 3.5);
                    else if (analogMode === 'pan') onPanCamera(0, -50 * baseSpeed);
                    else onRotateCamera('down');
                  }}
                  title="أسفل / للخلف"
                  className="absolute bottom-1 left-1/2 -translate-x-1/2 w-7 h-7 rounded-md bg-[#1F2736] hover:bg-blue-600 text-gray-200 hover:text-white flex items-center justify-center shadow transition border border-[#344157]"
                >
                  <ChevronDown className="w-4 h-4" />
                </button>

                {/* Left */}
                <button
                  onClick={() => {
                    if (analogMode === 'walk' && onWalkAnalog) onWalkAnalog(0, -1, baseSpeed * walkStride * 3.5);
                    else if (analogMode === 'pan') onPanCamera(-50 * baseSpeed, 0);
                    else onRotateCamera('left');
                  }}
                  title="يسار"
                  className="absolute left-1 top-1/2 -translate-y-1/2 w-7 h-7 rounded-md bg-[#1F2736] hover:bg-blue-600 text-gray-200 hover:text-white flex items-center justify-center shadow transition border border-[#344157]"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>

                {/* Right */}
                <button
                  onClick={() => {
                    if (analogMode === 'walk' && onWalkAnalog) onWalkAnalog(0, 1, baseSpeed * walkStride * 3.5);
                    else if (analogMode === 'pan') onPanCamera(50 * baseSpeed, 0);
                    else onRotateCamera('right');
                  }}
                  title="يمين"
                  className="absolute right-1 top-1/2 -translate-y-1/2 w-7 h-7 rounded-md bg-[#1F2736] hover:bg-blue-600 text-gray-200 hover:text-white flex items-center justify-center shadow transition border border-[#344157]"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>

                {/* Center Reset */}
                <button
                  onClick={onResetView}
                  title="توسيط"
                  className="w-6 h-6 rounded bg-blue-600/30 hover:bg-blue-600 text-blue-300 hover:text-white border border-blue-500/50 flex items-center justify-center transition"
                >
                  <RotateCcw className="w-3 h-3" />
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Manual Controls Position Customizer Modal (User Request) */}
      <ManualControlsPositionModal
        isOpen={isManualModalOpen}
        onClose={() => setIsManualModalOpen(false)}
        config={layoutConfig}
        onChangeConfig={handleUpdateLayoutConfig}
        onQuickSwap={() => handleToggleSwap()}
      />
    </>
  );
};
