import React from 'react';
import { X, Plus, Check, Ruler, Box, Layers, Sparkles } from 'lucide-react';
import { CatalogItemTemplate } from '../../types';
import { UnitShapePreview } from './UnitShapePreview';

interface ItemDetailsModalProps {
  template: CatalogItemTemplate | null;
  onClose: () => void;
  onAdd: (template: CatalogItemTemplate) => void;
}

export const ItemDetailsModal: React.FC<ItemDetailsModalProps> = ({ template, onClose, onAdd }) => {
  if (!template) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div
        id="item-details-dialog"
        className="w-full max-w-md bg-[#1C1C1E] border border-white/15 rounded-3xl shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-200"
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between">
          <h3 className="text-sm font-bold text-white tracking-wide">{template.nameAr || template.name}</h3>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-white/10 text-zinc-400 hover:text-white flex items-center justify-center transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* 3D Visual Preview Area */}
        <div className="p-6 bg-[#141416] flex items-center justify-center border-b border-white/10">
          <div className="w-28 h-28 flex items-center justify-center bg-zinc-900 rounded-2xl p-3 border border-white/10 shadow-inner">
            <UnitShapePreview template={template} className="w-24 h-24" />
          </div>
        </div>

        {/* Specs and Details */}
        <div className="p-5 space-y-4 flex-1">
          <div>
            <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">الوصف والمواصفات</span>
            <p className="text-xs text-zinc-300 mt-1 leading-relaxed">
              {template.descriptionAr || 'وحدة قياسية مصممة بمعايير هندسية متطورة مع تحكم ديناميكي كامل في المقاسات والخامات.'}
            </p>
          </div>

          {/* Dimension Grid */}
          <div className="grid grid-cols-3 gap-2.5 pt-1">
            <div className="p-2.5 rounded-xl bg-zinc-900 border border-white/5 text-center">
              <span className="text-[10px] text-zinc-400 block font-semibold">العرض</span>
              <span className="text-xs font-bold text-white mt-0.5 block">{template.defaultWidth / 10} سم</span>
            </div>
            <div className="p-2.5 rounded-xl bg-zinc-900 border border-white/5 text-center">
              <span className="text-[10px] text-zinc-400 block font-semibold">الارتفاع</span>
              <span className="text-xs font-bold text-white mt-0.5 block">{template.defaultHeight / 10} سم</span>
            </div>
            <div className="p-2.5 rounded-xl bg-zinc-900 border border-white/5 text-center">
              <span className="text-[10px] text-zinc-400 block font-semibold">العمق</span>
              <span className="text-xs font-bold text-white mt-0.5 block">{template.defaultDepth / 10} سم</span>
            </div>
          </div>

          {/* Door / Drawer counts */}
          <div className="flex items-center gap-4 text-[11px] text-zinc-400 bg-zinc-900/50 p-3 rounded-xl border border-white/5">
            <div>
              الأبواب: <span className="font-bold text-white">{template.defaultDoors}</span>
            </div>
            <div>
              الأدراج: <span className="font-bold text-white">{template.defaultDrawers}</span>
            </div>
            {template.badge && (
              <div className="mr-auto px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30 text-[10px] font-bold">
                {template.badge}
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-white/10 bg-zinc-900/50 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 rounded-full text-xs font-bold text-zinc-400 hover:text-white hover:bg-white/10 transition"
          >
            إغلاق
          </button>
          <button
            type="button"
            onClick={() => {
              onAdd(template);
              onClose();
            }}
            className="px-6 py-2.5 rounded-full text-xs font-bold bg-amber-400 hover:bg-amber-300 text-zinc-950 shadow-lg shadow-amber-400/25 transition active:scale-95 flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة إلى الغرفة</span>
          </button>
        </div>
      </div>
    </div>
  );
};
