import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  Project,
  ParametricCabinet,
  CatalogItemTemplate,
  CameraPreset,
  ShadingMode,
  RoomConfig,
  LightingConfig,
  WallOpening,
  ProjectType,
  CustomWall,
} from '../../types';
import { SceneManager } from '../../rendering/SceneManager';
import { createCabinetFromTemplate } from '../../domain/catalog/unitsCatalog';
import { projectRepository } from '../../domain/storage/projectRepository';
import { HistoryManager } from '../../domain/undo/historyManager';
import { PropertiesPanel } from './PropertiesPanel';
import { RPZCatalogPanel } from './RPZCatalogPanel';
import { CatalogDrawer } from './CatalogDrawer';
import { RoomSetupModal } from './RoomSetupModal';
import { FloorPlan2DView } from './FloorPlan2DView';
import { MaterialsModal } from './MaterialsModal';
import { DoorDrawerControlsModal } from './DoorDrawerControlsModal';
import { CostCutListModal } from './CostCutListModal';
import { VideoWalkthroughModal } from './VideoWalkthroughModal';
import { LightingModal } from './LightingModal';
import { FloorPlan2DModal } from './FloorPlan2DModal';
import { CADCameraOverlay } from './CADCameraOverlay';
import { CabinetDpadControls } from './CabinetDpadControls';
import { GameModeOverlay } from './GameModeOverlay';
import { ProjectSwitcherModal } from './ProjectSwitcherModal';
import { ManualControlsPositionModal, ControlsLayoutConfig } from './ManualControlsPositionModal';
import { RoomPlannerHeader } from './RoomPlannerHeader';
import { RoomPlannerBottomBar } from './RoomPlannerBottomBar';
import { FloatingObjectActions } from './FloatingObjectActions';
import { RoomPlannerCatalogModal } from './RoomPlannerCatalogModal';
import { StyleQuizModal } from './StyleQuizModal';
import { HelpGuideModal } from './HelpGuideModal';
import { AIUnitGeneratorModal } from './AIUnitGeneratorModal';
import { generateAutoRoomLayout, AutoRoomLayoutType } from '../../domain/room/autoRoomBuilder';
import {
  ArrowRight,
  Save,
  Undo2,
  Redo2,
  Plus,
  Home,
  Smartphone,
  Monitor,
  Sliders,
  DollarSign,
  Video,
  Camera,
  Layers,
  Ruler,
  RotateCcw,
  Sparkles,
  Maximize2,
  Play,
  CheckCircle2,
  Box,
  Layout,
  Eye,
  Lightbulb,
  Sun,
  Zap,
  MousePointer,
  Paintbrush,
  Hand,
  RotateCw,
  Trash2,
  Copy,
  FolderOpen,
  HelpCircle,
  Settings,
  Grid,
  Square,
  Compass,
  PanelLeftClose,
  PanelLeftOpen,
  PanelRightClose,
  PanelRightOpen,
  Move,
  Wand2,
  Shield,
  DoorClosed,
  PenTool,
  Trees,
  EyeOff,
  ArrowLeftRight,
  Gamepad2,
  FolderKanban,
  ChevronDown,
  X,
} from 'lucide-react';

interface DesignerScreenProps {
  initialProject: Project;
  onBackToDashboard: () => void;
  onSwitchProject?: (project: Project) => void;
  onOpenProjectsList?: () => void;
  onCreateNewProject?: (type: ProjectType, name?: string) => void;
}

export type CADToolType =
  | 'select'
  | 'rpz_catalog'
  | 'wall'
  | 'tape'
  | 'paint'
  | 'interact'
  | 'eye'
  | 'rotate'
  | 'delete';

export const DesignerScreen: React.FC<DesignerScreenProps> = ({
  initialProject,
  onBackToDashboard,
  onSwitchProject,
  onOpenProjectsList,
  onCreateNewProject,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneManagerRef = useRef<SceneManager | null>(null);
  const historyManagerRef = useRef<HistoryManager>(new HistoryManager(initialProject));

  const [project, setProject] = useState<Project>(initialProject);
  const [selectedUnitId, setSelectedUnitId] = useState<string | null>(
    initialProject.units.length > 0 ? initialProject.units[0].id : null
  );

  // Game Mode State (User Request: تشغيل التطبيق كاللعبة وفتح الأبواب وتصوير فيديو)
  const [isGameModeOpen, setIsGameModeOpen] = useState<boolean>(false);

  // Project Switcher Modal State (User Request: التنقل بين المشاريع)
  const [isProjectSwitcherOpen, setIsProjectSwitcherOpen] = useState<boolean>(false);

  // Active CAD Tool
  const [activeTool, setActiveTool] = useState<CADToolType>('select');

  // Docked Trays & Visibility (Default false for clean modern Room Planner UI)
  const [isRPZDockedOpen, setIsRPZDockedOpen] = useState(false);
  const [isPropertiesDockedOpen, setIsPropertiesDockedOpen] = useState(false);

  // Modern Room Planner UI States (Matching Screenshots)
  const [isCatalogOpen, setIsCatalogOpen] = useState<boolean>(false);
  const [isStyleQuizOpen, setIsStyleQuizOpen] = useState<boolean>(false);
  const [isHelpGuideOpen, setIsHelpGuideOpen] = useState<boolean>(false);
  const [cameraMode, setCameraMode] = useState<'360' | 'walk'>('360');
  const [catalogInitialSearch, setCatalogInitialSearch] = useState<string>('');
  const [isReplacingUnit, setIsReplacingUnit] = useState<boolean>(false);

  // Modals Visibility
  const [isRoomSetupOpen, setIsRoomSetupOpen] = useState(false);
  const [isFloorPlan2DOpen, setIsFloorPlan2DOpen] = useState(false);
  const [isMaterialsOpen, setIsMaterialsOpen] = useState(false);
  const [isDoorsOpen, setIsDoorsOpen] = useState(false);
  const [isCostOpen, setIsCostOpen] = useState(false);
  const [isVideoTourOpen, setIsVideoTourOpen] = useState(false);
  const [isLightingOpen, setIsLightingOpen] = useState(false);
  const [isAIGeneratorOpen, setIsAIGeneratorOpen] = useState(false);

  // Viewport & Mode Settings
  const [isMobileMode, setIsMobileMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return window.innerWidth < 768;
    }
    return false;
  });
  const [isLandscapeMode, setIsLandscapeMode] = useState(false);
  const [activeCameraPreset, setActiveCameraPreset] = useState<CameraPreset>('perspective');
  const [activeShading, setActiveShading] = useState<ShadingMode>('realistic');
  const [isMeasureActive, setIsMeasureActive] = useState(false);
  const [measuredDistance, setMeasuredDistance] = useState<number | null>(null);
  const [saveNotification, setSaveNotification] = useState(false);
  const [isCleanView, setIsCleanView] = useState<boolean>(false);

  // D-Pad and Collision Prevention State
  const [collisionGuardEnabled, setCollisionGuardEnabled] = useState<boolean>(true);
  const [isDpadOpen, setIsDpadOpen] = useState<boolean>(true);

  // Opening (Window & Door) Selection State
  const [selectedOpeningId, setSelectedOpeningId] = useState<string | null>(null);

  // Direct Click-to-Open & Smooth Orbit State
  const [isInteractMode, setIsInteractMode] = useState<boolean>(false);
  const [hideInteractTutorial, setHideInteractTutorial] = useState<boolean>(() => {
    try {
      return localStorage.getItem('rpz_hide_interact_tutorial') === 'true';
    } catch (_) {
      return false;
    }
  });
  const [isAutoRotate, setIsAutoRotate] = useState<boolean>(false);

  // User Requested: Ability to swap analog controls and CAD buttons layout
  const [toolsSide, setToolsSide] = useState<'left' | 'right'>(() => {
    try {
      return (localStorage.getItem('rpz_tools_side') as 'left' | 'right') || 'left';
    } catch {
      return 'left';
    }
  });
  const [controlsLayoutTrigger, setControlsLayoutTrigger] = useState<number>(0);

  const handleToggleControlsLayout = () => {
    setControlsLayoutTrigger((prev) => prev + 1);
  };

  const handleToggleToolsSide = () => {
    setToolsSide((prev) => {
      const next = prev === 'left' ? 'right' : 'left';
      try { localStorage.setItem('rpz_tools_side', next); } catch (_) {}
      return next;
    });
  };

  // View Mode (3D Perspective vs 2D Floor Plan)
  const [viewMode, setViewMode] = useState<'3d' | '2d'>('3d');
  const [selectedCustomWallId, setSelectedCustomWallId] = useState<string | null>(null);

  // Camera 0.5x Ultra-Wide Mode (User Request: مع كامر 0.5)
  const [isWide05, setIsWide05] = useState<boolean>(false);
  const handleToggleWide05 = () => {
    if (sceneManagerRef.current) {
      const next = sceneManagerRef.current.toggleCameraWide05();
      setIsWide05(next);
    }
  };
  const [isUnitSettingsHidden, setIsUnitSettingsHidden] = useState<boolean>(false);

  // SketchUp Value Control Box (VCB) input
  const [vcbInput, setVcbInput] = useState('');

  const selectedUnit = project.units.find((u) => u.id === selectedUnitId) || null;
  const selectedCustomWall = project.room.customWalls?.find((w) => w.id === selectedCustomWallId) || null;
  const selectedOpening = project.room.openings?.find((o) => o.id === selectedOpeningId) || null;

  // Initialize Three.js Scene
  useEffect(() => {
    if (!containerRef.current) return;

    const sm = new SceneManager(containerRef.current, project, {
      onUnitSelect: (id) => {
        setSelectedUnitId(id);
        if (id) {
          setSelectedOpeningId(null);
          setSelectedCustomWallId(null);
          setIsUnitSettingsHidden(false);
        }
      },
      onCustomWallSelect: (wallId) => {
        setSelectedCustomWallId(wallId);
        if (wallId) {
          setSelectedUnitId(null);
          setSelectedOpeningId(null);
          setIsUnitSettingsHidden(false);
        }
      },
      onOpeningSelect: (id) => {
        setSelectedOpeningId(id);
        if (id) {
          setSelectedUnitId(null);
          setSelectedCustomWallId(null);
        }
      },
      onDoorToggle: (unitId, doorIdx) => {
        setProject((prev) => {
          const updated = { ...prev };
          const u = updated.units.find((x) => x.id === unitId);
          if (u && u.doors && u.doors[doorIdx]) {
            const cur = u.doors[doorIdx].targetAngle || 0;
            u.doors[doorIdx].targetAngle = cur > 45 ? 0 : 90;
          }
          return { ...updated };
        });
      },
      onDrawerToggle: (unitId, drawerIdx) => {
        setProject((prev) => {
          const updated = { ...prev };
          const u = updated.units.find((x) => x.id === unitId);
          if (u && u.drawers && u.drawers[drawerIdx]) {
            const cur = u.drawers[drawerIdx].targetAmount || 0;
            u.drawers[drawerIdx].targetAmount = cur > 0.5 ? 0 : 1;
          }
          return { ...updated };
        });
      },
      onUnitInteractToggle: (unitId, isOpen) => {
        setProject((prev) => {
          const updated = { ...prev };
          const u = updated.units.find((x) => x.id === unitId);
          if (u) {
            if (u.doors) {
              u.doors.forEach((d) => {
                d.targetAngle = isOpen ? 90 : 0;
              });
            }
            if (u.drawers) {
              u.drawers.forEach((d) => {
                d.targetAmount = isOpen ? 1 : 0;
              });
            }
          }
          return { ...updated };
        });
      },
      onMeasureDistance: (dist) => {
        setMeasuredDistance(dist);
      },
    });

    sceneManagerRef.current = sm;

    const handleResize = () => {
      sm.resize();
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      sm.dispose();
      sceneManagerRef.current = null;
    };
  }, []);

  // Update Scene when project changes
  const applyProjectState = useCallback((newProject: Project, recordHistory: boolean = true) => {
    setProject(newProject);
    if (recordHistory) {
      historyManagerRef.current.pushState(newProject);
    }
    if (sceneManagerRef.current) {
      sceneManagerRef.current.project = newProject;
      sceneManagerRef.current.rebuildRoom();
      sceneManagerRef.current.rebuildAllCabinets();
    }
  }, []);

  // Update Room Config & Walls (2D and 3D Sync)
  const handleUpdateRoom = (newRoom: RoomConfig, recordHistory: boolean = true) => {
    const updated = { ...project, room: newRoom };
    setProject(updated);
    if (recordHistory) {
      historyManagerRef.current.pushState(updated);
    }
    if (sceneManagerRef.current) {
      sceneManagerRef.current.project = updated;
      sceneManagerRef.current.updateRoom(newRoom);
      sceneManagerRef.current.requestRender?.();
    }
  };

  // Save Project with snapshot
  const handleSave = () => {
    if (sceneManagerRef.current) {
      const snapshot = sceneManagerRef.current.captureSnapshot();
      const updated = { ...project, thumbnail: snapshot, updatedAt: new Date().toISOString() };
      projectRepository.saveProject(updated);
      setProject(updated);
    } else {
      projectRepository.saveProject(project);
    }
    setSaveNotification(true);
    setTimeout(() => setSaveNotification(false), 2500);
  };

  // Undo / Redo
  const handleUndo = () => {
    const prevState = historyManagerRef.current.undo();
    if (prevState) {
      applyProjectState(prevState, false);
    }
  };

  const handleRedo = () => {
    const nextState = historyManagerRef.current.redo();
    if (nextState) {
      applyProjectState(nextState, false);
    }
  };

  // Add Template Unit from RPZ Catalog or AI Generator without freezing
  const handleAddTemplate = (template: CatalogItemTemplate) => {
    const existing = project.units;
    let posX = 0;
    let posZ = 0;
    let lastSnapTarget: ParametricCabinet | null = null;

    if (existing.length > 0) {
      const last = existing[existing.length - 1];
      const isLastBase = last.category === 'kitchen_base' || last.category === 'kitchen_corner';
      const isNewBase = template.category === 'kitchen_base' || template.category === 'kitchen_corner';

      if (isLastBase && isNewBase) {
        // Automatically snap seamlessly to the right of the previous unit with 0 gap
        const rad = ((last.rotationY || 0) * Math.PI) / 180;
        const rightX = Math.cos(rad);
        const rightZ = Math.sin(rad);
        const D = (last.width / 2) + ((template.defaultWidth || 600) / 2);
        posX = last.positionX + D * rightX;
        posZ = last.positionZ + D * rightZ;
        lastSnapTarget = last;
      } else {
        posX = last.positionX + (last.width / 2) + ((template.defaultWidth || 600) / 2) + 20;
        posZ = last.positionZ;
      }

      const roomHalfW = (project.room.width || 6000) / 2 - 400;
      if (Math.abs(posX) > roomHalfW) {
        posX = -roomHalfW + 400;
        posZ = last.positionZ + 800;
        lastSnapTarget = null;
      }
    }

    const newUnit = createCabinetFromTemplate(template, existing.length);
    newUnit.positionX = Math.round(posX);
    newUnit.positionZ = Math.round(posZ);

    let updatedExisting = [...existing];
    if (lastSnapTarget) {
      newUnit.rotationY = lastSnapTarget.rotationY || 0;
      newUnit.positionY = lastSnapTarget.positionY || 0;
      newUnit.height = lastSnapTarget.height;
      newUnit.legsHeight = lastSnapTarget.legsHeight || 100;
      newUnit.depth = lastSnapTarget.depth;

      // Harmonize countertop to form one seamless continuous surface
      if (lastSnapTarget.countertop && newUnit.countertop) {
        const ctMat = lastSnapTarget.countertop.materialId || 'marble_calacatta_gold';
        const ctCol = lastSnapTarget.countertop.color || '#ede8df';
        const ctThick = lastSnapTarget.countertop.thickness || 35;
        const ctFrontOh = lastSnapTarget.countertop.overhangFront || 25;

        // Last unit right overhang = 0
        const updatedLast: ParametricCabinet = {
          ...lastSnapTarget,
          countertop: {
            ...lastSnapTarget.countertop,
            materialId: ctMat,
            color: ctCol,
            thickness: ctThick,
            overhangRight: 0,
            waterfallRight: false,
            overhangFront: ctFrontOh,
          },
        };
        updatedExisting = updatedExisting.map((u) => (u.id === updatedLast.id ? updatedLast : u));

        // New unit left overhang = 0
        newUnit.countertop = {
          ...newUnit.countertop,
          materialId: ctMat,
          color: ctCol,
          thickness: ctThick,
          overhangLeft: 0,
          waterfallLeft: false,
          overhangFront: ctFrontOh,
        };
      }
    }

    const updatedUnits = [...updatedExisting, newUnit];
    const updatedProject = { ...project, units: updatedUnits };

    setProject(updatedProject);
    historyManagerRef.current.pushState(updatedProject);

    if (sceneManagerRef.current) {
      sceneManagerRef.current.project = updatedProject;
      if (lastSnapTarget) {
        const updatedLast = updatedExisting.find((u) => u.id === lastSnapTarget!.id);
        if (updatedLast) sceneManagerRef.current.updateCabinet(updatedLast);
      }
      sceneManagerRef.current.updateCabinet(newUnit);
      sceneManagerRef.current.requestRender?.();
    }

    setSelectedUnitId(newUnit.id);
    setIsPropertiesDockedOpen(false);
    setIsRPZDockedOpen(false);
    setIsCatalogOpen(false);
  };

  // Apply Material and Color to All Units in Project (User Request)
  const handleApplyMaterialToAll = (materialId: string, color: string, target: 'front' | 'body' | 'countertop') => {
    const updatedUnits = project.units.map((u) => {
      if (target === 'front') {
        const updatedDoors = (u.doors || []).map((d) => ({ ...d, materialId, color }));
        const updatedDrawers = (u.drawers || []).map((d) => ({ ...d, materialId, color }));
        return {
          ...u,
          frontMaterialId: materialId,
          frontColor: color,
          color: color,
          doors: updatedDoors,
          drawers: updatedDrawers,
        };
      } else if (target === 'body') {
        return {
          ...u,
          bodyMaterialId: materialId,
          bodyColor: color,
        };
      } else {
        return {
          ...u,
          countertop: u.countertop
            ? { ...u.countertop, materialId, color, enabled: true }
            : {
                enabled: true,
                thickness: 30,
                overhangFront: 20,
                overhangBack: 0,
                overhangLeft: 0,
                overhangRight: 0,
                materialId,
                color,
              },
        };
      }
    });

    const updatedProject = { ...project, units: updatedUnits };
    setProject(updatedProject);
    historyManagerRef.current.pushState(updatedProject);

    if (sceneManagerRef.current) {
      sceneManagerRef.current.project = updatedProject;
      sceneManagerRef.current.rebuildAllCabinets();
      sceneManagerRef.current.requestRender?.();
    }
  };

  // Update Single Unit
  const handleUpdateUnit = (updatedUnit: ParametricCabinet) => {
    const updatedUnits = project.units.map((u) => (u.id === updatedUnit.id ? updatedUnit : u));
    const updatedProject = { ...project, units: updatedUnits };
    setProject(updatedProject);
    historyManagerRef.current.pushState(updatedProject);
    if (sceneManagerRef.current) {
      sceneManagerRef.current.project = updatedProject;
      sceneManagerRef.current.updateCabinet(updatedUnit);
    }
  };

  // Duplicate Unit
  const handleDuplicateUnit = (unit: ParametricCabinet) => {
    const duplicated: ParametricCabinet = {
      ...unit,
      id: `unit_${Date.now()}`,
      nameAr: `${unit.nameAr} (نسخة)`,
      positionX: unit.positionX + unit.width + 20,
    };
    const updatedUnits = [...project.units, duplicated];
    const updatedProject = { ...project, units: updatedUnits };
    applyProjectState(updatedProject);
    setSelectedUnitId(duplicated.id);
  };

  // Delete Unit
  const handleDeleteUnit = (unitId: string) => {
    const updatedUnits = project.units.filter((u) => u.id !== unitId);
    const updatedProject = { ...project, units: updatedUnits };
    applyProjectState(updatedProject);
    if (sceneManagerRef.current) {
      sceneManagerRef.current.removeCabinet(unitId);
    }
    setSelectedUnitId(updatedUnits.length > 0 ? updatedUnits[0].id : null);
  };

  // Rotate selected unit by 90 degrees
  const handleRotateSelected = (deltaDeg: number = 90) => {
    if (!selectedUnit) return;
    const newRot = (selectedUnit.rotationY + deltaDeg) % 360;
    handleUpdateUnit({ ...selectedUnit, rotationY: newRot });
  };

  // Snap and Merge Unit to Adjacent Unit (Left or Right) with Continuous Seamless Countertop
  // (ميزة دمج الوحدة الجديدة بالقديمة من اليمين أو اليسار وتوحيد السطحين كسطح واحد متصل)
  const handleSnapAndMergeUnit = (side: 'left' | 'right', unitId?: string) => {
    const targetUnitId = unitId || selectedUnitId;
    if (!targetUnitId) return;

    const current = project.units.find((u) => u.id === targetUnitId);
    if (!current) return;

    // Find the closest compatible cabinet to merge with
    const otherUnits = project.units.filter((u) => u.id !== current.id);
    if (otherUnits.length === 0) return;

    // Prefer base units with base units, wall with wall, tall with tall
    const isBase = current.category === 'kitchen_base' || current.category === 'kitchen_corner';
    const compatibleUnits = otherUnits.filter((u) =>
      isBase ? u.category === 'kitchen_base' || u.category === 'kitchen_corner' : true
    );

    const candidates = compatibleUnits.length > 0 ? compatibleUnits : otherUnits;

    let target: ParametricCabinet = candidates[0];
    let minDist = Infinity;
    for (const u of candidates) {
      const d = Math.hypot(u.positionX - current.positionX, u.positionZ - current.positionZ);
      if (d < minDist) {
        minDist = d;
        target = u;
      }
    }

    // Target rotation in radians
    const rad = ((target.rotationY || 0) * Math.PI) / 180;
    const rightX = Math.cos(rad);
    const rightZ = Math.sin(rad);

    // Distance between unit centers for exact 0-gap contact
    const halfDist = (target.width / 2) + (current.width / 2);

    let newPosX = 0;
    let newPosZ = 0;

    if (side === 'right') {
      // Place current to the RIGHT of target
      newPosX = target.positionX + halfDist * rightX;
      newPosZ = target.positionZ + halfDist * rightZ;
    } else {
      // Place current to the LEFT of target
      newPosX = target.positionX - halfDist * rightX;
      newPosZ = target.positionZ - halfDist * rightZ;
    }

    // Synchronize height, legs, depth, rotation
    const newRotY = target.rotationY || 0;
    const newPosY = target.positionY || 0;
    const newHeight = target.height;
    const newLegsHeight = target.legsHeight || 100;
    const newDepth = target.depth;

    // Harmonize countertops: identical marble/quartz, zero-gap junction, flush seamless plane
    let updatedTarget = { ...target };
    let updatedCurrent = {
      ...current,
      positionX: Math.round(newPosX),
      positionY: newPosY,
      positionZ: Math.round(newPosZ),
      rotationY: newRotY,
      height: newHeight,
      depth: newDepth,
      legsHeight: newLegsHeight,
    };

    if (isBase || target.countertop || current.countertop) {
      const unifiedMat = target.countertop?.materialId || current.countertop?.materialId || 'marble_calacatta_gold';
      const unifiedColor = target.countertop?.color || current.countertop?.color || '#ede8df';
      const unifiedThickness = target.countertop?.thickness || current.countertop?.thickness || 35;
      const unifiedFrontOh = target.countertop?.overhangFront || current.countertop?.overhangFront || 25;
      const unifiedBackOh = 0;
      const unifiedBacksplash = target.countertop?.hasBacksplash ?? current.countertop?.hasBacksplash ?? true;
      const unifiedBsHeight = target.countertop?.backsplashHeight || current.countertop?.backsplashHeight || 60;

      if (side === 'right') {
        // target is on the left, current is on the right
        // target right overhang = 0, current left overhang = 0
        updatedTarget = {
          ...updatedTarget,
          countertop: {
            ...(updatedTarget.countertop || { enabled: true, thickness: 35, overhangFront: 25, overhangBack: 0, overhangLeft: 0, overhangRight: 0 }),
            enabled: true,
            materialId: unifiedMat,
            color: unifiedColor,
            thickness: unifiedThickness,
            overhangFront: unifiedFrontOh,
            overhangBack: unifiedBackOh,
            overhangRight: 0,
            waterfallRight: false,
            hasBacksplash: unifiedBacksplash,
            backsplashHeight: unifiedBsHeight,
          },
        };

        updatedCurrent = {
          ...updatedCurrent,
          countertop: {
            ...(updatedCurrent.countertop || { enabled: true, thickness: 35, overhangFront: 25, overhangBack: 0, overhangLeft: 0, overhangRight: 0 }),
            enabled: true,
            materialId: unifiedMat,
            color: unifiedColor,
            thickness: unifiedThickness,
            overhangFront: unifiedFrontOh,
            overhangBack: unifiedBackOh,
            overhangLeft: 0,
            waterfallLeft: false,
            hasBacksplash: unifiedBacksplash,
            backsplashHeight: unifiedBsHeight,
          },
        };
      } else {
        // current is on the left, target is on the right
        // current right overhang = 0, target left overhang = 0
        updatedCurrent = {
          ...updatedCurrent,
          countertop: {
            ...(updatedCurrent.countertop || { enabled: true, thickness: 35, overhangFront: 25, overhangBack: 0, overhangLeft: 0, overhangRight: 0 }),
            enabled: true,
            materialId: unifiedMat,
            color: unifiedColor,
            thickness: unifiedThickness,
            overhangFront: unifiedFrontOh,
            overhangBack: unifiedBackOh,
            overhangRight: 0,
            waterfallRight: false,
            hasBacksplash: unifiedBacksplash,
            backsplashHeight: unifiedBsHeight,
          },
        };

        updatedTarget = {
          ...updatedTarget,
          countertop: {
            ...(updatedTarget.countertop || { enabled: true, thickness: 35, overhangFront: 25, overhangBack: 0, overhangLeft: 0, overhangRight: 0 }),
            enabled: true,
            materialId: unifiedMat,
            color: unifiedColor,
            thickness: unifiedThickness,
            overhangFront: unifiedFrontOh,
            overhangBack: unifiedBackOh,
            overhangLeft: 0,
            waterfallLeft: false,
            hasBacksplash: unifiedBacksplash,
            backsplashHeight: unifiedBsHeight,
          },
        };
      }
    }

    const updatedUnits = project.units.map((u) => {
      if (u.id === updatedCurrent.id) return updatedCurrent;
      if (u.id === updatedTarget.id) return updatedTarget;
      return u;
    });

    const updatedProject = { ...project, units: updatedUnits };
    applyProjectState(updatedProject);
    setSelectedUnitId(updatedCurrent.id);
  };

  // Unify all base cabinet countertops into a single seamless continuous surface
  const handleUnifyAllCountertops = () => {
    const baseUnits = project.units.filter(
      (u) => (u.category === 'kitchen_base' || u.category === 'kitchen_corner') && u.countertop?.enabled
    );
    if (baseUnits.length === 0) return;

    const benchmark = baseUnits[0].countertop!;
    const matId = benchmark.materialId || 'marble_calacatta_gold';
    const matColor = benchmark.color || '#ede8df';
    const ctThickness = benchmark.thickness || 35;
    const frontOh = benchmark.overhangFront || 25;

    const updatedUnits = project.units.map((u) => {
      if (u.category === 'kitchen_base' || u.category === 'kitchen_corner') {
        return {
          ...u,
          countertop: {
            ...(u.countertop || { enabled: true }),
            enabled: true,
            materialId: matId,
            color: matColor,
            thickness: ctThickness,
            overhangLeft: 0,
            overhangRight: 0,
            overhangFront: frontOh,
            overhangBack: 0,
          },
        };
      }
      return u;
    });

    const updatedProject = { ...project, units: updatedUnits };
    applyProjectState(updatedProject);
  };

  // Modern Room Planner Camera Mode Switching (360° orbit vs Walk)
  const handleCameraModeChange = (mode: '360' | 'walk') => {
    setCameraMode(mode);
    if (mode === 'walk') {
      handleSwitchCameraMode('walk');
    } else {
      handleSwitchCameraMode('rotate');
    }
  };

  const handleToggleWalkMode = () => {
    const nextMode = cameraMode === '360' ? 'walk' : '360';
    handleCameraModeChange(nextMode);
  };

  // Replace selected unit with a new template from catalog while preserving position & rotation
  const handleStartReplaceUnit = () => {
    setIsReplacingUnit(true);
    setIsCatalogOpen(true);
  };

  const handleReplaceWithTemplate = (template: CatalogItemTemplate) => {
    if (!selectedUnitId) return;
    const cur = project.units.find((u) => u.id === selectedUnitId);
    if (!cur) return;
    const newUnit = createCabinetFromTemplate(
      template,
      project.units.findIndex((u) => u.id === selectedUnitId)
    );
    newUnit.id = cur.id;
    newUnit.positionX = cur.positionX;
    newUnit.positionY = cur.positionY;
    newUnit.positionZ = cur.positionZ;
    newUnit.rotationY = cur.rotationY;
    newUnit.bodyMaterialId = cur.bodyMaterialId;
    newUnit.frontMaterialId = cur.frontMaterialId;
    if (cur.countertop && newUnit.countertop) {
      newUnit.countertop.materialId = cur.countertop.materialId;
      newUnit.countertop.color = cur.countertop.color;
    }

    const updatedUnits = project.units.map((u) => (u.id === cur.id ? newUnit : u));
    const updatedProject = { ...project, units: updatedUnits };
    applyProjectState(updatedProject);
    setSelectedUnitId(newUnit.id);
    setIsReplacingUnit(false);
  };

  // Apply style from StyleQuizModal (Matching Screenshots 3 & 4)
  const handleApplyStyle = (styleKey: string) => {
    if (styleKey === 'contemporary') {
      handleUpdateLighting({
        ...project.lighting,
        ambientColor: '#ffffff',
        ambientIntensity: 0.85,
        sunlightColor: '#fffbeb',
        sunlightIntensity: 1.1,
      });
      setProject((prev) => {
        const updated = {
          ...prev,
          room: { ...prev.room, wallColor: '#f3f4f6', floorTexture: 'parquet_natural' as const },
        };
        applyProjectState(updated);
        return updated;
      });
    } else if (styleKey === 'transitional') {
      handleUpdateLighting({
        ...project.lighting,
        ambientColor: '#fff7ed',
        ambientIntensity: 0.9,
        sunlightColor: '#fed7aa',
        sunlightIntensity: 1.2,
      });
      setProject((prev) => {
        const updated = {
          ...prev,
          room: { ...prev.room, wallColor: '#f5efe6', floorTexture: 'parquet_natural' as const },
        };
        applyProjectState(updated);
        return updated;
      });
    } else if (styleKey === 'traditional') {
      handleUpdateLighting({
        ...project.lighting,
        ambientColor: '#fef3c7',
        ambientIntensity: 0.95,
        sunlightColor: '#fde68a',
        sunlightIntensity: 1.15,
      });
      setProject((prev) => {
        const updated = {
          ...prev,
          room: { ...prev.room, wallColor: '#ece7df', floorTexture: 'parquet_dark' as const },
        };
        applyProjectState(updated);
        return updated;
      });
    } else {
      handleUpdateLighting({
        ...project.lighting,
        ambientColor: '#f8fafc',
        ambientIntensity: 1.0,
        sunlightColor: '#ffffff',
        sunlightIntensity: 1.25,
      });
      setProject((prev) => {
        const updated = {
          ...prev,
          room: { ...prev.room, wallColor: '#fafaf9', floorTexture: 'parquet_natural' as const },
        };
        applyProjectState(updated);
        return updated;
      });
    }
  };

  // Move selected unit using D-Pad with collision prevention
  const handleMoveUnitByDpad = (axis: 'x' | 'y' | 'z', deltaMm: number) => {
    if (!selectedUnitId || !sceneManagerRef.current) {
      return { collided: false };
    }
    const result = sceneManagerRef.current.moveCabinetByDpad(
      selectedUnitId,
      axis,
      deltaMm,
      collisionGuardEnabled
    );

    const pos = result?.position || result?.newPosition;
    if (pos) {
      // Sync project state with the updated cabinet coordinates
      setProject((prev) => {
        const updated = { ...prev };
        const u = updated.units.find((x) => x.id === selectedUnitId);
        if (u) {
          u.positionX = pos.x;
          u.positionY = pos.y;
          u.positionZ = pos.z;
        }
        return { ...updated };
      });
    }

    return { collided: !!result?.collided, collidedWith: result?.collidedWith };
  };

  // Move selected opening (Window/Door) along wall using D-pad
  const handleMoveOpening = (deltaDistanceMm: number, deltaSillMm: number) => {
    if (!selectedOpeningId) return;
    setProject((prev) => {
      const updated = { ...prev };
      const openings = [...(updated.room.openings || [])];
      const idx = openings.findIndex((o) => o.id === selectedOpeningId);
      if (idx === -1) return prev;

      const op = { ...openings[idx] };
      const wallIdx = op.wallIndex ?? 0;
      const wallLen = wallIdx === 0 || wallIdx === 2 ? updated.room.width : updated.room.length;

      // Adjust distance along wall with boundary clamps
      if (deltaDistanceMm !== 0) {
        const minDistance = 50;
        const maxDistance = Math.max(minDistance, wallLen - op.width - 50);
        op.distanceFromStart = Math.max(
          minDistance,
          Math.min(maxDistance, Math.round(op.distanceFromStart + deltaDistanceMm))
        );
      }

      // Adjust sill height (elevation from floor)
      if (deltaSillMm !== 0) {
        const minSill = op.type === 'door' ? 0 : 100;
        const maxSill = Math.max(minSill, updated.room.height - op.height - 100);
        op.sillHeight = Math.max(
          minSill,
          Math.min(maxSill, Math.round((op.sillHeight || 0) + deltaSillMm))
        );
      }

      openings[idx] = op;
      updated.room = { ...updated.room, openings };

      if (sceneManagerRef.current) {
        sceneManagerRef.current.updateRoom(updated.room);
      }

      return updated;
    });
  };

  // Switch wall for selected opening (North -> East -> South -> West)
  const handleSwitchOpeningWall = () => {
    if (!selectedOpeningId) return;
    setProject((prev) => {
      const updated = { ...prev };
      const openings = [...(updated.room.openings || [])];
      const idx = openings.findIndex((o) => o.id === selectedOpeningId);
      if (idx === -1) return prev;

      const op = { ...openings[idx] };
      const nextWall = ((op.wallIndex ?? 0) + 1) % 4;
      op.wallIndex = nextWall;

      const newWallLen = nextWall === 0 || nextWall === 2 ? updated.room.width : updated.room.length;
      op.distanceFromStart = Math.max(
        50,
        Math.min(newWallLen - op.width - 50, Math.round(newWallLen / 2 - op.width / 2))
      );

      openings[idx] = op;
      updated.room = { ...updated.room, openings };

      if (sceneManagerRef.current) {
        sceneManagerRef.current.updateRoom(updated.room);
      }

      return updated;
    });
  };

  // Resize selected opening
  const handleResizeOpening = (deltaWidth: number, deltaHeight: number) => {
    if (!selectedOpeningId) return;
    setProject((prev) => {
      const updated = { ...prev };
      const openings = [...(updated.room.openings || [])];
      const idx = openings.findIndex((o) => o.id === selectedOpeningId);
      if (idx === -1) return prev;

      const op = { ...openings[idx] };
      const wallIdx = op.wallIndex ?? 0;
      const wallLen = wallIdx === 0 || wallIdx === 2 ? updated.room.width : updated.room.length;

      if (deltaWidth !== 0) {
        op.width = Math.max(400, Math.min(wallLen - 100, Math.round(op.width + deltaWidth)));
      }
      if (deltaHeight !== 0) {
        op.height = Math.max(400, Math.min(updated.room.height - 100, Math.round(op.height + deltaHeight)));
      }

      // Re-clamp distance
      op.distanceFromStart = Math.max(50, Math.min(wallLen - op.width - 50, op.distanceFromStart));

      openings[idx] = op;
      updated.room = { ...updated.room, openings };

      if (sceneManagerRef.current) {
        sceneManagerRef.current.updateRoom(updated.room);
      }

      return updated;
    });
  };

  // Automatic Room Building & Layout Wizard
  const handleAutoBuildRoom = (newConfig: RoomConfig, layoutType: AutoRoomLayoutType) => {
    const generatedUnits = generateAutoRoomLayout(newConfig, layoutType);
    const updatedProject: Project = {
      ...project,
      room: newConfig,
      units: generatedUnits.length > 0 ? generatedUnits : project.units,
    };
    applyProjectState(updatedProject);
    if (generatedUnits.length > 0) {
      setSelectedUnitId(generatedUnits[0].id);
    }
    setSaveNotification(true);
    setTimeout(() => setSaveNotification(false), 2500);
  };

  // Lighting Config Update
  const handleUpdateLighting = (newLighting: LightingConfig) => {
    const updatedProject = { ...project, lighting: newLighting };
    setProject(updatedProject);
    if (sceneManagerRef.current) {
      sceneManagerRef.current.project = updatedProject;
      sceneManagerRef.current.applyLightingConfig(newLighting);
    }
  };

  // Quick Single Light Toggles
  const handleToggleAmbient = () => {
    handleUpdateLighting({
      ...project.lighting,
      ambientEnabled: !(project.lighting?.ambientEnabled ?? true),
    });
  };

  const handleToggleCeiling = () => {
    handleUpdateLighting({
      ...project.lighting,
      ceilingSpotlights: !(project.lighting?.ceilingSpotlights ?? true),
    });
  };

  const handleToggleCabinetInterior = () => {
    handleUpdateLighting({
      ...project.lighting,
      cabinetInteriorLed: !(project.lighting?.cabinetInteriorLed ?? true),
    });
  };

  const handleToggleUnderCabinetLed = () => {
    handleUpdateLighting({
      ...project.lighting,
      underCabinetLed: !(project.lighting?.underCabinetLed ?? true),
    });
  };

  // Camera presets
  const handleCameraPreset = (preset: CameraPreset) => {
    setActiveCameraPreset(preset);
    if (sceneManagerRef.current) {
      sceneManagerRef.current.setCameraPreset(preset);
    }
  };

  const handleSwitchCameraMode = (mode: 'walk' | 'rotate' | 'pan') => {
    if (sceneManagerRef.current) {
      sceneManagerRef.current.setNavigationMode(mode);
    }
    if (mode === 'walk') {
      setActiveCameraPreset('eye_level');
    } else if (activeCameraPreset === 'eye_level') {
      setActiveCameraPreset('perspective');
    }
  };

  const handleZoomIn = () => {
    sceneManagerRef.current?.zoomCamera(0.8);
  };

  const handleZoomOut = () => {
    sceneManagerRef.current?.zoomCamera(1.25);
  };

  const handleResetCamera = () => {
    sceneManagerRef.current?.frameAll();
    setActiveCameraPreset('isometric');
  };

  const handleRotateCamera = (direction: 'left' | 'right' | 'up' | 'down') => {
    sceneManagerRef.current?.rotateCameraStep(direction, 20);
  };

  const handleRotateCameraAnalog = (normalizedX: number, normalizedY: number, speedMultiplier: number = 1.0) => {
    sceneManagerRef.current?.rotateCameraContinuous(normalizedX, normalizedY, 0.035 * speedMultiplier);
  };

  const handleWalkAnalog = (normForward: number, normRight: number, speedMultiplier: number = 1.0) => {
    // 55mm base step for smooth and responsive walk speed
    sceneManagerRef.current?.walkContinuous(normForward, normRight, 55 * speedMultiplier);
  };

  const handleRotateContinuous = (normX: number, normY: number, speedMultiplier: number = 1.0) => {
    sceneManagerRef.current?.rotateCameraContinuous(normX, normY, 0.04 * speedMultiplier);
  };

  const handlePanAnalog = (normX: number, normY: number, speedMultiplier: number = 1.0) => {
    sceneManagerRef.current?.panCameraContinuous(normX, normY, speedMultiplier * 25);
  };

  const handlePanCamera = (deltaX: number, deltaY: number) => {
    sceneManagerRef.current?.panCamera(deltaX, deltaY);
  };

  const handleToggleAutoRotate = () => {
    if (!sceneManagerRef.current) return;
    const next = sceneManagerRef.current.toggleAutoRotate();
    setIsAutoRotate(next);
  };

  const handleToggleInteractMode = () => {
    setIsInteractMode((prev) => {
      const next = !prev;
      sceneManagerRef.current?.setInteractMode(next);
      if (next) {
        // When entering direct click-to-open interact mode:
        // Clear selected unit so properties panel and cabinet movement dpad do not appear
        setSelectedUnitId(null);
        setIsPropertiesDockedOpen(false);
        setIsDpadOpen(false);
      }
      return next;
    });
  };

  const handleSetEnvironment = (env: 'forest' | 'garden' | 'studio' | 'none') => {
    setProject((prev) => ({
      ...prev,
      room: {
        ...prev.room,
        environment: env,
      },
    }));
    sceneManagerRef.current?.setEnvironment(env);
  };

  const toggleMobileMode = () => {
    setIsMobileMode((prev) => {
      const next = !prev;
      if (next) {
        setIsRPZDockedOpen(false);
        setIsPropertiesDockedOpen(false);
      } else {
        setIsRPZDockedOpen(true);
        setIsPropertiesDockedOpen(true);
      }
      setTimeout(() => sceneManagerRef.current?.resize(), 200);
      return next;
    });
  };

  const handleToggleLandscape = async () => {
    setIsLandscapeMode((prev) => !prev);
    try {
      if (!document.fullscreenElement) {
        if (containerRef.current?.parentElement?.requestFullscreen) {
          await containerRef.current.parentElement.requestFullscreen().catch(() => {});
        }
      }
      if ((screen.orientation as any)?.lock) {
        await (screen.orientation as any).lock('landscape').catch(() => {});
      }
    } catch (e) {
      // ignore
    }
    setTimeout(() => {
      sceneManagerRef.current?.resize();
    }, 200);
  };

  // Shading mode
  const handleShadingChange = (mode: ShadingMode) => {
    setActiveShading(mode);
    if (sceneManagerRef.current) {
      sceneManagerRef.current.setShadingMode(mode);
    }
  };

  // Measure tool
  const handleToggleMeasure = () => {
    const next = !isMeasureActive;
    setIsMeasureActive(next);
    setActiveTool(next ? 'tape' : 'select');
    if (sceneManagerRef.current) {
      sceneManagerRef.current.setMeasureTool(next);
    }
    if (!next) setMeasuredDistance(null);
  };

  // Doors Animation All
  const [cameraCollisionEnabled, setCameraCollisionEnabled] = useState<boolean>(true);

  const handleToggleCameraCollision = () => {
    const next = !cameraCollisionEnabled;
    setCameraCollisionEnabled(next);
    sceneManagerRef.current?.setCameraCollisionEnabled(next);
  };

  const handleOpenAll = () => {
    sceneManagerRef.current?.openAllDoorsAndDrawers();
    setProject((prev) => {
      const updated = { ...prev };
      updated.units.forEach((u) => {
        if (u.doors) u.doors.forEach((d) => (d.targetAngle = 90));
        if (u.drawers) u.drawers.forEach((dr) => (dr.targetAmount = 1));
      });
      return { ...updated };
    });
  };

  const handleCloseAll = () => {
    sceneManagerRef.current?.closeAllDoorsAndDrawers();
    setProject((prev) => {
      const updated = { ...prev };
      updated.units.forEach((u) => {
        if (u.doors) u.doors.forEach((d) => (d.targetAngle = 0));
        if (u.drawers) u.drawers.forEach((dr) => (dr.targetAmount = 0));
      });
      return { ...updated };
    });
  };

  const [areAllDoorsOpen, setAreAllDoorsOpen] = useState<boolean>(false);

  const handleToggleAllDoors = () => {
    const isNowOpen = sceneManagerRef.current?.toggleAllDoorsAndDrawers() ?? !areAllDoorsOpen;
    setAreAllDoorsOpen(isNowOpen);
    setProject((prev) => {
      const updated = { ...prev };
      updated.units.forEach((u) => {
        if (u.doors) u.doors.forEach((d) => (d.targetAngle = isNowOpen ? 90 : 0));
        if (u.drawers) u.drawers.forEach((dr) => (dr.targetAmount = isNowOpen ? 1 : 0));
        u.doorOpenProgress = isNowOpen ? 1 : 0;
        u.drawerOpenProgress = isNowOpen ? 1 : 0;
      });
      return { ...updated };
    });
  };

  const handleToggleUnitDoors = (unitId?: string) => {
    const targetId = unitId || selectedUnitId;
    if (targetId && sceneManagerRef.current) {
      const isOpen = sceneManagerRef.current.toggleUnitDoors(targetId);
      setProject((prev) => {
        const updated = { ...prev };
        const u = updated.units.find((x) => x.id === targetId);
        if (u) {
          if (u.doors) u.doors.forEach((d) => (d.targetAngle = isOpen ? 90 : 0));
          if (u.drawers) u.drawers.forEach((dr) => (dr.targetAmount = isOpen ? 1 : 0));
          u.doorOpenProgress = isOpen ? 1 : 0;
          u.drawerOpenProgress = isOpen ? 1 : 0;
        }
        return { ...updated };
      });
    } else {
      handleToggleAllDoors();
    }
  };

  // Save Room Config
  const handleSaveRoomConfig = (newConfig: RoomConfig) => {
    const updatedProject = { ...project, room: newConfig };
    applyProjectState(updatedProject);
    if (sceneManagerRef.current) {
      sceneManagerRef.current.updateRoom(newConfig);
    }
  };

  // Smart Alignment
  const handleAlign = (type: 'left' | 'right' | 'center' | 'snap_wall' | 'snap_floor') => {
    if (!selectedUnit) return;
    const rW = project.room.width / 2;
    const rL = project.room.length / 2;
    let newX = selectedUnit.positionX;
    let newY = selectedUnit.positionY;
    let newZ = selectedUnit.positionZ;

    if (type === 'snap_wall') {
      newZ = -rL + selectedUnit.depth / 2;
    } else if (type === 'snap_floor') {
      newY = 0;
    } else if (type === 'center') {
      newX = 0;
    }
    handleUpdateUnit({ ...selectedUnit, positionX: newX, positionY: newY, positionZ: newZ });
  };

  // SketchUp Value Control Box (VCB) submit: parses "W, H, D" or "W" in mm
  const handleVcbSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUnit || !vcbInput.trim()) return;

    const parts = vcbInput
      .split(/[,xX\s]+/)
      .map((p) => parseFloat(p.trim()))
      .filter((n) => !isNaN(n));

    if (parts.length === 1) {
      // Just width
      handleUpdateUnit({ ...selectedUnit, width: Math.max(200, Math.min(2400, parts[0])) });
    } else if (parts.length >= 3) {
      // W, H, D
      handleUpdateUnit({
        ...selectedUnit,
        width: Math.max(200, Math.min(2400, parts[0])),
        height: Math.max(300, Math.min(2800, parts[1])),
        depth: Math.max(200, Math.min(1000, parts[2])),
      });
    }
    setVcbInput('');
  };

  // Keyboard Shortcuts handler
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) return;

      if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
        e.preventDefault();
        handleUndo();
      } else if ((e.ctrlKey || e.metaKey) && e.key === 'y') {
        e.preventDefault();
        handleRedo();
      } else if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        handleSave();
      } else if (e.key === ' ' || e.key === 'Escape') {
        setActiveTool('select');
        if (isMeasureActive) handleToggleMeasure();
      } else if (e.key.toLowerCase() === 'l' || e.key.toLowerCase() === 'c') {
        setIsRPZDockedOpen((prev) => !prev);
      } else if (e.key.toLowerCase() === 't') {
        handleToggleMeasure();
      } else if (e.key.toLowerCase() === 'b') {
        setIsMaterialsOpen(true);
      } else if (e.key.toLowerCase() === 'o') {
        handleOpenAll();
      } else if (e.key.toLowerCase() === 'r') {
        handleRotateSelected();
      } else if (e.key === 'Delete' || e.key === 'Backspace') {
        if (selectedUnitId) handleDeleteUnit(selectedUnitId);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedUnitId, selectedUnit, isMeasureActive]);

  // Snapshot handler for header camera button
  const handleCaptureSnapshot = () => {
    if (sceneManagerRef.current) {
      try {
        const dataUrl = sceneManagerRef.current.captureSnapshot();
        const a = document.createElement('a');
        a.href = dataUrl;
        a.download = `${project.name || 'home-plan'}-snapshot.jpg`;
        a.click();
        setSaveNotification(true);
        setTimeout(() => setSaveNotification(false), 2000);
      } catch (err) {
        console.error('Snapshot capture failed', err);
      }
    }
  };

  return (
    <div className="relative w-full h-screen overflow-hidden bg-[#121212] text-[#E5E5E5] flex flex-col select-none font-['Cairo',sans-serif]">
      {/* 1. ROOM PLANNER FLOATING TOP BAR (Matching Video 00:00 - 00:30) */}
      {!isGameModeOpen && (
        <RoomPlannerHeader
          cameraMode={cameraMode}
          onChangeCameraMode={handleCameraModeChange}
          onCameraModeChange={handleCameraModeChange}
          viewMode={viewMode}
          onChangeViewMode={(mode) => setViewMode(mode)}
          projectName={project.name}
          projectDimensions={
            project?.room
              ? `${((project.room.width || 4000) / 1000).toFixed(1)} × ${((project.room.length || 5000) / 1000).toFixed(1)} م`
              : ''
          }
          onBack={onBackToDashboard}
          onClose={onBackToDashboard}
          onUndo={handleUndo}
          canUndo={historyManagerRef.current.canUndo()}
          onExport={handleSave}
          onSave={handleSave}
          onShareOrExport={handleSave}
          onCaptureSnapshot={handleCaptureSnapshot}
          onOpenVideoWalkthrough={() => setIsVideoTourOpen(true)}
          onOpenLighting={() => setIsLightingOpen(true)}
          onOpenMaterials={() => setIsMaterialsOpen(true)}
          onOpenRoomSetup={() => setIsRoomSetupOpen(true)}
          onOpenProjectSwitcher={() => setIsProjectSwitcherOpen(true)}
          onOpenStyleQuiz={() => setIsStyleQuizOpen(true)}
          onOpenHelp={() => setIsHelpGuideOpen(true)}
          onOpenHelpGuide={() => setIsHelpGuideOpen(true)}
          onOpenGameMode={() => setIsGameModeOpen(true)}
          onToggleDoors={handleToggleAllDoors}
          areDoorsOpen={areAllDoorsOpen}
          onOpenUnitProperties={() => {
            setIsPropertiesDockedOpen(true);
            setIsUnitSettingsHidden(false);
          }}
          selectedUnitName={selectedUnit ? (selectedUnit.nameAr || selectedUnit.name || 'خزانة') : null}
          onOpenAIGenerator={() => setIsAIGeneratorOpen(true)}
          onToggleWide05={handleToggleWide05}
          isWide05={isWide05}
        />
      )}

      {/* Save Notification Toast */}
      {saveNotification && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 z-50 bg-emerald-600 text-white font-bold px-4 py-2 rounded-xl shadow-2xl flex items-center gap-2 text-xs animate-in fade-in slide-in-from-top-2 border border-emerald-400">
          <CheckCircle2 className="w-4 h-4 text-white" />
          تم حفظ المشروع والصورة المصغرة بنجاح!
        </div>
      )}

      {/* 2. MAIN VIEWPORT (Interactive 2D Blueprint OR 3D Canvas) */}
      <main className="relative flex-1 w-full h-full overflow-hidden bg-[#141416]">
        {/* 2D Floor Plan Blueprint */}
        {viewMode === '2d' && (
          <div className="absolute inset-0 z-10 w-full h-full">
            <FloorPlan2DView
              project={project}
              onUpdateRoom={handleUpdateRoom}
              onUpdateUnit={handleUpdateUnit}
              onDuplicateUnit={handleDuplicateUnit}
              onDeleteUnit={handleDeleteUnit}
              onSwitchTo3D={() => {
                setViewMode('3d');
                setTimeout(() => {
                  if (sceneManagerRef.current) {
                    if (typeof sceneManagerRef.current.resize === 'function') {
                      sceneManagerRef.current.resize();
                    } else if (typeof (sceneManagerRef.current as any).handleResize === 'function') {
                      (sceneManagerRef.current as any).handleResize();
                    }
                    sceneManagerRef.current.requestRender?.();
                  }
                }, 50);
              }}
              selectedUnitId={selectedUnitId}
              onSelectUnit={(id) => {
                setSelectedUnitId(id);
                if (id) setSelectedCustomWallId(null);
              }}
              selectedCustomWallId={selectedCustomWallId}
              onSelectCustomWall={(id) => {
                setSelectedCustomWallId(id);
                if (id) setSelectedUnitId(null);
              }}
              onOpenProperties={() => {
                setIsPropertiesDockedOpen(true);
                setIsUnitSettingsHidden(false);
              }}
              onOpenCatalog={() => {
                setCatalogInitialSearch('');
                setIsCatalogOpen(true);
              }}
              onToggleDoors={handleToggleAllDoors}
              areDoorsOpen={areAllDoorsOpen}
              onSnapAndMergeUnit={handleSnapAndMergeUnit}
            />
          </div>
        )}

        {/* Floating Quick View Mode Switcher on Canvas (Unmistakable 2D & 3D access) */}
        {!isGameModeOpen && (
          <div className="absolute top-16 sm:top-20 left-4 z-30 pointer-events-auto flex items-center gap-1 p-1 rounded-2xl bg-[#1C1C1E]/95 backdrop-blur-xl border border-white/20 shadow-2xl">
            <button
              type="button"
              id="floating-switch-2d"
              onClick={() => setViewMode('2d')}
              className={`px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 transition active:scale-95 ${
                viewMode === '2d'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950/60 ring-1 ring-emerald-400/50'
                  : 'bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30'
              }`}
              title="الانتقال إلى المخطط الهندسي ثنائي الأبعاد 2D"
            >
              <Layout className="w-3.5 h-3.5 text-emerald-400" />
              <span>مخطط 2D</span>
            </button>
            <button
              type="button"
              id="floating-switch-3d"
              onClick={() => setViewMode('3d')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition active:scale-95 ${
                viewMode === '3d'
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-950/60'
                  : 'text-zinc-400 hover:text-white hover:bg-white/10'
              }`}
              title="الانتقال إلى المنظور ثلاثي الأبعاد 3D"
            >
              <Box className="w-3.5 h-3.5" />
              <span>منظور 3D</span>
            </button>
          </div>
        )}

        {/* 3D Three.js Viewport (ALWAYS MOUNTED to preserve WebGL context and avoid black screen) */}
        <div className={`relative w-full h-full ${viewMode === '3d' ? 'block' : 'hidden'}`}>
          {/* Radial CAD Grid Background */}
          <div
            className="absolute inset-0 opacity-15 pointer-events-none"
            style={{
              backgroundImage: 'radial-gradient(#666 1px, transparent 1px)',
              backgroundSize: '36px 36px',
            }}
          />

          {/* Three.js Canvas Container */}
          <div ref={containerRef} className="w-full h-full cursor-grab active:cursor-grabbing" />
        </div>

        {/* 2. FLOATING OBJECT ACTIONS CAPSULE (When a unit or custom wall is selected, matching Video 00:14 - 00:21) */}
        {!isGameModeOpen && viewMode === '3d' && (selectedUnit || selectedCustomWall) && (
          isUnitSettingsHidden ? (
            <div className="absolute top-20 right-6 z-30 pointer-events-auto">
              <button
                type="button"
                onClick={() => setIsUnitSettingsHidden(false)}
                className="px-3.5 py-2 rounded-full bg-[#1C1C1E]/90 hover:bg-[#2C2C2E] text-white border border-white/20 shadow-2xl flex items-center gap-2 text-xs font-bold transition active:scale-95"
                title="إظهار لوحة إعدادات الوحدة المحددة"
              >
                <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
                <span>إظهار إعدادات الوحدة ({selectedUnit?.nameAr || selectedCustomWall?.nameAr || 'المحددة'})</span>
              </button>
            </div>
          ) : (
          <FloatingObjectActions
            unit={selectedUnit || undefined}
            selectedUnit={selectedUnit || undefined}
            customWall={selectedCustomWall || undefined}
            onOpenMaterials={() => setIsMaterialsOpen(true)}
            onUpdateDimensions={(w, h, d) => {
              if (selectedUnit) {
                handleUpdateUnit({
                  ...selectedUnit,
                  width: w,
                  height: h,
                  depth: d,
                });
              }
            }}
            onDuplicate={() => {
              if (selectedCustomWall) {
                const clone: CustomWall = {
                  ...selectedCustomWall,
                  id: `wall_${Date.now()}`,
                  startX: selectedCustomWall.startX + 200,
                  startZ: selectedCustomWall.startZ + 200,
                };
                handleUpdateRoom({
                  ...project.room,
                  customWalls: [...(project.room.customWalls || []), clone],
                });
                setSelectedCustomWallId(clone.id);
              } else if (selectedUnit) {
                handleDuplicateUnit(selectedUnit);
              }
            }}
            onDelete={() => {
              if (selectedCustomWall) {
                const updatedWalls = (project.room.customWalls || []).filter(
                  (w) => w.id !== selectedCustomWall.id
                );
                handleUpdateRoom({ ...project.room, customWalls: updatedWalls });
                setSelectedCustomWallId(null);
              } else if (selectedUnit) {
                handleDeleteUnit(selectedUnit.id);
              }
            }}
            onNudge={(dx, dz) => {
              if (selectedCustomWall) {
                const updatedWalls = (project.room.customWalls || []).map((w) => {
                  if (w.id === selectedCustomWall.id) {
                    return { ...w, startX: w.startX + dx, startZ: w.startZ + dz };
                  }
                  return w;
                });
                handleUpdateRoom({ ...project.room, customWalls: updatedWalls });
              } else if (selectedUnit) {
                if (sceneManagerRef.current) {
                  // Execute movement with active Collision Guard (walls, units, custom walls, floors)
                  if (dx !== 0) {
                    sceneManagerRef.current.moveCabinetByDpad(selectedUnit.id, 'x', dx, true);
                  }
                  if (dz !== 0) {
                    sceneManagerRef.current.moveCabinetByDpad(selectedUnit.id, 'z', dz, true);
                  }
                  const updatedU = project.units.find((u) => u.id === selectedUnit.id);
                  if (updatedU) {
                    handleUpdateUnit({ ...updatedU });
                  }
                } else {
                  handleUpdateUnit({
                    ...selectedUnit,
                    positionX: selectedUnit.positionX + dx,
                    positionZ: selectedUnit.positionZ + dz,
                  });
                }
              }
            }}
            onElevate={(dy) => {
              if (selectedUnit) {
                if (sceneManagerRef.current) {
                  sceneManagerRef.current.moveCabinetByDpad(selectedUnit.id, 'y', dy, true);
                  const updatedU = project.units.find((u) => u.id === selectedUnit.id);
                  if (updatedU) {
                    handleUpdateUnit({ ...updatedU });
                  }
                } else {
                  handleUpdateUnit({
                    ...selectedUnit,
                    positionY: Math.max(0, (selectedUnit.positionY || 0) + dy),
                  });
                }
              }
            }}
            onColorSelect={(hex) => {
              if (selectedCustomWall) {
                const updatedWalls = (project.room.customWalls || []).map((w) => {
                  if (w.id === selectedCustomWall.id) {
                    return { ...w, color: hex };
                  }
                  return w;
                });
                handleUpdateRoom({ ...project.room, customWalls: updatedWalls });
              } else if (selectedUnit) {
                handleUpdateUnit({
                  ...selectedUnit,
                  color: hex,
                });
              }
            }}
            onRotate90={() => {
              if (selectedCustomWall) {
                const updatedWalls = (project.room.customWalls || []).map((w) => {
                  if (w.id === selectedCustomWall.id) {
                    return { ...w, rotationY: ((w.rotationY || 0) + 90) % 360 };
                  }
                  return w;
                });
                handleUpdateRoom({ ...project.room, customWalls: updatedWalls });
              } else if (selectedUnit) {
                handleRotateSelected();
              }
            }}
            onToggleDoors={() => {
              if (selectedUnit) {
                handleToggleUnitDoors(selectedUnit.id);
              }
            }}
            onOpenFullDetails={() => {
              setIsPropertiesDockedOpen(true);
              setIsUnitSettingsHidden(false);
            }}
            onHideSettings={() => {
              setIsPropertiesDockedOpen(false);
              setIsUnitSettingsHidden(true);
            }}
            onDeselect={() => {
              setSelectedUnitId(null);
              setSelectedCustomWallId(null);
              setIsPropertiesDockedOpen(false);
              setIsUnitSettingsHidden(false);
            }}
            onSnapAndMerge={handleSnapAndMergeUnit}
          />
          )
        )}

        {/* 3. ROOM PLANNER FLOATING BOTTOM BAR (Only rendered in 3D mode so 2D tools are completely clean and unobscured) */}
        {!isGameModeOpen && viewMode === '3d' && (
          <RoomPlannerBottomBar
            viewMode={viewMode}
            onToggleViewMode={() => setViewMode((prev) => (prev === '3d' ? '2d' : '3d'))}
            onOpen2DPlan={() => setViewMode('2d')}
            onOpenCatalog={() => {
              setCatalogInitialSearch('');
              setIsCatalogOpen(true);
            }}
            onSearch={() => {
              setCatalogInitialSearch('');
              setIsCatalogOpen(true);
            }}
            onWalk={handleWalkAnalog}
            onRotateCamera={handleRotateCamera}
            onRotateContinuous={handleRotateContinuous}
            onPanContinuous={handlePanAnalog}
            onToggleWalkMode={handleToggleWalkMode}
            isWalking={cameraMode === 'walk'}
            onToggleDoors={handleToggleAllDoors}
            areDoorsOpen={areAllDoorsOpen}
            onToggleWide05={handleToggleWide05}
            isWide05={isWide05}
          />
        )}

          {/* Immersive Game Mode Overlay (User Request: تشغيل كاللعبة مع فيديو وفتح الأبواب) */}
          {isGameModeOpen && (
            <GameModeOverlay
              sceneManager={sceneManagerRef.current}
              onExitGameMode={() => setIsGameModeOpen(false)}
              projectName={project.name}
            />
          )}

          {/* Floating Properties Panel (التحكم بخصائص الوحدات والأجهزة) */}
          {isPropertiesDockedOpen && selectedUnit && (
            <div
              onClick={(e) => {
                if (e.target === e.currentTarget) setIsPropertiesDockedOpen(false);
              }}
              className="fixed inset-0 z-50 flex items-end sm:items-start justify-center sm:justify-end p-0 sm:p-4 bg-black/60 sm:bg-transparent backdrop-blur-sm sm:backdrop-blur-none pointer-events-auto sm:pointer-events-none transition-all duration-200"
            >
              <div
                onClick={(e) => e.stopPropagation()}
                className="w-full sm:w-[420px] max-h-[85vh] sm:max-h-[calc(100vh-5rem)] sm:mt-12 sm:mr-4 bg-[#18181B] rounded-t-3xl sm:rounded-2xl border border-white/20 shadow-2xl overflow-hidden flex flex-col pointer-events-auto animate-in fade-in slide-in-from-bottom-6 sm:slide-in-from-right-6 duration-200"
              >
                <PropertiesPanel
                  unit={selectedUnit}
                  isDocked={false}
                  onUpdate={handleUpdateUnit}
                  onDuplicate={handleDuplicateUnit}
                  onDelete={(id) => {
                    handleDeleteUnit(id);
                    setIsPropertiesDockedOpen(false);
                  }}
                  onClose={() => setIsPropertiesDockedOpen(false)}
                  onOpenMaterialsModal={() => setIsMaterialsOpen(true)}
                  onOpenDoorsModal={() => setIsDoorsOpen(true)}
                  onAlign={handleAlign}
                  onApplyMaterialToAll={handleApplyMaterialToAll}
                  onSnapAndMerge={handleSnapAndMergeUnit}
                  onUnifyCountertops={handleUnifyAllCountertops}
                />
              </div>
            </div>
          )}

          {/* Quick Selection Floating Action Pill on 3D View */}
          {viewMode === '3d' && selectedUnit && !isPropertiesDockedOpen && !isCatalogOpen && (
            <div className="absolute bottom-20 sm:bottom-6 left-1/2 -translate-x-1/2 z-30 pointer-events-auto flex items-center gap-1.5 px-3 py-2 rounded-2xl bg-[#18181B]/95 backdrop-blur-xl border border-white/20 shadow-2xl text-xs font-bold text-white animate-in fade-in slide-in-from-bottom-2">
              <span className="text-zinc-300 px-1 border-l border-white/15">
                {selectedUnit.nameAr || selectedUnit.name || 'خزانة'}
              </span>
              <button
                type="button"
                onClick={() => handleSnapAndMergeUnit('right')}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition active:scale-95 shadow-sm font-bold"
                title="دمج بالوحدة المجاورة يميناً وتوحيد السطح الرخامي كسطح واحد متصل"
              >
                <span>دمج يمين</span>
                <span>👉</span>
              </button>
              <button
                type="button"
                onClick={() => handleSnapAndMergeUnit('left')}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition active:scale-95 shadow-sm font-bold"
                title="دمج بالوحدة المجاورة يساراً وتوحيد السطح الرخامي كسطح واحد متصل"
              >
                <span>👈</span>
                <span>دمج يسار</span>
              </button>
              <button
                type="button"
                onClick={() => setIsPropertiesDockedOpen(true)}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white transition active:scale-95"
                title="تعديل الأبعاد والخامات"
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>خصائص</span>
              </button>
              <button
                type="button"
                onClick={() => handleRotateSelected(90)}
                className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white transition active:scale-95"
                title="تدوير 90 درجة"
              >
                <RotateCw className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => handleDeleteUnit(selectedUnit.id)}
                className="p-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-400 hover:text-red-300 border border-red-500/30 transition active:scale-95"
                title="حذف الخزانة"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setSelectedUnitId(null)}
                className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white transition active:scale-95"
                title="إلغاء التحديد"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}


        </main>

        {/* Modern Room Planner Bottom-Sheet Catalog (Matching Screenshots 5, 6, 7, 8, 9, 10) */}
        <RoomPlannerCatalogModal
          isOpen={isCatalogOpen}
          onClose={() => {
            setIsCatalogOpen(false);
            setIsReplacingUnit(false);
          }}
          onSelectTemplate={(template) => {
            if (isReplacingUnit && selectedUnitId) {
              handleReplaceWithTemplate(template);
            } else {
              handleAddTemplate(template);
            }
          }}
          initialSearch={catalogInitialSearch}
          onOpenAIGenerator={() => setIsAIGeneratorOpen(true)}
        />

        {/* AI Unit & Appliance Generator Modal (User Request: إنشاء وحدات مطابخ ووحدات كهربائية بالذكاء الاصطناعي) */}
        <AIUnitGeneratorModal
          isOpen={isAIGeneratorOpen}
          onClose={() => setIsAIGeneratorOpen(false)}
          onAddGeneratedUnit={(template) => {
            handleAddTemplate(template);
            setIsAIGeneratorOpen(false);
          }}
        />

        {/* Style Quiz Modal (AI Interior Designer matching Video 00:28 - 00:30) */}
        <StyleQuizModal
          isOpen={isStyleQuizOpen}
          onClose={() => setIsStyleQuizOpen(false)}
          onApplyStyle={handleApplyStyle}
          projectName={project.name}
          roomDimensions={
            project?.room
              ? `${((project.room.width || 4000) / 1000).toFixed(1)}م × ${((project.room.length || 5000) / 1000).toFixed(1)}م`
              : '6م × 5م'
          }
        />

        {/* Help & Guide Modal */}
        <HelpGuideModal
          isOpen={isHelpGuideOpen}
          onClose={() => setIsHelpGuideOpen(false)}
        />

      {/* ========================================================================= */}
      {/* 4. MODALS & POPUPS                                                        */}
      {/* ========================================================================= */}
      <RoomSetupModal
        isOpen={isRoomSetupOpen}
        onClose={() => setIsRoomSetupOpen(false)}
        roomConfig={project.room}
        onSave={handleSaveRoomConfig}
        onAutoBuild={handleAutoBuildRoom}
        onOpenFloorPlan2D={() => {
          setIsRoomSetupOpen(false);
          setIsFloorPlan2DOpen(true);
        }}
        onSelectOpeningForDpad={(openingId) => {
          setSelectedOpeningId(openingId);
          setSelectedUnitId(null);
          if (sceneManagerRef.current) {
            sceneManagerRef.current.setSelectedOpening(openingId);
          }
        }}
      />

      {/* 2D Floor Plan & Wall Drawing Modal */}
      <FloorPlan2DModal
        isOpen={isFloorPlan2DOpen}
        onClose={() => setIsFloorPlan2DOpen(false)}
        room={project.room}
        cabinets={project.units}
        onSaveRoom={(updatedRoom) => {
          handleSaveRoomConfig(updatedRoom);
        }}
      />

      <MaterialsModal
        isOpen={isMaterialsOpen}
        onClose={() => setIsMaterialsOpen(false)}
        unit={selectedUnit}
        onUpdateUnit={handleUpdateUnit}
      />

      <DoorDrawerControlsModal
        isOpen={isDoorsOpen}
        onClose={() => setIsDoorsOpen(false)}
        unit={selectedUnit}
        units={project.units}
        onSelectUnit={(id) => setSelectedUnitId(id)}
        onUpdateUnit={handleUpdateUnit}
        onOpenAll={handleOpenAll}
        onCloseAll={handleCloseAll}
      />

      <CostCutListModal
        isOpen={isCostOpen}
        onClose={() => setIsCostOpen(false)}
        units={project.units}
        projectName={project.name}
      />

      <LightingModal
        isOpen={isLightingOpen}
        onClose={() => setIsLightingOpen(false)}
        lighting={project.lighting}
        onUpdateLighting={handleUpdateLighting}
      />

      <VideoWalkthroughModal
        isOpen={isVideoTourOpen}
        onClose={() => setIsVideoTourOpen(false)}
        sceneManager={sceneManagerRef.current}
        project={project}
      />

      {/* Project Switcher Modal (User Request: التنقل بين المشاريع) */}
      <ProjectSwitcherModal
        currentProjectId={project.projectId}
        isOpen={isProjectSwitcherOpen}
        onClose={() => setIsProjectSwitcherOpen(false)}
        onSwitchProject={(p) => {
          projectRepository.saveProject(project);
          if (onSwitchProject) {
            onSwitchProject(p);
          } else {
            setProject(p);
            setSelectedUnitId(p.units.length > 0 ? p.units[0].id : null);
            sceneManagerRef.current?.loadProject(p);
          }
        }}
        onOpenProjectsList={() => {
          projectRepository.saveProject(project);
          if (onOpenProjectsList) {
            onOpenProjectsList();
          } else {
            onBackToDashboard();
          }
        }}
        onCreateNewProject={(type, name) => {
          projectRepository.saveProject(project);
          if (onCreateNewProject) {
            onCreateNewProject(type, name);
          } else {
            const newP = projectRepository.createNewProject(type, name);
            setProject(newP);
            setSelectedUnitId(newP.units.length > 0 ? newP.units[0].id : null);
            sceneManagerRef.current?.loadProject(newP);
          }
        }}
      />
    </div>
  );
};
