import React, { useState } from 'react';
import { ParametricCabinet } from '../../types';
import { X, Play, RotateCcw, Layers, Sparkles, DoorClosed, Check, ChevronDown } from 'lucide-react';

interface DoorDrawerControlsModalProps {
  isOpen: boolean;
  onClose: () => void;
  unit: ParametricCabinet | null;
  units?: ParametricCabinet[];
  onSelectUnit?: (unitId: string) => void;
  onUpdateUnit: (unit: ParametricCabinet) => void;
  onOpenAll: () => void;
  onCloseAll: () => void;
}

export const DoorDrawerControlsModal: React.FC<DoorDrawerControlsModalProps> = ({
  isOpen,
  onClose,
  unit,
  units = [],
  onSelectUnit,
  onUpdateUnit,
  onOpenAll,
  onCloseAll,
}) => {
  if (!isOpen) return null;

  // If no unit is currently selected, allow selecting from all units that have doors, drawers, or baskets
  const eligibleUnits = units.filter(
    (u) =>
      (u.doors && u.doors.length > 0) ||
      (u.drawers && u.drawers.length > 0) ||
      u.accessoryType === 'wire_basket_spice' ||
      u.accessoryType === 'wire_basket_dishes'
  );

  const activeUnit = unit || eligibleUnits[0] || null;

  const handleDoorAngleChange = (doorIdx: number, angle: number) => {
    if (!activeUnit) return;
    const updatedDoors = [...(activeUnit.doors || [])];
    if (updatedDoors[doorIdx]) {
      updatedDoors[doorIdx] = {
        ...updatedDoors[doorIdx],
        targetAngle: angle,
        openAngle: angle,
      };
      onUpdateUnit({ ...activeUnit, doors: updatedDoors });
    }
  };

  const handleDrawerAmountChange = (drawerIdx: number, amount: number) => {
    if (!activeUnit) return;
    const updatedDrawers = [...(activeUnit.drawers || [])];
    if (updatedDrawers[drawerIdx]) {
      updatedDrawers[drawerIdx] = {
        ...updatedDrawers[drawerIdx],
        targetAmount: amount,
        openAmount: amount,
      };
      onUpdateUnit({ ...activeUnit, drawers: updatedDrawers });
    }
  };

  const handleSpeedChange = (speedSec: number) => {
    if (!activeUnit) return;
    const updatedDoors = (activeUnit.doors || []).map((d) => ({ ...d, openSpeed: speedSec }));
    const updatedDrawers = (activeUnit.drawers || []).map((dr) => ({ ...dr, openSpeed: speedSec }));
    onUpdateUnit({ ...activeUnit, doors: updatedDoors, drawers: updatedDrawers });
  };

  return (
    <div
      onPointerDown={(e) => e.stopPropagation()}
      onClick={(e) => e.stopPropagation()}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200 font-['Cairo',sans-serif]"
      dir="rtl"
    >
      <div className="relative w-full max-w-lg bg-[#181C24] border border-[#333D4D] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-[#2C3545] flex items-center justify-between bg-[#1F2633]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/15 text-amber-400 border border-amber-500/30 flex items-center justify-center">
              <DoorClosed className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white tracking-wide">التحكم بالأبواب والأدراج والسلال (Door & Pull-Out Engine)</h2>
              <p className="text-[11px] text-gray-400">محاكاة فتح وإغلاق هيدروليكي واقعي وسحب السلال السلكية</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-white rounded hover:bg-[#2C3545] transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Global Quick Action Buttons across entire kitchen */}
        <div className="p-3 bg-[#13171F] border-b border-[#2C3545] space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-300">تحكم شامل لكامل المطبخ:</span>
            {/* Speed Selector */}
            <div className="flex items-center gap-1 bg-[#1A202C] p-1 rounded-lg border border-[#2E3848]">
              <span className="text-[10px] text-gray-400 px-1 font-semibold">السرعة:</span>
              {[0.3, 0.5, 1.0].map((s) => (
                <button
                  key={s}
                  onClick={() => handleSpeedChange(s)}
                  className={`px-2 py-0.5 rounded text-[11px] font-mono font-bold transition ${
                    (activeUnit?.doors?.[0]?.openSpeed || 0.5) === s
                      ? 'bg-amber-500 text-slate-950 shadow-sm'
                      : 'text-gray-400 hover:bg-[#263040]'
                  }`}
                >
                  {s}s
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenAll}
              className="flex-1 py-2 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-amber-500/20 transition active:scale-95"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              ⚡ فتح كل الأبواب والأدراج والسلال
            </button>
            <button
              onClick={onCloseAll}
              className="flex-1 py-2 px-3 rounded-xl bg-[#263040] hover:bg-[#303C50] text-gray-200 border border-[#3E4D64] font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              إغلاق الكل بالمطبخ
            </button>
          </div>
        </div>

        {/* Cabinet Selector if multiple units exist */}
        {eligibleUnits.length > 0 && (
          <div className="px-4 py-2 bg-[#171B24] border-b border-[#2C3545] flex items-center gap-2 overflow-x-auto scrollbar-thin">
            <span className="text-[11px] text-gray-400 shrink-0 font-medium">الوحدة المختارة:</span>
            {eligibleUnits.map((u) => {
              const isSelected = activeUnit?.id === u.id;
              return (
                <button
                  key={u.id}
                  onClick={() => onSelectUnit && onSelectUnit(u.id)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition border flex items-center gap-1 shrink-0 ${
                    isSelected
                      ? 'bg-blue-600/30 border-blue-500 text-blue-300 shadow-sm'
                      : 'bg-[#1E2533] border-[#2C3545] text-gray-400 hover:text-gray-200 hover:bg-[#263040]'
                  }`}
                >
                  {isSelected && <Check className="w-3 h-3 text-blue-400" />}
                  <span>{u.nameAr}</span>
                </button>
              );
            })}
          </div>
        )}

        {/* Individual Controls Body */}
        <div className="p-4 overflow-y-auto space-y-4 flex-1 text-xs">
          {activeUnit ? (
            <>
              {/* Unit Title */}
              <div className="flex items-center justify-between pb-1 border-b border-[#2C3545]">
                <span className="font-bold text-white text-xs">{activeUnit.nameAr}</span>
                <span className="text-[11px] text-gray-400 font-mono">
                  {activeUnit.width} × {activeUnit.height} × {activeUnit.depth} mm
                </span>
              </div>

              {/* Doors Sliders */}
              {activeUnit.doors && activeUnit.doors.length > 0 && (
                <div className="space-y-2.5">
                  <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-blue-400" />
                    تحكم زاوية فتح الأبواب ({activeUnit.doors.length} أبواب)
                  </h3>
                  <div className="space-y-2.5">
                    {activeUnit.doors.map((door, idx) => (
                      <div
                        key={door.doorId || idx}
                        className="p-2.5 bg-[#12161F] border border-[#2C3545] rounded-xl space-y-2"
                      >
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-semibold text-gray-300">
                            باب #{idx + 1}{' '}
                            <span className="text-gray-500 text-[11px]">
                              ({door.hingeSide === 'left' ? 'مفصلة يسار' : door.hingeSide === 'right' ? 'مفصلة يمين' : door.hingeSide})
                            </span>
                          </span>
                          <span className="font-mono text-amber-400 font-bold">
                            {Math.round(door.targetAngle || 0)}°
                          </span>
                        </div>

                        <div className="flex items-center gap-2.5">
                          <input
                            type="range"
                            min="0"
                            max="90"
                            step="5"
                            value={door.targetAngle || 0}
                            onChange={(e) => handleDoorAngleChange(idx, Number(e.target.value))}
                            className="flex-1 h-1.5 bg-[#252E3E] rounded-lg appearance-none cursor-pointer accent-amber-500"
                          />
                          <button
                            onClick={() => handleDoorAngleChange(idx, (door.targetAngle || 0) > 45 ? 0 : 90)}
                            className="px-2.5 py-1 rounded-lg bg-[#252E3E] hover:bg-[#323D52] border border-[#3E4D64] text-[11px] font-bold text-gray-200 transition"
                          >
                            {(door.targetAngle || 0) > 45 ? 'إغلاق' : 'فتح 90°'}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Drawers Sliders */}
              {activeUnit.drawers && activeUnit.drawers.length > 0 && (
                <div className="space-y-2.5">
                  <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-blue-400" />
                    تحكم سحب الأدراج والسلال للخارج ({activeUnit.drawers.length} أدراج/سلال)
                  </h3>
                  <div className="space-y-2.5">
                    {activeUnit.drawers.map((drawer, idx) => (
                      <div
                        key={drawer.drawerId || idx}
                        className="p-2.5 bg-[#12161F] border border-[#2C3545] rounded-xl space-y-2"
                      >
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-semibold text-gray-300">درج/سلة #{idx + 1}</span>
                          <span className="font-mono text-amber-400 font-bold">
                            {Math.round((drawer.targetAmount || 0) * 100)}%
                          </span>
                        </div>

                        <div className="flex items-center gap-2.5">
                          <input
                            type="range"
                            min="0"
                            max="1"
                            step="0.05"
                            value={drawer.targetAmount || 0}
                            onChange={(e) => handleDrawerAmountChange(idx, Number(e.target.value))}
                            className="flex-1 h-1.5 bg-[#252E3E] rounded-lg appearance-none cursor-pointer accent-amber-500"
                          />
                          <button
                            onClick={() => handleDrawerAmountChange(idx, (drawer.targetAmount || 0) > 0.5 ? 0 : 1)}
                            className="px-2.5 py-1 rounded-lg bg-[#252E3E] hover:bg-[#323D52] border border-[#3E4D64] text-[11px] font-bold text-gray-200 transition"
                          >
                            {(drawer.targetAmount || 0) > 0.5 ? 'إرجاع' : 'سحب 100%'}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Wire Basket Accessory Pull-Out Controller */}
              {(activeUnit.accessoryType === 'wire_basket_spice' || activeUnit.accessoryType === 'wire_basket_dishes') && (
                <div className="p-3 bg-[#12161F] border border-amber-500/40 rounded-xl space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-amber-300 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      {activeUnit.accessoryType === 'wire_basket_spice'
                        ? 'سلة زيوت وبهارات سلكية ستانلس (Spice Pull-Out)'
                        : 'سلة صحون ومواعين هيدروليكية (Dish Pull-Out)'}
                    </span>
                    <span className="font-mono text-amber-400 font-bold">
                      {Math.round(((activeUnit.drawers?.[0]?.targetAmount) || 0) * 100)}%
                    </span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <button
                      type="button"
                      onClick={() => {
                        const cur = activeUnit.drawers?.[0]?.targetAmount || 0;
                        const nextVal = cur > 0.5 ? 0 : 1;
                        const drawers =
                          activeUnit.drawers && activeUnit.drawers.length > 0
                            ? activeUnit.drawers.map((d, i) =>
                                i === 0 ? { ...d, targetAmount: nextVal, openAmount: nextVal } : d
                              )
                            : [
                                {
                                  drawerId: `dr_${Date.now()}`,
                                  height: activeUnit.height - 80,
                                  targetAmount: nextVal,
                                  openAmount: nextVal,
                                  openSpeed: 0.4,
                                },
                              ];
                        onUpdateUnit({ ...activeUnit, drawers });
                      }}
                      className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 transition active:scale-95"
                    >
                      {(activeUnit.drawers?.[0]?.targetAmount || 0) > 0.5
                        ? 'إرجاع السلة لداخل الخزانة'
                        : 'سحب السلة للخارج بالكامل (Pull-Out)'}
                    </button>
                  </div>
                </div>
              )}

              {(!activeUnit.doors || activeUnit.doors.length === 0) &&
                (!activeUnit.drawers || activeUnit.drawers.length === 0) &&
                activeUnit.accessoryType !== 'wire_basket_spice' &&
                activeUnit.accessoryType !== 'wire_basket_dishes' && (
                  <div className="text-center py-8 text-gray-400 text-xs">
                    الوحدة المحددة لا تحتوي على أبواب أو أدراج أو سلال حالياً. يمكنك تفعيلها من لوحة الخصائص أو الكتالوج.
                  </div>
                )}
            </>
          ) : (
            <div className="text-center py-8 text-gray-400 text-xs">
              لا توجد وحدات تحتوي على أبواب أو أدراج في المطبخ حالياً. قم بإضافة وحدات من الكتالوج (RPZ Library).
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-[#2C3545] flex justify-between items-center bg-[#1F2633]">
          <span className="text-[11px] text-gray-400">💡 يمكنك أيضاً الضغط مباشرة على أي درفة أو درج بالمشهد لفتحها</span>
          <button
            onClick={onClose}
            className="px-5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md transition"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
