import React, { useState } from 'react';
import {
  Palette,
  Ruler,
  Copy,
  Trash2,
  ArrowLeftRight,
  RotateCw,
  DoorOpen,
  Sliders,
  ChevronDown,
  ChevronUp,
  Move,
  EyeOff,
  X,
} from 'lucide-react';
import { ParametricCabinet, CustomWall } from '../../types';

export interface FloatingObjectActionsProps {
  unit?: ParametricCabinet;
  selectedUnit?: ParametricCabinet;
  customWall?: CustomWall;
  onOpenMaterials?: () => void;
  onDuplicate?: () => void;
  onDelete?: () => void;
  onReplace?: () => void;
  onRotate?: () => void;
  onRotate90?: () => void;
  onToggleDoors?: () => void;
  onUpdateDimensions?: (width: number, height: number, depth: number) => void;
  onOpenFullProperties?: () => void;
  onOpenFullDetails?: () => void;
  onDeselect?: () => void;
  onNudge?: (deltaX: number, deltaZ: number) => void;
  onElevate?: (deltaY: number) => void;
  onColorSelect?: (color: string) => void;
  onHideSettings?: () => void;
  onSnapAndMerge?: (side: 'left' | 'right') => void;
}

export const FloatingObjectActions: React.FC<FloatingObjectActionsProps> = ({
  unit,
  selectedUnit,
  customWall,
  onOpenMaterials,
  onDuplicate,
  onDelete,
  onReplace,
  onRotate,
  onRotate90,
  onToggleDoors,
  onUpdateDimensions,
  onOpenFullProperties,
  onOpenFullDetails,
  onDeselect,
  onNudge,
  onElevate,
  onColorSelect,
  onHideSettings,
  onSnapAndMerge,
}) => {
  const activeUnit = unit || selectedUnit;
  if (!activeUnit && !customWall) return null;

  const [showRulerPopover, setShowRulerPopover] = useState(false);

  const titleText = customWall
    ? customWall.nameAr ||
      `جدار فاصل معماري ${(customWall.length / 1000).toFixed(2)}م × ${((customWall.thickness || 180) / 1000).toFixed(2)}م`
    : activeUnit
    ? `${activeUnit.nameAr || activeUnit.name || 'خزانة'} ${(activeUnit.width / 1000).toFixed(2)}م × ${(activeUnit.depth / 1000).toFixed(2)}م`
    : '';

  const elevationMm = customWall ? 0 : activeUnit ? activeUnit.positionY || 0 : 0;
  const elevationM = (elevationMm / 1000).toFixed(2);

  const handleRotate = () => {
    if (onRotate90) onRotate90();
    else if (onRotate) onRotate();
  };

  const handleFullProps = () => {
    if (onOpenFullDetails) onOpenFullDetails();
    else if (onOpenFullProperties) onOpenFullProperties();
  };

  // Swatch colors matching video: White, Cream, Oak, Walnut, Charcoal, Slate Black
  const swatches = [
    { hex: '#F8FAFC', label: 'أبيض ناصع' },
    { hex: '#F5EFE6', label: 'كتان عاجي' },
    { hex: '#D97706', label: 'خشب زان طبيعي' },
    { hex: '#854D0E', label: 'خشب جوز دافئ' },
    { hex: '#334155', label: 'رمادي فحمي' },
    { hex: '#0F172A', label: 'أسود مطفي' },
  ];

  return (
    <div
      id="floating-object-card"
      className="absolute bottom-24 inset-x-0 z-40 flex flex-col items-center pointer-events-none px-4 animate-in fade-in slide-in-from-bottom-3 duration-200"
    >
      {/* ----------------------------------------------------------------- */}
      {/* Popover for dimensions if clicked ruler                            */}
      {/* ----------------------------------------------------------------- */}
      {showRulerPopover && activeUnit && (
        <div className="mb-2 p-3 bg-white rounded-2xl shadow-2xl border border-gray-200 pointer-events-auto flex items-center gap-3 text-xs text-zinc-800">
          <span className="font-bold text-zinc-500">المقاسات (مم):</span>
          <div className="flex items-center gap-1">
            <span className="text-zinc-400">العرض:</span>
            <input
              type="number"
              step="50"
              value={activeUnit.width}
              onChange={(e) =>
                onUpdateDimensions?.(
                  parseFloat(e.target.value) || activeUnit.width,
                  activeUnit.height,
                  activeUnit.depth
                )
              }
              className="w-16 px-2 py-1 bg-gray-100 rounded-lg text-center font-bold"
            />
          </div>
          <div className="flex items-center gap-1">
            <span className="text-zinc-400">العمق:</span>
            <input
              type="number"
              step="50"
              value={activeUnit.depth}
              onChange={(e) =>
                onUpdateDimensions?.(
                  activeUnit.width,
                  activeUnit.height,
                  parseFloat(e.target.value) || activeUnit.depth
                )
              }
              className="w-16 px-2 py-1 bg-gray-100 rounded-lg text-center font-bold"
            />
          </div>
          <button
            type="button"
            onClick={() => setShowRulerPopover(false)}
            className="px-2.5 py-1 bg-blue-600 text-white rounded-lg font-bold"
          >
            تم
          </button>
        </div>
      )}

      {/* ----------------------------------------------------------------- */}
      {/* MAIN WHITE FLOATING CARD (Matching Video 00:14 - 00:21)            */}
      {/* ----------------------------------------------------------------- */}
      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-gray-100 p-3.5 text-zinc-900 pointer-events-auto transition-all">
        {/* Row 1: Header (Title on Right, Quick Actions on Left) */}
        <div className="flex items-center justify-between gap-2 border-b border-gray-100 pb-2.5">
          {/* Item Title */}
          <div className="flex items-center gap-2 font-bold text-xs sm:text-sm text-zinc-800 truncate">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-600 shrink-0" />
            <span className="truncate">{titleText}</span>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-1.5 shrink-0 text-xs">
            {activeUnit && (
              <button
                type="button"
                id="btn-unit-toggle-doors"
                onClick={onToggleDoors}
                className={`px-2.5 py-1 rounded-xl font-bold transition flex items-center gap-1 border shadow-sm ${
                  (activeUnit.doorOpenProgress ?? 0) > 0.05
                    ? 'bg-amber-500 hover:bg-amber-600 text-white border-amber-400'
                    : 'bg-amber-50 hover:bg-amber-100 text-amber-800 border-amber-200'
                }`}
                title="فتح وإغلاق أبواب وأدراج هذه الوحدة"
              >
                <DoorOpen className="w-3.5 h-3.5" />
                <span>{(activeUnit.doorOpenProgress ?? 0) > 0.05 ? 'إغلاق الباب' : 'فتح الباب'}</span>
              </button>
            )}

            <button
              type="button"
              id="btn-unit-open-properties"
              onClick={handleFullProps}
              className="px-2.5 py-1 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold transition flex items-center gap-1 shadow-sm active:scale-95"
              title="تعديل خصائص وأبعاد وخامات وأجهزة الخزانة"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>الخصائص والأجهزة</span>
            </button>

            <button
              type="button"
              onClick={handleRotate}
              className="p-1.5 rounded-xl bg-gray-100 hover:bg-gray-200 text-zinc-700 font-bold transition flex items-center justify-center active:scale-95"
              title="تدوير 90 درجة"
            >
              <RotateCw className="w-3.5 h-3.5 text-purple-600" />
            </button>

            {/* زر إخفاء إعدادات الوحدة */}
            <button
              type="button"
              onClick={() => {
                if (onHideSettings) onHideSettings();
                else if (onDeselect) onDeselect();
              }}
              className="px-2 py-1 rounded-xl bg-gray-100 hover:bg-gray-200 text-zinc-600 hover:text-zinc-900 font-bold transition flex items-center gap-1"
              title="إخفاء لوحة الإعدادات مؤقتاً"
            >
              <EyeOff className="w-3.5 h-3.5 text-gray-500" />
              <span className="hidden sm:inline">إخفاء</span>
            </button>

            {/* زر إغلاق / إلغاء التحديد */}
            <button
              type="button"
              onClick={onDeselect}
              className="p-1.5 rounded-xl bg-gray-100 hover:bg-red-50 text-gray-400 hover:text-red-500 transition flex items-center justify-center"
              title="إلغاء التحديد"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Quick Dimensions Bar (Direct property controls right on card) */}
        {activeUnit && onUpdateDimensions && (
          <div className="flex items-center justify-between py-1.5 px-1 border-b border-gray-100 text-xs bg-zinc-50/80 rounded-xl my-1">
            <span className="font-bold text-zinc-500 text-[11px]">الأبعاد:</span>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1">
                <span className="text-zinc-400 text-[10px]">العرض:</span>
                <button
                  type="button"
                  onClick={() => onUpdateDimensions(Math.max(200, activeUnit.width - 50), activeUnit.height, activeUnit.depth)}
                  className="w-5 h-5 rounded bg-white border border-gray-200 font-bold text-zinc-600 flex items-center justify-center hover:bg-gray-100"
                >-</button>
                <span className="font-bold text-zinc-800 min-w-[40px] text-center font-mono">{(activeUnit.width / 10).toFixed(0)} سم</span>
                <button
                  type="button"
                  onClick={() => onUpdateDimensions(Math.min(2400, activeUnit.width + 50), activeUnit.height, activeUnit.depth)}
                  className="w-5 h-5 rounded bg-white border border-gray-200 font-bold text-zinc-600 flex items-center justify-center hover:bg-gray-100"
                >+</button>
              </div>

              <div className="flex items-center gap-1">
                <span className="text-zinc-400 text-[10px]">العمق:</span>
                <button
                  type="button"
                  onClick={() => onUpdateDimensions(activeUnit.width, activeUnit.height, Math.max(200, activeUnit.depth - 50))}
                  className="w-5 h-5 rounded bg-white border border-gray-200 font-bold text-zinc-600 flex items-center justify-center hover:bg-gray-100"
                >-</button>
                <span className="font-bold text-zinc-800 min-w-[40px] text-center font-mono">{(activeUnit.depth / 10).toFixed(0)} سم</span>
                <button
                  type="button"
                  onClick={() => onUpdateDimensions(activeUnit.width, activeUnit.height, Math.min(1200, activeUnit.depth + 50))}
                  className="w-5 h-5 rounded bg-white border border-gray-200 font-bold text-zinc-600 flex items-center justify-center hover:bg-gray-100"
                >+</button>
              </div>
            </div>
          </div>
        )}

        {/* Row 2: Movement Arrows & Elevation */}
        <div className="flex items-center justify-between py-2 border-b border-gray-100">
          {/* 4-Way Direction Arrows: ↑ ↓ ← → */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => onNudge?.(0, -100)}
              className="w-8 h-8 rounded-xl bg-gray-100 hover:bg-gray-200 active:bg-gray-300 flex items-center justify-center font-black text-sm text-zinc-700 shadow-sm active:scale-95 transition"
              title="تحريك للخلف"
            >
              ↑
            </button>
            <button
              type="button"
              onClick={() => onNudge?.(0, 100)}
              className="w-8 h-8 rounded-xl bg-gray-100 hover:bg-gray-200 active:bg-gray-300 flex items-center justify-center font-black text-sm text-zinc-700 shadow-sm active:scale-95 transition"
              title="تحريك للأمام"
            >
              ↓
            </button>
            <button
              type="button"
              onClick={() => onNudge?.(100, 0)}
              className="w-8 h-8 rounded-xl bg-gray-100 hover:bg-gray-200 active:bg-gray-300 flex items-center justify-center font-black text-sm text-zinc-700 shadow-sm active:scale-95 transition"
              title="تحريك لليمين"
            >
              →
            </button>
            <button
              type="button"
              onClick={() => onNudge?.(-100, 0)}
              className="w-8 h-8 rounded-xl bg-gray-100 hover:bg-gray-200 active:bg-gray-300 flex items-center justify-center font-black text-sm text-zinc-700 shadow-sm active:scale-95 transition"
              title="تحريك لليسار"
            >
              ←
            </button>
          </div>

          {/* Elevation Control: ▲ 1.4م ▼ */}
          <div className="flex items-center gap-1 bg-gray-100 px-2.5 py-1 rounded-xl text-xs font-bold text-zinc-800">
            <button
              type="button"
              onClick={() => onElevate?.(50)}
              className="p-0.5 hover:text-blue-600 transition active:scale-90"
              title="رفع للأعلى 5سم"
            >
              ▲
            </button>
            <span className="min-w-[44px] text-center">{elevationM} م</span>
            <button
              type="button"
              onClick={() => onElevate?.(-50)}
              className="p-0.5 hover:text-blue-600 transition active:scale-90"
              title="خفض للأسفل 5سم"
            >
              ▼
            </button>
          </div>
        </div>

        {/* Row 2.5: Snap and Merge with Continuous Seamless Countertop (دمج الوحدات وتوحيد السطح) */}
        {activeUnit && onSnapAndMerge && (
          <div className="flex items-center justify-between py-2 border-b border-gray-100 bg-indigo-50/70 -mx-3.5 px-3.5">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-indigo-600 animate-pulse" />
              <span className="text-indigo-950 font-bold text-xs">دمج وتوحيد السطح:</span>
              <span className="text-[10px] text-indigo-700 font-medium hidden sm:inline">(سطح متصل بدون فواصل)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                id="btn-snap-merge-right"
                onClick={() => onSnapAndMerge('right')}
                className="px-2.5 py-1 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-1 shadow-sm transition active:scale-95"
                title="دمج بالوحدة المجاورة يميناً وتوحيد السطحين كسطح واحد متصل"
              >
                <span>دمج يمين</span>
                <span>👉</span>
              </button>
              <button
                type="button"
                id="btn-snap-merge-left"
                onClick={() => onSnapAndMerge('left')}
                className="px-2.5 py-1 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-1 shadow-sm transition active:scale-95"
                title="دمج بالوحدة المجاورة يساراً وتوحيد السطحين كسطح واحد متصل"
              >
                <span>👈</span>
                <span>دمج يسار</span>
              </button>
            </div>
          </div>
        )}

        {/* Row 3: Color Swatches, Delete, Duplicate */}
        <div className="flex items-center justify-between pt-2.5">
          {/* Swatches List */}
          <div className="flex items-center gap-2">
            {swatches.map((s) => (
              <button
                key={s.hex}
                type="button"
                onClick={() => onColorSelect?.(s.hex)}
                style={{ backgroundColor: s.hex }}
                className="w-6 h-6 rounded-full border border-gray-300 hover:scale-110 active:scale-95 transition shadow-sm"
                title={s.label}
              />
            ))}
            <button
              type="button"
              onClick={onOpenMaterials}
              className="w-6 h-6 rounded-full border border-dashed border-gray-300 hover:border-gray-500 flex items-center justify-center text-xs text-gray-500 hover:bg-gray-50 transition"
              title="مكتبة الخامات الكاملة"
            >
              +
            </button>
          </div>

          {/* Actions: Duplicate & Delete */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={onDuplicate}
              className="p-2 rounded-xl bg-gray-100 hover:bg-gray-200 text-zinc-700 transition active:scale-95"
              title="نسخ وتكرار"
            >
              <Copy className="w-4 h-4 text-emerald-600" />
            </button>
            <button
              type="button"
              onClick={onDelete}
              className="p-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-600 transition active:scale-95"
              title="حذف"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
