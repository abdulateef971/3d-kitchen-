import React, { useState } from 'react';
import { ParametricCabinet, CostBreakdown, CutListPiece, PricingRules } from '../../types';
import { calculateProjectCost, DEFAULT_PRICING_RULES } from '../../domain/pricing/costCalculator';
import { generateProjectCutList } from '../../domain/cutlist/cutListGenerator';
import {
  X,
  DollarSign,
  Scissors,
  Download,
  Printer,
  Layers,
  FileSpreadsheet,
  Check,
  Sliders,
  RotateCcw,
  Sparkles,
} from 'lucide-react';

interface CostCutListModalProps {
  isOpen: boolean;
  onClose: () => void;
  units: ParametricCabinet[];
  projectName: string;
}

export const CostCutListModal: React.FC<CostCutListModalProps> = ({
  isOpen,
  onClose,
  units,
  projectName,
}) => {
  const [activeTab, setActiveTab] = useState<'cost' | 'cutlist' | 'rules'>('cost');
  const [pricingRules, setPricingRules] = useState<PricingRules>(DEFAULT_PRICING_RULES);

  if (!isOpen) return null;

  const cost: CostBreakdown = calculateProjectCost(units, pricingRules);
  const cutList: CutListPiece[] = generateProjectCutList(units);

  const handleExportCSV = () => {
    const headers = 'Unit,Part Name,Length (mm),Width (mm),Thickness (mm),Qty,Material,Edge Banding\n';
    const rows = cutList
      .map(
        (p) =>
          `"${p.unitName}","${p.partNameAr}",${p.length},${p.width},${p.thickness},${p.quantity},"${p.material}","${p.edgeBanding}"`
      )
      .join('\n');
    const blob = new Blob(['\uFEFF' + headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `CutList_${projectName.replace(/\s+/g, '_')}.csv`;
    link.click();
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200 font-['Cairo',sans-serif]">
      <div className="relative w-full max-w-4xl bg-[#1E1E1E] border border-[#333333] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-[#333333] flex items-center justify-between bg-[#252525]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded bg-emerald-600/15 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white tracking-wide">
                حساب التكلفة، قائمة القص، وقواعد التسعير (BOM & Pricing Rules)
              </h2>
              <p className="text-[11px] text-gray-400">
                مشروع: {projectName} ({units.length} وحدات مصممة)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-white rounded hover:bg-[#333333] transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="px-5 pt-2 flex items-center justify-between border-b border-[#333333] bg-[#1E1E1E] text-xs">
          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab('cost')}
              className={`px-3 py-2 font-bold border-b-2 transition flex items-center gap-1.5 text-xs ${
                activeTab === 'cost'
                  ? 'border-blue-500 text-blue-400'
                  : 'border-transparent text-gray-400 hover:text-gray-200'
              }`}
            >
              <DollarSign className="w-3.5 h-3.5" />
              تقدير التكلفة الإجمالية (Cost)
            </button>
            <button
              onClick={() => setActiveTab('cutlist')}
              className={`px-3 py-2 font-bold border-b-2 transition flex items-center gap-1.5 text-xs ${
                activeTab === 'cutlist'
                  ? 'border-blue-500 text-blue-400'
                  : 'border-transparent text-gray-400 hover:text-gray-200'
              }`}
            >
              <Scissors className="w-3.5 h-3.5" />
              قائمة تفصيل وقص الألواح ({cutList.length} قطعة)
            </button>
            <button
              onClick={() => setActiveTab('rules')}
              className={`px-3 py-2 font-bold border-b-2 transition flex items-center gap-1.5 text-xs ${
                activeTab === 'rules'
                  ? 'border-blue-500 text-blue-400'
                  : 'border-transparent text-gray-400 hover:text-gray-200'
              }`}
            >
              <Sliders className="w-3.5 h-3.5 text-amber-400" />
              قاعدة حساب التكاليف (Pricing Rules)
            </button>
          </div>

          <div className="flex items-center gap-2 pb-1.5">
            <button
              onClick={handleExportCSV}
              className="px-2.5 py-1 rounded-lg bg-[#252525] hover:bg-[#333333] border border-[#383838] text-gray-200 text-xs font-semibold flex items-center gap-1.5 transition"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              تصدير CSV / Excel
            </button>
            <button
              onClick={handlePrint}
              className="px-2.5 py-1 rounded-lg bg-[#252525] hover:bg-[#333333] border border-[#383838] text-gray-200 text-xs font-semibold flex items-center gap-1.5 transition"
            >
              <Printer className="w-3.5 h-3.5 text-blue-400" />
              طباعة التقرير
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto flex-1 space-y-5 text-xs">
          {activeTab === 'cost' && (
            /* Cost Breakdown View */
            <div className="space-y-4">
              {/* Summary Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3.5 rounded-xl bg-emerald-950/30 border border-emerald-500/30">
                  <span className="text-[11px] text-emerald-400 font-bold block">التكلفة التقديرية الكلية</span>
                  <span className="text-xl sm:text-2xl font-black text-white font-mono mt-1 block">
                    {cost.currency}{cost.totalCost.toLocaleString()}
                  </span>
                  <span className="text-[10px] text-gray-400 mt-1 block">
                    شامل المواد، الإكسسوارات، المصنعية ({pricingRules.laborRatePercentage}%) وهامش الربح ({pricingRules.profitMarginPercentage}%)
                  </span>
                </div>

                <div className="p-3.5 rounded-xl bg-[#121212] border border-[#333333]">
                  <span className="text-[11px] text-gray-400 font-bold block">عدد ألواح MDF المقدرة</span>
                  <span className="text-xl sm:text-2xl font-black text-blue-400 font-mono mt-1 block">
                    {cost.sheetsCount} <span className="text-xs font-normal text-gray-400">لوح</span>
                  </span>
                  <span className="text-[10px] text-gray-500 mt-1 block">قياس 2440 × 1220 مم مع 15% هدر قص</span>
                </div>

                <div className="p-3.5 rounded-xl bg-[#121212] border border-[#333333]">
                  <span className="text-[11px] text-gray-400 font-bold block">تكلفة الإكسسوارات والمفصلات</span>
                  <span className="text-xl sm:text-2xl font-black text-amber-400 font-mono mt-1 block">
                    {cost.currency}{cost.hardwareCost.toLocaleString()}
                  </span>
                  <span className="text-[10px] text-gray-500 mt-1 block">مفصلات هيدروليك + سكك أدراج + مقابض</span>
                </div>
              </div>

              {/* Breakdown Table */}
              <div className="bg-[#121212] rounded-xl border border-[#333333] overflow-hidden">
                <table className="w-full text-right text-xs">
                  <thead className="bg-[#252525] text-gray-400 border-b border-[#333333] font-bold">
                    <tr>
                      <th className="p-2.5">بند التكلفة</th>
                      <th className="p-2.5">التفاصيل الهندسية</th>
                      <th className="p-2.5 text-left">المبلغ ({cost.currency})</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#252525]">
                    <tr>
                      <td className="p-2.5 font-semibold text-gray-200">أخشاب وهيكل الوحدات وشريط القشاط (Carcase & Edges)</td>
                      <td className="p-2.5 text-gray-400">ألواح الجوانب والقواعد والأرفف والظهر وشريط PVC</td>
                      <td className="p-2.5 font-mono text-blue-300 font-bold text-left">{cost.currency}{cost.materialCost}</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 font-semibold text-gray-200">واجهات الأبواب والرفوف (Fronts)</td>
                      <td className="p-2.5 text-gray-400">درف الخزائن MDF/أكريليك/خشب مع القشاط</td>
                      <td className="p-2.5 font-mono text-blue-300 font-bold text-left">{cost.currency}{cost.doorsCost}</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 font-semibold text-gray-200">صناديق الأدراج (Drawer Boxes)</td>
                      <td className="p-2.5 text-gray-400">صناديق الأدراج وتجميع السحابات</td>
                      <td className="p-2.5 font-mono text-blue-300 font-bold text-left">{cost.currency}{cost.drawersCost}</td>
                    </tr>
                    {cost.countertopCost > 0 && (
                      <tr>
                        <td className="p-2.5 font-semibold text-gray-200">أسطح الرخام / الكوارتز (Countertops)</td>
                        <td className="p-2.5 text-gray-400">رخام كلكتا / كوارتز / جرانيت مع الوزرة الخلفية</td>
                        <td className="p-2.5 font-mono text-blue-300 font-bold text-left">{cost.currency}{cost.countertopCost}</td>
                      </tr>
                    )}
                    <tr>
                      <td className="p-2.5 font-semibold text-gray-200">الإكسسوارات والسكك والمقابض (Hardware)</td>
                      <td className="p-2.5 text-gray-400">مفصلات سوفت كلوز + مجاري تانديم + مقابض</td>
                      <td className="p-2.5 font-mono text-blue-300 font-bold text-left">{cost.currency}{cost.hardwareCost}</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 font-semibold text-gray-200">المصنعية والتركيب (Labor & Fabrication)</td>
                      <td className="p-2.5 text-gray-400">قص CNC، تركيب القشاط، والتجميع والتسليم ({pricingRules.laborRatePercentage}%)</td>
                      <td className="p-2.5 font-mono text-blue-300 font-bold text-left">{cost.currency}{cost.laborCost}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'cutlist' && (
            /* Cut-List Table View */
            <div className="space-y-3">
              <div className="bg-[#121212] rounded-xl border border-[#333333] overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead className="bg-[#252525] text-gray-400 border-b border-[#333333] font-bold">
                    <tr>
                      <th className="p-2.5">#</th>
                      <th className="p-2.5">الوحدة التابعة</th>
                      <th className="p-2.5">اسم القطعة</th>
                      <th className="p-2.5 font-mono">الطول (L)</th>
                      <th className="p-2.5 font-mono">العرض (W)</th>
                      <th className="p-2.5 font-mono">السماكة (T)</th>
                      <th className="p-2.5 font-mono">العدد</th>
                      <th className="p-2.5">الخامة</th>
                      <th className="p-2.5">شريط القشاط (PVC)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#252525]">
                    {cutList.map((piece, idx) => (
                      <tr key={piece.id || idx} className="hover:bg-[#1E1E1E] transition">
                        <td className="p-2.5 text-gray-500 font-mono">{idx + 1}</td>
                        <td className="p-2.5 text-gray-400">{piece.unitName}</td>
                        <td className="p-2.5 font-bold text-gray-200">{piece.partNameAr}</td>
                        <td className="p-2.5 font-mono text-blue-400 font-bold">{piece.length} mm</td>
                        <td className="p-2.5 font-mono text-blue-400 font-bold">{piece.width} mm</td>
                        <td className="p-2.5 font-mono text-gray-400">{piece.thickness} mm</td>
                        <td className="p-2.5 font-mono text-amber-300 font-bold">{piece.quantity}</td>
                        <td className="p-2.5 text-gray-300">{piece.material}</td>
                        <td className="p-2.5 text-[11px] font-mono text-gray-400">{piece.edgeBanding}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'rules' && (
            /* Pricing Rules Customization View (قاعدة حساب التكاليف) */
            <div className="space-y-4">
              <div className="flex items-center justify-between bg-[#121212] p-3 rounded-xl border border-[#333333]">
                <div className="flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-amber-400" />
                  <span className="font-bold text-white">تخصيص معادلة وأسعار التكاليف (Pricing Rules & Rates)</span>
                </div>
                <button
                  type="button"
                  onClick={() => setPricingRules(DEFAULT_PRICING_RULES)}
                  className="px-2.5 py-1 rounded bg-[#252525] hover:bg-[#333333] text-gray-300 text-xs font-semibold flex items-center gap-1.5 transition border border-[#444]"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  استعادة الأسعار الافتراضية
                </button>
              </div>

              {/* Currency Selector */}
              <div className="p-3 bg-[#121212] rounded-xl border border-[#333333] flex items-center justify-between">
                <span className="text-gray-300 font-semibold">رمز العملة (Currency):</span>
                <div className="flex gap-1.5">
                  {['$', 'SAR', 'AED', 'IQD', 'KWD', 'QAR', 'EGP'].map((curr) => (
                    <button
                      key={curr}
                      onClick={() => setPricingRules({ ...pricingRules, currency: curr })}
                      className={`px-3 py-1 rounded text-xs font-bold transition border ${
                        pricingRules.currency === curr
                          ? 'bg-blue-600 border-blue-500 text-white shadow'
                          : 'bg-[#1E1E1E] border-[#333] text-gray-400 hover:text-white'
                      }`}
                    >
                      {curr}
                    </button>
                  ))}
                </div>
              </div>

              {/* Grid of Unit Rates */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 bg-[#121212] rounded-xl border border-[#333333] space-y-1">
                  <span className="text-gray-400 block text-[11px]">سعر المتر المربع لخشب الهيكل (Carcase MDF / m²)</span>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={pricingRules.carcaseRatePerSqM}
                      onChange={(e) =>
                        setPricingRules({ ...pricingRules, carcaseRatePerSqM: Number(e.target.value) })
                      }
                      className="w-full bg-[#1E1E1E] border border-[#444] rounded px-3 py-1.5 text-white font-mono text-xs"
                    />
                    <span className="text-gray-400 font-mono">{pricingRules.currency}/m²</span>
                  </div>
                </div>

                <div className="p-3 bg-[#121212] rounded-xl border border-[#333333] space-y-1">
                  <span className="text-gray-400 block text-[11px]">سعر المتر المربع لدرف وأبواب الواجهات (Door Fronts / m²)</span>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={pricingRules.doorRatePerSqM}
                      onChange={(e) =>
                        setPricingRules({ ...pricingRules, doorRatePerSqM: Number(e.target.value) })
                      }
                      className="w-full bg-[#1E1E1E] border border-[#444] rounded px-3 py-1.5 text-white font-mono text-xs"
                    />
                    <span className="text-gray-400 font-mono">{pricingRules.currency}/m²</span>
                  </div>
                </div>

                <div className="p-3 bg-[#121212] rounded-xl border border-[#333333] space-y-1">
                  <span className="text-gray-400 block text-[11px]">سعر زوج المفصلات الهيدروليكية (Soft-Close Hinge Pair)</span>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      step="0.5"
                      value={pricingRules.hingePairRate}
                      onChange={(e) =>
                        setPricingRules({ ...pricingRules, hingePairRate: Number(e.target.value) })
                      }
                      className="w-full bg-[#1E1E1E] border border-[#444] rounded px-3 py-1.5 text-white font-mono text-xs"
                    />
                    <span className="text-gray-400 font-mono">{pricingRules.currency}</span>
                  </div>
                </div>

                <div className="p-3 bg-[#121212] rounded-xl border border-[#333333] space-y-1">
                  <span className="text-gray-400 block text-[11px]">سعر زوج سكك الأدراج التانديم (Tandem Drawer Slides)</span>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={pricingRules.drawerSlidePairRate}
                      onChange={(e) =>
                        setPricingRules({ ...pricingRules, drawerSlidePairRate: Number(e.target.value) })
                      }
                      className="w-full bg-[#1E1E1E] border border-[#444] rounded px-3 py-1.5 text-white font-mono text-xs"
                    />
                    <span className="text-gray-400 font-mono">{pricingRules.currency}</span>
                  </div>
                </div>

                <div className="p-3 bg-[#121212] rounded-xl border border-[#333333] space-y-1">
                  <span className="text-gray-400 block text-[11px]">سعر المتر المربع لأسطح الرخام/الكوارتز (Countertop / m²)</span>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={pricingRules.countertopRatePerSqM}
                      onChange={(e) =>
                        setPricingRules({ ...pricingRules, countertopRatePerSqM: Number(e.target.value) })
                      }
                      className="w-full bg-[#1E1E1E] border border-[#444] rounded px-3 py-1.5 text-white font-mono text-xs"
                    />
                    <span className="text-gray-400 font-mono">{pricingRules.currency}/m²</span>
                  </div>
                </div>

                <div className="p-3 bg-[#121212] rounded-xl border border-[#333333] space-y-1">
                  <span className="text-gray-400 block text-[11px]">سعر المتر الطولي لشريط القشاط PVC (Edge Banding / m)</span>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      step="0.1"
                      value={pricingRules.edgeBandingRatePerMeter}
                      onChange={(e) =>
                        setPricingRules({ ...pricingRules, edgeBandingRatePerMeter: Number(e.target.value) })
                      }
                      className="w-full bg-[#1E1E1E] border border-[#444] rounded px-3 py-1.5 text-white font-mono text-xs"
                    />
                    <span className="text-gray-400 font-mono">{pricingRules.currency}/m</span>
                  </div>
                </div>

                <div className="p-3 bg-[#121212] rounded-xl border border-[#333333] space-y-1">
                  <span className="text-gray-400 block text-[11px]">نسبة المصنعية والتجميع (Labor & Assembly %)</span>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={pricingRules.laborRatePercentage}
                      onChange={(e) =>
                        setPricingRules({ ...pricingRules, laborRatePercentage: Number(e.target.value) })
                      }
                      className="w-full bg-[#1E1E1E] border border-[#444] rounded px-3 py-1.5 text-white font-mono text-xs"
                    />
                    <span className="text-gray-400 font-mono">%</span>
                  </div>
                </div>

                <div className="p-3 bg-[#121212] rounded-xl border border-[#333333] space-y-1">
                  <span className="text-gray-400 block text-[11px]">نسبة هامش الربح (Profit Margin %)</span>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={pricingRules.profitMarginPercentage}
                      onChange={(e) =>
                        setPricingRules({ ...pricingRules, profitMarginPercentage: Number(e.target.value) })
                      }
                      className="w-full bg-[#1E1E1E] border border-[#444] rounded px-3 py-1.5 text-white font-mono text-xs"
                    />
                    <span className="text-gray-400 font-mono">%</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-[#333333] flex justify-end bg-[#252525]">
          <button
            onClick={onClose}
            className="px-5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md transition"
          >
            إغلاق النافذة
          </button>
        </div>
      </div>
    </div>
  );
};
