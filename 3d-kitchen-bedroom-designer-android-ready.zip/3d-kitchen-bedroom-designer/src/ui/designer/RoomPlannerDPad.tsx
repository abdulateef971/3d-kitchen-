import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Footprints } from 'lucide-react';

interface RoomPlannerDPadProps {
  onWalk: (forward: number, right: number) => void;
  onRotate?: (direction: 'left' | 'right') => void;
  onStop?: () => void;
  onCenterClick?: () => void;
  isWalkMode?: boolean;
}

export const RoomPlannerDPad: React.FC<RoomPlannerDPadProps> = ({
  onWalk,
  onRotate,
  onStop,
  onCenterClick,
  isWalkMode = false,
}) => {
  const [activeDirection, setActiveDirection] = useState<'up' | 'down' | 'left' | 'right' | 'center' | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const activeVectorRef = useRef<{ f: number; r: number }>({ f: 0, r: 0 });

  const startMoving = useCallback(
    (direction: 'up' | 'down' | 'left' | 'right') => {
      setActiveDirection(direction);
      let f = 0;
      let r = 0;
      if (direction === 'up') f = 1.0;
      if (direction === 'down') f = -1.0;
      if (direction === 'left') r = -1.0;
      if (direction === 'right') r = 1.0;

      activeVectorRef.current = { f, r };
    },
    []
  );

  const stopMoving = useCallback(() => {
    setActiveDirection(null);
    activeVectorRef.current = { f: 0, r: 0 };
    onStop?.();
  }, [onStop]);

  // Continuous movement loop while holding
  useEffect(() => {
    if (!activeDirection || activeDirection === 'center') {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
        animFrameRef.current = null;
      }
      return;
    }

    const loop = () => {
      const { f, r } = activeVectorRef.current;
      if (f !== 0 || r !== 0) {
        onWalk(f, r);
      }
      animFrameRef.current = requestAnimationFrame(loop);
    };

    animFrameRef.current = requestAnimationFrame(loop);
    return () => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    };
  }, [activeDirection, onWalk]);

  return (
    <div
      id="room-planner-dpad"
      className="relative select-none touch-none w-[96px] h-[96px] rounded-full bg-[#18181B]/90 backdrop-blur-md shadow-2xl border border-white/10 flex items-center justify-center p-1"
    >
      {/* Up Button ▲ */}
      <button
        type="button"
        id="dpad-up"
        onMouseDown={() => startMoving('up')}
        onMouseUp={stopMoving}
        onMouseLeave={stopMoving}
        onTouchStart={(e) => {
          e.preventDefault();
          startMoving('up');
        }}
        onTouchEnd={stopMoving}
        className={`absolute top-1 left-1/2 -translate-x-1/2 w-8 h-7 flex items-start justify-center pt-1 transition-transform active:scale-90 ${
          activeDirection === 'up' ? 'text-amber-400' : 'text-zinc-400 hover:text-white'
        }`}
        title="التقدم للأمام"
        aria-label="Move Forward"
      >
        <svg width="14" height="10" viewBox="0 0 14 10" fill="currentColor">
          <path d="M7 0L13.0622 9H0.937822L7 0Z" />
        </svg>
      </button>

      {/* Down Button ▼ */}
      <button
        type="button"
        id="dpad-down"
        onMouseDown={() => startMoving('down')}
        onMouseUp={stopMoving}
        onMouseLeave={stopMoving}
        onTouchStart={(e) => {
          e.preventDefault();
          startMoving('down');
        }}
        onTouchEnd={stopMoving}
        className={`absolute bottom-1 left-1/2 -translate-x-1/2 w-8 h-7 flex items-end justify-center pb-1 transition-transform active:scale-90 ${
          activeDirection === 'down' ? 'text-amber-400' : 'text-zinc-400 hover:text-white'
        }`}
        title="الرجوع للخلف"
        aria-label="Move Backward"
      >
        <svg width="14" height="10" viewBox="0 0 14 10" fill="currentColor">
          <path d="M7 10L0.937822 1L13.0622 1L7 10Z" />
        </svg>
      </button>

      {/* Left Button ◀ */}
      <button
        type="button"
        id="dpad-left"
        onMouseDown={() => startMoving('left')}
        onMouseUp={stopMoving}
        onMouseLeave={stopMoving}
        onTouchStart={(e) => {
          e.preventDefault();
          startMoving('left');
        }}
        onTouchEnd={stopMoving}
        className={`absolute left-1 top-1/2 -translate-y-1/2 w-7 h-8 flex items-center justify-start pl-1 transition-transform active:scale-90 ${
          activeDirection === 'left' ? 'text-amber-400' : 'text-zinc-400 hover:text-white'
        }`}
        title="التحرك يساراً"
        aria-label="Move Left"
      >
        <svg width="10" height="14" viewBox="0 0 10 14" fill="currentColor">
          <path d="M0 7L9 0.937822V13.0622L0 7Z" />
        </svg>
      </button>

      {/* Right Button ▶ */}
      <button
        type="button"
        id="dpad-right"
        onMouseDown={() => startMoving('right')}
        onMouseUp={stopMoving}
        onMouseLeave={stopMoving}
        onTouchStart={(e) => {
          e.preventDefault();
          startMoving('right');
        }}
        onTouchEnd={stopMoving}
        className={`absolute right-1 top-1/2 -translate-y-1/2 w-7 h-8 flex items-center justify-end pr-1 transition-transform active:scale-90 ${
          activeDirection === 'right' ? 'text-amber-400' : 'text-zinc-400 hover:text-white'
        }`}
        title="التحرك يميناً"
        aria-label="Move Right"
      >
        <svg width="10" height="14" viewBox="0 0 10 14" fill="currentColor">
          <path d="M10 7L1 13.0622V0.937822L10 7Z" />
        </svg>
      </button>

      {/* Center Circle with Footprints 👣 matching Screenshot 1 & 2 */}
      <button
        type="button"
        id="dpad-center"
        onClick={onCenterClick}
        className={`w-9 h-9 rounded-full flex items-center justify-center transition-all shadow-md active:scale-95 ${
          isWalkMode
            ? 'bg-amber-400 text-zinc-950 shadow-amber-500/20'
            : 'bg-white text-zinc-900 hover:bg-zinc-100 shadow-zinc-950/40'
        }`}
        title={isWalkMode ? 'وضع المشي نشط' : 'التبديل إلى وضع المشي'}
        aria-label="Walk Mode"
      >
        <Footprints className="w-4 h-4" />
      </button>
    </div>
  );
};
