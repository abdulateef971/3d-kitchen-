import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  X,
  Check,
  ZoomIn,
  ZoomOut,
  Maximize2,
  PenTool,
  Move,
  MousePointer,
  Trash2,
  RotateCcw,
  DoorOpen,
  AppWindow,
  Layers,
  Compass,
  Plus,
  HelpCircle,
  Eye,
  EyeOff,
} from 'lucide-react';
import { RoomConfig, CustomWall, WallOpening, ParametricCabinet } from '../../types';

interface FloorPlan2DModalProps {
  isOpen: boolean;
  onClose: () => void;
  room: RoomConfig;
  cabinets: ParametricCabinet[];
  onSaveRoom: (updatedRoom: RoomConfig) => void;
}

type ToolType = 'select' | 'pan' | 'draw_wall' | 'add_door' | 'add_window';

export const FloorPlan2DModal: React.FC<FloorPlan2DModalProps> = ({
  isOpen,
  onClose,
  room,
  cabinets,
  onSaveRoom,
}) => {
  // Local editable copy of room settings
  const [roomWidth, setRoomWidth] = useState<number>(room.width || 4000);
  const [roomLength, setRoomLength] = useState<number>(room.length || 5000);
  const [roomHeight, setRoomHeight] = useState<number>(room.height || 2800);
  const [customWalls, setCustomWalls] = useState<CustomWall[]>(
    room.customWalls ? JSON.parse(JSON.stringify(room.customWalls)) : []
  );
  const [openings, setOpenings] = useState<WallOpening[]>(
    room.openings ? JSON.parse(JSON.stringify(room.openings)) : []
  );

  // Active Tool
  const [activeTool, setActiveTool] = useState<ToolType>('draw_wall');
  const [wallThickness, setWallThickness] = useState<number>(120);
  const [gridSnapMm, setGridSnapMm] = useState<number>(50);
  const [showCabinets, setShowCabinets] = useState<boolean>(true);
  const [showDimensions, setShowDimensions] = useState<boolean>(true);
  const [isToolsVisible, setIsToolsVisible] = useState<boolean>(true);

  // Selection states
  const [selectedWallId, setSelectedWallId] = useState<string | null>(null);
  const [selectedOpeningId, setSelectedOpeningId] = useState<string | null>(null);

  // Canvas Transform State (Pan & Zoom)
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [zoom, setZoom] = useState<number>(0.12); // pixels per mm
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState<boolean>(false);
  const [panStart, setPanStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Drawing state for Wall tool
  const [drawingStart, setDrawingStart] = useState<{ x: number; z: number } | null>(null);
  const [currentCursorMm, setCurrentCursorMm] = useState<{ x: number; z: number }>({ x: 0, z: 0 });
  const [dragHandle, setDragHandle] = useState<{
    type: 'start' | 'end' | 'body' | 'room_w' | 'room_l';
    id?: string;
  } | null>(null);

  // Undo history
  const [history, setHistory] = useState<
    Array<{
      walls: CustomWall[];
      openings: WallOpening[];
      w: number;
      l: number;
    }>
  >([]);

  // Initialize view centered
  useEffect(() => {
    if (isOpen) {
      setRoomWidth(room.width || 4000);
      setRoomLength(room.length || 5000);
      setRoomHeight(room.height || 2800);
      setCustomWalls(room.customWalls ? JSON.parse(JSON.stringify(room.customWalls)) : []);
      setOpenings(room.openings ? JSON.parse(JSON.stringify(room.openings)) : []);
      setSelectedWallId(null);
      setSelectedOpeningId(null);
      setDrawingStart(null);
      setPan({ x: 0, y: 0 });
    }
  }, [isOpen, room]);

  const pushHistory = useCallback(() => {
    setHistory((prev) => [
      ...prev.slice(-15),
      {
        walls: JSON.parse(JSON.stringify(customWalls)),
        openings: JSON.parse(JSON.stringify(openings)),
        w: roomWidth,
        l: roomLength,
      },
    ]);
  }, [customWalls, openings, roomWidth, roomLength]);

  const handleUndo = () => {
    if (history.length === 0) return;
    const last = history[history.length - 1];
    setHistory((prev) => prev.slice(0, -1));
    setCustomWalls(last.walls);
    setOpenings(last.openings);
    setRoomWidth(last.w);
    setRoomLength(last.l);
    setSelectedWallId(null);
    setSelectedOpeningId(null);
  };

  // Convert World (mm) to Screen (px)
  const worldToScreen = useCallback(
    (xMm: number, zMm: number, canvas: HTMLCanvasElement) => {
      const cx = canvas.width / 2 + pan.x;
      const cy = canvas.height / 2 + pan.y;
      return {
        x: cx + xMm * zoom,
        y: cy + zMm * zoom,
      };
    },
    [pan, zoom]
  );

  // Convert Screen (px) to World (mm)
  const screenToWorld = useCallback(
    (screenX: number, screenY: number, canvas: HTMLCanvasElement) => {
      const cx = canvas.width / 2 + pan.x;
      const cy = canvas.height / 2 + pan.y;
      return {
        x: (screenX - cx) / zoom,
        z: (screenY - cy) / zoom,
      };
    },
    [pan, zoom]
  );

  // Snapping logic with orthogonal angle lock
  const snapCoordinate = useCallback(
    (rawX: number, rawZ: number, startPoint?: { x: number; z: number } | null) => {
      let x = Math.round(rawX / gridSnapMm) * gridSnapMm;
      let z = Math.round(rawZ / gridSnapMm) * gridSnapMm;

      // Outer room boundaries snap
      const halfW = roomWidth / 2;
      const halfL = roomLength / 2;
      const snapDist = 120;
      if (Math.abs(rawX - -halfW) < snapDist) x = -halfW;
      if (Math.abs(rawX - halfW) < snapDist) x = halfW;
      if (Math.abs(rawZ - -halfL) < snapDist) z = -halfL;
      if (Math.abs(rawZ - halfL) < snapDist) z = halfL;

      // If drawing from a start point: snap orthogonal angles (0°, 90°, 180°, 270°) and 45°
      if (startPoint) {
        const dx = x - startPoint.x;
        const dz = z - startPoint.z;
        const angleDeg = (Math.atan2(dz, dx) * 180) / Math.PI;

        // Snap to pure horizontal
        if (Math.abs(dz) < 160 || Math.abs(angleDeg) < 8 || Math.abs(Math.abs(angleDeg) - 180) < 8) {
          z = startPoint.z;
        }
        // Snap to pure vertical
        else if (Math.abs(dx) < 160 || Math.abs(Math.abs(angleDeg) - 90) < 8) {
          x = startPoint.x;
        }
      }

      return { x, z };
    },
    [gridSnapMm, roomWidth, roomLength]
  );

  // Fit room to canvas
  const handleFitView = useCallback(() => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const margin = 120;
    const scaleX = (canvas.width - margin * 2) / (roomWidth + 800);
    const scaleY = (canvas.height - margin * 2) / (roomLength + 800);
    const fitScale = Math.min(scaleX, scaleY, 0.25);
    setZoom(Math.max(0.05, fitScale));
    setPan({ x: 0, y: 0 });
  }, [roomWidth, roomLength]);

  // Main Canvas Render
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Resize canvas buffer to match display size
    const rect = canvas.getBoundingClientRect();
    if (canvas.width !== rect.width || canvas.height !== rect.height) {
      canvas.width = rect.width;
      canvas.height = rect.height;
    }

    const width = canvas.width;
    const height = canvas.height;

    // 1. Clear background (CAD blueprint dark theme)
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, width, height);

    // 2. Draw CAD Millimeter Grid
    const cx = width / 2 + pan.x;
    const cy = height / 2 + pan.y;

    // Minor grid (500mm)
    const stepMm = 500;
    const stepPx = stepMm * zoom;
    if (stepPx >= 15) {
      ctx.strokeStyle = '#1e293b';
      ctx.lineWidth = 1;
      ctx.beginPath();
      const startX = cx % stepPx;
      for (let x = startX; x < width; x += stepPx) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
      }
      const startY = cy % stepPx;
      for (let y = startY; y < height; y += stepPx) {
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
      }
      ctx.stroke();
    }

    // Major grid (1000mm / 1m)
    const majorStepPx = 1000 * zoom;
    if (majorStepPx >= 25) {
      ctx.strokeStyle = '#334155';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      const startX = cx % majorStepPx;
      for (let x = startX; x < width; x += majorStepPx) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
      }
      const startY = cy % majorStepPx;
      for (let y = startY; y < height; y += majorStepPx) {
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
      }
      ctx.stroke();
    }

    // Origin crosshairs (0, 0)
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(cx, 0);
    ctx.lineTo(cx, height);
    ctx.moveTo(0, cy);
    ctx.lineTo(width, cy);
    ctx.stroke();
    ctx.setLineDash([]);

    // 3. Room Interior Floor
    const halfW = roomWidth / 2;
    const halfL = roomLength / 2;
    const roomTopLeft = worldToScreen(-halfW, -halfL, canvas);
    const roomWpx = roomWidth * zoom;
    const roomLpx = roomLength * zoom;

    ctx.fillStyle = '#1e293b';
    ctx.fillRect(roomTopLeft.x, roomTopLeft.y, roomWpx, roomLpx);

    // 4. Cabinets Top-Down Layout Overlay
    if (showCabinets && cabinets.length > 0) {
      cabinets.forEach((cab) => {
        // Cabinet dimensions (width x depth)
        // Check rotationY (0, 90, 180, 270)
        let w = cab.width;
        let d = cab.depth;
        const rad = ((cab.rotationY || 0) * Math.PI) / 180;
        const cos = Math.abs(Math.cos(rad));
        const sin = Math.abs(Math.sin(rad));
        const rotW = w * cos + d * sin;
        const rotD = w * sin + d * cos;

        // Position in room coordinates (cab.positionX is center, cab.positionZ is center)
        const cabP = worldToScreen(cab.positionX, cab.positionZ, canvas);
        const cabWpx = rotW * zoom;
        const cabDpx = rotD * zoom;

        ctx.save();
        ctx.translate(cabP.x, cabP.y);
        ctx.rotate(-rad);

        // Cabinet footprint box
        const isWallCab = cab.category === 'kitchen_wall';
        ctx.fillStyle = isWallCab ? 'rgba(56, 189, 248, 0.18)' : 'rgba(245, 158, 11, 0.22)';
        ctx.fillRect((-cab.width / 2) * zoom, (-cab.depth / 2) * zoom, cab.width * zoom, cab.depth * zoom);

        ctx.strokeStyle = isWallCab ? '#38bdf8' : '#f59e0b';
        ctx.lineWidth = 1.5;
        if (isWallCab) ctx.setLineDash([3, 3]);
        ctx.strokeRect((-cab.width / 2) * zoom, (-cab.depth / 2) * zoom, cab.width * zoom, cab.depth * zoom);
        ctx.setLineDash([]);

        // Front face indicator line
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo((-cab.width / 2) * zoom, (cab.depth / 2) * zoom);
        ctx.lineTo((cab.width / 2) * zoom, (cab.depth / 2) * zoom);
        ctx.stroke();

        // Label if zoomed enough
        if (zoom >= 0.08) {
          ctx.fillStyle = '#cbd5e1';
          ctx.font = 'bold 9px Cairo, sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(cab.nameAr || cab.name, 0, 0);
        }

        ctx.restore();
      });
    }

    // 5. Outer Perimeter Walls (4 Walls with cutouts for Doors & Windows)
    const wallThickPx = 120 * zoom;

    // Helper to draw outer wall segments around openings
    const drawOuterWallWithCutouts = (wallIdx: number) => {
      const wallOps = openings
        .filter((o) => (o.wallIndex ?? 0) === wallIdx)
        .sort((a, b) => a.distanceFromStart - b.distanceFromStart);

      const isNorthSouth = wallIdx === 0 || wallIdx === 2;
      const wallLength = isNorthSouth ? roomWidth : roomLength;

      // Local cursor from 0 to wallLength
      let cur = 0;

      const drawSegment = (startMm: number, endMm: number) => {
        if (endMm <= startMm) return;
        let p1: { x: number; y: number };
        let wPx: number;
        let hPx: number;

        if (wallIdx === 0) {
          // North Wall (Back: -Z)
          p1 = worldToScreen(-halfW + startMm, -halfL - 120, canvas);
          wPx = (endMm - startMm) * zoom;
          hPx = wallThickPx;
        } else if (wallIdx === 1) {
          // East Wall (Right: +X)
          p1 = worldToScreen(halfW, -halfL + startMm, canvas);
          wPx = wallThickPx;
          hPx = (endMm - startMm) * zoom;
        } else if (wallIdx === 2) {
          // South Wall (Front: +Z)
          p1 = worldToScreen(-halfW + startMm, halfL, canvas);
          wPx = (endMm - startMm) * zoom;
          hPx = wallThickPx;
        } else {
          // West Wall (Left: -X)
          p1 = worldToScreen(-halfW - 120, -halfL + startMm, canvas);
          wPx = wallThickPx;
          hPx = (endMm - startMm) * zoom;
        }

        ctx.fillStyle = '#475569';
        ctx.fillRect(p1.x, p1.y, wPx, hPx);
        ctx.strokeStyle = '#64748b';
        ctx.lineWidth = 1;
        ctx.strokeRect(p1.x, p1.y, wPx, hPx);
      };

      wallOps.forEach((op) => {
        const opStart = Math.max(0, op.distanceFromStart);
        const opEnd = opStart + op.width;
        if (opStart > cur) {
          drawSegment(cur, opStart);
        }
        cur = Math.max(cur, opEnd);

        // Draw Opening Graphic (Door or Window)
        const isSelected = selectedOpeningId === op.id;

        if (op.type === 'window') {
          // Architectural Window symbol (2 parallel blue lines with sill)
          let opCenterMm: { x: number; z: number };
          if (wallIdx === 0) opCenterMm = { x: -halfW + opStart + op.width / 2, z: -halfL - 60 };
          else if (wallIdx === 1) opCenterMm = { x: halfW + 60, z: -halfL + opStart + op.width / 2 };
          else if (wallIdx === 2) opCenterMm = { x: -halfW + opStart + op.width / 2, z: halfL + 60 };
          else opCenterMm = { x: -halfW - 60, z: -halfL + opStart + op.width / 2 };

          const opSc = worldToScreen(opCenterMm.x, opCenterMm.z, canvas);
          ctx.save();
          ctx.translate(opSc.x, opSc.y);
          if (wallIdx === 1 || wallIdx === 3) ctx.rotate(Math.PI / 2);

          const wPx = op.width * zoom;
          const hPx = wallThickPx;

          // Void background
          ctx.fillStyle = isSelected ? 'rgba(56, 189, 248, 0.4)' : '#1e293b';
          ctx.fillRect(-wPx / 2, -hPx / 2, wPx, hPx);

          // Window Glass & Frame Double Lines
          ctx.strokeStyle = isSelected ? '#38bdf8' : '#67e8f9';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(-wPx / 2, -hPx / 4);
          ctx.lineTo(wPx / 2, -hPx / 4);
          ctx.moveTo(-wPx / 2, hPx / 4);
          ctx.lineTo(wPx / 2, hPx / 4);
          ctx.stroke();

          // Outer jamb ticks
          ctx.strokeStyle = '#cbd5e1';
          ctx.beginPath();
          ctx.moveTo(-wPx / 2, -hPx / 2);
          ctx.lineTo(-wPx / 2, hPx / 2);
          ctx.moveTo(wPx / 2, -hPx / 2);
          ctx.lineTo(wPx / 2, hPx / 2);
          ctx.stroke();

          ctx.restore();
        } else {
          // Architectural Door symbol (Open leaf line + 90 degree dotted swing arc)
          let opCenterMm: { x: number; z: number };
          if (wallIdx === 0) opCenterMm = { x: -halfW + opStart + op.width / 2, z: -halfL - 60 };
          else if (wallIdx === 1) opCenterMm = { x: halfW + 60, z: -halfL + opStart + op.width / 2 };
          else if (wallIdx === 2) opCenterMm = { x: -halfW + opStart + op.width / 2, z: halfL + 60 };
          else opCenterMm = { x: -halfW - 60, z: -halfL + opStart + op.width / 2 };

          const opSc = worldToScreen(opCenterMm.x, opCenterMm.z, canvas);
          ctx.save();
          ctx.translate(opSc.x, opSc.y);
          if (wallIdx === 1) ctx.rotate(Math.PI / 2);
          else if (wallIdx === 2) ctx.rotate(Math.PI);
          else if (wallIdx === 3) ctx.rotate(-Math.PI / 2);

          const wPx = op.width * zoom;
          const hPx = wallThickPx;

          // Clear opening void
          ctx.fillStyle = isSelected ? 'rgba(251, 191, 36, 0.4)' : '#1e293b';
          ctx.fillRect(-wPx / 2, -hPx / 2, wPx, hPx);

          // Door Swing Arc
          ctx.strokeStyle = isSelected ? '#fbbf24' : '#e2e8f0';
          ctx.lineWidth = 1.5;
          ctx.setLineDash([3, 3]);
          ctx.beginPath();
          ctx.arc(-wPx / 2, hPx / 2, wPx, 0, Math.PI / 2, false);
          ctx.stroke();
          ctx.setLineDash([]);

          // Door Leaf open line
          ctx.strokeStyle = '#f59e0b';
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.moveTo(-wPx / 2, hPx / 2);
          ctx.lineTo(-wPx / 2, hPx / 2 + wPx);
          ctx.stroke();

          ctx.restore();
        }
      });

      if (cur < wallLength) {
        drawSegment(cur, wallLength);
      }
    };

    // Draw all 4 perimeter walls
    drawOuterWallWithCutouts(0); // North
    drawOuterWallWithCutouts(1); // East
    drawOuterWallWithCutouts(2); // South
    drawOuterWallWithCutouts(3); // West

    // 6. Custom Walls & Partitions (قواطع وجدران مخصصة)
    customWalls.forEach((cw) => {
      const isSelected = selectedWallId === cw.id;
      const s = worldToScreen(cw.startX, cw.startZ, canvas);
      const rad = ((cw.rotationY || 0) * Math.PI) / 180;
      const eMmX = cw.startX + cw.length * Math.cos(rad);
      const eMmZ = cw.startZ + cw.length * Math.sin(rad);
      const e = worldToScreen(eMmX, eMmZ, canvas);

      ctx.save();
      ctx.strokeStyle = isSelected ? '#38bdf8' : cw.color || '#94a3b8';
      ctx.lineWidth = Math.max(3, (cw.thickness || wallThickness) * zoom);
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(s.x, s.y);
      ctx.lineTo(e.x, e.y);
      ctx.stroke();

      // If selected: draw endpoint handles
      if (isSelected) {
        ctx.fillStyle = '#38bdf8';
        ctx.beginPath();
        ctx.arc(s.x, s.y, 6, 0, Math.PI * 2);
        ctx.arc(e.x, e.y, 6, 0, Math.PI * 2);
        ctx.fill();

        // Length tag in mm
        const midX = (s.x + e.x) / 2;
        const midY = (s.y + e.y) / 2;
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(midX - 35, midY - 12, 70, 24);
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 1;
        ctx.strokeRect(midX - 35, midY - 12, 70, 24);

        ctx.fillStyle = '#38bdf8';
        ctx.font = 'bold 11px Cairo, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(`${Math.round(cw.length)} mm`, midX, midY);
      }
      ctx.restore();
    });

    // 7. Active Drawing Preview Line (If user is currently drawing a wall)
    if (drawingStart) {
      const s = worldToScreen(drawingStart.x, drawingStart.z, canvas);
      const e = worldToScreen(currentCursorMm.x, currentCursorMm.z, canvas);

      const dx = currentCursorMm.x - drawingStart.x;
      const dz = currentCursorMm.z - drawingStart.z;
      const lenMm = Math.round(Math.sqrt(dx * dx + dz * dz));

      // Ghost line
      ctx.save();
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = Math.max(3, wallThickness * zoom);
      ctx.lineCap = 'round';
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(s.x, s.y);
      ctx.lineTo(e.x, e.y);
      ctx.stroke();
      ctx.setLineDash([]);

      // Start & End points
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(s.x, s.y, 5, 0, Math.PI * 2);
      ctx.arc(e.x, e.y, 5, 0, Math.PI * 2);
      ctx.fill();

      // Floating length badge
      const midX = (s.x + e.x) / 2;
      const midY = (s.y + e.y) / 2;
      ctx.fillStyle = '#0284c7';
      ctx.beginPath();
      ctx.roundRect(midX - 45, midY - 14, 90, 26, 6);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 12px Cairo, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(`📏 ${lenMm} mm`, midX, midY);
      ctx.restore();
    }

    // 8. Dimension Rulers (Outer Wall Dimensions in mm)
    if (showDimensions) {
      ctx.save();
      ctx.fillStyle = '#94a3b8';
      ctx.font = 'bold 12px Cairo, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      // North Width
      const topDimY = roomTopLeft.y - 30;
      ctx.fillText(`العرض: ${roomWidth} mm`, roomTopLeft.x + roomWpx / 2, topDimY);

      // South Width
      const btmDimY = roomTopLeft.y + roomLpx + 30;
      ctx.fillText(`العرض: ${roomWidth} mm`, roomTopLeft.x + roomWpx / 2, btmDimY);

      // West Length
      const leftDimX = roomTopLeft.x - 45;
      ctx.save();
      ctx.translate(leftDimX, roomTopLeft.y + roomLpx / 2);
      ctx.rotate(-Math.PI / 2);
      ctx.fillText(`الطول: ${roomLength} mm`, 0, 0);
      ctx.restore();

      // East Length
      const rightDimX = roomTopLeft.x + roomWpx + 45;
      ctx.save();
      ctx.translate(rightDimX, roomTopLeft.y + roomLpx / 2);
      ctx.rotate(Math.PI / 2);
      ctx.fillText(`الطول: ${roomLength} mm`, 0, 0);
      ctx.restore();

      ctx.restore();
    }

    // 9. North Compass Arrow
    ctx.save();
    const compassX = 40;
    const compassY = 40;
    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.moveTo(compassX, compassY - 18);
    ctx.lineTo(compassX - 6, compassY);
    ctx.lineTo(compassX + 6, compassY);
    ctx.fill();
    ctx.fillStyle = '#94a3b8';
    ctx.beginPath();
    ctx.moveTo(compassX, compassY + 18);
    ctx.lineTo(compassX - 6, compassY);
    ctx.lineTo(compassX + 6, compassY);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('N', compassX, compassY - 22);
    ctx.restore();
  }, [
    roomWidth,
    roomLength,
    customWalls,
    openings,
    cabinets,
    pan,
    zoom,
    drawingStart,
    currentCursorMm,
    selectedWallId,
    selectedOpeningId,
    showCabinets,
    showDimensions,
    wallThickness,
    worldToScreen,
  ]);

  // Canvas Mouse Event Handlers
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    // Pan with middle click or if Pan tool active
    if (e.button === 1 || activeTool === 'pan' || e.altKey) {
      setIsPanning(true);
      setPanStart({ x: mouseX - pan.x, y: mouseY - pan.y });
      return;
    }

    const world = screenToWorld(mouseX, mouseY, canvas);
    const snapped = snapCoordinate(world.x, world.z, drawingStart);

    if (activeTool === 'draw_wall') {
      if (!drawingStart) {
        // Start first point of wall
        pushHistory();
        setDrawingStart(snapped);
      } else {
        // End point of wall
        const dx = snapped.x - drawingStart.x;
        const dz = snapped.z - drawingStart.z;
        const len = Math.sqrt(dx * dx + dz * dz);

        if (len >= 150) {
          const rad = Math.atan2(dz, dx);
          const deg = (rad * 180) / Math.PI;

          const newWall: CustomWall = {
            id: `wall_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
            startX: drawingStart.x,
            startZ: drawingStart.z,
            length: Math.round(len),
            rotationY: Math.round(deg),
            thickness: wallThickness,
            height: roomHeight,
            color: '#cbd5e1',
            isPartition: true,
          };

          setCustomWalls((prev) => [...prev, newWall]);
          setSelectedWallId(newWall.id);
        }
        setDrawingStart(null);
      }
    } else if (activeTool === 'add_door' || activeTool === 'add_window') {
      // Find nearest outer wall to drop opening
      const halfW = roomWidth / 2;
      const halfL = roomLength / 2;
      const distN = Math.abs(world.z - -halfL);
      const distE = Math.abs(world.x - halfW);
      const distS = Math.abs(world.z - halfL);
      const distW = Math.abs(world.x - -halfW);

      const minDist = Math.min(distN, distE, distS, distW);
      let wallIndex = 0;
      let distFromStart = 500;

      if (minDist === distN) {
        wallIndex = 0;
        distFromStart = Math.max(100, Math.min(roomWidth - 900, world.x + halfW - 450));
      } else if (minDist === distE) {
        wallIndex = 1;
        distFromStart = Math.max(100, Math.min(roomLength - 900, world.z + halfL - 450));
      } else if (minDist === distS) {
        wallIndex = 2;
        distFromStart = Math.max(100, Math.min(roomWidth - 900, world.x + halfW - 450));
      } else {
        wallIndex = 3;
        distFromStart = Math.max(100, Math.min(roomLength - 900, world.z + halfL - 450));
      }

      pushHistory();
      const isWindow = activeTool === 'add_window';
      const newOp: WallOpening = {
        id: `${isWindow ? 'win' : 'door'}_${Date.now()}`,
        type: isWindow ? 'window' : 'door',
        wallIndex,
        distanceFromStart: Math.round(distFromStart),
        width: isWindow ? 1200 : 900,
        height: isWindow ? 1200 : 2100,
        sillHeight: isWindow ? 900 : 0,
        windowStyle: 'panoramic',
      };

      setOpenings((prev) => [...prev, newOp]);
      setSelectedOpeningId(newOp.id);
      setActiveTool('select');
    } else if (activeTool === 'select') {
      // Hit testing for custom walls
      let clickedWallId: string | null = null;
      customWalls.forEach((cw) => {
        const rad = ((cw.rotationY || 0) * Math.PI) / 180;
        const eX = cw.startX + cw.length * Math.cos(rad);
        const eZ = cw.startZ + cw.length * Math.sin(rad);

        // Distance from point to line segment
        const A = world.x - cw.startX;
        const B = world.z - cw.startZ;
        const C = eX - cw.startX;
        const D = eZ - cw.startZ;
        const dot = A * C + B * D;
        const lenSq = C * C + D * D;
        let param = -1;
        if (lenSq !== 0) param = dot / lenSq;

        let xx: number, zz: number;
        if (param < 0) {
          xx = cw.startX;
          zz = cw.startZ;
        } else if (param > 1) {
          xx = eX;
          zz = eZ;
        } else {
          xx = cw.startX + param * C;
          zz = cw.startZ + param * D;
        }

        const dist = Math.sqrt((world.x - xx) ** 2 + (world.z - zz) ** 2);
        if (dist < 180) {
          clickedWallId = cw.id;
        }
      });

      setSelectedWallId(clickedWallId);
      if (clickedWallId) setSelectedOpeningId(null);
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    if (isPanning) {
      setPan({
        x: mouseX - panStart.x,
        y: mouseY - panStart.y,
      });
      return;
    }

    const world = screenToWorld(mouseX, mouseY, canvas);
    const snapped = snapCoordinate(world.x, world.z, drawingStart);
    setCurrentCursorMm(snapped);
  };

  const handleMouseUp = () => {
    setIsPanning(false);
  };

  // Wheel Zoom
  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 1.15 : 0.85;
    setZoom((prev) => Math.max(0.02, Math.min(prev * zoomFactor, 0.6)));
  };

  // Delete selected element
  const handleDeleteSelected = () => {
    if (selectedWallId) {
      pushHistory();
      setCustomWalls((prev) => prev.filter((w) => w.id !== selectedWallId));
      setSelectedWallId(null);
    } else if (selectedOpeningId) {
      pushHistory();
      setOpenings((prev) => prev.filter((o) => o.id !== selectedOpeningId));
      setSelectedOpeningId(null);
    }
  };

  // Apply and save changes to 3D room
  const handleSaveAndApply = () => {
    onSaveRoom({
      ...room,
      width: roomWidth,
      length: roomLength,
      height: roomHeight,
      customWalls,
      openings,
    });
    onClose();
  };

  if (!isOpen) return null;

  const selectedWall = customWalls.find((w) => w.id === selectedWallId);
  const selectedOpening = openings.find((o) => o.id === selectedOpeningId);

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4">
      <div className="relative w-full h-full max-w-7xl max-h-[92vh] bg-[#0b1120] border border-[#1e293b] rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* 1. Header Bar */}
        <header className="h-14 px-4 bg-[#111c30] border-b border-[#1e293b] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <span className="w-8 h-8 rounded-lg bg-blue-600/20 text-blue-400 flex items-center justify-center font-bold">
              📐
            </span>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                مخطط الغرفة ورسم الجدران ثنائي الأبعاد (2D Floor Plan)
              </h2>
              <p className="text-[11px] text-gray-400">
                الأبعاد الحالية:{' '}
                <span className="text-blue-400 font-bold">{roomWidth} مم</span> ×{' '}
                <span className="text-blue-400 font-bold">{roomLength} مم</span> | الارتفاع:{' '}
                <span className="text-amber-400 font-bold">{roomHeight} مم</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* زر إخفاء / إظهار أدوات المخطط */}
            <button
              onClick={() => setIsToolsVisible((prev) => !prev)}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 border ${
                !isToolsVisible
                  ? 'bg-amber-600/20 text-amber-300 border-amber-500/40 hover:bg-amber-600/30'
                  : 'bg-[#1e293b] hover:bg-[#334155] text-gray-300 border-[#334155]'
              }`}
              title={isToolsVisible ? 'إخفاء شريط أدوات المخطط لتوسيع مساحة الرسم' : 'إظهار شريط أدوات المخطط'}
            >
              {isToolsVisible ? (
                <>
                  <EyeOff className="w-3.5 h-3.5 text-gray-400" />
                  <span>إخفاء الأدوات</span>
                </>
              ) : (
                <>
                  <Eye className="w-3.5 h-3.5 text-amber-400" />
                  <span>إظهار الأدوات</span>
                </>
              )}
            </button>

            <button
              onClick={handleUndo}
              disabled={history.length === 0}
              className="px-2.5 py-1.5 bg-[#1e293b] hover:bg-[#334155] disabled:opacity-30 text-gray-300 rounded-lg text-xs font-bold transition flex items-center gap-1.5"
              title="تراجع عن آخر خطوة (Ctrl+Z)"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>تراجع</span>
            </button>

            <button
              onClick={handleFitView}
              className="px-2.5 py-1.5 bg-[#1e293b] hover:bg-[#334155] text-gray-300 rounded-lg text-xs font-bold transition flex items-center gap-1.5"
              title="ملاءمة الشاشة"
            >
              <Maximize2 className="w-3.5 h-3.5" />
              <span>ملاءمة</span>
            </button>

            <button
              onClick={handleSaveAndApply}
              className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow-lg shadow-emerald-950/40"
            >
              <Check className="w-4 h-4" />
              <span>حفظ وتطبيق في 3D</span>
            </button>

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg text-gray-400 hover:text-white hover:bg-[#1e293b] flex items-center justify-center transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* 2. Main Workspace Layout */}
        <div className="relative flex-1 flex overflow-hidden">
          {/* A. Left Tools Palette */}
          {isToolsVisible && (
            <aside className="w-56 bg-[#0f172a] border-l border-[#1e293b] p-3 flex flex-col gap-4 shrink-0 overflow-y-auto animate-in fade-in slide-in-from-right-2 duration-150">
              {/* Tools Selector */}
            <div>
              <label className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block mb-2">
                أدوات المخطط
              </label>
              <div className="grid grid-cols-1 gap-1.5">
                <button
                  onClick={() => {
                    setActiveTool('draw_wall');
                    setDrawingStart(null);
                  }}
                  className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-2.5 transition text-right ${
                    activeTool === 'draw_wall'
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-900/30'
                      : 'bg-[#1e293b]/70 hover:bg-[#1e293b] text-gray-300'
                  }`}
                >
                  <PenTool className="w-4 h-4 text-blue-300 shrink-0" />
                  <div className="text-right">
                    <div>رسم جدار / قاطع</div>
                    <div className="text-[10px] text-blue-200 font-normal">انقر نقطة البداية ثم النهاية</div>
                  </div>
                </button>

                <button
                  onClick={() => {
                    setActiveTool('select');
                    setDrawingStart(null);
                  }}
                  className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-2.5 transition text-right ${
                    activeTool === 'select'
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-900/30'
                      : 'bg-[#1e293b]/70 hover:bg-[#1e293b] text-gray-300'
                  }`}
                >
                  <MousePointer className="w-4 h-4 text-amber-400 shrink-0" />
                  <div>
                    <div>تحديد وتعديل</div>
                    <div className="text-[10px] text-gray-400 font-normal">حدد جداراً لتعديله أو حذفه</div>
                  </div>
                </button>

                <button
                  onClick={() => {
                    setActiveTool('add_door');
                    setDrawingStart(null);
                  }}
                  className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-2.5 transition text-right ${
                    activeTool === 'add_door'
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-900/30'
                      : 'bg-[#1e293b]/70 hover:bg-[#1e293b] text-gray-300'
                  }`}
                >
                  <DoorOpen className="w-4 h-4 text-amber-500 shrink-0" />
                  <div>
                    <div>إضافة باب على جدار</div>
                    <div className="text-[10px] text-gray-400 font-normal">انقر على أي جدار لإسقاط الباب</div>
                  </div>
                </button>

                <button
                  onClick={() => {
                    setActiveTool('add_window');
                    setDrawingStart(null);
                  }}
                  className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-2.5 transition text-right ${
                    activeTool === 'add_window'
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-900/30'
                      : 'bg-[#1e293b]/70 hover:bg-[#1e293b] text-gray-300'
                  }`}
                >
                  <AppWindow className="w-4 h-4 text-cyan-400 shrink-0" />
                  <div>
                    <div>إضافة نافذة على جدار</div>
                    <div className="text-[10px] text-gray-400 font-normal">انقر على أي جدار لإسقاط النافذة</div>
                  </div>
                </button>

                <button
                  onClick={() => {
                    setActiveTool('pan');
                    setDrawingStart(null);
                  }}
                  className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-2.5 transition text-right ${
                    activeTool === 'pan'
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-900/30'
                      : 'bg-[#1e293b]/70 hover:bg-[#1e293b] text-gray-300'
                  }`}
                >
                  <Move className="w-4 h-4 text-gray-400 shrink-0" />
                  <span>تحريك الشاشة (Pan)</span>
                </button>
              </div>
            </div>

            {/* Wall Thickness Selector */}
            <div className="bg-[#131f37] p-2.5 rounded-xl border border-[#1e293b]">
              <label className="text-[11px] font-bold text-gray-300 block mb-1.5">
                سماكة الجدار الجديد
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                {[100, 120, 150, 200].map((th) => (
                  <button
                    key={th}
                    onClick={() => setWallThickness(th)}
                    className={`py-1 rounded text-xs font-bold transition ${
                      wallThickness === th
                        ? 'bg-blue-600 text-white'
                        : 'bg-[#1e293b] text-gray-400 hover:text-white'
                    }`}
                  >
                    {th} مم
                  </button>
                ))}
              </div>
            </div>

            {/* Snapping Settings */}
            <div className="bg-[#131f37] p-2.5 rounded-xl border border-[#1e293b]">
              <label className="text-[11px] font-bold text-gray-300 block mb-1.5">
                دقة المحاذاة (Grid Snap)
              </label>
              <div className="grid grid-cols-3 gap-1">
                {[25, 50, 100].map((s) => (
                  <button
                    key={s}
                    onClick={() => setGridSnapMm(s)}
                    className={`py-1 rounded text-[11px] font-bold transition ${
                      gridSnapMm === s
                        ? 'bg-blue-600 text-white'
                        : 'bg-[#1e293b] text-gray-400 hover:text-white'
                    }`}
                  >
                    {s} مم
                  </button>
                ))}
              </div>
            </div>

            {/* View Layers Toggles */}
            <div className="bg-[#131f37] p-2.5 rounded-xl border border-[#1e293b] space-y-2 text-xs">
              <label className="text-[11px] font-bold text-gray-300 block">طبقات العرض</label>
              <label className="flex items-center gap-2 text-gray-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={showCabinets}
                  onChange={(e) => setShowCabinets(e.target.checked)}
                  className="rounded text-blue-600"
                />
                <span>عرض وحدات وخزائن المطبخ ({cabinets.length})</span>
              </label>
              <label className="flex items-center gap-2 text-gray-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={showDimensions}
                  onChange={(e) => setShowDimensions(e.target.checked)}
                  className="rounded text-blue-600"
                />
                <span>عرض مقاسات الأبعاد (mm)</span>
              </label>
            </div>

            {/* Selected Element Inspector */}
            {(selectedWall || selectedOpening) && (
              <div className="bg-[#162544] p-3 rounded-xl border border-blue-500/40 text-xs space-y-2 mt-auto">
                <div className="flex items-center justify-between text-blue-300 font-bold border-b border-blue-500/20 pb-1">
                  <span>{selectedWall ? 'تعديل الجدار المحدد' : 'تعديل الفتحة المحددة'}</span>
                  <button
                    onClick={handleDeleteSelected}
                    className="p-1 text-red-400 hover:bg-red-500/20 rounded transition"
                    title="حذف العنصر المحدد"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                {selectedWall && (
                  <div className="space-y-1.5 text-gray-300">
                    <div className="flex justify-between">
                      <span className="text-gray-400">الطول:</span>
                      <span className="font-bold text-white">{selectedWall.length} مم</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">السماكة:</span>
                      <span className="font-bold text-white">{selectedWall.thickness || 120} مم</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">الزاوية:</span>
                      <span className="font-bold text-white">{selectedWall.rotationY}°</span>
                    </div>
                  </div>
                )}

                {selectedOpening && (
                  <div className="space-y-1.5 text-gray-300">
                    <div className="flex justify-between">
                      <span className="text-gray-400">النوع:</span>
                      <span className="font-bold text-white">
                        {selectedOpening.type === 'window' ? 'نافذة' : 'باب'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">العرض:</span>
                      <span className="font-bold text-white">{selectedOpening.width} مم</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">الجدار:</span>
                      <span className="font-bold text-white">
                        {selectedOpening.wallIndex === 0
                          ? 'شمالي (خلفي)'
                          : selectedOpening.wallIndex === 1
                          ? 'شرقي (يمين)'
                          : selectedOpening.wallIndex === 2
                          ? 'جنوبي (أمامي)'
                          : 'غربي (يسار)'}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            )}
          </aside>
          )}

          {/* B. Central Interactive Drawing Canvas */}
          <main className="relative flex-1 h-full bg-[#0b1120] overflow-hidden">
            {/* Floating button when tools are hidden */}
            {!isToolsVisible && (
              <button
                onClick={() => setIsToolsVisible(true)}
                className="absolute top-4 right-4 z-20 px-3.5 py-2 rounded-xl bg-[#0f172a]/95 backdrop-blur-md border border-cyan-500/60 text-cyan-300 hover:bg-[#1e293b] hover:text-white text-xs font-bold flex items-center gap-2 shadow-2xl transition animate-in fade-in"
                title="إظهار أدوات المخطط"
              >
                <PenTool className="w-4 h-4 text-cyan-400" />
                <span>إظهار أدوات المخطط</span>
              </button>
            )}

            <canvas
              ref={canvasRef}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onWheel={handleWheel}
              className={`w-full h-full ${
                activeTool === 'pan' || isPanning
                  ? 'cursor-grab active:cursor-grabbing'
                  : activeTool === 'draw_wall'
                  ? 'cursor-crosshair'
                  : 'cursor-default'
              }`}
            />

            {/* Bottom HUD Bar */}
            <div className="absolute bottom-3 left-3 z-20 flex items-center gap-2 bg-[#111c30]/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-[#1e293b] text-xs text-gray-300 shadow-xl">
              <span>
                إحداثيات المؤشر:{' '}
                <span className="font-mono text-cyan-400 font-bold">
                  X: {Math.round(currentCursorMm.x)} mm, Z: {Math.round(currentCursorMm.z)} mm
                </span>
              </span>
              <span className="text-gray-600">|</span>
              <span>
                التكبير: <span className="font-mono text-amber-400 font-bold">{Math.round(zoom * 1000)}%</span>
              </span>
            </div>

            {/* Floating Quick Action Tutorial Banner */}
            <div className="absolute top-3 left-1/2 -translate-x-1/2 z-20 bg-[#1e293b]/95 border border-[#334155] px-3.5 py-1.5 rounded-full text-xs text-gray-200 shadow-lg flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
              {activeTool === 'draw_wall' && (
                <span>
                  {drawingStart
                    ? '🎯 انقر الآن لتحديد نقطة نهاية الجدار'
                    : '✏️ انقر في أي مكان لبدء رسم جدار أو قاطع داخلي'}
                </span>
              )}
              {activeTool === 'select' && <span>📐 انقر على أي جدار أو باب لتحديده وتعديل أبعاده أو حذفه</span>}
              {activeTool === 'add_door' && <span>🚪 انقر على أي جدار خارجي لإسقاط الباب مباشرة</span>}
              {activeTool === 'add_window' && <span>🪟 انقر على أي جدار خارجي لإسقاط النافذة مباشرة</span>}
              {activeTool === 'pan' && <span>🖐️ اسحب بالماوس لتحريك الشاشة، وعجلة الماوس للتكبير والتصغير</span>}
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};
