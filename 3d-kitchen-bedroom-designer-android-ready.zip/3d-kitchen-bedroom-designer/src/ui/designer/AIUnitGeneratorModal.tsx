import React, { useState } from 'react';
import {
  Sparkles,
  Bot,
  Zap,
  Box,
  Layers,
  Check,
  X,
  Loader2,
  Cpu,
  Flame,
  Refrigerator,
  Microwave,
  Utensils,
  Maximize2,
  RefreshCw,
  PlusCircle,
  HelpCircle,
} from 'lucide-react';
import { CatalogItemTemplate, CabinetCategory } from '../../types';
import { UnitShapePreview } from './UnitShapePreview';

interface AIUnitGeneratorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddGeneratedUnit: (template: CatalogItemTemplate) => void;
}

export const AIUnitGeneratorModal: React.FC<AIUnitGeneratorModalProps> = ({
  isOpen,
  onClose,
  onAddGeneratedUnit,
}) => {
  const [prompt, setPrompt] = useState<string>('');
  const [category, setCategory] = useState<CabinetCategory>('base');
  const [applianceType, setApplianceType] = useState<string>('none');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [generatedTemplate, setGeneratedTemplate] = useState<CatalogItemTemplate | null>(null);
  const [generationSource, setGenerationSource] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  // Preset inspiration prompts
  const presets = [
    {
      label: 'طباخ حثي سيراميك مع أدراج عميقة',
      prompt: 'طباخ سيراميك كهربائي حثي 90 سم مدمج فوق 3 أدراج عميقة مع مقسمات أواني',
      category: 'base' as CabinetCategory,
      appliance: 'cooktop_induction',
      icon: <Flame className="w-3.5 h-3.5 text-red-400" />,
    },
    {
      label: 'برج ثلاجة فرنسية ذكية بابين',
      prompt: 'ثلاجة فرنسية ذكية بابين مع موزع ثلج ومياه وشاشة ذكية وخزانة علوية',
      category: 'tall' as CabinetCategory,
      appliance: 'refrigerator_french',
      icon: <Refrigerator className="w-3.5 h-3.5 text-blue-400" />,
    },
    {
      label: 'برج أفران مزدوجة ومايكروويف بلت إن',
      prompt: 'برج طولي لأفران مدمجة بلت-إن وفرن مايكروويف مع أدراج تخزين سفلية',
      category: 'tall' as CabinetCategory,
      appliance: 'oven',
      icon: <Microwave className="w-3.5 h-3.5 text-amber-400" />,
    },
    {
      label: 'وحدة حوض مزدوج جرانيت مع خلاط ذهبي',
      prompt: 'حوض مطبخ جرانيت أسود حوضين مع خلاط مياه نحاسي ذهبي فاخر ومساحة للمنظفات',
      category: 'base' as CabinetCategory,
      appliance: 'sink_double',
      icon: <Utensils className="w-3.5 h-3.5 text-emerald-400" />,
    },
    {
      label: 'شفاط بوكس جزيرة زجاجي T-Shape',
      prompt: 'شفاط هواء جزيرة زجاجي بوكس T-Shape عصري 90 سم مع إضاءة ليد وإنارة خافتة',
      category: 'wall' as CabinetCategory,
      appliance: 'hood_box',
      icon: <Zap className="w-3.5 h-3.5 text-purple-400" />,
    },
    {
      label: 'سلة بهارات وزيوت هيدروليك 20 سم',
      prompt: 'سلة سحب سلكية نحيفة للبهارات وزجاجات الزيت دورين مع قضبان كروم مانعة للسقوط',
      category: 'base' as CabinetCategory,
      appliance: 'none',
      icon: <Box className="w-3.5 h-3.5 text-amber-300" />,
    },
  ];

  const handleGenerate = async (customPrompt?: string) => {
    const textToUse = customPrompt || prompt;
    if (!textToUse.trim()) {
      setErrorMessage('يرجى كتابة وصف أو اختيار أحد النماذج السريعة');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      const res = await fetch(`${(import.meta as any).env?.VITE_API_BASE_URL || ''}/api/ai/generate-unit`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: textToUse,
          category,
          applianceType,
        }),
      });

      if (!res.ok) {
        throw new Error('حدث خطأ أثناء التواصل مع خادم الذكاء الاصطناعي');
      }

      const data = await res.json();
      if (data.success && data.template) {
        setGeneratedTemplate(data.template);
        let sourceName = 'المحرك البارامتري الذكي';
        if (data.source === 'gemini') {
          if (data.modelUsed?.includes('3.8-flash')) {
            sourceName = 'Gemini 3.8 Flash';
          } else if (data.modelUsed?.includes('3.1-flash-lite')) {
            sourceName = 'Gemini 3.1 Flash Lite';
          } else if (data.modelUsed?.includes('flash-latest')) {
            sourceName = 'Gemini Flash';
          } else {
            sourceName = 'Google Gemini AI';
          }
        }
        setGenerationSource(sourceName);
      } else {
        throw new Error(data.error || 'لم يتم إنشاء الوحدة بنجاح');
      }
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || 'فشل التوليد، يرجى المحاولة مجدداً');
    } finally {
      setIsLoading(false);
    }
  };

  const handleConfirmAdd = () => {
    if (!generatedTemplate) return;
    onAddGeneratedUnit(generatedTemplate);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-in fade-in duration-200 font-['Cairo',sans-serif]"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-2xl bg-[#18181B] border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
        dir="rtl"
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-blue-950/40 via-purple-950/30 to-zinc-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-blue-500/20">
              <Sparkles className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <span>توليد وحدات وأجهزة مطبخ بالذكاء الاصطناعي</span>
                <span className="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 text-[10px] font-bold border border-blue-400/30">
                  AI Studio Engine
                </span>
              </h3>
              <p className="text-xs text-zinc-400 mt-0.5">
                اكتب أي مواصفات لخزانة أو جهاز كهربائي وسيقوم الذكاء الاصطناعي ببرمجتها وإضافتها لمكتبة التصميم فوراً
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white flex items-center justify-center transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-5 flex-1 text-sm">
          {/* Preset Prompts Pill Selector */}
          <div>
            <label className="text-xs font-bold text-zinc-300 mb-2 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              نماذج وأجهزة جاهزة للتوليد الفوري بنقرة واحدة:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {presets.map((preset, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setPrompt(preset.prompt);
                    setCategory(preset.category);
                    setApplianceType(preset.appliance);
                    handleGenerate(preset.prompt);
                  }}
                  className="p-2.5 rounded-xl bg-zinc-900/80 hover:bg-zinc-800 border border-white/5 hover:border-blue-500/50 text-right transition flex items-center gap-2 group"
                >
                  <div className="w-7 h-7 rounded-lg bg-zinc-800 group-hover:bg-blue-600/20 flex items-center justify-center shrink-0">
                    {preset.icon}
                  </div>
                  <span className="text-xs font-semibold text-zinc-300 group-hover:text-white line-clamp-1">
                    {preset.label}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Custom Description Input */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-zinc-300 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Bot className="w-3.5 h-3.5 text-blue-400" />
                أو اكتب مواصفات وحدتك المخصصة بحرية:
              </span>
              <span className="text-[11px] text-zinc-500 font-normal">عربي أو إنجليزي</span>
            </label>
            <div className="relative">
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="مثال: وحدة جزيرة مطبخ 120 سم مع طباخ حثي مدمج 4 عيون، وشلال رخامي، و3 أدراج سفلية خشب جوز..."
                rows={3}
                className="w-full bg-zinc-900 border border-white/10 rounded-xl p-3 text-white text-xs placeholder:text-zinc-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Category & Appliance Controls */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-zinc-900/60 p-3.5 rounded-xl border border-white/5">
            <div>
              <span className="text-xs text-zinc-400 block mb-1.5 font-medium">تصنيف الوحدة:</span>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as CabinetCategory)}
                className="w-full bg-zinc-800 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
              >
                <option value="base">وحدة سفلية أرضية (Base Cabinet)</option>
                <option value="wall">وحدة جدارية علوية (Wall Cabinet)</option>
                <option value="tall">دولاب / برج أجهزة طولي (Tall Tower)</option>
                <option value="special">وحدة أجهزة خاصة (Special Unit)</option>
              </select>
            </div>

            <div>
              <span className="text-xs text-zinc-400 block mb-1.5 font-medium">الجهاز الكهربائي المدمج:</span>
              <select
                value={applianceType}
                onChange={(e) => setApplianceType(e.target.value)}
                className="w-full bg-zinc-800 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
              >
                <option value="none">بدون جهاز مدمج (خزانة عادية)</option>
                <option value="cooktop_gas">طباخ غاز مع شعلات حديد زهر</option>
                <option value="cooktop_induction">طباخ سيراميك كهربائي حثي</option>
                <option value="oven">فرن بلت-إن مدمج كهربائي</option>
                <option value="microwave">مايكروويف مدمج Built-in</option>
                <option value="refrigerator_french">ثلاجة بابين فرنسية مع موزع ماء</option>
                <option value="refrigerator">ثلاجة عمودية استانلس</option>
                <option value="sink">مغسلة استانلس مفردة مع خلاط</option>
                <option value="sink_double">مغسلة حوضين مزدوجة مع خلاط ذهبي</option>
                <option value="hood_pyramid">شفاط هرمي استانلس ستيل</option>
                <option value="hood_box">شفاط بوكس زجاجي T-Shape</option>
                <option value="range_stove">طباخ وفرن قائم كبير Freestanding</option>
              </select>
            </div>
          </div>

          {/* Error Message if any */}
          {errorMessage && (
            <div className="p-3 rounded-xl bg-red-950/40 border border-red-500/30 text-red-300 text-xs flex items-center gap-2">
              <X className="w-4 h-4 shrink-0 text-red-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Generate Button */}
          <button
            type="button"
            disabled={isLoading}
            onClick={() => handleGenerate()}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-bold text-sm shadow-xl shadow-blue-900/30 flex items-center justify-center gap-2 transition active:scale-95 disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>جاري استشارة الذكاء الاصطناعي وهندسة الوحدة ثلاثية الأبعاد...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>توليد الوحدة الآن بالذكاء الاصطناعي</span>
              </>
            )}
          </button>

          {/* Generated Result Preview Card */}
          {generatedTemplate && (
            <div className="p-4 rounded-xl bg-gradient-to-br from-zinc-900 to-blue-950/30 border border-blue-500/40 space-y-3 animate-in fade-in slide-in-from-bottom-2 duration-300">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                  <span className="text-xs font-bold text-emerald-400">تم توليد الوحدة بنجاح!</span>
                </div>
                {generationSource && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/10 text-zinc-300">
                    بواسطة {generationSource}
                  </span>
                )}
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-4 bg-black/40 p-3 rounded-xl border border-white/5">
                <div className="w-24 h-24 rounded-lg bg-zinc-900 border border-white/10 flex items-center justify-center shrink-0 overflow-hidden">
                  <UnitShapePreview template={generatedTemplate} className="w-20 h-20" />
                </div>
                <div className="space-y-1.5 flex-1 text-right">
                  <h4 className="font-bold text-white text-sm text-amber-300">
                    {generatedTemplate.nameAr || generatedTemplate.name}
                  </h4>
                  <p className="text-xs text-zinc-300 line-clamp-2">
                    {generatedTemplate.descriptionAr || generatedTemplate.name}
                  </p>
                  <div className="flex flex-wrap items-center gap-2 text-[11px] text-zinc-400 font-mono pt-1">
                    <span className="bg-zinc-800 px-2 py-0.5 rounded">
                      العرض: {(generatedTemplate.defaultWidth / 10).toFixed(0)} سم
                    </span>
                    <span className="bg-zinc-800 px-2 py-0.5 rounded">
                      الارتفاع: {(generatedTemplate.defaultHeight / 10).toFixed(0)} سم
                    </span>
                    <span className="bg-zinc-800 px-2 py-0.5 rounded">
                      العمق: {(generatedTemplate.defaultDepth / 10).toFixed(0)} سم
                    </span>
                    {generatedTemplate.defaultDoors > 0 && (
                      <span className="bg-blue-950/60 text-blue-300 px-2 py-0.5 rounded">
                        {generatedTemplate.defaultDoors} أبواب
                      </span>
                    )}
                    {generatedTemplate.defaultDrawers > 0 && (
                      <span className="bg-purple-950/60 text-purple-300 px-2 py-0.5 rounded">
                        {generatedTemplate.defaultDrawers} أدراج
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Action Buttons for Generated Unit */}
              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={handleConfirmAdd}
                  className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg flex items-center justify-center gap-2 transition active:scale-95"
                >
                  <Check className="w-4 h-4" />
                  <span>إضافة الوحدة للمكتبة والتصميم فوراً</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleGenerate()}
                  className="px-3 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-bold transition flex items-center gap-1.5"
                  title="إعادة التوليد بتنويع جديد"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>توليد شكل آخر</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
