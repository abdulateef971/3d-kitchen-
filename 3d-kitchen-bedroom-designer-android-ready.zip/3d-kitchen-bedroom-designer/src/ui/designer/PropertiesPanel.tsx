import React, { useState } from 'react';
import { ParametricCabinet, HingeSide } from '../../types';
import {
  X,
  Copy,
  Trash2,
  Sliders,
  RotateCw,
  Layers,
  Sparkles,
  Move,
  AlignLeft,
  AlignRight,
  AlignCenter,
  ShieldAlert,
  Palette,
  Check,
  CheckCheck,
} from 'lucide-react';
import { MATERIALS_CATALOG, HANDLES_CATALOG } from '../../domain/materials/materialsCatalog';

interface PropertiesPanelProps {
  unit: ParametricCabinet | null;
  onUpdate: (updatedUnit: ParametricCabinet) => void;
  onDuplicate: (unit: ParametricCabinet) => void;
  onDelete: (unitId: string) => void;
  onClose: () => void;
  onOpenMaterialsModal: () => void;
  onOpenDoorsModal: () => void;
  onAlign?: (alignmentType: 'left' | 'right' | 'center' | 'snap_wall' | 'snap_floor') => void;
  onApplyMaterialToAll?: (materialId: string, color: string, target: 'front' | 'body' | 'countertop') => void;
  onSnapAndMerge?: (side: 'left' | 'right') => void;
  onUnifyCountertops?: () => void;
  isDocked?: boolean;
}

// Curated realistic swatches with high-fidelity visual styling
const REALISTIC_SWATCHES = [
  // أخشاب طبيعية فاخرة
  {
    id: 'wood_natural_oak',
    nameAr: 'سنديان طبيعي (Oak)',
    category: 'wood',
    color: '#c8a876',
    gradient: 'linear-gradient(135deg, #d4b886 0%, #aa8856 100%)',
    badge: 'خشب طبيعي',
  },
  {
    id: 'wood_walnut',
    nameAr: 'جوز أمريكي (Walnut)',
    category: 'wood',
    color: '#5c4033',
    gradient: 'linear-gradient(135deg, #6c4e40 0%, #462e24 100%)',
    badge: 'خشب فخم',
  },
  {
    id: 'wood_ash_light',
    nameAr: 'دردار فاتح (Ash)',
    category: 'wood',
    color: '#e2d3b8',
    gradient: 'linear-gradient(135deg, #ebe0cc 0%, #cfbd9f 100%)',
    badge: 'خشب مودرن',
  },
  {
    id: 'wood_ebony_dark',
    nameAr: 'أبنوس داكن (Ebony)',
    category: 'wood',
    color: '#2a2421',
    gradient: 'linear-gradient(135deg, #38302c 0%, #1a1614 100%)',
    badge: 'خشب ملكي',
  },
  // معادن وأجهزة فاخرة
  {
    id: 'metal_brushed_steel',
    nameAr: 'ستانلس ستيل طبيعي (Stainless Steel)',
    category: 'metal',
    color: '#e2e8f0',
    gradient: 'linear-gradient(135deg, #f8fafc 0%, #cbd5e1 50%, #94a3b8 100%)',
    badge: 'ستانلس ستيل',
  },
  {
    id: 'metal_matte_black',
    nameAr: 'أسود مطفي معدني (Black Steel)',
    category: 'metal',
    color: '#18181b',
    gradient: 'linear-gradient(135deg, #27272a 0%, #09090b 100%)',
    badge: 'أسود ميتاليك',
  },
  {
    id: 'metal_chrome',
    nameAr: 'كروم فضي عاكس (Chrome)',
    category: 'metal',
    color: '#f1f5f9',
    gradient: 'linear-gradient(135deg, #ffffff 0%, #e2e8f0 50%, #94a3b8 100%)',
    badge: 'كروم لامع',
  },
  // ألوان مطفية وسوفت تتش
  {
    id: 'mdf_matte_white',
    nameAr: 'أبيض مطفي ناصع',
    category: 'matte',
    color: '#f8fafc',
    gradient: 'linear-gradient(135deg, #ffffff 0%, #e2e8f0 100%)',
    badge: 'سوفت تتش',
  },
  {
    id: 'mdf_matte_warm_cashmere',
    nameAr: 'كشمير دافئ فخم',
    category: 'matte',
    color: '#d4c7b8',
    gradient: 'linear-gradient(135deg, #dfd4c7 0%, #beaf9e 100%)',
    badge: 'كشمير ملكي',
  },
  {
    id: 'mdf_matte_anthracite',
    nameAr: 'رمادي أنتراسيت',
    category: 'matte',
    color: '#334155',
    gradient: 'linear-gradient(135deg, #475569 0%, #1e293b 100%)',
    badge: 'أنتراسيت',
  },
  {
    id: 'mdf_matte_sage_green',
    nameAr: 'أخضر ميرمية',
    category: 'matte',
    color: '#65776c',
    gradient: 'linear-gradient(135deg, #75887c 0%, #4f6055 100%)',
    badge: 'إسكندنافي',
  },
  {
    id: 'mdf_matte_navy_blue',
    nameAr: 'كحلي ملكي داكن',
    category: 'matte',
    color: '#1e293b',
    gradient: 'linear-gradient(135deg, #28374d 0%, #0f172a 100%)',
    badge: 'أزرق ملكي',
  },
  {
    id: 'mdf_matte_desert_sand',
    nameAr: 'بيج رملي صحراوي',
    category: 'matte',
    color: '#d6c4a5',
    gradient: 'linear-gradient(135deg, #e0d0b5 0%, #c4b090 100%)',
    badge: 'بيج دافئ',
  },
  // رخام ومرمر فاخر
  {
    id: 'marble_calacatta_gold',
    nameAr: 'كالاكاتا جولد إيطالي',
    category: 'marble',
    color: '#ede8df',
    gradient: 'linear-gradient(135deg, #f5f2ec 0%, #d8cdbe 100%)',
    badge: 'رخام ذهبي',
  },
  {
    id: 'marble_nero_marquina',
    nameAr: 'نيرو ماركينا أسود',
    category: 'marble',
    color: '#1a1a1a',
    gradient: 'linear-gradient(135deg, #2b2b2b 0%, #0f0f0f 100%)',
    badge: 'رخام أسود',
  },
  {
    id: 'marble_carrara_white',
    nameAr: 'كرارا أبيض ناصع',
    category: 'marble',
    color: '#f5f5f5',
    gradient: 'linear-gradient(135deg, #ffffff 0%, #e0e0e0 100%)',
    badge: 'كرارا إيطالي',
  },
  {
    id: 'marble_travertine_navona',
    nameAr: 'ترافنتين كلاسيكي',
    category: 'marble',
    color: '#e0d5be',
    gradient: 'linear-gradient(135deg, #ebe1cc 0%, #c9bda4 100%)',
    badge: 'حجر ترافنتين',
  },
  {
    id: 'marble_emerald_green',
    nameAr: 'رخام زمردي فيردي',
    category: 'marble',
    color: '#1b3b2b',
    gradient: 'linear-gradient(135deg, #244d38 0%, #12281d 100%)',
    badge: 'أخضر فيردي',
  },
  // أكريليك هاي جلوس لامع
  {
    id: 'acrylic_gloss_white',
    nameAr: 'أبيض هاي جلوس لامع',
    category: 'gloss',
    color: '#ffffff',
    gradient: 'linear-gradient(135deg, #ffffff 0%, #dcdcdc 100%)',
    badge: 'هاي جلوس',
  },
  {
    id: 'acrylic_gloss_cappuccino',
    nameAr: 'كابتشينو بيج لامع',
    category: 'gloss',
    color: '#c4b5a0',
    gradient: 'linear-gradient(135deg, #d4c5b2 0%, #ad9c88 100%)',
    badge: 'كابتشينو لامع',
  },
  {
    id: 'acrylic_gloss_black',
    nameAr: 'أسود بيانو فاخر',
    category: 'gloss',
    color: '#0d0d0d',
    gradient: 'linear-gradient(135deg, #222222 0%, #000000 100%)',
    badge: 'بيانو جلوس',
  },
];

export const PropertiesPanel: React.FC<PropertiesPanelProps> = ({
  unit,
  onUpdate,
  onDuplicate,
  onDelete,
  onClose,
  onOpenMaterialsModal,
  onOpenDoorsModal,
  onAlign,
  onApplyMaterialToAll,
  onSnapAndMerge,
  onUnifyCountertops,
  isDocked = false,
}) => {
  const [materialTarget, setMaterialTarget] = useState<'front' | 'body' | 'countertop'>('front');
  const [materialFilterCategory, setMaterialFilterCategory] = useState<'all' | 'wood' | 'matte' | 'marble' | 'gloss' | 'metal'>('all');
  const [showAppliedToast, setShowAppliedToast] = useState<boolean>(false);
  if (!unit) return null;

  const limits = unit.limits || {
    minWidth: 200,
    maxWidth: 2400,
    minHeight: 300,
    maxHeight: 2800,
    minDepth: 200,
    maxDepth: 1000,
  };

  const handleDimensionChange = (field: 'width' | 'height' | 'depth', rawValue: number) => {
    if (isNaN(rawValue)) return;
    let value = rawValue;
    if (field === 'width') {
      value = Math.max(limits.minWidth, Math.min(limits.maxWidth, rawValue));
    } else if (field === 'height') {
      value = Math.max(limits.minHeight, Math.min(limits.maxHeight, rawValue));
    } else if (field === 'depth') {
      value = Math.max(limits.minDepth, Math.min(limits.maxDepth, rawValue));
    }

    const updated = { ...unit, [field]: value };

    // Dynamically adjust child doors width & height safely
    if (updated.doors && updated.doors.length > 0) {
      const count = updated.doors.length;
      const doorW = Math.max(50, updated.width / count - 3);
      const drawerDed = updated.drawers?.length ? updated.height / (updated.drawers.length + 1) : 6;
      const doorH = Math.max(50, updated.height - drawerDed);
      updated.doors = updated.doors.map((d) => ({
        ...d,
        width: doorW,
        height: doorH,
      }));
    }

    // Dynamically adjust child drawers width & depth safely
    if (updated.drawers && updated.drawers.length > 0) {
      const count = updated.drawers.length;
      const drawerW = Math.max(50, updated.width - 6);
      const drawerH = Math.max(50, (updated.height - 36) / count);
      const drawerD = Math.max(50, updated.depth - 50);
      updated.drawers = updated.drawers.map((dr) => ({
        ...dr,
        width: drawerW,
        height: drawerH,
        depth: drawerD,
      }));
    }

    onUpdate(updated);
  };

  const handleDoorCountChange = (count: number) => {
    const updated = { ...unit, doorCount: count };
    if (count === 0) {
      updated.doors = [];
    } else {
      const doors = [];
      const doorW = updated.width / count - 3;
      const doorH = updated.height - 6;
      for (let i = 0; i < count; i++) {
        let hinge: HingeSide = 'left';
        if (count === 2) hinge = i === 0 ? 'left' : 'right';
        doors.push({
          doorId: `door_${Date.now()}_${i}`,
          width: doorW,
          height: doorH,
          thickness: 18,
          hingeSide: hinge,
          openAngle: 0,
          targetAngle: 0,
          openSpeed: 0.5,
          materialId: unit.frontMaterialId,
          color: unit.frontColor,
        });
      }
      updated.doors = doors;
    }
    onUpdate(updated);
  };

  const handleDrawerCountChange = (count: number) => {
    const updated = { ...unit, drawerCount: count };
    if (count === 0) {
      updated.drawers = [];
    } else {
      const drawers = [];
      const drawerW = updated.width - 6;
      const drawerH = (updated.height - 36) / count;
      const drawerD = updated.depth - 50;
      for (let i = 0; i < count; i++) {
        drawers.push({
          drawerId: `drawer_${Date.now()}_${i}`,
          index: i,
          width: drawerW,
          height: drawerH,
          depth: drawerD,
          thickness: 18,
          openAmount: 0,
          targetAmount: 0,
          openSpeed: 0.4,
          materialId: unit.frontMaterialId,
          color: unit.frontColor,
        });
      }
      updated.drawers = drawers;
    }
    onUpdate(updated);
  };

  const handleRotate = (angleDelta: number) => {
    const newRot = (unit.rotationY + angleDelta + 360) % 360;
    onUpdate({ ...unit, rotationY: newRot });
  };

  const isAppliance =
    unit.category === 'kitchen_appliance' ||
    Boolean(unit.accessoryType && unit.accessoryType !== 'none');

  return (
    <div
      onPointerDown={(e) => e.stopPropagation()}
      onClick={(e) => e.stopPropagation()}
      className={
        isDocked
          ? "w-80 md:w-88 bg-[#181818] border-l border-[#333333] flex flex-col h-full z-20 shrink-0 font-['Cairo',sans-serif] shadow-xl"
          : "w-full h-full bg-[#18181B] flex flex-col overflow-hidden text-sm font-['Cairo',sans-serif] select-none"
      }
    >
      {/* Header */}
      <div className="px-4 py-3 border-b border-white/10 flex items-center justify-between bg-[#202024] shrink-0">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className={`w-3 h-3 rounded-full shrink-0 ${isAppliance ? 'bg-amber-400 shadow-amber-500/50' : 'bg-blue-500 shadow-blue-500/50'} shadow-sm`} />
          <div className="min-w-0">
            <h3 className="font-bold text-white text-xs sm:text-sm truncate tracking-wide">{unit.nameAr || unit.name}</h3>
            <span className="text-[10px] text-zinc-400 block font-medium">
              {isAppliance ? '⚡ جهاز مطبخي مدمج (Built-in Appliance)' : '📐 وحدة خزانة بارامترية'}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() => onDuplicate(unit)}
            title="نسخ الوحدة (Duplicate)"
            className="p-1.5 text-zinc-400 hover:text-emerald-400 hover:bg-white/10 rounded-lg transition active:scale-95"
          >
            <Copy className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => onDelete(unit.id)}
            title="حذف الوحدة (Delete)"
            className="p-1.5 text-zinc-400 hover:text-rose-400 hover:bg-white/10 rounded-lg transition active:scale-95"
          >
            <Trash2 className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={onClose}
            title="إغلاق لوحة الخصائص"
            className="px-2.5 py-1 text-xs font-bold text-zinc-200 hover:text-white bg-white/10 hover:bg-white/20 rounded-lg transition flex items-center gap-1 active:scale-95"
          >
            <span>إغلاق</span>
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 overflow-y-auto space-y-4 flex-1">
        {/* Parametric Dimensions (Width, Height, Depth) */}
        <div className="space-y-3 bg-[#121212] p-3.5 rounded-lg border border-[#333333]">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-blue-400 uppercase tracking-wider flex items-center gap-1.5">
              <Sliders className="w-3 h-3 text-blue-400" />
              الأبعاد الهندسية (Parametric)
            </span>
            <span className="text-[10px] text-gray-400 font-mono">تحديث فوري 3D</span>
          </div>

          {/* Width */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-gray-400">العرض (Width):</span>
              <span className="text-blue-400 font-mono font-bold">
                {unit.width} mm <span className="text-gray-500 font-normal">({(unit.width / 10).toFixed(1)} cm)</span>
              </span>
            </div>
            <input
              type="range"
              min={limits.minWidth}
              max={limits.maxWidth}
              step={10}
              value={unit.width}
              onChange={(e) => handleDimensionChange('width', Number(e.target.value))}
              className="w-full h-1.5 bg-[#2A2A2A] rounded-lg appearance-none cursor-pointer accent-blue-600"
            />
            <div className="flex justify-between text-[10px] text-gray-500 font-mono">
              <span>{limits.minWidth}mm</span>
              <span>{limits.maxWidth}mm</span>
            </div>
          </div>

          {/* Height */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-gray-400">الارتفاع (Height):</span>
              <span className="text-blue-400 font-mono font-bold">
                {unit.height} mm <span className="text-gray-500 font-normal">({(unit.height / 10).toFixed(1)} cm)</span>
              </span>
            </div>
            <input
              type="range"
              min={limits.minHeight}
              max={limits.maxHeight}
              step={10}
              value={unit.height}
              onChange={(e) => handleDimensionChange('height', Number(e.target.value))}
              className="w-full h-1.5 bg-[#2A2A2A] rounded-lg appearance-none cursor-pointer accent-blue-600"
            />
            <div className="flex justify-between text-[10px] text-gray-500 font-mono">
              <span>{limits.minHeight}mm</span>
              <span>{limits.maxHeight}mm</span>
            </div>
          </div>

          {/* Depth */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-gray-400">العمق (Depth):</span>
              <span className="text-blue-400 font-mono font-bold">
                {unit.depth} mm <span className="text-gray-500 font-normal">({(unit.depth / 10).toFixed(1)} cm)</span>
              </span>
            </div>
            <input
              type="range"
              min={limits.minDepth}
              max={limits.maxDepth}
              step={10}
              value={unit.depth}
              onChange={(e) => handleDimensionChange('depth', Number(e.target.value))}
              className="w-full h-1.5 bg-[#2A2A2A] rounded-lg appearance-none cursor-pointer accent-blue-600"
            />
            <div className="flex justify-between text-[10px] text-gray-500 font-mono">
              <span>{limits.minDepth}mm</span>
              <span>{limits.maxDepth}mm</span>
            </div>
          </div>
        </div>

        {/* Position & Rotation */}
        <div className="space-y-3 bg-[#121212] p-3.5 rounded-lg border border-[#333333]">
          <span className="text-[11px] font-bold text-blue-400 uppercase tracking-wider flex items-center gap-1.5">
            <Move className="w-3 h-3 text-blue-400" />
            الموقع والتدوير (Transform)
          </span>

          <div className="grid grid-cols-3 gap-2 text-xs">
            <div>
              <span className="text-gray-400 block text-[10px]">المحور X</span>
              <input
                type="number"
                step="50"
                value={Math.round(unit.positionX)}
                onChange={(e) => onUpdate({ ...unit, positionX: Number(e.target.value) })}
                className="w-full bg-[#1E1E1E] border border-[#444444] rounded px-2 py-1 text-white font-mono text-xs focus:border-blue-500 focus:outline-none"
              />
            </div>
            <div>
              <span className="text-gray-400 block text-[10px]">الارتفاع Y</span>
              <input
                type="number"
                step="50"
                value={Math.round(unit.positionY)}
                onChange={(e) => onUpdate({ ...unit, positionY: Number(e.target.value) })}
                className="w-full bg-[#1E1E1E] border border-[#444444] rounded px-2 py-1 text-white font-mono text-xs focus:border-blue-500 focus:outline-none"
              />
            </div>
            <div>
              <span className="text-gray-400 block text-[10px]">العمق Z</span>
              <input
                type="number"
                step="50"
                value={Math.round(unit.positionZ)}
                onChange={(e) => onUpdate({ ...unit, positionZ: Number(e.target.value) })}
                className="w-full bg-[#1E1E1E] border border-[#444444] rounded px-2 py-1 text-white font-mono text-xs focus:border-blue-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Quick Rotation Buttons */}
          <div className="pt-1 flex items-center justify-between">
            <span className="text-xs text-gray-400 font-mono">تدوير: {unit.rotationY}°</span>
            <div className="flex gap-1.5">
              <button
                onClick={() => handleRotate(90)}
                className="px-2.5 py-1 bg-[#252525] hover:bg-[#333333] text-gray-200 rounded text-xs flex items-center gap-1 font-semibold transition border border-[#444444]"
              >
                <RotateCw className="w-3 h-3 text-blue-400" />
                +90°
              </button>
              <button
                onClick={() => handleRotate(-90)}
                className="px-2.5 py-1 bg-[#252525] hover:bg-[#333333] text-gray-200 rounded text-xs flex items-center gap-1 font-semibold transition border border-[#444444]"
              >
                <RotateCw className="w-3 h-3 text-blue-400 -scale-x-100" />
                -90°
              </button>
            </div>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* REALISTIC MATERIALS & COLORS STUDIO (User Request)                        */}
        {/* نظام اختيار وتطبيق خامات وألوان واقعية (خشب، رخام، مطفي، جلوس)               */}
        {/* ========================================================================= */}
        <div className="space-y-3 bg-[#121212] p-3.5 rounded-lg border border-[#333333]">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
              <Palette className="w-3.5 h-3.5 text-amber-400" />
              الخامات والألوان الواقعية (Realistic Finishes)
            </span>
            <button
              onClick={onOpenMaterialsModal}
              className="text-[10px] text-blue-400 hover:text-blue-300 font-semibold flex items-center gap-0.5"
            >
              <span>المكتبة الشاملة &gt;</span>
            </button>
          </div>

          {/* Target Tabs: Fronts/Doors vs Carcase Body vs Countertop Marble */}
          <div className="flex p-0.5 bg-[#1C1C1E] rounded-lg border border-[#2D2D2D] text-xs">
            <button
              onClick={() => setMaterialTarget('front')}
              className={`flex-1 py-1 px-2 rounded-md font-bold text-[11px] transition ${
                materialTarget === 'front'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 shadow-sm'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              الواجهات والأبواب
            </button>
            <button
              onClick={() => setMaterialTarget('body')}
              className={`flex-1 py-1 px-2 rounded-md font-bold text-[11px] transition ${
                materialTarget === 'body'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 shadow-sm'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              هيكل الخزانة
            </button>
            <button
              onClick={() => setMaterialTarget('countertop')}
              className={`flex-1 py-1 px-2 rounded-md font-bold text-[11px] transition ${
                materialTarget === 'countertop'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 shadow-sm'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              سطح الرخام
            </button>
          </div>

          {/* Category Filter Pills (Wood, Matte, Marble, Gloss, Metal) */}
          <div className="flex gap-1 overflow-x-auto pb-1 text-[10px] font-bold no-scrollbar">
            {[
              { id: 'all', label: 'الكل' },
              { id: 'wood', label: 'أخشاب طبيعية 🪵' },
              { id: 'matte', label: 'ألوان مطفية 🎨' },
              { id: 'metal', label: 'معادن وأجهزة ⚡' },
              { id: 'marble', label: 'رخام ومرمر 🏛️' },
              { id: 'gloss', label: 'أكريليك لامع ✨' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setMaterialFilterCategory(cat.id as any)}
                className={`px-2 py-0.5 rounded-full whitespace-nowrap transition ${
                  materialFilterCategory === cat.id
                    ? 'bg-zinc-200 text-zinc-900 font-black'
                    : 'bg-[#1E1E1E] text-gray-400 hover:text-white border border-[#333333]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Realistic Materials Grid */}
          <div className="grid grid-cols-2 gap-1.5 max-h-52 overflow-y-auto pr-0.5">
            {REALISTIC_SWATCHES.filter(
              (s) => materialFilterCategory === 'all' || s.category === materialFilterCategory
            ).map((swatch) => {
              const currentMatId =
                materialTarget === 'front'
                  ? unit.frontMaterialId || unit.materialId
                  : materialTarget === 'body'
                  ? unit.bodyMaterialId
                  : unit.countertop?.materialId;
              const isSelected = currentMatId === swatch.id;

              return (
                <button
                  key={swatch.id}
                  onClick={() => {
                    if (materialTarget === 'front') {
                      const updatedDoors = (unit.doors || []).map((d) => ({
                        ...d,
                        materialId: swatch.id,
                        color: swatch.color,
                      }));
                      const updatedDrawers = (unit.drawers || []).map((d) => ({
                        ...d,
                        materialId: swatch.id,
                        color: swatch.color,
                      }));
                      onUpdate({
                        ...unit,
                        frontMaterialId: swatch.id,
                        frontColor: swatch.color,
                        color: swatch.color,
                        doors: updatedDoors,
                        drawers: updatedDrawers,
                      });
                    } else if (materialTarget === 'body') {
                      onUpdate({
                        ...unit,
                        bodyMaterialId: swatch.id,
                        bodyColor: swatch.color,
                      });
                    } else if (materialTarget === 'countertop') {
                      onUpdate({
                        ...unit,
                        countertop: unit.countertop
                          ? { ...unit.countertop, materialId: swatch.id, color: swatch.color, enabled: true }
                          : {
                              enabled: true,
                              thickness: 30,
                              overhangFront: 20,
                              overhangBack: 0,
                              overhangLeft: 0,
                              overhangRight: 0,
                              materialId: swatch.id,
                              color: swatch.color,
                            },
                      });
                    }
                  }}
                  className={`p-1.5 rounded-lg border text-right flex items-center gap-2 transition group relative ${
                    isSelected
                      ? 'bg-amber-500/10 border-amber-500 ring-1 ring-amber-500/40 text-white'
                      : 'bg-[#18181A] border-[#2C2C2E] hover:border-gray-500 text-gray-300'
                  }`}
                >
                  {/* Swatch Color Orb with Realistic Gradient */}
                  <div
                    className="w-7 h-7 rounded-md shrink-0 shadow-inner border border-white/20 relative overflow-hidden"
                    style={{ background: swatch.gradient }}
                  >
                    {isSelected && (
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                        <Check className="w-3.5 h-3.5 text-white drop-shadow" />
                      </div>
                    )}
                  </div>

                  {/* Swatch Label & Badge */}
                  <div className="flex flex-col min-w-0 flex-1">
                    <span className="text-[11px] font-bold truncate leading-tight">{swatch.nameAr}</span>
                    <span className="text-[9px] text-gray-400 font-mono">{swatch.badge}</span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Custom Color Picker & Apply to All Controls */}
          <div className="pt-2 border-t border-[#252525] flex flex-col gap-2">
            <div className="flex items-center justify-between gap-2 text-xs">
              <span className="text-gray-400 text-[11px]">لون حر مخصص (Custom HEX):</span>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={
                    (materialTarget === 'front'
                      ? unit.frontColor || unit.color || '#f8fafc'
                      : materialTarget === 'body'
                      ? unit.bodyColor || '#ffffff'
                      : unit.countertop?.color || '#ede8df') as string
                  }
                  onChange={(e) => {
                    const hex = e.target.value;
                    if (materialTarget === 'front') {
                      const updatedDoors = (unit.doors || []).map((d) => ({ ...d, color: hex }));
                      const updatedDrawers = (unit.drawers || []).map((d) => ({ ...d, color: hex }));
                      onUpdate({
                        ...unit,
                        frontColor: hex,
                        color: hex,
                        doors: updatedDoors,
                        drawers: updatedDrawers,
                      });
                    } else if (materialTarget === 'body') {
                      onUpdate({ ...unit, bodyColor: hex });
                    } else if (materialTarget === 'countertop') {
                      onUpdate({
                        ...unit,
                        countertop: unit.countertop
                          ? { ...unit.countertop, color: hex, enabled: true }
                          : {
                              enabled: true,
                              thickness: 30,
                              overhangFront: 20,
                              overhangBack: 0,
                              overhangLeft: 0,
                              overhangRight: 0,
                              materialId: 'custom',
                              color: hex,
                            },
                      });
                    }
                  }}
                  className="w-7 h-7 rounded cursor-pointer border border-[#444444] bg-transparent p-0.5"
                />
                <span className="font-mono text-zinc-300 text-[11px]">
                  {materialTarget === 'front'
                    ? unit.frontColor || unit.color || '#f8fafc'
                    : materialTarget === 'body'
                    ? unit.bodyColor || '#ffffff'
                    : unit.countertop?.color || '#ede8df'}
                </span>
              </div>
            </div>

            {/* Apply To All Units In Project Button */}
            {onApplyMaterialToAll && (
              <button
                type="button"
                onClick={() => {
                  let activeMatId = unit.frontMaterialId || 'mdf_matte_white';
                  let activeColor = unit.frontColor || '#f8fafc';
                  if (materialTarget === 'body') {
                    activeMatId = unit.bodyMaterialId || 'mdf_matte_white';
                    activeColor = unit.bodyColor || '#ffffff';
                  } else if (materialTarget === 'countertop') {
                    activeMatId = unit.countertop?.materialId || 'marble_calacatta_gold';
                    activeColor = unit.countertop?.color || '#ede8df';
                  }
                  onApplyMaterialToAll(activeMatId, activeColor, materialTarget);
                  setShowAppliedToast(true);
                  setTimeout(() => setShowAppliedToast(false), 2000);
                }}
                className="w-full py-1.5 px-3 rounded-lg bg-[#1F1F23] hover:bg-[#2A2A30] border border-amber-500/30 text-amber-300 hover:text-amber-200 text-xs font-bold flex items-center justify-center gap-1.5 transition active:scale-98"
              >
                {showAppliedToast ? (
                  <>
                    <CheckCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">تم تطبيق الخامة على جميع قطع المشروع!</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>تطبيق هذه الخامة على جميع وحدات المشروع</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>

        {/* Doors & Drawers Configuration */}
        <div className="space-y-3 bg-[#121212] p-3.5 rounded-lg border border-[#333333]">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-blue-400 uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-3 h-3 text-blue-400" />
              الأبواب والأدراج
            </span>
            <button
              onClick={onOpenDoorsModal}
              className="text-[11px] text-blue-400 hover:text-blue-300 font-semibold"
            >
              التحكم بالفتح &gt;
            </button>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            {/* Doors Count */}
            <div>
              <span className="text-gray-400 block mb-1">عدد الأبواب:</span>
              <div className="flex gap-1">
                {[0, 1, 2, 3, 4].map((num) => (
                  <button
                    key={num}
                    onClick={() => handleDoorCountChange(num)}
                    className={`flex-1 py-1 rounded text-xs font-bold transition ${
                      unit.doorCount === num
                        ? 'bg-blue-600 text-white shadow-sm'
                        : 'bg-[#1E1E1E] text-gray-400 hover:bg-[#2A2A2A] border border-[#333333]'
                    }`}
                  >
                    {num}
                  </button>
                ))}
              </div>
            </div>

            {/* Drawers Count */}
            <div>
              <span className="text-gray-400 block mb-1">عدد الأدراج:</span>
              <div className="flex gap-1">
                {[0, 1, 2, 3, 4, 5].map((num) => (
                  <button
                    key={num}
                    onClick={() => handleDrawerCountChange(num)}
                    className={`flex-1 py-1 rounded text-xs font-bold transition ${
                      unit.drawerCount === num
                        ? 'bg-blue-600 text-white shadow-sm'
                        : 'bg-[#1E1E1E] text-gray-400 hover:bg-[#2A2A2A] border border-[#333333]'
                    }`}
                  >
                    {num}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Shelves count */}
          <div className="flex items-center justify-between pt-2 border-t border-[#252525] text-xs">
            <span className="text-gray-400">الأرفف الداخلية:</span>
            <div className="flex items-center gap-2">
              <button
                onClick={() =>
                  onUpdate({
                    ...unit,
                    shelves: { ...unit.shelves, count: Math.max(0, (unit.shelves?.count || 0) - 1) },
                  })
                }
                className="w-6 h-6 rounded bg-[#1E1E1E] hover:bg-[#2A2A2A] text-gray-300 font-bold border border-[#333333]"
              >
                -
              </button>
              <span className="font-mono text-blue-400 font-bold">{unit.shelves?.count || 0}</span>
              <button
                onClick={() =>
                  onUpdate({
                    ...unit,
                    shelves: { ...unit.shelves, count: Math.min(8, (unit.shelves?.count || 0) + 1) },
                  })
                }
                className="w-6 h-6 rounded bg-[#1E1E1E] hover:bg-[#2A2A2A] text-gray-300 font-bold border border-[#333333]"
              >
                +
              </button>
            </div>
          </div>
        </div>

        {/* Door Profile & Glass Options (أشكال وتصاميم الأبواب والزجاج) */}
        {unit.doors && unit.doors.length > 0 && (
          <div className="space-y-3 bg-[#121212] p-3.5 rounded-lg border border-[#333333]">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-blue-400 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3 h-3 text-blue-400" />
                شكل وتصميم الأبواب (Door Profiles)
              </span>
            </div>

            {/* Door Style Options Grid */}
            <div className="grid grid-cols-3 gap-1.5">
              {[
                { id: 'slab', label: 'مسطح Slab' },
                { id: 'shaker', label: 'شاكر Shaker' },
                { id: 'glass_frame', label: 'زجاج Glass' },
                { id: 'fluted', label: 'مضلع Fluted' },
                { id: 'j_pull', label: 'مدمج J-Pull' },
                { id: 'raised_panel', label: 'نافر Raised' },
                { id: 'louver', label: 'شيش Louver' },
              ].map((st) => (
                <button
                  key={st.id}
                  onClick={() => {
                    const updatedDoors = unit.doors.map((d) => ({ ...d, doorStyle: st.id as any }));
                    onUpdate({ ...unit, doorStyle: st.id as any, doors: updatedDoors });
                  }}
                  className={`py-1.5 px-2 rounded text-[11px] font-medium border text-center transition ${
                    (unit.doorStyle || 'slab') === st.id
                      ? 'bg-blue-600 border-blue-500 text-white font-bold shadow'
                      : 'bg-[#1E1E1E] border-[#333333] text-gray-300 hover:bg-[#2A2A2A]'
                  }`}
                >
                  {st.label}
                </button>
              ))}
            </div>

            {/* If Glass Door selected, show Glass Type options */}
            {(unit.doorStyle === 'glass_frame' || unit.doors.some((d) => d.hasGlassPanel)) && (
              <div className="pt-2 border-t border-[#252525] space-y-1.5">
                <span className="text-[11px] text-gray-400 block font-medium">نوع الزجاج (Glass Type):</span>
                <div className="grid grid-cols-2 gap-1.5">
                  {[
                    { id: 'clear', label: 'شفاف كريستال' },
                    { id: 'smoked', label: 'برونزي مدخن' },
                    { id: 'fluted', label: 'مضلع ومموج' },
                    { id: 'frosted', label: 'مثلج مصنفر' },
                  ].map((gt) => (
                    <button
                      key={gt.id}
                      onClick={() => {
                        const updatedDoors = unit.doors.map((d) => ({
                          ...d,
                          glassType: gt.id as any,
                          hasGlassPanel: true,
                        }));
                        onUpdate({ ...unit, doors: updatedDoors });
                      }}
                      className="py-1 px-2 bg-[#1E1E1E] hover:bg-[#2A2A2A] text-gray-300 rounded text-[10px] border border-[#333333] text-center"
                    >
                      {gt.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Countertop & Waterfall Marble (المرمر والشلال الرخامي) */}
        {unit.category !== 'kitchen_wall' &&
         unit.category !== 'kitchen_appliance' &&
         !['refrigerator_french', 'refrigerator_side_by_side', 'refrigerator', 'refrigerator_under', 'hood_pyramid', 'hood_box', 'range_stove', 'bed_headboard'].includes(unit.accessoryType || '') && (
          <div className="space-y-3 bg-[#121212] p-3.5 rounded-lg border border-[#333333]">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-blue-400 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3 h-3 text-blue-400" />
                رخام الكاونتر والشلال (Marble Top)
              </span>
              <input
                type="checkbox"
                checked={Boolean(unit.countertop?.enabled)}
                onChange={(e) =>
                  onUpdate({
                    ...unit,
                    countertop: {
                      ...(unit.countertop || {
                        enabled: true,
                        thickness: 35,
                        overhangFront: 20,
                        overhangBack: 0,
                        overhangLeft: 0,
                        overhangRight: 0,
                        materialId: 'marble_calacatta_gold',
                        color: '#ede8df',
                      }),
                      enabled: e.target.checked,
                    },
                  })
                }
                className="w-4 h-4 accent-blue-600 rounded cursor-pointer"
              />
            </div>

            {unit.countertop?.enabled && (
              <div className="space-y-2.5 text-xs">
                {/* Marble Pattern Selection */}
                <div>
                  <span className="text-gray-400 block mb-1">نوع الرخام / المرمر:</span>
                  <select
                    value={unit.countertop.materialId || 'marble_calacatta_gold'}
                    onChange={(e) =>
                      onUpdate({
                        ...unit,
                        countertop: {
                          ...unit.countertop!,
                          materialId: e.target.value,
                        },
                      })
                    }
                    className="w-full bg-[#1E1E1E] border border-[#444444] rounded px-2 py-1.5 text-white text-xs focus:border-blue-500 focus:outline-none"
                  >
                    <option value="marble_calacatta_gold">رخام كالاكاتا جولد إيطالي عروق ذهبية</option>
                    <option value="marble_nero_marquina">رخام نيرو ماركينا أسود عروق بيضاء</option>
                    <option value="marble_carrara_white">رخام كرارا أبيض ناصع</option>
                    <option value="marble_emerald_green">رخام زمردي أخضر فيردي</option>
                    <option value="marble_travertine_navona">رخام ترافنتين كلاسيكي بيج</option>
                    <option value="granite_absolute_black">جرانيت أسود جرانيتي صلب</option>
                  </select>
                </div>

                {/* Waterfall Edges */}
                <div className="pt-2 border-t border-[#252525]">
                  <span className="text-gray-400 block mb-1.5 font-medium">شلال رخامي جانبي (Waterfall Edges):</span>
                  <div className="grid grid-cols-2 gap-2">
                    <label className="flex items-center gap-2 cursor-pointer bg-[#1E1E1E] p-1.5 rounded border border-[#333]">
                      <input
                        type="checkbox"
                        checked={unit.countertop.waterfallLeft || false}
                        onChange={(e) =>
                          onUpdate({
                            ...unit,
                            countertop: {
                              ...unit.countertop!,
                              waterfallLeft: e.target.checked,
                            },
                          })
                        }
                        className="accent-blue-600 rounded"
                      />
                      <span className="text-[11px] text-gray-300">شلال يسار</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer bg-[#1E1E1E] p-1.5 rounded border border-[#333]">
                      <input
                        type="checkbox"
                        checked={unit.countertop.waterfallRight || false}
                        onChange={(e) =>
                          onUpdate({
                            ...unit,
                            countertop: {
                              ...unit.countertop!,
                              waterfallRight: e.target.checked,
                            },
                          })
                        }
                        className="accent-blue-600 rounded"
                      />
                      <span className="text-[11px] text-gray-300">شلال يمين</span>
                    </label>
                  </div>
                </div>

                {/* Seamless Countertop Merging & Harmonization (دمج بالوحدة المجاورة كسطح متصل) */}
                {onSnapAndMerge && (
                  <div className="pt-3 border-t border-[#252525] space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300 font-bold text-xs flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
                        دمج بالوحدة المجاورة وتوحيد السطح:
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => onSnapAndMerge('right')}
                        className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-indigo-600/90 hover:bg-indigo-600 text-white font-bold text-xs transition active:scale-95 shadow-md"
                        title="دمج بالوحدة المجاورة يميناً وتوحيد السطح الرخامي كسطح واحد متصل"
                      >
                        <span>دمج يمين</span>
                        <span>👉</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => onSnapAndMerge('left')}
                        className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-indigo-600/90 hover:bg-indigo-600 text-white font-bold text-xs transition active:scale-95 shadow-md"
                        title="دمج بالوحدة المجاورة يساراً وتوحيد السطح الرخامي كسطح واحد متصل"
                      >
                        <span>👈</span>
                        <span>دمج يسار</span>
                      </button>
                    </div>
                    {onUnifyCountertops && (
                      <button
                        type="button"
                        onClick={onUnifyCountertops}
                        className="w-full mt-1.5 py-1.5 px-2.5 rounded-lg bg-indigo-950/60 hover:bg-indigo-900/60 text-indigo-300 hover:text-white border border-indigo-500/30 text-[11px] font-bold transition flex items-center justify-center gap-1"
                      >
                        <Sparkles className="w-3 h-3 text-indigo-400" />
                        <span>توحيد أسطح الرخام لكافة خزائن المطبخ المتصلة</span>
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Appliance & Accessory Integration (الأجهزة والمغاسل والشفاطات) */}
        <div className={`space-y-3 p-3.5 rounded-lg border ${isAppliance ? 'bg-[#181920] border-amber-500/40' : 'bg-[#121212] border-[#333333]'}`}>
          <div className="flex items-center justify-between">
            <span className={`text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5 ${isAppliance ? 'text-amber-400' : 'text-blue-400'}`}>
              <Sliders className="w-3.5 h-3.5" />
              الأجهزة المدمجة والإكسسوارات (Appliances & Equipment)
            </span>
            {isAppliance && (
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold">
                جهاز نشط
              </span>
            )}
          </div>

          <select
            value={unit.accessoryType || 'none'}
            onChange={(e) =>
              onUpdate({
                ...unit,
                accessoryType: e.target.value as any,
              })
            }
            className="w-full bg-[#1E1E1E] border border-[#444444] rounded-lg px-2.5 py-2 text-white text-xs focus:border-blue-500 focus:outline-none"
          >
            <option value="none">بدون أجهزة مدمجة (خزانة مطبخ عادية)</option>
            <optgroup label="طباخات وأفران وميكروويف">
              <option value="cooktop_gas">🔥 طباخ غاز مع شعلات حديد زهر وعيون نحاسية</option>
              <option value="cooktop_induction">⚡ طباخ سيراميك كهربائي مع حلقات إضاءة حمراء</option>
              <option value="oven">🥘 فرن بلت-إن مدمج واقعي مع تجويف وشاشة لمس</option>
              <option value="microwave">📻 مايكروويف مدمج Built-in Microwave</option>
              <option value="range_stove">🍳 طباخ وفرن شيف قائم متكامل 90 سم (Range Stove)</option>
            </optgroup>
            <optgroup label="ثلاجات وأجهزة تبريد">
              <option value="refrigerator_french">🧊 ثلاجة فرنسية 4 أبواب مع موزع مياه وثلج 90 سم</option>
              <option value="refrigerator_side_by_side">❄️ ثلاجة أمريكية سايد باي سايد بابين 90 سم</option>
              <option value="refrigerator">🚪 ثلاجة عمودية باب واحد استانلس 60 سم</option>
              <option value="refrigerator_under">🍷 ثلاجة مشروبات مدمجة أسفل الرخام</option>
            </optgroup>
            <optgroup label="مغاسل وغسالات صحون">
              <option value="sink">🚰 مغسلة استانلس مفردة مع خلاط عالي فاخر</option>
              <option value="sink_double">💧 مغسلة حوضين مزدوجة مع خلاط مياه ذهبي</option>
              <option value="dishwasher">🍽️ غسالة صحون مدمجة مع شاشة لمس علوية ومقبض</option>
            </optgroup>
            <optgroup label="شفاطات ومرشحات">
              <option value="hood_pyramid">💨 مرشحة / شفاط هرمي ستانلس مع مدخنة 90 سم</option>
              <option value="hood_box">⬛ شفاط زجاجي بوكس T-Shape مودرن</option>
            </optgroup>
            <optgroup label="سلال وأنظمة تخزين داخلية">
              <option value="wire_basket_spice">🥫 سلة زيوت وبهارات سلكية ستانلس قابلة للسحب</option>
              <option value="wire_basket_dishes">🥣 سلة صحون ومواعين هيدروليكية قابلة للسحب</option>
              <option value="corner_carousel">🔄 صينية ركن دوارة 360 درجة (Lazy Susan)</option>
              <option value="corner_magic">✨ نظام ماجيك كورنر سحب هيدروليكي للمطبخ</option>
            </optgroup>
            <optgroup label="أثاث غرف النوم والدواليب">
              <option value="clothes_rod">👔 علاقة تعليق ملابس للدواليب</option>
              <option value="dressing_mirror">🪞 مرآة تسريحة مضيئة LED دائرية</option>
              <option value="bed_headboard">🛏️ سرير نوم فاخر مع خلفية منجدة</option>
            </optgroup>
          </select>

          {/* Appliance / Sink Custom Color & Finish */}
          {unit.accessoryType && unit.accessoryType !== 'none' && (
            <div className="mt-3 p-2.5 rounded-xl bg-[#141416] border border-amber-500/25 space-y-2">
              <div className="flex items-center justify-between text-[11px] font-bold text-amber-300">
                <span>لون وتشطيب الجهاز / حوض السنك:</span>
                <span className="font-mono text-zinc-400 text-[10px]">{unit.applianceColor || 'افتراضي'}</span>
              </div>
              <div className="flex items-center gap-2">
                {[
                  { label: 'نانو أسود ميتاليك (مثل الصورة)', color: '#1c2024' },
                  { label: 'استيل فضي ناعم', color: '#94a3b8' },
                  { label: 'ذهبي شمبانيا / نحاسي فاخر', color: '#c29b38' },
                  { label: 'أنثراسيت غامق مطفي', color: '#111827' },
                  { label: 'أبيض لؤلؤي', color: '#f8fafc' },
                ].map((item) => (
                  <button
                    key={item.color}
                    type="button"
                    onClick={() =>
                      onUpdate({
                        ...unit,
                        applianceColor: item.color,
                      })
                    }
                    title={item.label}
                    style={{ backgroundColor: item.color }}
                    className={`w-7 h-7 rounded-lg border transition active:scale-95 flex items-center justify-center ${
                      (unit.applianceColor || '#1c2024') === item.color
                        ? 'ring-2 ring-amber-400 border-white scale-105'
                        : 'border-white/20 opacity-80 hover:opacity-100'
                    }`}
                  />
                ))}
                {/* Custom Color Picker */}
                <label className="relative cursor-pointer flex items-center justify-center w-7 h-7 rounded-lg bg-zinc-800 border border-white/20 hover:border-amber-400 text-[9px] text-zinc-300 font-bold overflow-hidden" title="اختيار لون مخصص">
                  <span>🎨</span>
                  <input
                    type="color"
                    value={unit.applianceColor || '#1c2024'}
                    onChange={(e) =>
                      onUpdate({
                        ...unit,
                        applianceColor: e.target.value,
                      })
                    }
                    className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                  />
                </label>
              </div>
            </div>
          )}
        </div>

        {/* Alignment Tools */}
        {onAlign && (
          <div className="space-y-2 bg-[#121212] p-3 rounded-lg border border-[#333333]">
            <span className="text-[10px] font-bold text-gray-400 block uppercase tracking-wider">محاذاة تلقائية (Smart Align)</span>
            <div className="grid grid-cols-3 gap-1.5 text-xs">
              <button
                onClick={() => onAlign('snap_wall')}
                className="py-1 px-2 bg-[#1E1E1E] hover:bg-[#2A2A2A] text-gray-300 rounded text-[11px] font-medium border border-[#333333]"
              >
                لصق بالجدار
              </button>
              <button
                onClick={() => onAlign('snap_floor')}
                className="py-1 px-2 bg-[#1E1E1E] hover:bg-[#2A2A2A] text-gray-300 rounded text-[11px] font-medium border border-[#333333]"
              >
                لصق بالأرض
              </button>
              <button
                onClick={() => onAlign('center')}
                className="py-1 px-2 bg-[#1E1E1E] hover:bg-[#2A2A2A] text-gray-300 rounded text-[11px] font-medium border border-[#333333]"
              >
                توسيط
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
