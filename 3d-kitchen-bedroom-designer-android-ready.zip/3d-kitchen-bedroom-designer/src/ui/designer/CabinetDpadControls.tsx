import React, { useState } from 'react';
import { ParametricCabinet, WallOpening, RoomConfig } from '../../types';
import {
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ArrowUp,
  ArrowDown,
  RotateCw,
  ShieldCheck,
  ShieldAlert,
  Sliders,
  Move,
  X,
  Minimize2,
  Maximize2,
  DoorClosed,
  Square,
  Repeat,
  Plus,
  Minus,
  Layers,
  Sparkles,
} from 'lucide-react';

interface CabinetDpadControlsProps {
  selectedUnit?: ParametricCabinet | null;
  selectedOpening?: WallOpening | null;
  roomConfig?: RoomConfig;
  onMoveAxis?: (axis: 'x' | 'y' | 'z', deltaMm: number) => { collided: boolean; collidedWith?: string };
  onRotateUnit?: (deltaDeg: number) => void;
  onMoveOpening?: (deltaDistanceMm: number, deltaSillMm: number) => void;
  onSwitchOpeningWall?: () => void;
  onResizeOpening?: (deltaWidth: number, deltaHeight: number) => void;
  collisionGuard?: boolean;
  onToggleCollisionGuard?: () => void;
  onDeselect: () => void;
}

export const CabinetDpadControls: React.FC<CabinetDpadControlsProps> = ({
  selectedUnit,
  selectedOpening,
  roomConfig,
  onMoveAxis,
  onRotateUnit,
  onMoveOpening,
  onSwitchOpeningWall,
  onResizeOpening,
  collisionGuard = true,
  onToggleCollisionGuard,
  onDeselect,
}) => {
  const [stepMm, setStepMm] = useState<number>(50);
  const [lastCollisionAlert, setLastCollisionAlert] = useState<string | null>(null);
  const [isDpadVisible, setIsDpadVisible] = useState<boolean>(true);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);

  // If nothing is selected, do not render
  if (!selectedUnit && !selectedOpening) return null;

  const isOpeningMode = !!selectedOpening;

  const handleUnitMove = (axis: 'x' | 'y' | 'z', deltaMm: number) => {
    if (!onMoveAxis) return;
    const res = onMoveAxis(axis, deltaMm);
    if (res.collided) {
      setLastCollisionAlert(res.collidedWith || 'عائق أو جدار');
      setTimeout(() => setLastCollisionAlert(null), 3000);
    } else {
      setLastCollisionAlert(null);
    }
  };

  const handleOpeningMove = (deltaDist: number, deltaSill: number) => {
    if (onMoveOpening) {
      onMoveOpening(deltaDist, deltaSill);
    }
  };

  const getWallName = (wallIdx: number = 0) => {
    switch (wallIdx) {
      case 0:
        return 'الجدار الخلفي (North)';
      case 1:
        return 'الجدار الأيمن (East)';
      case 2:
        return 'الجدار الأمامي (South)';
      case 3:
        return 'الجدار الأيسر (West)';
      default:
        return `جدار ${wallIdx}`;
    }
  };

  return (
    <div
      onPointerDown={(e) => e.stopPropagation()}
      onClick={(e) => e.stopPropagation()}
      className="fixed bottom-20 right-3 sm:right-6 z-40 select-none pointer-events-auto font-['Cairo',sans-serif]"
      dir="rtl"
    >
      {/* 1. Minimized floating button when collapsed */}
      {!isDpadVisible && (
        <button
          onClick={() => setIsDpadVisible(true)}
          className="bg-[#12161E]/95 hover:bg-[#1C2330] text-gray-200 hover:text-white border border-[#2D3848] px-3.5 py-2 rounded-full text-xs font-bold shadow-2xl flex items-center gap-2 transition hover:scale-105"
        >
          {isOpeningMode ? (
            selectedOpening?.type === 'door' ? (
              <DoorClosed className="w-4 h-4 text-amber-400" />
            ) : (
              <Square className="w-4 h-4 text-cyan-400" />
            )
          ) : (
            <Move className="w-4 h-4 text-blue-400" />
          )}
          <span>
            {isOpeningMode
              ? selectedOpening?.type === 'door'
                ? `باب: ${selectedOpening.name || 'محدد'}`
                : `نافذة: ${selectedOpening?.name || 'محددة'}`
              : `خزانة: ${selectedUnit?.name || 'محددة'}`}
          </span>
          <span className="text-[10px] bg-blue-600/30 text-blue-300 px-1.5 py-0.5 rounded-full">
            إظهار D-Pad 🎮
          </span>
        </button>
      )}

      {/* 2. Main D-Pad Card */}
      {isDpadVisible && (
        <div
          className={`bg-[#12161E]/95 backdrop-blur-xl border ${
            lastCollisionAlert
              ? 'border-red-500/80 shadow-red-950/50 shadow-2xl'
              : isOpeningMode
              ? 'border-cyan-500/50 shadow-2xl shadow-cyan-950/30'
              : 'border-[#2F3B4D] shadow-2xl'
          } rounded-2xl p-3 text-white transition-all duration-200 w-80`}
        >
          {/* Top Bar Header */}
          <div className="flex items-center justify-between border-b border-[#252E3E] pb-2 mb-2.5">
            <div className="flex items-center gap-2 overflow-hidden">
              <div
                className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 border ${
                  isOpeningMode
                    ? selectedOpening?.type === 'door'
                      ? 'bg-amber-600/20 text-amber-400 border-amber-500/40'
                      : 'bg-cyan-600/20 text-cyan-400 border-cyan-500/40'
                    : 'bg-blue-600/20 text-blue-400 border-blue-500/40'
                }`}
              >
                {isOpeningMode ? (
                  selectedOpening?.type === 'door' ? (
                    <DoorClosed className="w-4 h-4" />
                  ) : (
                    <Square className="w-4 h-4" />
                  )
                ) : (
                  <Move className="w-4 h-4" />
                )}
              </div>
              <div className="truncate">
                <div className="flex items-center gap-1.5">
                  <h4 className="text-xs font-bold text-gray-100 truncate">
                    {isOpeningMode
                      ? selectedOpening?.type === 'door'
                        ? selectedOpening.name || 'باب الغرفة'
                        : selectedOpening?.name || 'نافذة الجدار'
                      : selectedUnit?.name}
                  </h4>
                  <span
                    className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${
                      isOpeningMode
                        ? 'bg-cyan-950 text-cyan-300 border border-cyan-700/50'
                        : 'bg-blue-950 text-blue-300 border border-blue-700/50'
                    }`}
                  >
                    {isOpeningMode ? 'فتحة جدار' : 'وحدة مطبخ'}
                  </span>
                </div>
                <p className="text-[10px] text-gray-400 font-mono">
                  {isOpeningMode
                    ? `${getWallName(selectedOpening?.wallIndex)} | مسافة: ${Math.round(
                        selectedOpening?.distanceFromStart || 0
                      )}mm`
                    : `X:${Math.round(selectedUnit?.positionX || 0)} Y:${Math.round(
                        selectedUnit?.positionY || 0
                      )} Z:${Math.round(selectedUnit?.positionZ || 0)}`}
                </p>
              </div>
            </div>

            {/* Actions: Settings, Minimize, Deselect */}
            <div className="flex items-center gap-1 shrink-0">
              {/* Settings Toggle Button (⚙️ إعدادات D-Pad قابلة للإخفاء) */}
              <button
                onClick={() => setIsSettingsOpen((prev) => !prev)}
                className={`p-1.5 rounded-lg transition ${
                  isSettingsOpen
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-gray-400 hover:text-white hover:bg-[#202938]'
                }`}
                title="إعدادات خطوة الحركة والأبعاد (قابلة للإخفاء)"
              >
                <Sliders className="w-3.5 h-3.5" />
              </button>

              {/* Minimize D-Pad Button */}
              <button
                onClick={() => setIsDpadVisible(false)}
                className="p-1.5 text-gray-400 hover:text-white rounded-lg hover:bg-[#202938] transition"
                title="إخفاء لوحة الـ D-Pad"
              >
                <Minimize2 className="w-3.5 h-3.5" />
              </button>

              {/* Close / Deselect */}
              <button
                onClick={onDeselect}
                className="p-1.5 text-gray-400 hover:text-red-400 rounded-lg hover:bg-[#202938] transition"
                title="إلغاء التحديد"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Collision Warning Banner */}
          {lastCollisionAlert && (
            <div className="mb-2.5 px-2.5 py-1.5 bg-red-950/80 border border-red-500/60 rounded-xl text-red-300 text-[11px] flex items-center gap-1.5 animate-pulse">
              <ShieldAlert className="w-3.5 h-3.5 text-red-400 shrink-0" />
              <span className="truncate">تنبيه تصادم! منع التداخل مع ({lastCollisionAlert})</span>
            </div>
          )}

          {/* ========================================================================= */}
          {/* 3. D-PAD INTERACTIVE CONTROLS BODY                                        */}
          {/* ========================================================================= */}
          <div className="flex items-center justify-between gap-3">
            {/* 4-Way Directional Pad */}
            <div className="relative w-36 h-36 bg-[#0B0E14] rounded-2xl border border-[#232C3B] p-2 flex items-center justify-center shadow-inner">
              {/* Center decorative hub */}
              <div className="w-8 h-8 rounded-full bg-[#18202D] border border-[#2C384B] flex items-center justify-center text-[9px] text-gray-400 font-bold font-mono">
                {isOpeningMode ? (selectedOpening?.type === 'door' ? 'DOOR' : 'WIN') : 'DPAD'}
              </div>

              {/* UP / Forward (or Window Sill Height UP) */}
              <button
                onClick={() => {
                  if (isOpeningMode) {
                    handleOpeningMove(0, stepMm);
                  } else {
                    handleUnitMove('z', -stepMm);
                  }
                }}
                className="absolute top-1.5 left-1/2 -translate-x-1/2 w-10 h-10 rounded-xl bg-[#161E2B] hover:bg-blue-600 active:bg-blue-700 text-gray-200 hover:text-white border border-[#2B374A] flex flex-col items-center justify-center shadow transition active:scale-95"
                title={isOpeningMode ? 'رفع النافذة للأعلى (+جلسة الشباك)' : 'تحريك للأمام (-Z)'}
              >
                <ChevronUp className="w-5 h-5" />
              </button>

              {/* DOWN / Backward (or Window Sill Height DOWN) */}
              <button
                onClick={() => {
                  if (isOpeningMode) {
                    handleOpeningMove(0, -stepMm);
                  } else {
                    handleUnitMove('z', stepMm);
                  }
                }}
                className="absolute bottom-1.5 left-1/2 -translate-x-1/2 w-10 h-10 rounded-xl bg-[#161E2B] hover:bg-blue-600 active:bg-blue-700 text-gray-200 hover:text-white border border-[#2B374A] flex flex-col items-center justify-center shadow transition active:scale-95"
                title={isOpeningMode ? 'خفض النافذة للأسفل (-جلسة الشباك)' : 'تحريك للخلف (+Z)'}
              >
                <ChevronDown className="w-5 h-5" />
              </button>

              {/* LEFT: Move along wall left (-distance) or Unit (-X) */}
              <button
                onClick={() => {
                  if (isOpeningMode) {
                    handleOpeningMove(-stepMm, 0);
                  } else {
                    handleUnitMove('x', -stepMm);
                  }
                }}
                className="absolute left-1.5 top-1/2 -translate-y-1/2 w-10 h-10 rounded-xl bg-[#161E2B] hover:bg-blue-600 active:bg-blue-700 text-gray-200 hover:text-white border border-[#2B374A] flex flex-col items-center justify-center shadow transition active:scale-95"
                title={isOpeningMode ? 'تحريك يسار على طول الجدار' : 'تحريك يسار (-X)'}
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              {/* RIGHT: Move along wall right (+distance) or Unit (+X) */}
              <button
                onClick={() => {
                  if (isOpeningMode) {
                    handleOpeningMove(stepMm, 0);
                  } else {
                    handleUnitMove('x', stepMm);
                  }
                }}
                className="absolute right-1.5 top-1/2 -translate-y-1/2 w-10 h-10 rounded-xl bg-[#161E2B] hover:bg-blue-600 active:bg-blue-700 text-gray-200 hover:text-white border border-[#2B374A] flex flex-col items-center justify-center shadow transition active:scale-95"
                title={isOpeningMode ? 'تحريك يمين على طول الجدار' : 'تحريك يمين (+X)'}
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>

            {/* Side Action Buttons */}
            <div className="flex flex-col gap-2 flex-1">
              {isOpeningMode ? (
                <>
                  {/* Switch Wall Button (تبديل الجدار) */}
                  <button
                    onClick={onSwitchOpeningWall}
                    className="py-2 px-2.5 rounded-xl bg-[#161E2B] hover:bg-amber-600 active:bg-amber-700 border border-[#2B374A] text-amber-200 hover:text-white flex items-center justify-center gap-1.5 text-xs font-bold shadow transition active:scale-95"
                    title="نقل الفتحة إلى الجدار التالي (North → East → South → West)"
                  >
                    <Repeat className="w-3.5 h-3.5 text-amber-300" />
                    <span>تبديل الجدار</span>
                  </button>

                  {/* Width adjustments */}
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => onResizeOpening && onResizeOpening(100, 0)}
                      className="flex-1 py-1.5 rounded-xl bg-[#161E2B] hover:bg-[#253247] border border-[#2B374A] text-gray-200 hover:text-white flex items-center justify-center gap-1 text-[11px] font-bold transition"
                      title="زيادة العرض +100mm"
                    >
                      <Plus className="w-3 h-3 text-cyan-400" />
                      <span>عرض</span>
                    </button>
                    <button
                      onClick={() => onResizeOpening && onResizeOpening(-100, 0)}
                      className="flex-1 py-1.5 rounded-xl bg-[#161E2B] hover:bg-[#253247] border border-[#2B374A] text-gray-200 hover:text-white flex items-center justify-center gap-1 text-[11px] font-bold transition"
                      title="إنقاص العرض -100mm"
                    >
                      <Minus className="w-3 h-3 text-cyan-400" />
                      <span>عرض</span>
                    </button>
                  </div>

                  {/* Wall Tag */}
                  <div className="bg-[#0B0E14] border border-[#232C3B] p-1.5 rounded-xl text-center">
                    <span className="text-[10px] text-gray-400 block">الجدار الحالي:</span>
                    <span className="text-[11px] font-bold text-cyan-300 block truncate">
                      {getWallName(selectedOpening?.wallIndex)}
                    </span>
                  </div>
                </>
              ) : (
                <>
                  {/* Elevation Y+ */}
                  <button
                    onClick={() => handleUnitMove('y', stepMm)}
                    className="py-1.5 px-2 rounded-xl bg-[#161E2B] hover:bg-emerald-600 active:bg-emerald-700 border border-[#2B374A] text-gray-200 hover:text-white flex items-center justify-center gap-1.5 text-xs font-semibold shadow transition active:scale-95"
                    title="رفع للأعلى (+Y)"
                  >
                    <ArrowUp className="w-3.5 h-3.5 text-emerald-400" />
                    <span>أعلى Y+</span>
                  </button>

                  {/* Elevation Y- */}
                  <button
                    onClick={() => handleUnitMove('y', -stepMm)}
                    className="py-1.5 px-2 rounded-xl bg-[#161E2B] hover:bg-emerald-600 active:bg-emerald-700 border border-[#2B374A] text-gray-200 hover:text-white flex items-center justify-center gap-1.5 text-xs font-semibold shadow transition active:scale-95"
                    title="خفض للأسفل (-Y)"
                  >
                    <ArrowDown className="w-3.5 h-3.5 text-emerald-400" />
                    <span>أسفل Y-</span>
                  </button>

                  {/* Rotate Unit 90° */}
                  <button
                    onClick={() => onRotateUnit && onRotateUnit(90)}
                    className="py-1.5 px-2 rounded-xl bg-[#161E2B] hover:bg-amber-600 active:bg-amber-700 border border-[#2B374A] text-gray-200 hover:text-white flex items-center justify-center gap-1.5 text-xs font-semibold shadow transition active:scale-95"
                    title="تدوير الخزانة 90 درجة"
                  >
                    <RotateCw className="w-3.5 h-3.5 text-amber-400" />
                    <span>تدوير 90°</span>
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. SEPARATE HIDEABLE D-PAD SETTINGS MODAL / PANEL                          */}
      {/* ========================================================================= */}
      {isSettingsOpen && (
        <div
          onPointerDown={(e) => e.stopPropagation()}
          onClick={(e) => e.stopPropagation()}
          className="fixed bottom-24 right-3 sm:right-6 z-50 w-[300px] bg-[#12161E]/95 backdrop-blur-xl border border-[#303C4E] rounded-2xl shadow-2xl p-4 text-white animate-in fade-in slide-in-from-bottom-4 duration-200 font-['Cairo',sans-serif]"
          dir="rtl"
        >
          {/* Modal Header */}
          <div className="flex items-center justify-between border-b border-[#252E3E] pb-2.5 mb-3">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30">
                <Sliders className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold text-gray-100">إعدادات الـ D-Pad المتقدمة</span>
            </div>
            <button
              onClick={() => setIsSettingsOpen(false)}
              className="p-1 text-gray-400 hover:text-white rounded-lg hover:bg-[#1E2736] transition"
              title="إغلاق لوحة الإعدادات"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex flex-col gap-3 text-xs">
            {/* 1. Step Size Selection */}
            <div>
              <span className="text-[11px] font-bold text-gray-300 mb-1.5 block">
                حجم خطوة الحركة بالمليمتر (Step Size):
              </span>
              <div className="grid grid-cols-5 gap-1 bg-[#0B0E14] p-1 rounded-xl border border-[#232C3B]">
                {[10, 50, 100, 200, 500].map((step) => (
                  <button
                    key={step}
                    onClick={() => setStepMm(step)}
                    className={`py-1.5 rounded-lg font-mono font-bold text-[11px] transition ${
                      stepMm === step
                        ? 'bg-blue-600 text-white shadow-sm'
                        : 'text-gray-400 hover:text-white hover:bg-[#1A2230]'
                    }`}
                  >
                    {step}
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Opening Mode Details */}
            {isOpeningMode && selectedOpening && (
              <div className="bg-[#0B0E14] p-2.5 rounded-xl border border-[#232C3B] space-y-2">
                <span className="text-[11px] font-bold text-cyan-300 block">
                  أبعاد وموضع الفتحة ({selectedOpening.type === 'door' ? 'باب' : 'نافذة'}):
                </span>
                <div className="grid grid-cols-2 gap-2 text-[10px]">
                  <div>
                    <span className="text-gray-400 block">العرض:</span>
                    <span className="font-bold text-gray-100 font-mono">{selectedOpening.width} mm</span>
                  </div>
                  <div>
                    <span className="text-gray-400 block">الارتفاع:</span>
                    <span className="font-bold text-gray-100 font-mono">{selectedOpening.height} mm</span>
                  </div>
                  <div>
                    <span className="text-gray-400 block">المسافة من البداية:</span>
                    <span className="font-bold text-gray-100 font-mono">
                      {Math.round(selectedOpening.distanceFromStart)} mm
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-400 block">ارتفاع الجلسة:</span>
                    <span className="font-bold text-gray-100 font-mono">
                      {Math.round(selectedOpening.sillHeight)} mm
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* 3. Cabinet Collision Guard Toggle */}
            {!isOpeningMode && onToggleCollisionGuard && (
              <div>
                <span className="text-[11px] font-bold text-gray-300 mb-1.5 block">
                  حماية التصادم والحركة:
                </span>
                <button
                  onClick={onToggleCollisionGuard}
                  className={`w-full py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-between border transition ${
                    collisionGuard
                      ? 'bg-emerald-600/20 border-emerald-500/40 text-emerald-300 hover:bg-emerald-600/30'
                      : 'bg-red-950/30 border-red-500/40 text-red-300 hover:bg-red-950/50'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    {collisionGuard ? (
                      <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <ShieldAlert className="w-4 h-4 text-red-400" />
                    )}
                    <span>{collisionGuard ? 'مانع التصادم مُفعّل' : 'حركة حرة (بدون قيود)'}</span>
                  </span>
                  <span className="text-[10px] bg-black/40 px-2 py-0.5 rounded font-mono">
                    {collisionGuard ? 'ON' : 'OFF'}
                  </span>
                </button>
              </div>
            )}

            {/* Close button at bottom */}
            <button
              onClick={() => setIsSettingsOpen(false)}
              className="mt-1 w-full py-1.5 rounded-xl bg-[#1E2736] hover:bg-[#28354A] text-gray-300 hover:text-white text-xs font-bold transition"
            >
              تم وإغلاق الإعدادات
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
