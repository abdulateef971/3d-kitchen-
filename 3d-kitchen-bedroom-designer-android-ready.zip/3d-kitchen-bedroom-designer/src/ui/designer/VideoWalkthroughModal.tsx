import React, { useState, useEffect, useRef } from 'react';
import { Project, CameraPreset } from '../../types';
import { SceneManager } from '../../rendering/SceneManager';
import {
  X,
  Play,
  Pause,
  RotateCcw,
  Video,
  Sun,
  Moon,
  Sparkles,
  Camera,
  Eye,
  Download,
  DoorOpen,
  DoorClosed,
  Radio,
  CheckCircle2,
  Sliders,
  Layers,
  Flame,
  Zap,
  Maximize,
  Image as ImageIcon,
  Check,
  RefreshCw,
} from 'lucide-react';

interface VideoWalkthroughModalProps {
  isOpen: boolean;
  onClose: () => void;
  sceneManager: SceneManager | null;
  project: Project;
}

type StudioTab = 'photo' | 'video';

interface ResolutionPreset {
  id: string;
  label: string;
  sublabel: string;
  width: number;
  height: number;
  aspect: string;
}

const RESOLUTION_PRESETS: ResolutionPreset[] = [
  { id: '4k', label: '4K Ultra HD', sublabel: '3840×2160 فائقة الدقة', width: 3840, height: 2160, aspect: '16:9' },
  { id: '2k', label: '2K Quad HD', sublabel: '2560×1440 معمارية نقية', width: 2560, height: 1440, aspect: '16:9' },
  { id: 'fhd', label: 'Full HD 1080p', sublabel: '1920×1080 سريعة وخفيفة', width: 1920, height: 1080, aspect: '16:9' },
  { id: 'square', label: 'مربع إنستغرام (1:1)', sublabel: '2048×2048 لمنصات التواصل', width: 2048, height: 2048, aspect: '1:1' },
  { id: 'portrait', label: 'ستوري تيك توك / ريلز', sublabel: '1080×1920 طولي للهاتف', width: 1080, height: 1920, aspect: '9:16' },
];

export const VideoWalkthroughModal: React.FC<VideoWalkthroughModalProps> = ({
  isOpen,
  onClose,
  sceneManager,
  project,
}) => {
  const [activeTab, setActiveTab] = useState<StudioTab>('photo');

  // Photo Render States
  const [selectedRes, setSelectedRes] = useState<ResolutionPreset>(RESOLUTION_PRESETS[1]); // Default 2K
  const [imageFormat, setImageFormat] = useState<'jpeg' | 'png'>('jpeg');
  const [isRenderingPhoto, setIsRenderingPhoto] = useState<boolean>(false);
  const [snapshotUrl, setSnapshotUrl] = useState<string | null>(null);

  // Video Tour States
  const [isPlaying, setIsPlaying] = useState(false);
  const [videoMode, setVideoMode] = useState<'orbit360' | 'walkthrough' | 'showcase'>('orbit360');
  const [videoDuration, setVideoDuration] = useState<number>(15); // 10, 15, 25 seconds
  const [videoSpeed, setVideoSpeed] = useState<number>(1.0); // 0.5x, 1.0x, 1.5x
  const [mood, setMood] = useState<'day' | 'night' | 'studio' | 'luxury'>('day');

  // Video recording states
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordingSeconds, setRecordingSeconds] = useState<number>(0);
  const [recordedVideoUrl, setRecordedVideoUrl] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const recordingTimerRef = useRef<any>(null);

  // Animation tour loop
  useEffect(() => {
    if (!isOpen || !sceneManager || !isPlaying) return;

    let animId: number;
    let step = 0;

    const tourLoop = () => {
      const speedFactor = 0.006 * videoSpeed;

      if (videoMode === 'orbit360') {
        sceneManager.cameraTheta += speedFactor;
        sceneManager.updateCameraTransform();
      } else if (videoMode === 'walkthrough') {
        step += 0.01 * videoSpeed;
        sceneManager.cameraTheta += speedFactor * 0.7;
        sceneManager.updateCameraTransform();
      } else if (videoMode === 'showcase') {
        step += 0.015 * videoSpeed;
        // Rhythmically open then close cabinet doors, drawers, pullouts
        if (Math.sin(step) > 0.82) {
          sceneManager.openAllDoorsAndDrawers();
        } else if (Math.sin(step) < -0.82) {
          sceneManager.closeAllDoorsAndDrawers();
        }
        sceneManager.cameraTheta += speedFactor * 0.6;
        sceneManager.updateCameraTransform();
      }

      animId = requestAnimationFrame(tourLoop);
    };

    animId = requestAnimationFrame(tourLoop);

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [isOpen, isPlaying, videoMode, videoSpeed, sceneManager]);

  if (!isOpen || !sceneManager) return null;

  const handleTogglePlay = () => {
    if (!isPlaying) {
      if (videoMode === 'walkthrough') {
        sceneManager.setCameraPreset('eye_level');
      } else {
        sceneManager.setCameraPreset('perspective');
      }
    }
    setIsPlaying(!isPlaying);
  };

  const handleApplyMood = (m: 'day' | 'night' | 'studio' | 'luxury') => {
    setMood(m);
    if (m === 'day') {
      sceneManager.applyLightingConfig({
        ambientIntensity: 0.88,
        ambientColor: '#ffffff',
        sunIntensity: 1.4,
        shadowsEnabled: true,
        underCabinetLed: true,
        underCabinetLedColor: '#fef08a',
        ceilingSpotlights: true,
      });
    } else if (m === 'night') {
      sceneManager.applyLightingConfig({
        ambientIntensity: 0.22,
        ambientColor: '#1e1b4b',
        sunIntensity: 0.08,
        shadowsEnabled: true,
        underCabinetLed: true,
        underCabinetLedColor: '#fbbf24',
        ceilingSpotlights: true,
        ceilingSpotlightColor: '#fef08a',
      });
    } else if (m === 'luxury') {
      sceneManager.applyLightingConfig({
        ambientIntensity: 0.65,
        ambientColor: '#fff7ed',
        sunIntensity: 1.15,
        shadowsEnabled: true,
        underCabinetLed: true,
        underCabinetLedColor: '#f59e0b',
        ceilingSpotlights: true,
        ceilingSpotlightColor: '#fde047',
      });
    } else {
      sceneManager.applyLightingConfig({
        ambientIntensity: 0.95,
        ambientColor: '#f8fafc',
        sunIntensity: 0.9,
        shadowsEnabled: true,
        underCabinetLed: false,
        ceilingSpotlights: true,
      });
    }
    sceneManager.requestShadowUpdate();
  };

  // High-Resolution Photo Render
  const handleRenderPhoto = () => {
    setIsRenderingPhoto(true);
    setTimeout(() => {
      try {
        sceneManager.requestShadowUpdate();
        const url = sceneManager.captureHighResSnapshot(
          selectedRes.width,
          selectedRes.height,
          imageFormat,
          0.98
        );
        setSnapshotUrl(url);
      } catch (err) {
        console.error('High-res render failed, falling back to standard', err);
        const fallback = sceneManager.captureSnapshot();
        setSnapshotUrl(fallback);
      } finally {
        setIsRenderingPhoto(false);
      }
    }, 60);
  };

  // Video Recording Flow
  const startVideoRecording = () => {
    if (!sceneManager) return;
    try {
      const canvas = sceneManager.renderer.domElement;
      const stream = canvas.captureStream ? canvas.captureStream(30) : null;
      if (!stream) {
        alert('ميزة تسجيل الفيديو تتطلب متصفحاً حديثاً يدعم CanvasStream.');
        return;
      }

      recordedChunksRef.current = [];
      const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
        ? 'video/webm;codecs=vp9'
        : 'video/webm';

      const recorder = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: 8000000 });
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          recordedChunksRef.current.push(event.data);
        }
      };

      recorder.onstop = () => {
        const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
        const videoUrl = URL.createObjectURL(blob);
        setRecordedVideoUrl(videoUrl);
        setIsRecording(false);
        setIsPlaying(false);
        if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
      };

      recorder.start(200);
      setIsRecording(true);
      setRecordingSeconds(0);
      setRecordedVideoUrl(null);
      setIsPlaying(true);

      recordingTimerRef.current = setInterval(() => {
        setRecordingSeconds((prev) => {
          if (prev >= videoDuration) {
            stopVideoRecording();
            return prev;
          }
          return prev + 1;
        });
      }, 1000);
    } catch (err) {
      console.error('Failed to record video:', err);
      setIsRecording(false);
    }
  };

  const stopVideoRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    if (recordingTimerRef.current) {
      clearInterval(recordingTimerRef.current);
    }
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 font-['Cairo',sans-serif]"
      dir="rtl"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-2xl bg-[#131720] border border-[#2c3647] rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-[#252e3d] flex items-center justify-between bg-gradient-to-r from-[#171d29] to-[#121620]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-purple-600 to-indigo-700 text-white flex items-center justify-center shadow-lg shadow-purple-600/30">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-white tracking-wide flex items-center gap-2">
                <span>استوديو الرندر والفيديو الاحترافي</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30 font-bold">
                  4K Ultra HD
                </span>
              </h2>
              <p className="text-[11px] text-gray-400">
                إنتاج رندر صور فوتوغرافية فائقة الجودة وفيديو سينمائي بدقة عالية
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-white rounded-xl hover:bg-[#202735] transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="px-5 pt-3 pb-1 border-b border-[#202735] flex items-center gap-2 bg-[#0f131a]">
          <button
            onClick={() => setActiveTab('photo')}
            className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
              activeTab === 'photo'
                ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                : 'text-gray-400 hover:text-white hover:bg-[#1a212e]'
            }`}
          >
            <Camera className="w-4 h-4" />
            <span>رندر الصور الفوتوغرافية (Photo 4K)</span>
          </button>

          <button
            onClick={() => setActiveTab('video')}
            className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
              activeTab === 'video'
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                : 'text-gray-400 hover:text-white hover:bg-[#1a212e]'
            }`}
          >
            <Video className="w-4 h-4" />
            <span>إنتاج الفيديو السينمائي (Video Tour)</span>
          </button>
        </div>

        {/* Body Content */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs">
          {/* Lighting Mood Switcher (Shared) */}
          <div className="p-3.5 bg-[#171d27] rounded-2xl border border-[#273243] space-y-2">
            <span className="font-bold text-gray-200 block text-xs flex items-center gap-1.5">
              <Sun className="w-3.5 h-3.5 text-amber-400" />
              <span>أجواء الإضاءة والظلال الواقعية (Lighting Mood)</span>
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => handleApplyMood('day')}
                className={`p-2.5 rounded-xl border font-bold flex items-center justify-center gap-1.5 transition text-[11px] ${
                  mood === 'day'
                    ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-sm'
                    : 'bg-[#0f131a] border-[#252e3c] text-gray-400 hover:bg-[#1c2330]'
                }`}
              >
                <Sun className="w-3.5 h-3.5 text-amber-400" />
                نهاري ساطع
              </button>

              <button
                type="button"
                onClick={() => handleApplyMood('luxury')}
                className={`p-2.5 rounded-xl border font-bold flex items-center justify-center gap-1.5 transition text-[11px] ${
                  mood === 'luxury'
                    ? 'bg-amber-600/20 border-amber-500 text-amber-200 shadow-sm'
                    : 'bg-[#0f131a] border-[#252e3c] text-gray-400 hover:bg-[#1c2330]'
                }`}
              >
                <Flame className="w-3.5 h-3.5 text-orange-400" />
                ذهبي فاخر (Warm)
              </button>

              <button
                type="button"
                onClick={() => handleApplyMood('night')}
                className={`p-2.5 rounded-xl border font-bold flex items-center justify-center gap-1.5 transition text-[11px] ${
                  mood === 'night'
                    ? 'bg-indigo-500/20 border-indigo-400 text-indigo-300 shadow-sm'
                    : 'bg-[#0f131a] border-[#252e3c] text-gray-400 hover:bg-[#1c2330]'
                }`}
              >
                <Moon className="w-3.5 h-3.5 text-indigo-400" />
                ليلي دافئ + LED
              </button>

              <button
                type="button"
                onClick={() => handleApplyMood('studio')}
                className={`p-2.5 rounded-xl border font-bold flex items-center justify-center gap-1.5 transition text-[11px] ${
                  mood === 'studio'
                    ? 'bg-blue-600/20 border-blue-400 text-blue-300 shadow-sm'
                    : 'bg-[#0f131a] border-[#252e3c] text-gray-400 hover:bg-[#1c2330]'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 text-blue-400" />
                استوديو معماري
              </button>
            </div>
          </div>

          {/* TAB 1: PHOTO RENDER */}
          {activeTab === 'photo' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              {/* Resolution Selector */}
              <div className="space-y-2">
                <span className="font-bold text-gray-200 block text-xs">
                  اختر دقة ونقاء الرندر (Resolution Preset):
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {RESOLUTION_PRESETS.map((res) => (
                    <button
                      key={res.id}
                      type="button"
                      onClick={() => setSelectedRes(res)}
                      className={`p-3 rounded-2xl border text-right transition flex items-center justify-between ${
                        selectedRes.id === res.id
                          ? 'bg-purple-600/20 border-purple-500 text-white shadow-md'
                          : 'bg-[#151a24] border-[#273243] text-gray-400 hover:bg-[#1c2330] hover:text-gray-200'
                      }`}
                    >
                      <div>
                        <div className="font-bold text-xs flex items-center gap-1.5">
                          {selectedRes.id === res.id && <Check className="w-3.5 h-3.5 text-purple-400" />}
                          <span>{res.label}</span>
                        </div>
                        <div className="text-[10px] text-gray-400 mt-0.5">{res.sublabel}</div>
                      </div>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-lg bg-[#0e1219] text-purple-300 border border-[#232b3a]">
                        {res.aspect}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Format & Quick Actions */}
              <div className="flex items-center justify-between p-3 bg-[#151a24] rounded-2xl border border-[#273243]">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-gray-300">صيغة الملف:</span>
                  <button
                    onClick={() => setImageFormat('jpeg')}
                    className={`px-3 py-1 rounded-xl font-bold text-xs transition ${
                      imageFormat === 'jpeg' ? 'bg-purple-600 text-white' : 'bg-[#0f131a] text-gray-400'
                    }`}
                  >
                    JPG (عالي الضغط)
                  </button>
                  <button
                    onClick={() => setImageFormat('png')}
                    className={`px-3 py-1 rounded-xl font-bold text-xs transition ${
                      imageFormat === 'png' ? 'bg-purple-600 text-white' : 'bg-[#0f131a] text-gray-400'
                    }`}
                  >
                    PNG (بدون فقدان)
                  </button>
                </div>

                {/* Open/Close Cabinets */}
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => sceneManager.openAllDoorsAndDrawers()}
                    className="p-2 rounded-xl bg-[#0f131a] hover:bg-[#1f2838] text-blue-400 transition"
                    title="فتح الأبواب والمجرات قبل الرندر"
                  >
                    <DoorOpen className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => sceneManager.closeAllDoorsAndDrawers()}
                    className="p-2 rounded-xl bg-[#0f131a] hover:bg-[#1f2838] text-gray-400 transition"
                    title="غلق جميع الأبواب"
                  >
                    <DoorClosed className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Render Button */}
              <button
                type="button"
                onClick={handleRenderPhoto}
                disabled={isRenderingPhoto}
                className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-xl shadow-purple-600/30 transition active:scale-[0.99] disabled:opacity-50"
              >
                {isRenderingPhoto ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>جاري معالجة الرندر فائق الدقة ({selectedRes.width}×{selectedRes.height})...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-amber-300" />
                    <span>التقاط رندر فوتوغرافي فائق الدقة ({selectedRes.label})</span>
                  </>
                )}
              </button>

              {/* Snapshot Result Preview */}
              {snapshotUrl && (
                <div className="p-3.5 bg-[#151a24] rounded-2xl border border-purple-500/40 space-y-2.5 animate-in zoom-in-95 duration-150">
                  <div className="flex items-center justify-between">
                    <span className="text-purple-300 font-bold flex items-center gap-1.5 text-xs">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      تم إنشاء صورة الرندر بنجاح ({selectedRes.width} × {selectedRes.height})
                    </span>
                    <span className="text-[10px] text-gray-400 uppercase font-mono">
                      {imageFormat.toUpperCase()}
                    </span>
                  </div>

                  <div className="relative rounded-xl overflow-hidden border border-[#2b3547] bg-black max-h-64 flex items-center justify-center">
                    <img
                      src={snapshotUrl}
                      alt="3D Architectural Render"
                      className="w-full h-auto max-h-64 object-contain"
                    />
                  </div>

                  <a
                    href={snapshotUrl}
                    download={`Render_${project.name.replace(/\s+/g, '_')}_${selectedRes.id}.${imageFormat}`}
                    className="w-full py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition"
                  >
                    <Download className="w-4 h-4" />
                    <span>تحميل صورة الرندر عالية الدقة (Download {selectedRes.label})</span>
                  </a>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: CINEMATIC VIDEO */}
          {activeTab === 'video' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              {/* Choreography Mode */}
              <div className="space-y-2">
                <span className="font-bold text-gray-200 block text-xs">مسار وحركة الكاميرا في الفيديو:</span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setVideoMode('orbit360');
                      sceneManager.setCameraPreset('perspective');
                    }}
                    className={`p-3 rounded-2xl border text-right font-bold transition flex flex-col gap-1 ${
                      videoMode === 'orbit360'
                        ? 'bg-blue-600/20 border-blue-500 text-blue-300 shadow-md'
                        : 'bg-[#151a24] border-[#273243] text-gray-400 hover:bg-[#1c2330]'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 text-xs">
                      <RotateCcw className="w-3.5 h-3.5 text-blue-400" />
                      <span>دوران مداري 360°</span>
                    </div>
                    <span className="text-[10px] text-gray-400 font-normal">دوران سينمائي سلس شامل</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setVideoMode('walkthrough');
                      sceneManager.setCameraPreset('eye_level');
                    }}
                    className={`p-3 rounded-2xl border text-right font-bold transition flex flex-col gap-1 ${
                      videoMode === 'walkthrough'
                        ? 'bg-blue-600/20 border-blue-500 text-blue-300 shadow-md'
                        : 'bg-[#151a24] border-[#273243] text-gray-400 hover:bg-[#1c2330]'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 text-xs">
                      <Eye className="w-3.5 h-3.5 text-amber-400" />
                      <span>تجول داخلي واقعي</span>
                    </div>
                    <span className="text-[10px] text-gray-400 font-normal">منظور الشخص الأول داخل المطبخ</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setVideoMode('showcase');
                      sceneManager.setCameraPreset('perspective');
                    }}
                    className={`p-3 rounded-2xl border text-right font-bold transition flex flex-col gap-1 ${
                      videoMode === 'showcase'
                        ? 'bg-blue-600/20 border-blue-500 text-blue-300 shadow-md'
                        : 'bg-[#151a24] border-[#273243] text-gray-400 hover:bg-[#1c2330]'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 text-xs">
                      <DoorOpen className="w-3.5 h-3.5 text-emerald-400" />
                      <span>استعراض الوحدات والسلال</span>
                    </div>
                    <span className="text-[10px] text-gray-400 font-normal">فتح وإغلاق الخزائن والمجرات</span>
                  </button>
                </div>
              </div>

              {/* Settings: Duration & Speed */}
              <div className="grid grid-cols-2 gap-3 p-3 bg-[#151a24] rounded-2xl border border-[#273243]">
                {/* Duration */}
                <div className="space-y-1.5">
                  <span className="text-[11px] font-bold text-gray-300 block">مدة الفيديو المسجل:</span>
                  <div className="flex items-center gap-1">
                    {[10, 15, 25].map((sec) => (
                      <button
                        key={sec}
                        onClick={() => setVideoDuration(sec)}
                        className={`flex-1 py-1 rounded-xl font-bold text-xs transition ${
                          videoDuration === sec
                            ? 'bg-blue-600 text-white'
                            : 'bg-[#0e1219] text-gray-400 hover:text-white'
                        }`}
                      >
                        {sec} ثانية
                      </button>
                    ))}
                  </div>
                </div>

                {/* Speed */}
                <div className="space-y-1.5">
                  <span className="text-[11px] font-bold text-gray-300 block">سرعة حركة الكاميرا:</span>
                  <div className="flex items-center gap-1">
                    {[
                      { val: 0.5, label: '0.5x سينمائي هادئ' },
                      { val: 1.0, label: '1.0x قياسي' },
                      { val: 1.5, label: '1.5x سريع' },
                    ].map((s) => (
                      <button
                        key={s.val}
                        onClick={() => setVideoSpeed(s.val)}
                        className={`flex-1 py-1 rounded-xl font-bold text-[10px] transition ${
                          videoSpeed === s.val
                            ? 'bg-blue-600 text-white'
                            : 'bg-[#0e1219] text-gray-400 hover:text-white'
                        }`}
                      >
                        {s.val}x
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Play / Record Action Bar */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                <button
                  type="button"
                  onClick={handleTogglePlay}
                  className={`py-3 px-4 rounded-2xl font-bold flex items-center justify-center gap-2 shadow-lg transition text-xs ${
                    isPlaying
                      ? 'bg-amber-500 hover:bg-amber-600 text-black shadow-amber-500/20'
                      : 'bg-[#1f2838] hover:bg-[#2a364a] text-white border border-[#3b4860]'
                  }`}
                >
                  {isPlaying ? (
                    <>
                      <Pause className="w-4 h-4" />
                      <span>إيقاف مؤقت للمعاينة</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 fill-current" />
                      <span>معاينة الجولة الحية</span>
                    </>
                  )}
                </button>

                {isRecording ? (
                  <button
                    type="button"
                    onClick={stopVideoRecording}
                    className="py-3 px-4 rounded-2xl bg-red-600 hover:bg-red-700 text-white font-bold flex items-center justify-center gap-2 shadow-lg animate-pulse text-xs"
                  >
                    <Radio className="w-4 h-4" />
                    <span>
                      إيقاف وحفظ الفيديو (00:{recordingSeconds < 10 ? `0${recordingSeconds}` : recordingSeconds} / {videoDuration}s)
                    </span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={startVideoRecording}
                    className="py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-900/30 transition text-xs"
                  >
                    <Video className="w-4 h-4" />
                    <span>تسجيل وعمل فيديو احترافي ({videoDuration} ثانية)</span>
                  </button>
                )}
              </div>

              {/* Video Result Preview */}
              {recordedVideoUrl && (
                <div className="p-3.5 bg-[#151a24] rounded-2xl border border-emerald-500/40 space-y-2.5 animate-in zoom-in-95 duration-150">
                  <div className="flex items-center justify-between">
                    <span className="text-emerald-400 font-bold flex items-center gap-1.5 text-xs">
                      <CheckCircle2 className="w-4 h-4" />
                      تم تسجيل فيديو المشروع بنجاح!
                    </span>
                    <span className="text-[10px] text-gray-400">WebM / MP4 High Bitrate</span>
                  </div>

                  <video
                    src={recordedVideoUrl}
                    controls
                    autoPlay
                    loop
                    className="w-full h-48 rounded-xl bg-black border border-[#2b3547] object-cover"
                  />

                  <a
                    href={recordedVideoUrl}
                    download={`Video_${project.name.replace(/\s+/g, '_')}.webm`}
                    className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow transition"
                  >
                    <Download className="w-4 h-4" />
                    <span>تحميل الفيديو على جهازك (Download Video)</span>
                  </a>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
