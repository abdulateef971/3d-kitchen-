import React, { useState } from 'react';
import { ParametricCabinet, MaterialDefinition, HandleConfig } from '../../types';
import { MATERIALS_CATALOG, HANDLES_CATALOG, getMaterialById } from '../../domain/materials/materialsCatalog';
import { X, Check, Palette, Sparkles, Wand2 } from 'lucide-react';

interface MaterialsModalProps {
  isOpen: boolean;
  onClose: () => void;
  unit: ParametricCabinet | null;
  onUpdateUnit: (updated: ParametricCabinet) => void;
  onApplyToAllUnits?: (bodyMatId: string, frontMatId: string, ctMatId?: string) => void;
}

type MaterialTarget = 'body' | 'front' | 'countertop' | 'handle';

export const MaterialsModal: React.FC<MaterialsModalProps> = ({
  isOpen,
  onClose,
  unit,
  onUpdateUnit,
  onApplyToAllUnits,
}) => {
  const [activeTarget, setActiveTarget] = useState<MaterialTarget>('front');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  if (!isOpen || !unit) return null;

  const currentBodyMat = getMaterialById(unit.bodyMaterialId);
  const currentFrontMat = getMaterialById(unit.frontMaterialId);
  const currentCtMat = unit.countertop ? getMaterialById(unit.countertop.materialId) : null;

  const filteredMaterials = MATERIALS_CATALOG.filter((m) => {
    if (activeTarget === 'countertop') {
      return m.category === 'marble' || m.category === 'wood' || m.category === 'mdf';
    }
    if (selectedCategory === 'all') return true;
    return m.category === selectedCategory;
  });

  const handleSelectMaterial = (mat: MaterialDefinition) => {
    if (activeTarget === 'body') {
      onUpdateUnit({
        ...unit,
        bodyMaterialId: mat.id,
        bodyColor: mat.color,
      });
    } else if (activeTarget === 'front') {
      const updatedDoors = (unit.doors || []).map((d) => ({
        ...d,
        materialId: mat.id,
        color: mat.color,
      }));
      const updatedDrawers = (unit.drawers || []).map((dr) => ({
        ...dr,
        materialId: mat.id,
        color: mat.color,
      }));
      onUpdateUnit({
        ...unit,
        frontMaterialId: mat.id,
        frontColor: mat.color,
        doors: updatedDoors,
        drawers: updatedDrawers,
      });
    } else if (activeTarget === 'countertop' && unit.countertop) {
      onUpdateUnit({
        ...unit,
        countertop: {
          ...unit.countertop,
          materialId: mat.id,
          color: mat.color,
        },
      });
    }
  };

  const handleSelectHandle = (handle: HandleConfig) => {
    onUpdateUnit({
      ...unit,
      handleConfig: { ...handle },
    });
  };

  const handleColorChange = (hex: string) => {
    if (activeTarget === 'body') {
      onUpdateUnit({ ...unit, bodyColor: hex });
    } else if (activeTarget === 'front') {
      const updatedDoors = (unit.doors || []).map((d) => ({ ...d, color: hex }));
      const updatedDrawers = (unit.drawers || []).map((dr) => ({ ...dr, color: hex }));
      onUpdateUnit({ ...unit, frontColor: hex, doors: updatedDoors, drawers: updatedDrawers });
    } else if (activeTarget === 'countertop' && unit.countertop) {
      onUpdateUnit({ ...unit, countertop: { ...unit.countertop, color: hex } });
    }
  };

  // Luxury Presets
  const applyPreset = (preset: 'nordic' | 'walnut_gold' | 'monochrome_black' | 'gloss_white') => {
    if (preset === 'nordic') {
      handleSelectMaterial(getMaterialById('mdf_matte_warm_cashmere'));
      onUpdateUnit({
        ...unit,
        bodyMaterialId: 'wood_natural_oak',
        bodyColor: '#c8a876',
        frontMaterialId: 'mdf_matte_warm_cashmere',
        frontColor: '#d4c7b8',
      });
    } else if (preset === 'walnut_gold') {
      onUpdateUnit({
        ...unit,
        bodyMaterialId: 'wood_walnut',
        bodyColor: '#5c4033',
        frontMaterialId: 'wood_walnut',
        frontColor: '#5c4033',
        handleConfig: HANDLES_CATALOG.find((h) => h.id === 'handle_bar_gold') || unit.handleConfig,
      });
    } else if (preset === 'monochrome_black') {
      onUpdateUnit({
        ...unit,
        bodyMaterialId: 'mdf_matte_anthracite',
        bodyColor: '#334155',
        frontMaterialId: 'mdf_matte_anthracite',
        frontColor: '#334155',
        countertop: unit.countertop
          ? { ...unit.countertop, materialId: 'marble_nero_marquina', color: '#18181b' }
          : undefined,
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl bg-[#1E1E1E] border border-[#333333] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-[#333333] flex items-center justify-between bg-[#252525]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded bg-blue-600/15 text-blue-400 border border-blue-500/30 flex items-center justify-center">
              <Palette className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white tracking-wide">تخصيص الخامات والألوان (Materials Studio)</h2>
              <p className="text-[11px] text-gray-400">تطبيق خامات خشبية، MDF، أكريليك، ورخام على الوحدة</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-white rounded hover:bg-[#333333] transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Preset Schemes Banner */}
        <div className="px-5 py-2.5 bg-[#181818] border-b border-[#333333] flex items-center justify-between gap-2 overflow-x-auto text-xs">
          <span className="text-gray-400 flex items-center gap-1 font-bold whitespace-nowrap text-[11px]">
            <Wand2 className="w-3.5 h-3.5 text-blue-400" />
            تنسيقات فاخرة جاهزة:
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => applyPreset('nordic')}
              className="px-2.5 py-1 rounded bg-[#121212] hover:bg-[#252525] border border-[#333333] text-gray-300 whitespace-nowrap font-medium transition text-[11px]"
            >
              كشمير دافئ وسنديان
            </button>
            <button
              onClick={() => applyPreset('walnut_gold')}
              className="px-2.5 py-1 rounded bg-[#121212] hover:bg-[#252525] border border-[#333333] text-gray-300 whitespace-nowrap font-medium transition text-[11px]"
            >
              جوز أمريكي مع ذهبي
            </button>
            <button
              onClick={() => applyPreset('monochrome_black')}
              className="px-2.5 py-1 rounded bg-[#121212] hover:bg-[#252525] border border-[#333333] text-gray-300 whitespace-nowrap font-medium transition text-[11px]"
            >
              فحمي مات مع رخام أسود
            </button>
          </div>
        </div>

        {/* Target Part Switcher Tabs */}
        <div className="px-5 pt-3.5 flex items-center gap-1.5 text-xs font-bold overflow-x-auto">
          <button
            onClick={() => setActiveTarget('front')}
            className={`px-3 py-1.5 rounded-lg transition text-xs ${
              activeTarget === 'front'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-[#121212] text-gray-400 hover:bg-[#252525] border border-[#333333]'
            }`}
          >
            واجهات الأبواب والأدراج ({currentFrontMat.nameAr})
          </button>
          <button
            onClick={() => setActiveTarget('body')}
            className={`px-3 py-1.5 rounded-lg transition text-xs ${
              activeTarget === 'body'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-[#121212] text-gray-400 hover:bg-[#252525] border border-[#333333]'
            }`}
          >
            جسم وهيكل الوحدة ({currentBodyMat.nameAr})
          </button>
          {unit.countertop && (
            <button
              onClick={() => setActiveTarget('countertop')}
              className={`px-3 py-1.5 rounded-lg transition text-xs ${
                activeTarget === 'countertop'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-[#121212] text-gray-400 hover:bg-[#252525] border border-[#333333]'
              }`}
            >
              سطح العمل / الرخام ({currentCtMat?.nameAr || 'الرخام'})
            </button>
          )}
          <button
            onClick={() => setActiveTarget('handle')}
            className={`px-3 py-1.5 rounded-lg transition text-xs ${
              activeTarget === 'handle'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-[#121212] text-gray-400 hover:bg-[#252525] border border-[#333333]'
            }`}
          >
            المقابض (Handles)
          </button>
        </div>

        {/* Body Content */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          {activeTarget !== 'handle' ? (
            <>
              {/* Category Filter for Materials */}
              <div className="flex items-center gap-1 overflow-x-auto pb-0.5 text-xs">
                {['all', 'mdf', 'wood', 'acrylic', 'marble', 'glass', 'metal'].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-2.5 py-1 rounded text-[11px] capitalize transition ${
                      selectedCategory === cat
                        ? 'bg-blue-600 text-white font-bold'
                        : 'bg-[#121212] text-gray-400 hover:bg-[#252525] border border-[#333333]'
                    }`}
                  >
                    {cat === 'all'
                      ? 'جميع الخامات'
                      : cat === 'wood'
                      ? 'أخشاب طبيعية'
                      : cat === 'mdf'
                      ? 'MDF مطفي'
                      : cat === 'acrylic'
                      ? 'أكريليك لامع'
                      : cat === 'marble'
                      ? 'رخام وكوارتز'
                      : cat === 'glass'
                      ? 'زجاج ديكور'
                      : 'معادن'}
                  </button>
                ))}
              </div>

              {/* Color Customizer */}
              <div className="p-2.5 bg-[#121212] rounded-xl border border-[#333333] flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <input
                    type="color"
                    value={
                      activeTarget === 'body'
                        ? unit.bodyColor
                        : activeTarget === 'front'
                        ? unit.frontColor
                        : unit.countertop?.color || '#ffffff'
                    }
                    onChange={(e) => handleColorChange(e.target.value)}
                    className="w-7 h-7 rounded cursor-pointer bg-transparent border-0"
                  />
                  <div>
                    <span className="text-xs font-bold text-white block">تعديل لون مخصص</span>
                    <span className="text-[10px] text-gray-500 font-mono">
                      {activeTarget === 'body'
                        ? unit.bodyColor
                        : activeTarget === 'front'
                        ? unit.frontColor
                        : unit.countertop?.color}
                    </span>
                  </div>
                </div>
              </div>

              {/* Materials Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {filteredMaterials.map((mat) => {
                  const isCurrent =
                    (activeTarget === 'body' && unit.bodyMaterialId === mat.id) ||
                    (activeTarget === 'front' && unit.frontMaterialId === mat.id) ||
                    (activeTarget === 'countertop' && unit.countertop?.materialId === mat.id);

                  return (
                    <button
                      key={mat.id}
                      onClick={() => handleSelectMaterial(mat)}
                      className={`p-2.5 rounded-xl border text-right transition flex flex-col gap-1.5 relative overflow-hidden group ${
                        isCurrent
                          ? 'bg-[#252525] border-blue-500 shadow-md shadow-blue-600/10'
                          : 'bg-[#121212] border-[#333333] hover:border-[#444444]'
                      }`}
                    >
                      {/* Swatch Preview Box */}
                      <div
                        className="w-full h-14 rounded-lg border border-white/10 shadow-inner flex items-end justify-end p-1.5"
                        style={{ backgroundColor: mat.color }}
                      >
                        {isCurrent && (
                          <div className="p-0.5 rounded-full bg-blue-600 text-white shadow">
                            <Check className="w-3 h-3 stroke-[3]" />
                          </div>
                        )}
                      </div>

                      <div>
                        <span className="font-bold text-xs text-white block group-hover:text-blue-400 transition">
                          {mat.nameAr}
                        </span>
                        <span className="text-[10px] text-gray-400 block font-mono mt-0.5">
                          {mat.name} • ${mat.costPerSqMeter}/m²
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </>
          ) : (
            /* Handles Selection */
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-white">اختر طراز المقبض (Handle Style)</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {HANDLES_CATALOG.map((handle) => {
                  const isSelected = unit.handleConfig.id === handle.id;
                  return (
                    <button
                      key={handle.id}
                      onClick={() => handleSelectHandle(handle)}
                      className={`p-3 rounded-xl border text-right transition flex items-center justify-between ${
                        isSelected
                          ? 'bg-[#252525] border-blue-500 shadow-sm'
                          : 'bg-[#121212] border-[#333333] hover:border-[#444444]'
                      }`}
                    >
                      <div>
                        <span className="font-bold text-xs text-white block">{handle.nameAr}</span>
                        <span className="text-[11px] text-gray-400 block mt-0.5">{handle.material}</span>
                      </div>
                      {isSelected && (
                        <div className="p-1 rounded-full bg-blue-600 text-white">
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-[#333333] flex items-center justify-between bg-[#252525] text-xs">
          {onApplyToAllUnits && (
            <button
              onClick={() => onApplyToAllUnits(unit.bodyMaterialId, unit.frontMaterialId, unit.countertop?.materialId)}
              className="px-3 py-1.5 rounded-lg bg-[#1E1E1E] hover:bg-[#2A2A2A] text-gray-300 font-semibold transition border border-[#333333]"
            >
              تطبيق الخامات على جميع وحدات المشروع
            </button>
          )}
          <button
            onClick={onClose}
            className="px-5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold transition shadow-md mr-auto"
          >
            تم
          </button>
        </div>
      </div>
    </div>
  );
};
