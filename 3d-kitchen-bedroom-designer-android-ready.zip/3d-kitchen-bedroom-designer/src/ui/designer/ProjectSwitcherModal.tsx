import React, { useState } from 'react';
import { Project, ProjectType } from '../../types';
import { projectRepository } from '../../domain/storage/projectRepository';
import {
  FolderKanban,
  X,
  Plus,
  Box,
  Check,
  Search,
  ExternalLink,
  Calendar,
  Layers,
  ArrowRight,
} from 'lucide-react';

interface ProjectSwitcherModalProps {
  currentProjectId: string;
  isOpen: boolean;
  onClose: () => void;
  onSwitchProject: (project: Project) => void;
  onOpenProjectsList: () => void;
  onCreateNewProject: (type: ProjectType, name?: string) => void;
}

export const ProjectSwitcherModal: React.FC<ProjectSwitcherModalProps> = ({
  currentProjectId,
  isOpen,
  onClose,
  onSwitchProject,
  onOpenProjectsList,
  onCreateNewProject,
}) => {
  const [projects, setProjects] = useState<Project[]>(() => projectRepository.getAllProjects());
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateMenu, setShowCreateMenu] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [selectedType, setSelectedType] = useState<ProjectType>('kitchen');

  if (!isOpen) return null;

  const filteredProjects = projects.filter((p) =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCreateNewProject(selectedType, newProjectName.trim() || undefined);
    onClose();
  };

  return (
    <div
      onPointerDown={(e) => e.stopPropagation()}
      onClick={onClose}
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 font-['Cairo',sans-serif]"
      dir="rtl"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="bg-[#121620] border border-[#2B384E] rounded-3xl p-5 sm:p-6 w-full max-w-xl max-h-[85vh] flex flex-col shadow-2xl text-white animate-in zoom-in-95 duration-200"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#253043] pb-4 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-blue-900/40">
              <FolderKanban className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">التنقل بين المشاريع</h2>
              <p className="text-xs text-gray-400">
                اختر أي مشروع للانتقال إليه فوراً وتعديله في بيئة 3D
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-gray-800 text-gray-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Actions Bar */}
        <div className="py-3 flex items-center gap-2 shrink-0">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="البحث في المشاريع..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#181F2C] border border-[#2B384E] rounded-xl pr-9 pl-3 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition"
            />
          </div>

          <button
            onClick={() => setShowCreateMenu((prev) => !prev)}
            className="px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-blue-900/30 transition shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>مشروع جديد</span>
          </button>
        </div>

        {/* Create New Project Inline Form */}
        {showCreateMenu && (
          <form
            onSubmit={handleCreateSubmit}
            className="bg-[#18202D] border border-blue-500/40 rounded-2xl p-3.5 mb-3 flex flex-col gap-2.5 shrink-0 animate-in fade-in duration-150"
          >
            <div className="flex items-center justify-between text-xs font-bold text-blue-300">
              <span>إنشاء وتصميم مشروع جديد:</span>
              <button
                type="button"
                onClick={() => setShowCreateMenu(false)}
                className="text-gray-400 hover:text-white text-[11px]"
              >
                إلغاء
              </button>
            </div>

            <div className="grid grid-cols-3 gap-1.5">
              {[
                { id: 'kitchen' as ProjectType, label: 'مطبخ كامل' },
                { id: 'bedroom' as ProjectType, label: 'غرفة نوم' },
                { id: 'wardrobe' as ProjectType, label: 'دواليب وخزائن' },
              ].map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setSelectedType(t.id)}
                  className={`py-1.5 px-2 rounded-lg text-xs font-bold border transition ${
                    selectedType === t.id
                      ? 'bg-blue-600 text-white border-blue-400'
                      : 'bg-[#121620] text-gray-400 border-[#2A3549] hover:text-white'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                placeholder="اسم المشروع (اختياري)..."
                value={newProjectName}
                onChange={(e) => setNewProjectName(e.target.value)}
                className="flex-1 bg-[#121620] border border-[#2A3549] rounded-xl px-3 py-1.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-blue-400"
              />
              <button
                type="submit"
                className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition shadow-sm"
              >
                إنشاء وفتح
              </button>
            </div>
          </form>
        )}

        {/* Projects List */}
        <div className="flex-1 overflow-y-auto flex flex-col gap-2.5 pr-1 scrollbar-thin scrollbar-thumb-gray-700">
          {filteredProjects.length === 0 ? (
            <div className="py-12 text-center text-gray-400 text-xs">
              لم يتم العثور على مشاريع مطابقة للبحث
            </div>
          ) : (
            filteredProjects.map((p) => {
              const isCurrent = p.projectId === currentProjectId;
              return (
                <div
                  key={p.projectId}
                  onClick={() => {
                    if (!isCurrent) {
                      onSwitchProject(p);
                      onClose();
                    }
                  }}
                  className={`p-3.5 rounded-2xl border transition flex items-center justify-between cursor-pointer ${
                    isCurrent
                      ? 'bg-blue-950/40 border-blue-500/80 shadow-md ring-1 ring-blue-500/40'
                      : 'bg-[#161D2A] border-[#253245] hover:border-blue-400 hover:bg-[#1C2536]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold ${
                        isCurrent
                          ? 'bg-blue-600 text-white'
                          : 'bg-[#222C3D] text-blue-300'
                      }`}
                    >
                      <Box className="w-5 h-5" />
                    </div>

                    <div className="flex flex-col">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-white">{p.name}</span>
                        {isCurrent && (
                          <span className="text-[10px] bg-blue-500 text-white font-bold px-2 py-0.5 rounded-full">
                            المشروع المفتوح حالياً ✓
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-3 text-[11px] text-gray-400 mt-1">
                        <span className="flex items-center gap-1">
                          <Layers className="w-3 h-3 text-blue-400" />
                          <span>{p.units?.length || 0} وحدة</span>
                        </span>
                        <span>•</span>
                        <span>{p.type === 'kitchen' ? 'مطبخ' : 'غرف وخزائن'}</span>
                        <span>•</span>
                        <span className="font-mono">
                          {p.room.width}×{p.room.length} مم
                        </span>
                      </div>
                    </div>
                  </div>

                  <div>
                    {isCurrent ? (
                      <span className="w-8 h-8 rounded-full bg-blue-600/20 text-blue-400 flex items-center justify-center">
                        <Check className="w-4 h-4" />
                      </span>
                    ) : (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSwitchProject(p);
                          onClose();
                        }}
                        className="px-3 py-1.5 rounded-xl bg-[#222D3E] hover:bg-blue-600 text-gray-300 hover:text-white text-xs font-bold transition flex items-center gap-1.5"
                      >
                        <span>فتح المشروع</span>
                        <ArrowRight className="w-3.5 h-3.5 rotate-180" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer: Manage all projects in full dashboard */}
        <div className="pt-3 border-t border-[#253043] flex items-center justify-between shrink-0">
          <button
            onClick={() => {
              onClose();
              onOpenProjectsList();
            }}
            className="text-xs text-blue-400 hover:text-blue-300 hover:underline flex items-center gap-1.5 font-bold"
          >
            <FolderKanban className="w-4 h-4" />
            <span>عرض وإدارة جميع المشاريع في الشاشة الكاملة ←</span>
          </button>

          <span className="text-[10px] text-gray-500 font-mono">
            إجمالي المشاريع: {projects.length}
          </span>
        </div>
      </div>
    </div>
  );
};
