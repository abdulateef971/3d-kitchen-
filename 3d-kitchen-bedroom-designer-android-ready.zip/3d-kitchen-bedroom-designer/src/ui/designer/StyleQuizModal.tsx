import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Palette,
  Lightbulb,
  Bot,
  Send,
  Check,
  CheckCircle2,
  ArrowRight,
  Plus,
  Compass,
} from 'lucide-react';
import { Project } from '../../types';

export interface StyleQuizModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyStyle: (styleKey: string) => void;
  projectName?: string;
  roomDimensions?: string;
}

interface StyleCard {
  id: string;
  nameAr: string;
  badge: string;
  badgeColor: string;
  description: string;
  colors: string[];
  colorHexes: string[];
  wallColor: string;
  floorTexture: string;
}

const STYLE_CARDS: StyleCard[] = [
  {
    id: 'nordic',
    nameAr: 'النمط الاسكندنافي (Nordic)',
    badge: 'الأكثر طلباً',
    badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    description:
      'يمتاز بالبساطة الأنيقة، الخشب الطبيعي الفاتح، والخطوط النظيفة مع إضاءة دافئة تجلب الراحة والهدوء.',
    colors: ['خشب زان طبيعي', 'كتان أبيض', 'ألومنيوم لامع'],
    colorHexes: ['#D97706', '#F8FAFC', '#94A3B8'],
    wallColor: '#F8FAFC',
    floorTexture: 'parquet_natural',
  },
  {
    id: 'modern',
    nameAr: 'النمط المعاصر (Modern)',
    badge: 'عصري فخم',
    badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
    description:
      'جرأة وفخامة هندسية مع ألوان الفحم والرخام الإيطالي، ولمسات معدنية ذهبية وإضاءة ذكية متطورة.',
    colors: ['رخام نيرو ماركينا', 'فحم رمادي داكن', 'ذهبي مطفي'],
    colorHexes: ['#0F172A', '#334155', '#EAB308'],
    wallColor: '#F1F5F9',
    floorTexture: 'tile_marble',
  },
  {
    id: 'neoclassical',
    nameAr: 'النمط الكلاسيكي الفاخر (Neoclassical)',
    badge: 'أصالة وفخامة',
    badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
    description:
      'زخارف راقية مع درف شاكر بيضاء، أسطح كوارتز ناصعة، ومقابض برونزية دافئة مع أرضيات خشب جوز ملكي.',
    colors: ['أبيض عاجي', 'خشب جوز ملكي', 'برونز أنتيك'],
    colorHexes: ['#F5EFE6', '#854D0E', '#B45309'],
    wallColor: '#FAF7F2',
    floorTexture: 'parquet_dark',
  },
  {
    id: 'industrial',
    nameAr: 'النمط الصناعي المودرن (Industrial Loft)',
    badge: 'طابع عصري متقدم',
    badgeColor: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
    description:
      'مزيج الخرسانة والحديد الأسود المطفي مع أخشاب الروستيك المعتقة وسبوتلايت سقفية موجهة بدقة.',
    colors: ['خرسانة رمادية', 'حديد أسود مطفي', 'خشب ريفي'],
    colorHexes: ['#64748B', '#0F172A', '#78350F'],
    wallColor: '#E2E8F0',
    floorTexture: 'tile_grey',
  },
];

export const StyleQuizModal: React.FC<StyleQuizModalProps> = ({
  isOpen,
  onClose,
  onApplyStyle,
  projectName = 'مطبخي العصري',
  roomDimensions = '6م × 5م',
}) => {
  const [activeTab, setActiveTab] = useState<'styles' | 'recommendations' | 'gemini'>('styles');
  const [appliedNotification, setAppliedNotification] = useState<string | null>(null);

  // Gemini consultation state
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant'; text: string }>>([
    {
      role: 'assistant',
      text: `مرحباً بك! أنا مهندس الديكور والتصميم الداخلي الذكي. مساحة غرفتك الحالية (${roomDimensions}) تعطينا إمكانيات مذهلة لإضافة جزيرة مركزية فخمة مع قواطع خشبية ديكورية. كيف تحب أن نبدأ تنسيق ألوان غرفتك اليوم؟`,
    },
  ]);
  const [inputValue, setInputValue] = useState<string>('');

  if (!isOpen) return null;

  const handleApplyFull = (styleId: string, styleName: string) => {
    onApplyStyle(styleId);
    setAppliedNotification(`تم تطبيق ${styleName} بنجاح على مشروعك!`);
    setTimeout(() => {
      setAppliedNotification(null);
      onClose();
    }, 1200);
  };

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;
    const userText = inputValue;
    setMessages((prev) => [...prev, { role: 'user', text: userText }]);
    setInputValue('');

    // Intelligent immediate assistant response
    setTimeout(() => {
      let reply = `بناءً على مساحة غرفتك (${roomDimensions})، أوصي باختيار خامات رخام كلكتا مع أخشاب الزان الطبيعي وإضاءة ليد غير مباشرة بدرجة 3000K، لإعطاء شعور بالاتساع والهدوء والفخامة.`;
      if (userText.includes('رخام') || userText.includes('سطح')) {
        reply =
          'أسطح رخام الكوارتز المعالج أو البورسلين الإسباني هي الخيار الأمثل لمقاومة الحرارة والخدوش مع مظهر فاخر فائق النقاء.';
      } else if (userText.includes('إضاءة') || userText.includes('نور')) {
        reply =
          'أنصح بتوزيع الإضاءة على ثلاث طبقات: إنارة عامة بالسقف 4000K، سبوتلايت موجهة للعمل 3000K، وشريط LED مخفي أسفل الخزائن العلوية.';
      } else if (userText.includes('لون') || userText.includes('الوان')) {
        reply =
          'أفضل معادلة لونية لمساحة 30 م² هي قاعدة 60-30-10: 60% أبيض كتان أو رمادي فاتح، 30% خشب طبيعي، و10% لمسات معدنية سوداء أو نحاسية.';
      }
      setMessages((prev) => [...prev, { role: 'assistant', text: reply }]);
    }, 450);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-6 animate-in fade-in duration-200">
      <div
        id="style-quiz-dialog"
        className="relative w-full max-w-4xl bg-[#141416] border border-white/15 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200 text-white"
      >
        {/* --------------------------------------------------------------- */}
        {/* 1. Header (Matching Video 00:28)                                */}
        {/* --------------------------------------------------------------- */}
        <header className="px-6 py-4 border-b border-white/10 flex items-center justify-between shrink-0 bg-[#1C1C1E]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-blue-900/40">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <span>محرك التصميم الداخلي والذكاء الاصطناعي</span>
              </h2>
              <p className="text-xs text-zinc-400">
                أنماط معمارية مسبقة، اقتراحات مكملة ذكية، وتحليل هندسي للمساحة
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white flex items-center justify-center transition"
          >
            <X className="w-5 h-5" />
          </button>
        </header>

        {/* --------------------------------------------------------------- */}
        {/* 2. Three Main Tabs (Matching Video 00:28 - 00:30)               */}
        {/* --------------------------------------------------------------- */}
        <div className="px-6 pt-3 border-b border-white/10 bg-[#18181B] flex items-center gap-2 overflow-x-auto">
          {/* Tab 1: Interior Styles */}
          <button
            type="button"
            onClick={() => setActiveTab('styles')}
            className={`pb-3 px-3 text-xs sm:text-sm font-bold transition flex items-center gap-2 border-b-2 whitespace-nowrap ${
              activeTab === 'styles'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Palette className="w-4 h-4" />
            <span>أنماط ديكور جاهزة تلوين (Interior Styles)</span>
          </button>

          {/* Tab 2: AI Recommendations */}
          <button
            type="button"
            onClick={() => setActiveTab('recommendations')}
            className={`pb-3 px-3 text-xs sm:text-sm font-bold transition flex items-center gap-2 border-b-2 whitespace-nowrap ${
              activeTab === 'recommendations'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Lightbulb className="w-4 h-4" />
            <span>محرك الاقتراحات الذكي (AI Recommendations)</span>
          </button>

          {/* Tab 3: Gemini Consultation */}
          <button
            type="button"
            onClick={() => setActiveTab('gemini')}
            className={`pb-3 px-3 text-xs sm:text-sm font-bold transition flex items-center gap-2 border-b-2 whitespace-nowrap ${
              activeTab === 'gemini'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Bot className="w-4 h-4" />
            <span>استشارة مهندس الديكور (Gemini)</span>
          </button>
        </div>

        {/* --------------------------------------------------------------- */}
        {/* 3. Toast Notification when style applied                         */}
        {/* --------------------------------------------------------------- */}
        {appliedNotification && (
          <div className="mx-6 mt-4 p-3 bg-emerald-600/90 text-white rounded-2xl flex items-center gap-2 text-xs font-bold animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-white" />
            <span>{appliedNotification}</span>
          </div>
        )}

        {/* --------------------------------------------------------------- */}
        {/* 4. Tab Content Workspace                                         */}
        {/* --------------------------------------------------------------- */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          {/* TAB 1: INTERIOR STYLES */}
          {activeTab === 'styles' && (
            <div className="flex flex-col gap-4">
              {/* Informational Banner matching Video */}
              <div className="p-4 rounded-2xl bg-blue-600/10 border border-blue-500/20 flex items-start gap-3 text-xs text-blue-200">
                <Sparkles className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                <div className="leading-relaxed">
                  <div className="font-bold text-white text-sm mb-0.5">
                    اختر نمط التصميم المفضل لتأثيث الغرفة فوراً
                  </div>
                  يقوم التطبيق بتوزيع قطع الأثاث المنسقة وتعيين دهان الجدران والأرضيات المناسبة لمساحة غرفتك ({roomDimensions})
                </div>
              </div>

              {/* Styles Grid Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {STYLE_CARDS.map((card) => (
                  <div
                    key={card.id}
                    className="p-4 rounded-3xl bg-[#1C1C1E] border border-white/10 hover:border-white/20 transition flex flex-col justify-between gap-4 shadow-xl"
                  >
                    <div>
                      {/* Header with Title and Badge */}
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <h3 className="font-bold text-sm text-white">{card.nameAr}</h3>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${card.badgeColor}`}
                        >
                          {card.badge}
                        </span>
                      </div>

                      {/* Description */}
                      <p className="text-xs text-zinc-400 leading-relaxed mb-3">
                        {card.description}
                      </p>

                      {/* Color palette chips */}
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] text-zinc-500 font-bold">الألوان:</span>
                        <div className="flex items-center gap-1.5">
                          {card.colorHexes.map((hex, idx) => (
                            <span
                              key={hex}
                              style={{ backgroundColor: hex }}
                              className="w-4 h-4 rounded-full border border-white/20 inline-block"
                              title={card.colors[idx]}
                            />
                          ))}
                          <span className="text-[11px] text-zinc-300 font-medium">
                            {card.colors.join('، ')}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons: تطبيق كامل جديد & + دمج النمط */}
                    <div className="flex items-center gap-2 pt-2 border-t border-white/10">
                      <button
                        type="button"
                        onClick={() => handleApplyFull(card.id, card.nameAr)}
                        className="flex-1 py-2 px-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-lg shadow-blue-900/40 active:scale-95"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>تطبيق كامل جديد</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleApplyFull(card.id, card.nameAr)}
                        className="py-2 px-3 bg-white/5 hover:bg-white/10 text-zinc-300 hover:text-white rounded-xl text-xs font-bold transition flex items-center gap-1 active:scale-95"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>دمج النمط</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: AI RECOMMENDATIONS */}
          {activeTab === 'recommendations' && (
            <div className="flex flex-col gap-4">
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-200 flex items-start gap-3">
                <Lightbulb className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-white text-sm mb-0.5">
                    تحليل هندسي ذكي لمساحة غرفتك ({roomDimensions})
                  </div>
                  يقوم الذكاء الاصطناعي بحساب حركة المرور ومثلث العمل المثالي بين الثلاجة وحوض الغسيل وموقد الطهي.
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-[#1C1C1E] border border-white/10 flex flex-col justify-between gap-3">
                  <div>
                    <div className="font-bold text-sm text-white mb-1">
                      جزيرة مطبخ مركزية مع مقاعد بار
                    </div>
                    <p className="text-xs text-zinc-400">
                      مساحة 30 م² مثالية لجزيرة كلكتا رخامية بطول 2.4م توفر 4 مقاعد جلوس ومساحة تحضير طعام رحبة.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleApplyFull('island_modern', 'جزيرة مطبخ كلكتا')}
                    className="py-2 px-3 bg-white/10 hover:bg-white/15 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5 text-blue-400" />
                    <span>إضافة الجزيرة للمشروع</span>
                  </button>
                </div>

                <div className="p-4 rounded-2xl bg-[#1C1C1E] border border-white/10 flex flex-col justify-between gap-3">
                  <div>
                    <div className="font-bold text-sm text-white mb-1">
                      جدار فاصل خفيف ديكوري
                    </div>
                    <p className="text-xs text-zinc-400">
                      فصل بصري أنيق بين مساحة الطهي والاستقبال مع الحفاظ على امتداد الضوء الطبيعي.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleApplyFull('partition_wall', 'جدار فاصل معماري')}
                    className="py-2 px-3 bg-white/10 hover:bg-white/15 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5 text-amber-400" />
                    <span>إضافة القاطع الديكوري</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: GEMINI CONSULTATION */}
          {activeTab === 'gemini' && (
            <div className="flex flex-col h-[400px]">
              <div className="flex-1 overflow-y-auto space-y-3 p-3 bg-black/40 rounded-2xl border border-white/10 mb-3">
                {messages.map((m, idx) => (
                  <div
                    key={idx}
                    className={`flex gap-2.5 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    {m.role === 'assistant' && (
                      <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center shrink-0">
                        <Bot className="w-4 h-4 text-white" />
                      </div>
                    )}
                    <div
                      className={`max-w-[80%] p-3 rounded-2xl text-xs leading-relaxed ${
                        m.role === 'user'
                          ? 'bg-blue-600 text-white font-medium'
                          : 'bg-[#1C1C1E] text-zinc-200 border border-white/10'
                      }`}
                    >
                      {m.text}
                    </div>
                  </div>
                ))}
              </div>

              {/* Quick Prompt Questions */}
              <div className="flex items-center gap-2 overflow-x-auto pb-2 mb-2">
                {[
                  'كيف أنسق الألوان مع مساحة 30 م²؟',
                  'ما أفضل خامة لأسطح المطبخ؟',
                  'اقترح توزيع إضاءة مريحة للعين',
                ].map((q) => (
                  <button
                    key={q}
                    type="button"
                    onClick={() => {
                      setInputValue(q);
                    }}
                    className="px-3 py-1 bg-white/5 hover:bg-white/10 text-zinc-300 rounded-full text-[11px] font-medium whitespace-nowrap transition border border-white/10"
                  >
                    {q}
                  </button>
                ))}
              </div>

              {/* Chat Input */}
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder="اسأل مهندس الديكور عن أي تنسيق، خامات، أو أبعاد..."
                  className="flex-1 px-4 py-2.5 bg-[#1C1C1E] border border-white/15 rounded-2xl text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-blue-500"
                />
                <button
                  type="button"
                  onClick={handleSendMessage}
                  className="p-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl transition active:scale-95 shadow-lg shadow-blue-900/40"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
