import React from 'react';
import { X, Footprints, Compass, Plus, Palette, Ruler, Hand, Sparkles } from 'lucide-react';

interface HelpGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HelpGuideModal: React.FC<HelpGuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div
        id="help-guide-dialog"
        className="w-full max-w-lg bg-[#1C1C1E] border border-white/15 rounded-3xl shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-200"
      >
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center font-black">
              ?
            </div>
            <h3 className="text-sm font-bold text-white tracking-wide">دليل استخدام التطبيق والملاحة</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-white/10 text-zinc-400 hover:text-white flex items-center justify-center transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-4 overflow-y-auto max-h-[70vh] text-right">
          {/* Item 1 */}
          <div className="p-3.5 rounded-2xl bg-zinc-900 border border-white/5 flex items-start gap-3.5">
            <div className="w-9 h-9 rounded-xl bg-amber-400/15 text-amber-400 border border-amber-400/30 flex items-center justify-center shrink-0">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white mb-0.5">تبديل الرؤية (360° وتجول)</h4>
              <p className="text-[11px] text-zinc-400 leading-relaxed">
                استخدم الزر العلوي للتبديل بين وضع الدوران البانورامي الشامل 360° أو وضع التجول الشخصي الحر في الغرفة.
              </p>
            </div>
          </div>

          {/* Item 2 */}
          <div className="p-3.5 rounded-2xl bg-zinc-900 border border-white/5 flex items-start gap-3.5">
            <div className="w-9 h-9 rounded-xl bg-blue-400/15 text-blue-400 border border-blue-400/30 flex items-center justify-center shrink-0">
              <Footprints className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white mb-0.5">وحدة التحكم بالأسهم (D-Pad)</h4>
              <p className="text-[11px] text-zinc-400 leading-relaxed">
                اضغط أو اسحب الأسهم السفلية للتحرك للأمام والخلف واليسار واليمين بسلاسة تامة.
              </p>
            </div>
          </div>

          {/* Item 3 */}
          <div className="p-3.5 rounded-2xl bg-zinc-900 border border-white/5 flex items-start gap-3.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-400/15 text-emerald-400 border border-emerald-400/30 flex items-center justify-center shrink-0">
              <Plus className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white mb-0.5">إضافة الأثاث والوحدات (+)</h4>
              <p className="text-[11px] text-zinc-400 leading-relaxed">
                اضغط على زر (+) في الأسفل لتصفح مكتبة الوحدات المصنفة (مطابخ، أجهزة، زينة، طاولات وكراسي) وإدراجها بنقرة واحدة.
              </p>
            </div>
          </div>

          {/* Item 4 */}
          <div className="p-3.5 rounded-2xl bg-zinc-900 border border-white/5 flex items-start gap-3.5">
            <div className="w-9 h-9 rounded-xl bg-purple-400/15 text-purple-400 border border-purple-400/30 flex items-center justify-center shrink-0">
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white mb-0.5">الشريط السريع للقطعة المحددة</h4>
              <p className="text-[11px] text-zinc-400 leading-relaxed">
                عند النقر على أي قطعة أثاث، يظهر شريط عائم يتيح لك تعديل الألوان والمقاسات، التكرار، الحذف، أو فتح الدرف والأدراج.
              </p>
            </div>
          </div>
        </div>

        <div className="p-4 border-t border-white/10 bg-zinc-900/50 flex justify-center">
          <button
            type="button"
            onClick={onClose}
            className="px-8 py-2.5 rounded-full text-xs font-bold bg-white text-zinc-950 hover:bg-zinc-100 transition active:scale-95"
          >
            فهمت ذلك، استمرار
          </button>
        </div>
      </div>
    </div>
  );
};
