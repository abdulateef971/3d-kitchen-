import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Box, Layers, Sparkles, Compass } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(15);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(onComplete, 400);
          return 100;
        }
        return prev + 25;
      });
    }, 250);

    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.02 }}
      transition={{ duration: 0.4 }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#0F0F0F] text-[#E5E5E5] overflow-hidden"
    >
      {/* Subtle architectural grid background */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#33333315_1px,transparent_1px),linear-gradient(to_bottom,#33333315_1px,transparent_1px)] bg-[size:32px_32px] opacity-40 pointer-events-none" />

      {/* Decorative Glow */}
      <div className="absolute w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none -top-20 -left-20" />
      <div className="absolute w-96 h-96 bg-blue-400/5 rounded-full blur-3xl pointer-events-none -bottom-20 -right-20" />

      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
        className="relative z-10 flex flex-col items-center text-center px-6"
      >
        {/* Animated App Icon */}
        <div className="relative mb-6">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-600 to-blue-400 p-0.5 shadow-xl shadow-blue-900/30">
            <div className="w-full h-full bg-[#1E1E1E] rounded-[14px] flex items-center justify-center relative overflow-hidden">
              <Box className="w-10 h-10 text-blue-400 animate-pulse" />
              <div className="absolute top-2 right-2">
                <Compass className="w-3.5 h-3.5 text-blue-400/80 animate-spin" style={{ animationDuration: '6s' }} />
              </div>
            </div>
          </div>
          <div className="absolute -bottom-2 -right-2 bg-blue-600 text-white font-bold text-[9px] px-2 py-0.5 rounded shadow">
            3D CAD PRO
          </div>
        </div>

        {/* Title & Tagline */}
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mb-2 font-['Cairo']">
          3D Kitchen & Bedroom Designer
        </h1>
        <p className="text-sm text-gray-400 font-medium mb-6 max-w-md font-['Cairo']">
          المصمم الذكي للمطابخ وغرف النوم والخزائن بنظام بارامتري واقعي
        </p>

        {/* Features badges */}
        <div className="flex flex-wrap justify-center gap-2 mb-8 text-xs text-gray-300">
          <span className="bg-[#1E1E1E] border border-[#333333] px-3 py-1.5 rounded-lg flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-blue-400" />
            نظام بارامتري بالمليمتر
          </span>
          <span className="bg-[#1E1E1E] border border-[#333333] px-3 py-1.5 rounded-lg flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-blue-400" />
            محاكاة حركة الأبواب والأدراج
          </span>
        </div>

        {/* Progress Bar */}
        <div className="w-56 h-1.5 bg-[#252525] rounded-full overflow-hidden mb-2.5">
          <motion.div
            className="h-full bg-blue-600"
            style={{ width: `${progress}%` }}
            transition={{ ease: 'easeOut' }}
          />
        </div>
        <span className="text-[11px] font-mono text-gray-500 tracking-wider">
          جاري تهيئة محرك 3D ومكتبة الخامات... {progress}%
        </span>
      </motion.div>
    </motion.div>
  );
};
