import React, { useState } from 'react';
import { Project, ProjectType } from '../../types';
import { projectRepository } from '../../domain/storage/projectRepository';
import {
  Plus,
  Box,
  FolderKanban,
  Sparkles,
  Layers,
  Home,
  ChefHat,
  BedDouble,
  DoorClosed,
  CheckCircle2,
  Sliders,
  DollarSign,
  ArrowLeft,
  Compass,
} from 'lucide-react';

interface HomeScreenProps {
  onOpenProject: (project: Project) => void;
  onOpenProjectsList: () => void;
  onCreateNewProject: (type: ProjectType, name?: string) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onOpenProject,
  onOpenProjectsList,
  onCreateNewProject,
}) => {
  const [recentProjects, setRecentProjects] = useState<Project[]>(() =>
    projectRepository.getAllProjects().slice(0, 3)
  );
  const [isNewModalOpen, setIsNewModalOpen] = useState(false);
  const [selectedType, setSelectedType] = useState<ProjectType>('kitchen');
  const [projectName, setProjectName] = useState('');

  const totalProjects = projectRepository.getAllProjects().length;

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCreateNewProject(selectedType, projectName.trim() || undefined);
    setIsNewModalOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#0F0F0F] text-[#E5E5E5] p-6 md:p-12 font-['Cairo',sans-serif] flex flex-col justify-between">
      <div className="max-w-7xl mx-auto w-full space-y-10">
        {/* Top Header */}
        <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#333333] pb-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-lg bg-blue-600 flex items-center justify-center font-bold text-white shadow-lg shadow-blue-600/25">
              <Box className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
                3D Kitchen & Bedroom Designer
              </h1>
              <p className="text-xs sm:text-sm text-blue-400 font-medium">
                نظام تصميم المطابخ وغرف النوم والخزائن البارامتري بالمليمتر
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onOpenProjectsList}
              className="px-4 py-2 rounded-lg bg-[#1E1E1E] hover:bg-[#2A2A2A] border border-[#333333] text-gray-200 text-xs font-semibold flex items-center gap-2 transition"
            >
              <FolderKanban className="w-4 h-4 text-blue-400" />
              مشاريعي ({totalProjects})
            </button>
            <button
              onClick={() => setIsNewModalOpen(true)}
              className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-blue-600/25 transition"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              مشروع جديد
            </button>
          </div>
        </header>

        {/* Quick Launch Cards */}
        <section className="space-y-4">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-blue-400" />
            بدء تصميم فوري (Quick Start Studio)
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Kitchen Card */}
            <div
              onClick={() => {
                setSelectedType('kitchen');
                setIsNewModalOpen(true);
              }}
              className="group relative p-6 sm:p-7 rounded-2xl bg-[#1E1E1E] border border-[#333333] hover:border-blue-500 shadow-xl hover:shadow-2xl transition duration-300 cursor-pointer flex flex-col justify-between min-h-[200px]"
            >
              <div className="space-y-3 z-10">
                <div className="w-10 h-10 rounded-lg bg-blue-600/15 text-blue-400 border border-blue-500/30 flex items-center justify-center">
                  <ChefHat className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-white group-hover:text-blue-400 transition">
                  تصميم مطبخ عصري (Modular Kitchen)
                </h3>
                <p className="text-xs text-gray-400 max-w-sm leading-relaxed">
                  خزائن سفلية، علوية جدارية، خزائن أبراج، أحواض، أفران، أسطح رخام، وإضاءات LED خفية تحت الوحدات.
                </p>
              </div>

              <div className="pt-4 flex items-center justify-between z-10 border-t border-[#2A2A2A]">
                <span className="text-xs font-semibold text-blue-400 flex items-center gap-1 group-hover:-translate-x-1 transition">
                  بدء تصميم مطبخ جديد <ArrowLeft className="w-3.5 h-3.5" />
                </span>
                <span className="text-[11px] font-mono text-gray-500">نظام بارامتري كامل</span>
              </div>
            </div>

            {/* Bedroom / Wardrobe Card */}
            <div
              onClick={() => {
                setSelectedType('bedroom');
                setIsNewModalOpen(true);
              }}
              className="group relative p-6 sm:p-7 rounded-2xl bg-[#1E1E1E] border border-[#333333] hover:border-blue-500 shadow-xl hover:shadow-2xl transition duration-300 cursor-pointer flex flex-col justify-between min-h-[200px]"
            >
              <div className="space-y-3 z-10">
                <div className="w-10 h-10 rounded-lg bg-blue-600/15 text-blue-400 border border-blue-500/30 flex items-center justify-center">
                  <BedDouble className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-white group-hover:text-blue-400 transition">
                  تصميم غرف نوم وخزائن (Wardrobes & Bedrooms)
                </h3>
                <p className="text-xs text-gray-400 max-w-sm leading-relaxed">
                  دواليب ملابس مفصلية وسحابة، تسريحات، أدراج كومودينو، أرفف ديكور، وتقسيمات داخلية مخصصة.
                </p>
              </div>

              <div className="pt-4 flex items-center justify-between z-10 border-t border-[#2A2A2A]">
                <span className="text-xs font-semibold text-blue-400 flex items-center gap-1 group-hover:-translate-x-1 transition">
                  بدء تصميم غرفة نوم <ArrowLeft className="w-3.5 h-3.5" />
                </span>
                <span className="text-[11px] font-mono text-gray-500">خامات وأخشاب طبيعية</span>
              </div>
            </div>
          </div>
        </section>

        {/* Recent Projects */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <FolderKanban className="w-4 h-4 text-blue-400" />
              آخر المشاريع المصممة (Recent Projects)
            </h2>
            <button onClick={onOpenProjectsList} className="text-xs font-semibold text-blue-400 hover:underline">
              عرض جميع المشاريع ({totalProjects}) &gt;
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
            {recentProjects.map((proj) => (
              <div
                key={proj.projectId}
                onClick={() => onOpenProject(proj)}
                className="group bg-[#1E1E1E] hover:bg-[#252525] border border-[#333333] hover:border-blue-500/60 rounded-xl p-4 cursor-pointer transition shadow-md flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="w-full h-32 bg-[#121212] rounded-lg overflow-hidden flex items-center justify-center border border-[#333333]">
                    {proj.thumbnail ? (
                      <img src={proj.thumbnail} alt={proj.name} className="w-full h-full object-cover" />
                    ) : (
                      <Box className="w-8 h-8 text-gray-700" />
                    )}
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-white group-hover:text-blue-400 transition">
                      {proj.name}
                    </h4>
                    <span className="text-[11px] text-gray-400 font-mono">
                      {proj.units.length} وحدات • {proj.type === 'kitchen' ? 'مطبخ' : 'غرفة نوم'}
                    </span>
                  </div>
                </div>

                <div className="pt-3 border-t border-[#333333] flex items-center justify-between text-xs text-gray-500">
                  <span>{new Date(proj.updatedAt).toLocaleDateString('ar-SA')}</span>
                  <span className="text-blue-400 font-semibold group-hover:-translate-x-1 transition">فتح &gt;</span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Feature Highlights Grid */}
        <section className="grid grid-cols-1 sm:grid-cols-4 gap-4 pt-4 border-t border-[#333333] text-xs">
          <div className="p-4 bg-[#1E1E1E] rounded-xl border border-[#333333] space-y-1">
            <span className="font-bold text-blue-400 block flex items-center gap-1.5">
              <Sliders className="w-4 h-4" />
              تعديل بارامتري بالمليمتر
            </span>
            <p className="text-gray-400 text-[11px]">
              تغيير العرض والارتفاع والعمق مع إعادة تشكيل درف الأبواب والأدراج تلقائياً.
            </p>
          </div>

          <div className="p-4 bg-[#1E1E1E] rounded-xl border border-[#333333] space-y-1">
            <span className="font-bold text-blue-400 block flex items-center gap-1.5">
              <DoorClosed className="w-4 h-4" />
              محاكاة فتح وإغلاق واقعية
            </span>
            <p className="text-gray-400 text-[11px]">
              دوران الأبواب حول محور المفصلة وسحب الأدراج للخارج بسلاسة وسرعات مختلفة.
            </p>
          </div>

          <div className="p-4 bg-[#1E1E1E] rounded-xl border border-[#333333] space-y-1">
            <span className="font-bold text-emerald-400 block flex items-center gap-1.5">
              <DollarSign className="w-4 h-4" />
              حساب التكلفة وقائمة القص
            </span>
            <p className="text-gray-400 text-[11px]">
              تفصيل ألواح MDF، شريط القشاط PVC، والإكسسوارات مع تصدير Excel فوري.
            </p>
          </div>

          <div className="p-4 bg-[#1E1E1E] rounded-xl border border-[#333333] space-y-1">
            <span className="font-bold text-blue-400 block flex items-center gap-1.5">
              <Sparkles className="w-4 h-4" />
              خامات ورخام PBR
            </span>
            <p className="text-gray-400 text-[11px]">
              مكتبة أخشاب، أكريليك، رخام كلكتا، كوارتز، ومقابض عصرية بدقة عالية.
            </p>
          </div>
        </section>
      </div>

      {/* New Project Modal */}
      {isNewModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-md bg-[#1E1E1E] border border-[#333333] rounded-2xl shadow-2xl overflow-hidden p-6 space-y-6">
            <div className="space-y-1">
              <h3 className="text-base font-bold text-white">إنشاء مشروع تصميم جديد</h3>
              <p className="text-xs text-gray-400">حدد نوع المشروع والاسم لبدء الرسم 3D</p>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-5">
              {/* Type Selection */}
              <div className="space-y-2">
                <label className="text-xs font-medium text-gray-300">نوع المشروع:</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setSelectedType('kitchen')}
                    className={`p-3 rounded-xl border text-right font-bold transition flex items-center gap-2.5 text-xs ${
                      selectedType === 'kitchen'
                        ? 'bg-blue-600/15 border-blue-500 text-white shadow-sm'
                        : 'bg-[#121212] border-[#333333] text-gray-400 hover:bg-[#252525]'
                    }`}
                  >
                    <ChefHat className="w-4 h-4 text-blue-400" />
                    مطبخ (Kitchen)
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedType('bedroom')}
                    className={`p-3 rounded-xl border text-right font-bold transition flex items-center gap-2.5 text-xs ${
                      selectedType === 'bedroom'
                        ? 'bg-blue-600/15 border-blue-500 text-white shadow-sm'
                        : 'bg-[#121212] border-[#333333] text-gray-400 hover:bg-[#252525]'
                    }`}
                  >
                    <BedDouble className="w-4 h-4 text-blue-400" />
                    غرفة نوم / خزانة
                  </button>
                </div>
              </div>

              {/* Name Input */}
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-gray-300">اسم المشروع (اختياري):</label>
                <input
                  type="text"
                  placeholder={selectedType === 'kitchen' ? 'مطبخ فيلا مودرن' : 'غرفة نوم ماستر مع دريسنج'}
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  className="w-full bg-[#121212] border border-[#383838] rounded-lg px-3.5 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 transition"
                  autoFocus
                />
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsNewModalOpen(false)}
                  className="px-3.5 py-1.5 rounded-lg bg-[#2A2A2A] hover:bg-[#383838] text-gray-300 text-xs font-semibold transition border border-[#444444]"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-600/25 transition"
                >
                  إنشاء وبدء التصميم
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
