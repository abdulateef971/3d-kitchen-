import { ParametricCabinet, CutListPiece } from '../../types';
import { getMaterialById } from '../materials/materialsCatalog';

/**
 * Cut-List Generator Engine
 * Decomposes every 3D unit into exact MDF/Wood panel dimensions for CNC or panel saw cutting
 */
export function generateProjectCutList(units: ParametricCabinet[]): CutListPiece[] {
  const pieces: CutListPiece[] = [];

  units.forEach((unit, uIdx) => {
    const unitName = `${unit.nameAr} (#${uIdx + 1})`;
    const bodyMat = getMaterialById(unit.bodyMaterialId).nameAr;
    const frontMat = getMaterialById(unit.frontMaterialId).nameAr;
    const t = unit.bodyThickness || 18;

    // 1. Left & Right Side Panels (Gables)
    pieces.push({
      id: `${unit.id}_side_left`,
      unitName,
      partName: 'Left Side Panel',
      partNameAr: 'جنب أيسر للوحدة',
      length: unit.height,
      width: unit.depth,
      thickness: t,
      quantity: 1,
      material: bodyMat,
      edgeBanding: '1L (Front)',
    });

    pieces.push({
      id: `${unit.id}_side_right`,
      unitName,
      partName: 'Right Side Panel',
      partNameAr: 'جنب أيمن للوحدة',
      length: unit.height,
      width: unit.depth,
      thickness: t,
      quantity: 1,
      material: bodyMat,
      edgeBanding: '1L (Front)',
    });

    // 2. Bottom Base Panel
    const internalWidth = unit.width - 2 * t;
    pieces.push({
      id: `${unit.id}_bottom`,
      unitName,
      partName: 'Bottom Base Panel',
      partNameAr: 'قاعدة سفلية (قاع)',
      length: internalWidth,
      width: unit.depth,
      thickness: t,
      quantity: 1,
      material: bodyMat,
      edgeBanding: '1L (Front)',
    });

    // 3. Top Panel or Stretchers
    pieces.push({
      id: `${unit.id}_top`,
      unitName,
      partName: 'Top Stretcher / Top Panel',
      partNameAr: 'سقف / رباطات علوية',
      length: internalWidth,
      width: unit.category === 'kitchen_wall' ? unit.depth : 100, // Top stretchers for base, full top for wall
      thickness: t,
      quantity: unit.category === 'kitchen_wall' ? 1 : 2,
      material: bodyMat,
      edgeBanding: '1L',
    });

    // 4. Back Panel (MDF 8mm or 18mm)
    pieces.push({
      id: `${unit.id}_back`,
      unitName,
      partName: 'Back Panel',
      partNameAr: 'ظهر الخزانة (Backing)',
      length: unit.height - 10,
      width: unit.width - 10,
      thickness: unit.backThickness || 8,
      quantity: 1,
      material: 'MDF 8mm ظهر ملون',
      edgeBanding: 'None',
    });

    // 5. Internal Shelves
    if (unit.shelves && unit.shelves.count > 0) {
      pieces.push({
        id: `${unit.id}_shelves`,
        unitName,
        partName: 'Adjustable Shelf',
        partNameAr: 'رف داخلي متحرك',
        length: internalWidth - 2,
        width: unit.depth - 20,
        thickness: t,
        quantity: unit.shelves.count,
        material: bodyMat,
        edgeBanding: '1L (Front PVC 2mm)',
      });
    }

    // 6. Doors (Fronts)
    if (unit.doors && unit.doors.length > 0) {
      unit.doors.forEach((door, dIdx) => {
        pieces.push({
          id: `${unit.id}_door_${dIdx}`,
          unitName,
          partName: `Front Door ${dIdx + 1}`,
          partNameAr: `درفة باب ${dIdx + 1} (${door.hingeSide === 'left' ? 'يسار' : door.hingeSide === 'right' ? 'يمين' : 'مزدوج'})`,
          length: Math.round(door.height),
          width: Math.round(door.width),
          thickness: door.thickness || 18,
          quantity: 1,
          material: frontMat,
          edgeBanding: '2L + 2W (PVC 2mm دائرية)',
        });
      });
    }

    // 7. Drawers Fronts and Internal Boxes
    if (unit.drawers && unit.drawers.length > 0) {
      unit.drawers.forEach((drawer, drIdx) => {
        // Front
        pieces.push({
          id: `${unit.id}_drawer_front_${drIdx}`,
          unitName,
          partName: `Drawer Front ${drIdx + 1}`,
          partNameAr: `واجهة درج ${drIdx + 1}`,
          length: Math.round(drawer.height),
          width: Math.round(drawer.width),
          thickness: drawer.thickness || 18,
          quantity: 1,
          material: frontMat,
          edgeBanding: '2L + 2W (PVC 2mm)',
        });

        // Drawer Sides
        pieces.push({
          id: `${unit.id}_drawer_box_sides_${drIdx}`,
          unitName,
          partName: `Drawer Box Sides ${drIdx + 1}`,
          partNameAr: `جوانب صندوق الدرج ${drIdx + 1}`,
          length: Math.round(drawer.depth),
          width: Math.max(80, Math.round(drawer.height - 60)),
          thickness: 16,
          quantity: 2,
          material: 'MDF 16mm أبيض',
          edgeBanding: '1L',
        });
      });
    }
  });

  return pieces;
}
