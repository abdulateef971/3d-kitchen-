import { ParametricCabinet, RoomConfig, CustomWall } from '../../types';

export interface BoundingBox3D {
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
  minZ: number;
  maxZ: number;
}

export interface CollisionResult {
  collided: boolean;
  collidedWithUnitId?: string;
  collidedWithUnitName?: string;
  collisionType?: 'cabinet' | 'wall' | 'custom_wall' | 'ceiling' | 'floor';
}

/**
 * Calculates 3D Axis-Aligned Bounding Box (AABB) of a cabinet
 * taking into account rotation and legs height.
 */
export function getCabinetBoundingBox(
  unit: ParametricCabinet,
  overridePosition?: { x?: number; y?: number; z?: number }
): BoundingBox3D {
  const x = overridePosition?.x ?? unit.positionX;
  const y = overridePosition?.y ?? unit.positionY;
  const z = overridePosition?.z ?? unit.positionZ;

  // Determine effective width and depth based on rotation
  const isRotated = Math.abs(unit.rotationY % 180) === 90;
  const effW = isRotated ? unit.depth : unit.width;
  const effD = isRotated ? unit.width : unit.depth;
  const effH = unit.height + (unit.legsHeight || 0);

  return {
    minX: x - effW / 2,
    maxX: x + effW / 2,
    minY: y,
    maxY: y + effH,
    minZ: z - effD / 2,
    maxZ: z + effD / 2,
  };
}

/**
 * Calculates 3D AABB for a custom interior partition wall.
 */
export function getCustomWallBoundingBox(wall: CustomWall): BoundingBox3D {
  const rad = ((wall.rotationY || 0) * Math.PI) / 180;
  const length = wall.length;
  const thickness = wall.thickness || 180;
  const height = wall.height || 2800;

  // Wall extends from (startX, startZ) along direction (cos, sin)
  const cos = Math.cos(rad);
  const sin = Math.sin(rad);

  const p1x = wall.startX;
  const p1z = wall.startZ;
  const p2x = wall.startX + length * cos;
  const p2z = wall.startZ + length * sin;

  const minX = Math.min(p1x, p2x) - thickness / 2;
  const maxX = Math.max(p1x, p2x) + thickness / 2;
  const minZ = Math.min(p1z, p2z) - thickness / 2;
  const maxZ = Math.max(p1z, p2z) + thickness / 2;

  return {
    minX,
    maxX,
    minY: 0,
    maxY: height,
    minZ,
    maxZ,
  };
}

/**
 * Checks if two 3D bounding boxes intersect.
 * Uses a small tolerance margin (1.5mm) so adjacent units touching flush
 * face-to-face do NOT trigger false collisions.
 */
export function doBoxesIntersect(
  a: BoundingBox3D,
  b: BoundingBox3D,
  margin: number = 1.5
): boolean {
  return (
    a.minX < b.maxX - margin &&
    a.maxX > b.minX + margin &&
    a.minY < b.maxY - margin &&
    a.maxY > b.minY + margin &&
    a.minZ < b.maxZ - margin &&
    a.maxZ > b.minZ + margin
  );
}

/**
 * Validates whether placing the unit at candidate (x, y, z)
 * causes collision with other units, perimeter walls, custom partition walls, floor, or ceiling.
 */
export function checkCabinetCollision(
  unit: ParametricCabinet,
  candidatePos: { x: number; y: number; z: number },
  allUnits: ParametricCabinet[],
  room?: RoomConfig
): CollisionResult {
  const box = getCabinetBoundingBox(unit, candidatePos);

  // 1. Check against Room Boundaries (Floors, Ceilings, Perimeter Walls)
  if (room) {
    const halfRoomW = room.width / 2;
    const halfRoomL = room.length / 2;

    // Floor collision
    if (box.minY < -0.5) {
      return { collided: true, collisionType: 'floor', collidedWithUnitName: 'الأرضية' };
    }
    // Ceiling collision
    if (box.maxY > room.height + 0.5) {
      return { collided: true, collisionType: 'ceiling', collidedWithUnitName: 'السقف' };
    }
    // Perimeter Walls
    if (box.minX < -halfRoomW - 0.5) {
      return { collided: true, collisionType: 'wall', collidedWithUnitName: 'الجدار الأيسر' };
    }
    if (box.maxX > halfRoomW + 0.5) {
      return { collided: true, collisionType: 'wall', collidedWithUnitName: 'الجدار الأيمن' };
    }
    if (box.minZ < -halfRoomL - 0.5) {
      return { collided: true, collisionType: 'wall', collidedWithUnitName: 'الجدار الخلفي' };
    }
    if (box.maxZ > halfRoomL + 0.5) {
      return { collided: true, collisionType: 'wall', collidedWithUnitName: 'حدود الغرفة الأمامية' };
    }

    // Custom Partition Walls collision
    if (room.customWalls && room.customWalls.length > 0) {
      for (const cw of room.customWalls) {
        const wallBox = getCustomWallBoundingBox(cw);
        if (doBoxesIntersect(box, wallBox)) {
          return {
            collided: true,
            collisionType: 'custom_wall',
            collidedWithUnitName: cw.nameAr || cw.name || 'الجدار الفاصل',
          };
        }
      }
    }
  }

  // 2. Check against all other cabinets in the scene
  for (const other of allUnits) {
    if (other.id === unit.id) continue;

    const otherBox = getCabinetBoundingBox(other);
    if (doBoxesIntersect(box, otherBox)) {
      return {
        collided: true,
        collidedWithUnitId: other.id,
        collidedWithUnitName: other.nameAr || other.name || 'خزانة مجاورة',
        collisionType: 'cabinet',
      };
    }
  }

  return { collided: false };
}

/**
 * Resolves movement to prevent collisions.
 * If target position collides, attempts sliding along allowed axes or
 * clamps the position to the edge of the obstacle (flush contact).
 */
export function resolveCabinetMovement(
  unit: ParametricCabinet,
  targetPos: { x: number; y: number; z: number },
  allUnits: ParametricCabinet[],
  room?: RoomConfig
): {
  position: { x: number; y: number; z: number };
  collided: boolean;
  collidedWithUnitName?: string;
} {
  const check = checkCabinetCollision(unit, targetPos, allUnits, room);
  if (!check.collided) {
    return { position: targetPos, collided: false };
  }

  // Try X-only movement
  const checkX = checkCabinetCollision(
    unit,
    { x: targetPos.x, y: unit.positionY, z: unit.positionZ },
    allUnits,
    room
  );
  if (!checkX.collided) {
    return {
      position: { x: targetPos.x, y: unit.positionY, z: unit.positionZ },
      collided: true,
      collidedWithUnitName: check.collidedWithUnitName,
    };
  }

  // Try Z-only movement
  const checkZ = checkCabinetCollision(
    unit,
    { x: unit.positionX, y: unit.positionY, z: targetPos.z },
    allUnits,
    room
  );
  if (!checkZ.collided) {
    return {
      position: { x: unit.positionX, y: unit.positionY, z: targetPos.z },
      collided: true,
      collidedWithUnitName: check.collidedWithUnitName,
    };
  }

  // Try Y-only movement
  const checkY = checkCabinetCollision(
    unit,
    { x: unit.positionX, y: targetPos.y, z: unit.positionZ },
    allUnits,
    room
  );
  if (!checkY.collided) {
    return {
      position: { x: unit.positionX, y: targetPos.y, z: unit.positionZ },
      collided: true,
      collidedWithUnitName: check.collidedWithUnitName,
    };
  }

  // Block movement completely
  return {
    position: { x: unit.positionX, y: unit.positionY, z: unit.positionZ },
    collided: true,
    collidedWithUnitName: check.collidedWithUnitName,
  };
}
