import { RoomConfig, ParametricCabinet, CatalogItemTemplate } from '../../types';
import { CATALOG_TEMPLATES } from '../catalog/catalogData';
import { createCabinetFromTemplate } from '../catalog/unitsCatalog';

export type AutoRoomLayoutType = 'empty' | 'l_kitchen' | 'u_kitchen' | 'linear_kitchen' | 'bedroom';

/**
 * Finds a catalog template safely by ID or partial match
 */
function findTemplate(id: string, fallbackId: string): CatalogItemTemplate {
  const found = CATALOG_TEMPLATES.find((t) => t.templateId === id || t.templateId.includes(id));
  if (found) return found;
  const fallback = CATALOG_TEMPLATES.find((t) => t.templateId === fallbackId || t.templateId.includes(fallbackId));
  return fallback || CATALOG_TEMPLATES[0];
}

/**
 * Automatically generates a parametric unit layout tailored to exact room dimensions
 */
export function generateAutoRoomLayout(
  room: RoomConfig,
  layoutType: AutoRoomLayoutType
): ParametricCabinet[] {
  if (layoutType === 'empty') {
    return [];
  }

  const units: ParametricCabinet[] = [];
  const halfW = room.width / 2;
  const halfL = room.length / 2;
  const wallCabinetY = 1450;

  // --------------------------------------------------------------------------
  // 1. L-SHAPED KITCHEN (مطبخ متكامل على شكل L مع زاوية وسلال وحوض وثلاجة)
  // --------------------------------------------------------------------------
  if (layoutType === 'l_kitchen') {
    // A. Corner Base Unit at North-West Corner (-X, -Z)
    const cornerTpl = findTemplate('corner_base_carousel_900', 'corner_base_l_900');
    const cornerUnit = createCabinetFromTemplate(
      cornerTpl,
      -halfW + 450,
      -halfL + 450,
      'mdf_matte_warm_cashmere',
      'mdf_matte_white',
      'marble_calacatta_gold'
    );
    cornerUnit.id = `unit_corner_${Date.now()}_1`;
    units.push(cornerUnit);

    // B. Run along North Back Wall (extending from corner to the Right +X)
    let curX = -halfW + 900;
    const northBackZ = -halfL + 300;

    // 1. Double Stainless Sink Unit
    const sinkTpl = findTemplate('sink_double_stainless_900', 'sink_single_undermount_600');
    const sinkW = sinkTpl.defaultWidth;
    if (curX + sinkW / 2 <= halfW - 100) {
      const sinkUnit = createCabinetFromTemplate(sinkTpl, curX + sinkW / 2, northBackZ);
      sinkUnit.id = `unit_sink_${Date.now()}_2`;
      units.push(sinkUnit);

      // Wall cabinet above sink (Dish rack wall unit)
      const wallDishTpl = findTemplate('wall_dish_drainer_900', 'wall_standard_2door_800');
      const wallDish = createCabinetFromTemplate(wallDishTpl, curX + sinkW / 2, -halfL + 185);
      wallDish.positionY = wallCabinetY;
      wallDish.id = `unit_wall_dish_${Date.now()}_3`;
      units.push(wallDish);

      curX += sinkW;
    }

    // 2. Wire Dish & Plate Pull-Out Basket (سلة مواعين وصحون هيدروليكية)
    const dishTpl = findTemplate('dish_rack_pullout_600', 'dish_rack_pullout_800');
    const dishW = dishTpl.defaultWidth;
    if (curX + dishW / 2 <= halfW - 100) {
      const dishUnit = createCabinetFromTemplate(dishTpl, curX + dishW / 2, northBackZ);
      dishUnit.id = `unit_dish_${Date.now()}_4`;
      units.push(dishUnit);

      // Glass Wall cabinet above
      const wallGlassTpl = findTemplate('wall_glass_fluted_aluminium_800', 'wall_standard_2door_800');
      const wallGlass = createCabinetFromTemplate(wallGlassTpl, curX + dishW / 2, -halfL + 185);
      wallGlass.positionY = wallCabinetY;
      wallGlass.id = `unit_wall_glass_${Date.now()}_5`;
      units.push(wallGlass);

      curX += dishW;
    }

    // 3. Wire Spice & Oil Bottle Pull-Out Basket (سلة زيوت وبهارات)
    const spiceTpl = findTemplate('spice_rack_200_double', 'spice_rack_150_slim');
    const spiceW = spiceTpl.defaultWidth;
    if (curX + spiceW / 2 <= halfW - 100) {
      const spiceUnit = createCabinetFromTemplate(spiceTpl, curX + spiceW / 2, northBackZ);
      spiceUnit.id = `unit_spice_${Date.now()}_6`;
      units.push(spiceUnit);
      curX += spiceW;
    }

    // 4. 3-Drawer Base Cabinet
    const drawerTpl = findTemplate('base_3drawers_softclose_800', 'base_standard_2door_800');
    const drawerW = drawerTpl.defaultWidth;
    if (curX + drawerW / 2 <= halfW - 100) {
      const drawerUnit = createCabinetFromTemplate(drawerTpl, curX + drawerW / 2, northBackZ);
      drawerUnit.id = `unit_drawer_${Date.now()}_7`;
      units.push(drawerUnit);
      curX += drawerW;
    }

    // C. Run along West Left Wall (extending from corner Southward +Z)
    let curZ = -halfL + 900;
    const westX = -halfW + 300;

    // 1. Tall Refrigerator Unit (ثلاجة مطبخ مدمجة)
    const fridgeTpl = findTemplate('tall_fridge_double_builtin_900', 'tall_fridge_french_door_900');
    const fridgeD = 650;
    if (curZ + fridgeD / 2 <= halfL - 100) {
      const fridgeUnit = createCabinetFromTemplate(fridgeTpl, westX + 50, curZ + fridgeD / 2);
      fridgeUnit.rotationY = 90;
      fridgeUnit.id = `unit_fridge_${Date.now()}_8`;
      units.push(fridgeUnit);
      curZ += fridgeD + 50;
    }

    // 2. Tall Pantry Pull-Out Unit
    const pantryTpl = findTemplate('tall_pantry_pullout_600', 'tall_pantry_larder_600');
    const pantryD = 600;
    if (curZ + pantryD / 2 <= halfL - 100) {
      const pantryUnit = createCabinetFromTemplate(pantryTpl, westX + 50, curZ + pantryD / 2);
      pantryUnit.rotationY = 90;
      pantryUnit.id = `unit_pantry_${Date.now()}_9`;
      units.push(pantryUnit);
      curZ += pantryD;
    }
  }

  // --------------------------------------------------------------------------
  // 2. U-SHAPED KITCHEN (مطبخ U متكامل مع زاويتين وسلال وأجهزة)
  // --------------------------------------------------------------------------
  else if (layoutType === 'u_kitchen') {
    // Corner 1: North-West (-X, -Z)
    const cornerTpl1 = findTemplate('corner_base_carousel_900', 'corner_base_l_900');
    const corner1 = createCabinetFromTemplate(cornerTpl1, -halfW + 450, -halfL + 450);
    corner1.id = `unit_u_c1_${Date.now()}`;
    units.push(corner1);

    // Corner 2: North-East (+X, -Z)
    const cornerTpl2 = findTemplate('corner_base_lemans_1000', 'corner_base_l_900');
    const corner2 = createCabinetFromTemplate(cornerTpl2, halfW - 450, -halfL + 450);
    corner2.id = `unit_u_c2_${Date.now()}`;
    units.push(corner2);

    // Center North Wall: Double Sink + Dish Rack
    const centerNorthX = 0;
    const sinkTpl = findTemplate('sink_double_stainless_900', 'sink_single_undermount_600');
    const sinkUnit = createCabinetFromTemplate(sinkTpl, centerNorthX, -halfL + 300);
    sinkUnit.id = `unit_u_sink_${Date.now()}`;
    units.push(sinkUnit);

    // Dish pull-out basket next to sink
    const dishTpl = findTemplate('dish_rack_pullout_600', 'dish_rack_pullout_800');
    const dishUnit = createCabinetFromTemplate(dishTpl, centerNorthX - 750, -halfL + 300);
    dishUnit.id = `unit_u_dish_${Date.now()}`;
    units.push(dishUnit);

    // Spice pull-out basket next to sink
    const spiceTpl = findTemplate('spice_rack_200_double', 'spice_rack_150_slim');
    const spiceUnit = createCabinetFromTemplate(spiceTpl, centerNorthX + 550, -halfL + 300);
    spiceUnit.id = `unit_u_spice_${Date.now()}`;
    units.push(spiceUnit);

    // West Wall: Fridge & Pantry
    const fridgeTpl = findTemplate('tall_fridge_double_builtin_900', 'tall_fridge_french_door_900');
    const fridgeUnit = createCabinetFromTemplate(fridgeTpl, -halfW + 350, 0);
    fridgeUnit.rotationY = 90;
    fridgeUnit.id = `unit_u_fridge_${Date.now()}`;
    units.push(fridgeUnit);

    // East Wall: Drawers & Cooktop
    const drawerTpl = findTemplate('base_3drawers_softclose_800', 'base_standard_2door_800');
    const drawerUnit = createCabinetFromTemplate(drawerTpl, halfW - 350, 0);
    drawerUnit.rotationY = -90;
    drawerUnit.id = `unit_u_drawers_${Date.now()}`;
    units.push(drawerUnit);
  }

  // --------------------------------------------------------------------------
  // 3. LINEAR STRAIGHT KITCHEN (مطبخ خطي جدار مستقيم)
  // --------------------------------------------------------------------------
  else if (layoutType === 'linear_kitchen') {
    let curX = -halfW + 450;
    const backZ = -halfL + 300;

    // Fridge
    const fridgeTpl = findTemplate('tall_fridge_double_builtin_900', 'tall_fridge_french_door_900');
    const fW = fridgeTpl.defaultWidth;
    if (curX + fW / 2 <= halfW - 100) {
      const fridge = createCabinetFromTemplate(fridgeTpl, curX + fW / 2, -halfL + 325);
      fridge.id = `unit_lin_f_${Date.now()}`;
      units.push(fridge);
      curX += fW + 20;
    }

    // Spice Pull-Out Basket
    const spiceTpl = findTemplate('spice_rack_200_double', 'spice_rack_150_slim');
    const spW = spiceTpl.defaultWidth;
    if (curX + spW / 2 <= halfW - 100) {
      const spice = createCabinetFromTemplate(spiceTpl, curX + spW / 2, backZ);
      spice.id = `unit_lin_sp_${Date.now()}`;
      units.push(spice);
      curX += spW + 20;
    }

    // Sink Double Basin
    const sinkTpl = findTemplate('sink_double_stainless_900', 'sink_single_undermount_600');
    const sW = sinkTpl.defaultWidth;
    if (curX + sW / 2 <= halfW - 100) {
      const sink = createCabinetFromTemplate(sinkTpl, curX + sW / 2, backZ);
      sink.id = `unit_lin_s_${Date.now()}`;
      units.push(sink);

      // Wall Dish Rack above sink
      const wallDishTpl = findTemplate('wall_dish_drainer_900', 'wall_standard_2door_800');
      const wallDish = createCabinetFromTemplate(wallDishTpl, curX + sW / 2, -halfL + 185);
      wallDish.positionY = wallCabinetY;
      wallDish.id = `unit_lin_wd_${Date.now()}`;
      units.push(wallDish);

      curX += sW + 20;
    }

    // Dish Pull-Out Basket
    const dishTpl = findTemplate('dish_rack_pullout_600', 'dish_rack_pullout_800');
    const dW = dishTpl.defaultWidth;
    if (curX + dW / 2 <= halfW - 100) {
      const dish = createCabinetFromTemplate(dishTpl, curX + dW / 2, backZ);
      dish.id = `unit_lin_d_${Date.now()}`;
      units.push(dish);
      curX += dW + 20;
    }

    // 3-Drawer Unit
    const drwTpl = findTemplate('base_3drawers_softclose_800', 'base_standard_2door_800');
    const drW = drwTpl.defaultWidth;
    if (curX + drW / 2 <= halfW - 100) {
      const drw = createCabinetFromTemplate(drwTpl, curX + drW / 2, backZ);
      drw.id = `unit_lin_dr_${Date.now()}`;
      units.push(drw);
      curX += drW + 20;
    }
  }

  // --------------------------------------------------------------------------
  // 4. MASTER BEDROOM (غرفة نوم ماستر مع دواليب وسرير وخزائن)
  // --------------------------------------------------------------------------
  else if (layoutType === 'bedroom') {
    // A. Master Wardrobe along West Left Wall or North Back Wall
    const wardrobeTpl = findTemplate('bedroom_wardrobe_sliding_mirror_2400', 'bedroom_wardrobe_hinged_6door_2700');
    const wardrobe = createCabinetFromTemplate(
      wardrobeTpl,
      -halfW + 400,
      -halfL + 1200,
      'wood_walnut_dark',
      'glass_mirror'
    );
    wardrobe.rotationY = 90;
    wardrobe.id = `unit_bed_w_${Date.now()}`;
    units.push(wardrobe);

    // B. King Size Bed Centered against North Back Wall
    const bedTpl = findTemplate('bedroom_bed_king_storage_1800', 'bedroom_wardrobe_sliding_mirror_2400');
    const bed = createCabinetFromTemplate(
      bedTpl,
      halfW * 0.25,
      -halfL + 1100,
      'wood_walnut_dark',
      'fabric_velvet_navy'
    );
    bed.id = `unit_bed_b_${Date.now()}`;
    units.push(bed);

    // C. Nightstands Left & Right of the bed
    const nightstandTpl = findTemplate('bedroom_nightstand_2drawer_500', 'bedroom_bed_king_storage_1800');
    const nsLeft = createCabinetFromTemplate(
      nightstandTpl,
      bed.positionX - bed.width / 2 - 320,
      -halfL + 250
    );
    nsLeft.id = `unit_bed_nsl_${Date.now()}`;
    units.push(nsLeft);

    const nsRight = createCabinetFromTemplate(
      nightstandTpl,
      bed.positionX + bed.width / 2 + 320,
      -halfL + 250
    );
    nsRight.id = `unit_bed_nsr_${Date.now()}`;
    units.push(nsRight);

    // D. Dresser with Drawers opposite the bed
    const dresserTpl = findTemplate('bedroom_dresser_6drawer_1200', 'bedroom_nightstand_2drawer_500');
    const dresser = createCabinetFromTemplate(
      dresserTpl,
      bed.positionX,
      halfL - 300,
      'wood_walnut_dark',
      'wood_walnut_dark'
    );
    dresser.rotationY = 180;
    dresser.id = `unit_bed_dr_${Date.now()}`;
    units.push(dresser);
  }

  return units;
}
