import { ParametricCabinet, CostBreakdown, PricingRules } from '../../types';
import { getMaterialById } from '../materials/materialsCatalog';

export const DEFAULT_PRICING_RULES: PricingRules = {
  carcaseRatePerSqM: 55, // $55 / m² MDF Carcase
  doorRatePerSqM: 75,    // $75 / m² Front finish
  drawerBoxRatePerSqM: 45, // $45 / m² Drawer box
  hingePairRate: 4.5,    // $4.5 per soft-close hinge
  drawerSlidePairRate: 22, // $22 per pair soft-close tandem slides
  handleRate: 6.5,       // $6.5 per handle
  countertopRatePerSqM: 160, // $160 / m² Stone/Marble
  edgeBandingRatePerMeter: 1.8, // $1.8 per meter PVC edging
  laborRatePercentage: 30, // 30% Fabrication & assembly
  profitMarginPercentage: 15, // 15% Profit margin
  currency: '$',
};

/**
 * Parametric Cost Calculator Engine (قاعدة حساب التكاليف المتقدمة)
 * Calculates detailed bill of quantities and estimated costs based on real mm geometry and pricing rules
 */
export function calculateProjectCost(
  units: ParametricCabinet[],
  customRules?: Partial<PricingRules>
): CostBreakdown {
  const rules: PricingRules = { ...DEFAULT_PRICING_RULES, ...customRules };

  let materialCost = 0;
  let hardwareCost = 0;
  let doorsCost = 0;
  let drawersCost = 0;
  let countertopCost = 0;
  let totalBoardAreaSqM = 0;
  let totalEdgeBandingMeters = 0;

  units.forEach((unit) => {
    const w = unit.width / 1000; // m
    const h = unit.height / 1000; // m
    const d = unit.depth / 1000; // m

    const bodyMat = getMaterialById(unit.bodyMaterialId);
    const frontMat = getMaterialById(unit.frontMaterialId);

    const carcaseRate = bodyMat?.costPerSqMeter || rules.carcaseRatePerSqM;
    const doorRate = frontMat?.costPerSqMeter || rules.doorRatePerSqM;

    // Carcase / Box Board Area (2 sides + top + bottom + back + shelves)
    const sidesArea = 2 * (h * d);
    const topBottomArea = 2 * (w * d);
    const backArea = w * h;
    const shelvesArea = (unit.shelves?.count || 0) * (w * d);
    const unitCarcaseArea = sidesArea + topBottomArea + backArea + shelvesArea;

    totalBoardAreaSqM += unitCarcaseArea;
    materialCost += unitCarcaseArea * carcaseRate;

    // Edge banding approximation (perimeter of exposed parts)
    const carcaseEdges = 2 * (2 * h + 2 * d) + 2 * w;
    totalEdgeBandingMeters += carcaseEdges;

    // Fronts / Doors calculation
    if (unit.doors && unit.doors.length > 0) {
      const doorArea = w * h;
      totalBoardAreaSqM += doorArea;
      doorsCost += doorArea * doorRate;

      // Hinges hardware cost
      const hingesPerDoor = unit.height > 1600 ? 4 : unit.height > 1000 ? 3 : 2;
      const totalHinges = unit.doors.length * hingesPerDoor;
      hardwareCost += totalHinges * rules.hingePairRate;

      // Door perimeter edge banding
      totalEdgeBandingMeters += unit.doors.length * (2 * h + 2 * (w / unit.doors.length));
    }

    // Drawers calculation
    if (unit.drawers && unit.drawers.length > 0) {
      const drawerBoxArea = unit.drawers.length * (2 * (0.15 * d) + 2 * (0.15 * w) + (w * d));
      totalBoardAreaSqM += drawerBoxArea;
      drawersCost += drawerBoxArea * rules.drawerBoxRatePerSqM;

      // Soft-close undermount drawer slides + brackets
      hardwareCost += unit.drawers.length * rules.drawerSlidePairRate;
    }

    // Handles hardware cost
    const totalHandles = (unit.doors?.length || 0) + (unit.drawers?.length || 0);
    hardwareCost += totalHandles * rules.handleRate;

    // Countertop calculation
    if (unit.countertop && unit.countertop.enabled) {
      const ctMat = getMaterialById(unit.countertop.materialId);
      const ctLength = (unit.width + (unit.countertop.overhangLeft || 0) + (unit.countertop.overhangRight || 0)) / 1000;
      const ctDepth = (unit.depth + (unit.countertop.overhangFront || 0) + (unit.countertop.overhangBack || 0)) / 1000;
      const ctArea = ctLength * ctDepth;
      const ctRate = ctMat?.costPerSqMeter || rules.countertopRatePerSqM;
      countertopCost += ctArea * ctRate;
    }
  });

  // Edge Banding Material Cost
  const edgeBandingCost = totalEdgeBandingMeters * rules.edgeBandingRatePerMeter;
  materialCost += edgeBandingCost;

  // Estimated sheets of 2440 x 1220 mm (approx 2.97 sq.m) with 15% cutting waste
  const sheetArea = 2.44 * 1.22;
  const sheetsCount = Math.ceil((totalBoardAreaSqM * 1.15) / sheetArea);

  // Subtotal of raw production
  const productionSubtotal = materialCost + doorsCost + drawersCost + hardwareCost + countertopCost;

  // Labor & fabrication
  const laborCost = Math.round(productionSubtotal * (rules.laborRatePercentage / 100));

  // Profit Margin
  const profitCost = Math.round((productionSubtotal + laborCost) * (rules.profitMarginPercentage / 100));

  const totalCost = Math.round(productionSubtotal + laborCost + profitCost);

  return {
    materialCost: Math.round(materialCost),
    hardwareCost: Math.round(hardwareCost),
    doorsCost: Math.round(doorsCost),
    drawersCost: Math.round(drawersCost),
    countertopCost: Math.round(countertopCost),
    laborCost,
    totalCost,
    currency: rules.currency || '$',
    sheetsCount: Math.max(1, sheetsCount),
  };
}
