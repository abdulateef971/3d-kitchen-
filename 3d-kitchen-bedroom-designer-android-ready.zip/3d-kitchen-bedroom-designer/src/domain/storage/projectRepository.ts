import { Project, ProjectType, ParametricCabinet } from '../../types';
import { CATALOG_TEMPLATES, createCabinetFromTemplate } from '../catalog/unitsCatalog';

const STORAGE_KEY = '3d_designer_projects_v1';

// Starter Showcase Projects
export function createDefaultKitchenProject(): Project {
  const baseSink = createCabinetFromTemplate(
    CATALOG_TEMPLATES.find((t) => t.templateId === 'kitchen_base_sink')!,
    -900,
    -1000
  );
  
  const base3Drawers = createCabinetFromTemplate(
    CATALOG_TEMPLATES.find((t) => t.templateId === 'kitchen_base_3_drawers')!,
    0,
    -1000
  );

  const baseOven = createCabinetFromTemplate(
    CATALOG_TEMPLATES.find((t) => t.templateId === 'kitchen_base_oven_cooktop')!,
    750,
    -1000
  );

  const baseSingle = createCabinetFromTemplate(
    CATALOG_TEMPLATES.find((t) => t.templateId === 'kitchen_base_single_door')!,
    1350,
    -1000
  );

  const wallGlass = createCabinetFromTemplate(
    CATALOG_TEMPLATES.find((t) => t.templateId === 'kitchen_wall_glass_door')!,
    -900,
    -1000
  );

  const wallDouble = createCabinetFromTemplate(
    CATALOG_TEMPLATES.find((t) => t.templateId === 'kitchen_wall_double_door')!,
    0,
    -1000
  );

  const wallLift = createCabinetFromTemplate(
    CATALOG_TEMPLATES.find((t) => t.templateId === 'kitchen_wall_lift_up')!,
    900,
    -1000
  );

  return {
    projectId: 'demo_kitchen_modern',
    name: 'مطبخ مودرن كشمير ورخام كلكتا',
    type: 'kitchen',
    room: {
      width: 4500,
      length: 4000,
      height: 2800,
      wallColor: '#f1f5f9',
      floorMaterialId: 'marble_carrara_white',
      floorColor: '#e2e8f0',
      ceilingColor: '#ffffff',
      showCeiling: false,
      showNorthWall: true,
      showSouthWall: false,
      showEastWall: true,
      showWestWall: true,
      openings: [
        {
          id: 'win_1',
          type: 'window',
          wallIndex: 0,
          distanceFromStart: 1800,
          width: 1200,
          height: 1000,
          sillHeight: 1100,
        },
      ],
    },
    units: [baseSink, base3Drawers, baseOven, baseSingle, wallGlass, wallDouble, wallLift],
    lighting: {
      ambientEnabled: true,
      ambientIntensity: 0.7,
      ambientColor: '#ffffff',
      sunIntensity: 1.2,
      sunColor: '#fffbeb',
      ceilingSpotlights: true,
      ceilingSpotlightColor: '#fff7ed',
      ceilingIntensity: 0.8,
      cabinetInteriorLed: true,
      cabinetInteriorLedColor: '#fef3c7',
      cabinetInteriorIntensity: 0.75,
      underCabinetLed: true,
      underCabinetLedColor: '#fef08a',
      underCabinetIntensity: 0.85,
      shadowsEnabled: true,
    },
    camera: {
      preset: 'perspective',
      distance: 3800,
      target: [0, 900, 0],
      position: [0, 2000, 3800],
    },
    unitOfMeasure: 'mm',
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    updatedAt: new Date().toISOString(),
    notes: 'تصميم مطبخ عصري مجهز بأدراج Blum هيدروليك مع إنارة LED تحت الخزائن العلوية.',
  };
}

export function createDefaultBedroomProject(): Project {
  const masterWardrobe = createCabinetFromTemplate(
    CATALOG_TEMPLATES.find((t) => t.templateId === 'bedroom_wardrobe_4_doors')!,
    -500,
    -1200
  );

  const nightstandLeft = createCabinetFromTemplate(
    CATALOG_TEMPLATES.find((t) => t.templateId === 'bedroom_nightstand_2_drawers')!,
    900,
    -1000
  );

  const vanity = createCabinetFromTemplate(
    CATALOG_TEMPLATES.find((t) => t.templateId === 'bedroom_dressing_vanity')!,
    -1200,
    600
  );
  vanity.rotationY = 90;

  return {
    projectId: 'demo_bedroom_master',
    name: 'غرفة نوم ماستر مع دولاب 4 أبواب وتسريحة',
    type: 'bedroom',
    room: {
      width: 5000,
      length: 4500,
      height: 2800,
      wallColor: '#f8fafc',
      floorMaterialId: 'wood_natural_oak',
      floorColor: '#c8a876',
      ceilingColor: '#ffffff',
      showCeiling: false,
      showNorthWall: true,
      showSouthWall: false,
      showEastWall: true,
      showWestWall: true,
      openings: [
        {
          id: 'win_bed',
          type: 'window',
          wallIndex: 0,
          distanceFromStart: 2000,
          width: 1400,
          height: 1200,
          sillHeight: 900,
        },
      ],
    },
    units: [masterWardrobe, nightstandLeft, vanity],
    lighting: {
      ambientEnabled: true,
      ambientIntensity: 0.65,
      ambientColor: '#ffffff',
      sunIntensity: 1.0,
      sunColor: '#fffbeb',
      ceilingSpotlights: true,
      ceilingSpotlightColor: '#fffbeb',
      ceilingIntensity: 0.8,
      cabinetInteriorLed: true,
      cabinetInteriorLedColor: '#fef3c7',
      cabinetInteriorIntensity: 0.75,
      underCabinetLed: true,
      underCabinetLedColor: '#fef3c7',
      underCabinetIntensity: 0.85,
      shadowsEnabled: true,
    },
    camera: {
      preset: 'perspective',
      distance: 4200,
      target: [0, 900, 0],
      position: [1200, 2200, 4200],
    },
    unitOfMeasure: 'mm',
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
    updatedAt: new Date().toISOString(),
    notes: 'غرفة نوم رئيسية بتناسق خشبي دافئ مع تقسيمات ملابس وإضاءة جانبية هادئة.',
  };
}

export function createDefaultWardrobeProject(): Project {
  const slidingWardrobe = createCabinetFromTemplate(
    CATALOG_TEMPLATES.find((t) => t.templateId === 'bedroom_wardrobe_sliding')!,
    0,
    -1000
  );

  const chest = createCabinetFromTemplate(
    CATALOG_TEMPLATES.find((t) => t.templateId === 'bedroom_drawer_chest_5')!,
    1200,
    -1000
  );

  return {
    projectId: 'demo_wardrobe_sliding',
    name: 'غرفة ملابس وخزانة جرار سحاب',
    type: 'wardrobe',
    room: {
      width: 4000,
      length: 3500,
      height: 2700,
      wallColor: '#f1f5f9',
      floorMaterialId: 'wood_walnut',
      floorColor: '#5c4033',
      ceilingColor: '#ffffff',
      showCeiling: false,
      showNorthWall: true,
      showSouthWall: false,
      showEastWall: true,
      showWestWall: true,
      openings: [],
    },
    units: [slidingWardrobe, chest],
    lighting: {
      ambientEnabled: true,
      ambientIntensity: 0.7,
      ambientColor: '#ffffff',
      sunIntensity: 1.1,
      sunColor: '#fffbeb',
      ceilingSpotlights: true,
      ceilingSpotlightColor: '#fff7ed',
      ceilingIntensity: 0.8,
      cabinetInteriorLed: true,
      cabinetInteriorLedColor: '#fde047',
      cabinetInteriorIntensity: 0.75,
      underCabinetLed: true,
      underCabinetLedColor: '#fde047',
      underCabinetIntensity: 0.85,
      shadowsEnabled: true,
    },
    camera: {
      preset: 'perspective',
      distance: 3500,
      target: [0, 900, 0],
      position: [0, 1800, 3500],
    },
    unitOfMeasure: 'mm',
    createdAt: new Date(Date.now() - 86400000 * 8).toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

export class ProjectRepository {
  public static getAllProjects(): Project[] {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (data !== null) {
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed)) {
          return parsed;
        }
      }
    } catch (e) {
      console.error('Error loading projects from storage', e);
    }

    // Seed defaults only when storage has never been initialized
    const defaults = [
      createDefaultKitchenProject(),
      createDefaultBedroomProject(),
      createDefaultWardrobeProject(),
    ];
    this.saveAllProjects(defaults);
    return defaults;
  }

  public static saveAllProjects(projects: Project[]): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(projects));
    } catch (e) {
      console.error('Error saving projects to storage', e);
    }
  }

  public static getProjectById(id: string): Project | null {
    const all = this.getAllProjects();
    return all.find((p) => p.projectId === id) || null;
  }

  public static saveProject(project: Project): void {
    const all = this.getAllProjects();
    const index = all.findIndex((p) => p.projectId === project.projectId);
    const updated = {
      ...project,
      updatedAt: new Date().toISOString(),
    };
    if (index >= 0) {
      all[index] = updated;
    } else {
      all.unshift(updated);
    }
    this.saveAllProjects(all);
  }

  public static deleteProject(projectId: string): void {
    const all = this.getAllProjects().filter((p) => p.projectId !== projectId);
    this.saveAllProjects(all);
  }

  public static duplicateProject(projectId: string): Project | null {
    const original = this.getProjectById(projectId);
    if (!original) return null;

    const copy: Project = {
      ...JSON.parse(JSON.stringify(original)),
      projectId: `proj_${Date.now()}`,
      name: `${original.name} (نسخة)`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const all = this.getAllProjects();
    all.unshift(copy);
    this.saveAllProjects(all);
    return copy;
  }

  public static createNewProject(
    type: ProjectType,
    name?: string,
    roomWidth: number = 4000,
    roomLength: number = 4000,
    roomHeight: number = 2800
  ): Project {
    const newProj: Project = {
      projectId: `proj_${Date.now()}`,
      name: (name && name.trim()) || (type === 'kitchen' ? 'مشروع مطبخ جديد' : type === 'bedroom' ? 'مشروع غرفة نوم جديدة' : 'مشروع خزانة ملابس'),
      type,
      room: {
        width: roomWidth,
        length: roomLength,
        height: roomHeight,
        wallColor: '#f1f5f9',
        floorMaterialId: type === 'kitchen' ? 'marble_carrara_white' : 'wood_natural_oak',
        floorColor: '#e2e8f0',
        ceilingColor: '#ffffff',
        showCeiling: false,
        showNorthWall: true,
        showSouthWall: false,
        showEastWall: true,
        showWestWall: true,
        openings: [],
      },
      units: [],
      lighting: {
        ambientEnabled: true,
        ambientIntensity: 0.7,
        ambientColor: '#ffffff',
        sunIntensity: 1.2,
        sunColor: '#fffbeb',
        ceilingSpotlights: true,
        ceilingSpotlightColor: '#fff7ed',
        ceilingIntensity: 0.8,
        cabinetInteriorLed: true,
        cabinetInteriorLedColor: '#fef3c7',
        cabinetInteriorIntensity: 0.75,
        underCabinetLed: true,
        underCabinetLedColor: '#fef08a',
        underCabinetIntensity: 0.85,
        shadowsEnabled: true,
      },
      camera: {
        preset: 'perspective',
        distance: 3800,
        target: [0, 800, 0],
        position: [0, 1800, 3800],
      },
      unitOfMeasure: 'mm',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    this.saveProject(newProj);
    return newProj;
  }
}

export const projectRepository = ProjectRepository;
