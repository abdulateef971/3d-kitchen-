import { CatalogItemTemplate, ParametricCabinet, DoorConfig, DrawerConfig, HingeSide } from '../../types';
import { CATALOG_TEMPLATES } from './catalogData';

export { CATALOG_TEMPLATES };

/**
 * Factory function to create a fully configured Parametric Cabinet instance from a catalog template
 */
export function createCabinetFromTemplate(
  template: CatalogItemTemplate,
  positionX: number = 0,
  positionZ: number = 0,
  bodyMaterialId: string = 'mdf_matte_warm_cashmere',
  frontMaterialId: string = 'mdf_matte_white',
  countertopMaterialId: string = 'marble_calacatta_gold'
): ParametricCabinet {
  const width = template.defaultWidth;
  const height = template.defaultHeight;
  const depth = template.defaultDepth;
  const isWall = template.category === 'kitchen_wall';
  const isBase = template.category === 'kitchen_base' || template.category === 'kitchen_corner';
  
  // Create doors
  const doors: DoorConfig[] = [];
  if (template.defaultDoors > 0) {
    const doorCount = template.defaultDoors;
    const doorWidth = width / doorCount;
    for (let i = 0; i < doorCount; i++) {
      let hinge: HingeSide = 'left';
      if (template.defaultHingeSide === 'double') {
        hinge = i === 0 ? 'left' : 'right';
      } else if (template.defaultHingeSide === 'top_lift' || template.defaultHingeSide === 'lift_up') {
        hinge = 'top_lift';
      } else if (template.defaultHingeSide === 'sliding') {
        hinge = 'sliding';
      } else if (template.defaultHingeSide === 'none') {
        hinge = 'none';
      } else {
        hinge = template.defaultHingeSide || 'left';
      }
      
      doors.push({
        doorId: `door_${Date.now()}_${i}`,
        width: doorWidth - 3, // 3mm gap
        height: height - (template.defaultDrawers > 0 ? (height / (template.defaultDrawers + 1)) : 6),
        thickness: 18,
        hingeSide: hinge,
        openAngle: 0,
        targetAngle: 0,
        openSpeed: 0.5,
        materialId: frontMaterialId,
        color: '#f8fafc',
        hasGlassPanel: template.templateId.includes('glass'),
        hasFrame: false,
      });
    }
  }

  // Create drawers
  const drawers: DrawerConfig[] = [];
  if (template.defaultDrawers > 0) {
    const drawerCount = template.defaultDrawers;
    const drawerHeight = height / drawerCount - 4;
    for (let i = 0; i < drawerCount; i++) {
      drawers.push({
        drawerId: `drawer_${Date.now()}_${i}`,
        index: i,
        width: width - 36, // carcase inner width
        height: drawerHeight - 3,
        depth: depth - 50,
        thickness: 18,
        openAmount: 0,
        targetAmount: 0,
        openSpeed: 0.4,
        materialId: frontMaterialId,
        color: '#f8fafc',
      });
    }
  }

  // Wall cabinets mount at 1450mm off the ground by default
  const initialY = isWall ? 1450 : 0;

  return {
    id: `unit_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
    templateId: template.templateId,
    name: template.name,
    nameAr: template.nameAr || template.name,
    category: template.category,
    subCategory: template.subCategory,
    width,
    height,
    depth,
    limits: template.limits || {
      minWidth: 200,
      maxWidth: 3000,
      minHeight: 300,
      maxHeight: 2800,
      minDepth: 200,
      maxDepth: 1200,
    },
    bodyThickness: 18,
    backThickness: 8,
    legsHeight: template.defaultLegsHeight,
    hasPlinthKick: isBase,
    positionX,
    positionY: initialY,
    positionZ,
    rotationY: 0,
    doorCount: template.defaultDoors,
    doors,
    drawerCount: template.defaultDrawers,
    drawers,
    shelves: {
      count: template.defaultShelves,
      thickness: 18,
      spacing: 'equal',
    },
    countertop: isBase ? {
      enabled: true,
      thickness: 35,
      overhangFront: 25,
      overhangBack: 0,
      overhangLeft: 0,
      overhangRight: 0,
      materialId: countertopMaterialId,
      color: '#ede8df',
      hasBacksplash: true,
      backsplashHeight: 60,
    } : undefined,
    bodyMaterialId,
    bodyColor: '#d4c7b8',
    frontMaterialId,
    frontColor: '#f8fafc',
    handleConfig: {
      id: 'handle_bar_black',
      name: 'Modern Black Bar',
      nameAr: 'مقبض أسود عصري',
      style: 'bar_modern',
      length: 160,
      thickness: 12,
      color: '#18181b',
      material: 'Aluminum',
      position: 'vertical',
      offsetFromEdge: 40,
    },
    accessoryType: template.accessoryType || 'none',
    isSelected: false,
  };
}
