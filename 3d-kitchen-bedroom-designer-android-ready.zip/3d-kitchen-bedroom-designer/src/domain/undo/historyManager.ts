import { Project } from '../../types';

export class HistoryManager {
  private undoStack: string[] = [];
  private redoStack: string[] = [];
  private maxHistory: number = 30;

  constructor(initialState?: Project) {
    if (initialState) {
      this.undoStack.push(JSON.stringify(initialState));
    }
  }

  public pushState(state: Project): void {
    const serialized = JSON.stringify(state);
    // Avoid pushing duplicate identical states
    if (this.undoStack.length > 0 && this.undoStack[this.undoStack.length - 1] === serialized) {
      return;
    }
    this.undoStack.push(serialized);
    if (this.undoStack.length > this.maxHistory) {
      this.undoStack.shift();
    }
    // Clear redo stack on new action
    this.redoStack = [];
  }

  public canUndo(): boolean {
    return this.undoStack.length > 1;
  }

  public canRedo(): boolean {
    return this.redoStack.length > 0;
  }

  public undo(): Project | null {
    if (!this.canUndo()) return null;
    const currentState = this.undoStack.pop();
    if (currentState) {
      this.redoStack.push(currentState);
    }
    const previousSerialized = this.undoStack[this.undoStack.length - 1];
    return previousSerialized ? JSON.parse(previousSerialized) : null;
  }

  public redo(): Project | null {
    if (!this.canRedo()) return null;
    const nextSerialized = this.redoStack.pop();
    if (!nextSerialized) return null;
    this.undoStack.push(nextSerialized);
    return JSON.parse(nextSerialized);
  }

  public clear(): void {
    this.undoStack = [];
    this.redoStack = [];
  }
}
