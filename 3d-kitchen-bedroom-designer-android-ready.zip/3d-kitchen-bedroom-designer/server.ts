import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let geminiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!geminiClient && process.env.GEMINI_API_KEY) {
    try {
      geminiClient = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });
    } catch (e) {
      console.error('Failed to initialize Gemini client:', e);
    }
  }
  return geminiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', hasGeminiKey: Boolean(process.env.GEMINI_API_KEY) });
  });

  // AI Unit Generator Endpoint
  app.post('/api/ai/generate-unit', async (req, res) => {
    try {
      const {
        prompt = '',
        category = 'kitchen_base',
        applianceType = 'none',
        style = 'modern',
      } = req.body || {};

      const ai = getGeminiClient();

      if (ai) {
        const systemInstruction = `You are an expert CAD kitchen and furniture design architect.
Generate a valid JSON specification for a parametric kitchen unit or electrical appliance based on the user prompt.
All dimensions MUST be in millimeters (mm): width between 150 and 1200 mm, height between 300 and 2400 mm, depth between 250 and 800 mm.`;

        const userMessage = `Create a realistic parametric unit for:
Category: ${category}
Requested Appliance/Type: ${applianceType}
Style: ${style}
User Prompt: ${prompt}`;

        const unitResponseSchema = {
          type: Type.OBJECT,
          properties: {
            templateId: { type: Type.STRING },
            name: { type: Type.STRING },
            nameAr: { type: Type.STRING },
            category: { type: Type.STRING },
            subCategory: { type: Type.STRING },
            defaultWidth: { type: Type.NUMBER, description: 'Width in millimeters (e.g. 600, 900)' },
            defaultHeight: { type: Type.NUMBER, description: 'Height in millimeters (e.g. 720, 2100)' },
            defaultDepth: { type: Type.NUMBER, description: 'Depth in millimeters (e.g. 560, 600)' },
            defaultDoors: { type: Type.NUMBER },
            defaultHingeSide: { type: Type.STRING },
            defaultDrawers: { type: Type.NUMBER },
            defaultShelves: { type: Type.NUMBER },
            defaultLegsHeight: { type: Type.NUMBER },
            accessoryType: { type: Type.STRING },
            descriptionAr: { type: Type.STRING },
            badge: { type: Type.STRING },
          },
          required: [
            'name',
            'nameAr',
            'category',
            'defaultWidth',
            'defaultHeight',
            'defaultDepth',
          ],
        };

        // Candidate models list: ultra-fast and high-availability model first, followed by alternates
        const candidateModels = [
          'gemini-3.1-flash-lite',
          'gemini-flash-latest',
          'gemini-3.8-flash',
        ];

        let lastApiError: any = null;

        for (const modelName of candidateModels) {
          try {
            const response = await ai.models.generateContent({
              model: modelName,
              contents: userMessage,
              config: {
                systemInstruction,
                responseMimeType: 'application/json',
                responseSchema: unitResponseSchema,
              },
            });

            const responseText = response.text || '';
            const cleanedText = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
            const templateData = JSON.parse(cleanedText);

            // Normalize dimensions from cm to mm if necessary
            let defW = templateData.defaultWidth || 600;
            let defH = templateData.defaultHeight || 720;
            let defD = templateData.defaultDepth || 560;
            if (defW > 0 && defW < 150) defW *= 10;
            if (defH > 0 && defH < 300) defH *= 10;
            if (defD > 0 && defD < 150) defD *= 10;

            // Normalize category
            let cat = templateData.category || category;
            if (cat === 'appliance' || cat === 'appliances') cat = 'kitchen_appliance';
            else if (cat === 'base') cat = 'kitchen_base';
            else if (cat === 'wall') cat = 'kitchen_wall';
            else if (cat === 'tall') cat = 'kitchen_tall';

            return res.json({
              success: true,
              source: 'gemini',
              modelUsed: modelName,
              template: {
                ...templateData,
                category: cat,
                defaultWidth: defW,
                defaultHeight: defH,
                defaultDepth: defD,
                templateId: `ai_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
                badge: templateData.badge || 'ذكاء اصطناعي AI',
                limits: {
                  minWidth: Math.max(150, defW - 200),
                  maxWidth: defW + 400,
                  minHeight: Math.max(300, defH - 200),
                  maxHeight: defH + 400,
                  minDepth: Math.max(250, defD - 150),
                  maxDepth: defD + 200,
                },
              },
            });
          } catch (modelErr: any) {
            lastApiError = modelErr;
          }
        }

        if (lastApiError) {
          console.warn('Notice: Transitioned to CAD parametric generator.');
        }
      }

      // Smart parametric generator fallback (when no API key or API limit)
      const sanitizedPrompt = (prompt || '').toLowerCase();
      let genCategory = category;
      let genAppliance = applianceType;
      let defWidth = 600;
      let defHeight = 720;
      let defDepth = 560;
      let doors = 1;
      let drawers = 0;
      let shelves = 1;
      let nameAr = 'وحدة مطبخ ذكية مطورة بالـ AI';
      let nameEn = 'AI Smart Kitchen Cabinet';
      let descAr = 'وحدة مطبخ مصممة بنظام الذكاء الاصطناعي مع تحكم بارامتري كامل في الخامات والمقاسات.';

      if (sanitizedPrompt.includes('ثلاج') || sanitizedPrompt.includes('refrig') || genAppliance.includes('refrig')) {
        genCategory = 'kitchen_tall';
        genAppliance = sanitizedPrompt.includes('فرنس') || sanitizedPrompt.includes('french') ? 'refrigerator_french' : 'refrigerator';
        defWidth = genAppliance === 'refrigerator_french' ? 900 : 700;
        defHeight = 2100;
        defDepth = 650;
        doors = 2;
        shelves = 0;
        nameAr = genAppliance === 'refrigerator_french' ? 'ثلاجة فرنسية ذكية بابين مع شاشة تحكم' : 'ثلاجة عمودية ذكية استانلس ستيل';
        nameEn = 'Smart French Door Refrigerator Tower';
        descAr = 'وحدة ثلاجة ذكية فاخرة مدمجة مع نظام تبريد وتوزيع مياه وإضاءة داخلية متطورة.';
      } else if (sanitizedPrompt.includes('طباخ') || sanitizedPrompt.includes('غاز') || sanitizedPrompt.includes('سيراميك') || sanitizedPrompt.includes('cooktop') || genAppliance.includes('cooktop')) {
        genCategory = 'kitchen_base';
        const isInduction = sanitizedPrompt.includes('كهرب') || sanitizedPrompt.includes('سيراميك') || sanitizedPrompt.includes('induction');
        genAppliance = isInduction ? 'cooktop_induction' : 'cooktop_gas';
        defWidth = 900;
        defHeight = 720;
        defDepth = 600;
        doors = 0;
        drawers = 3;
        nameAr = isInduction ? 'طباخ سيراميك كهربائي حثي 90 سم مع 3 أدراج عميقة' : 'طباخ غاز شعلات نحاسية 90 سم مع خزائن أدراج';
        nameEn = isInduction ? 'Smart 90cm Induction Cooktop with Deep Drawers' : 'Smart 90cm Gas Cooktop Unit';
        descAr = 'وحدة طباخ عريضة مدمجة مع أدراج أواني عميقة ومفصلات هيدروليكية ناعمة.';
      } else if (sanitizedPrompt.includes('فرن') || sanitizedPrompt.includes('مايكرو') || sanitizedPrompt.includes('oven') || sanitizedPrompt.includes('tower') || genAppliance === 'oven' || genAppliance === 'microwave') {
        genCategory = 'kitchen_tall';
        genAppliance = sanitizedPrompt.includes('مايكرو') ? 'microwave' : 'oven';
        defWidth = 600;
        defHeight = 2100;
        defDepth = 580;
        doors = 1;
        drawers = 2;
        shelves = 2;
        nameAr = 'برج أجهزة مدمجة (فرن ومايكروويف بلت إن) 60 سم';
        nameEn = 'Built-in Oven & Microwave Tall Tower 60cm';
        descAr = 'برج أجهزة ألماني فاخر يدمج الفرن الكهربائي والمايكروويف مع خزائن تخزين علوية وسفلية.';
      } else if (sanitizedPrompt.includes('شفاط') || sanitizedPrompt.includes('مرشح') || sanitizedPrompt.includes('hood') || genAppliance.includes('hood')) {
        genCategory = 'kitchen_wall';
        genAppliance = sanitizedPrompt.includes('بوكس') || sanitizedPrompt.includes('box') ? 'hood_box' : 'hood_pyramid';
        defWidth = 900;
        defHeight = 600;
        defDepth = 500;
        doors = 0;
        drawers = 0;
        shelves = 0;
        nameAr = genAppliance === 'hood_box' ? 'شفاط جزيرة زجاجي بوكس T-Shape مودرن 90 سم' : 'شفاط هرمي استانلس ستيل عالي الشفط 90 سم';
        nameEn = 'Modern Kitchen Range Hood 90cm';
        descAr = 'شفاط مطبخ عالي الكفاءة مع فلاتر كربونية ومحرك شفط صامت وإنارة LED.';
      } else if (sanitizedPrompt.includes('حوض') || sanitizedPrompt.includes('مغسل') || sanitizedPrompt.includes('sink') || genAppliance.includes('sink')) {
        genCategory = 'kitchen_base';
        const isDouble = sanitizedPrompt.includes('حوضين') || sanitizedPrompt.includes('مزدوج') || sanitizedPrompt.includes('double');
        genAppliance = isDouble ? 'sink_double' : 'sink';
        defWidth = isDouble ? 900 : 600;
        defHeight = 720;
        defDepth = 580;
        doors = 2;
        drawers = 0;
        shelves = 0;
        nameAr = isDouble ? 'وحدة حوضين رخام وجرانيت أسود 90 سم مع خلاط ذهبي' : 'وحدة مغسلة استانلس ستيل 60 سم مع خلاط عنق وزة';
        nameEn = 'Under-mount Sink Cabinet with Luxury Faucet';
        descAr = 'وحدة مغسلة سفلية مقاومة للرطوبة مع مساحة مخصصة لتصريف وفلترة المياه تحت الحوض.';
      } else if (sanitizedPrompt.includes('قهو') || sanitizedPrompt.includes('coffee') || sanitizedPrompt.includes('بار')) {
        genCategory = 'kitchen_base';
        genAppliance = 'none';
        defWidth = 800;
        defHeight = 720;
        defDepth = 560;
        doors = 1;
        drawers = 2;
        shelves = 1;
        nameAr = 'محطة بار قهوة ذكية مع منظم كبسولات وأدراج';
        nameEn = 'Smart Coffee Bar Station with Organizers';
        descAr = 'محطة قهوة أنيقة مصممة لتجهيز الإسبريسو والمشروبات مع أدراج مخصصة لكبسولات القهوة.';
      } else if (sanitizedPrompt.includes('سلة') || sanitizedPrompt.includes('زيت') || sanitizedPrompt.includes('بهار') || sanitizedPrompt.includes('spice')) {
        genCategory = 'kitchen_base';
        genAppliance = 'none';
        defWidth = 250;
        defHeight = 720;
        defDepth = 560;
        doors = 1;
        drawers = 0;
        shelves = 0;
        nameAr = 'سلة بهارات وزيوت سحب هيدروليكية ستانلس 25 سم';
        nameEn = 'Pull-out Multi-Tier Spice & Oil Basket 25cm';
        descAr = 'سلة سفلية سلكية من الكروم والستانلس لحفظ الزيوت والصلصات مع سحب صامت بالكامل.';
      }

      const generatedTemplate = {
        templateId: `ai_unit_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        name: nameEn,
        nameAr,
        category: genCategory,
        subCategory: genAppliance !== 'none' ? 'appliances' : drawers > 0 ? 'drawers' : 'doors',
        defaultWidth: defWidth,
        defaultHeight: defHeight,
        defaultDepth: defDepth,
        limits: {
          minWidth: Math.max(150, defWidth - 200),
          maxWidth: defWidth + 400,
          minHeight: Math.max(300, defHeight - 200),
          maxHeight: defHeight + 400,
          minDepth: Math.max(250, defDepth - 150),
          maxDepth: defDepth + 200,
        },
        defaultDoors: doors,
        defaultHingeSide: doors > 1 ? 'double' : doors === 1 ? 'left' : 'none',
        defaultDrawers: drawers,
        defaultShelves: shelves,
        defaultLegsHeight: 100,
        accessoryType: genAppliance,
        descriptionAr: descAr,
        badge: 'ذكاء اصطناعي AI',
      };

      return res.json({
        success: true,
        source: 'parametric_engine',
        modelUsed: 'parametric_engine',
        template: generatedTemplate,
      });
    } catch (err: any) {
      console.error('AI generation endpoint error:', err);
      return res.status(500).json({ error: err.message || 'Generation failed' });
    }
  });

  // Vite middleware for development vs static dist for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
