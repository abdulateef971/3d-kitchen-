# 3D Kitchen & Bedroom Designer

A React + TypeScript + Three.js application for parametric kitchen, bedroom, and wardrobe design.

## Run
```bash
npm install
cp .env.example .env
# Set GEMINI_API_KEY in .env only on the server
npm run dev
```

See [ANDROID_AR.md](./ANDROID_AR.md) for Android/Capacitor setup and deployment notes.
